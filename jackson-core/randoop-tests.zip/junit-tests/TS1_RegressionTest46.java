import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest46.test047");
        int int0 = com.fasterxml.jackson.core.StreamWriteFeature.collectDefaults();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }
}

