import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest101.test102");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        com.fasterxml.jackson.core.util.Named[] namedArray1 = new com.fasterxml.jackson.core.util.Named[] { base64Variant0 };
        java.util.ArrayList<com.fasterxml.jackson.core.util.Named> namedList2 = new java.util.ArrayList<com.fasterxml.jackson.core.util.Named>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.core.util.Named>) namedList2, namedArray1);
        com.fasterxml.jackson.core.sym.BinaryNameMatcher binaryNameMatcher5 = com.fasterxml.jackson.core.sym.BinaryNameMatcher.constructFrom((java.util.List<com.fasterxml.jackson.core.util.Named>) namedList2, true);
        int int7 = binaryNameMatcher5.matchByQuad((int) (byte) -1);
        int int9 = binaryNameMatcher5.matchByQuad(32767);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(binaryNameMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }
}

