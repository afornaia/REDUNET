import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest33.test034");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter1 = null;
        com.fasterxml.jackson.core.filter.FilteringParserDelegate filteringParserDelegate4 = new com.fasterxml.jackson.core.filter.FilteringParserDelegate(jsonParser0, tokenFilter1, true, true);
        java.util.Locale locale5 = null;
        com.fasterxml.jackson.core.util.Named[] namedArray6 = new com.fasterxml.jackson.core.util.Named[] {};
        java.util.ArrayList<com.fasterxml.jackson.core.util.Named> namedList7 = new java.util.ArrayList<com.fasterxml.jackson.core.util.Named>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.core.util.Named>) namedList7, namedArray6);
        com.fasterxml.jackson.core.sym.BinaryNameMatcher binaryNameMatcher10 = com.fasterxml.jackson.core.sym.BinaryNameMatcher.constructCaseInsensitive(locale5, (java.util.List<com.fasterxml.jackson.core.util.Named>) namedList7, true);
        // The following exception was thrown during execution in test generation
        try {
            int int11 = filteringParserDelegate4.nextFieldName((com.fasterxml.jackson.core.sym.FieldNameMatcher) binaryNameMatcher10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(binaryNameMatcher10);
    }
}

