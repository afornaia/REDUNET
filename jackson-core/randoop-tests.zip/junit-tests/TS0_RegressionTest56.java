import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest56.test057");
        java.util.concurrent.ConcurrentHashMap.KeySetView<java.lang.String, java.lang.Boolean> strSet0 = java.util.concurrent.ConcurrentHashMap.newKeySet();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strSet0);
    }
}

