import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest99.test100");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        boolean boolean2 = base64Variant0.usesPaddingChar(10);
        com.fasterxml.jackson.core.Base64Variant base64Variant3 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        java.lang.String str4 = base64Variant3.missingPaddingMessage();
        com.fasterxml.jackson.core.Base64Variant base64Variant5 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray12 = new char[] { '#', 'a', '4', '4', '#' };
        int int14 = base64Variant5.encodeBase64Chunk(100, charArray12, (int) (short) 1);
        com.fasterxml.jackson.core.Base64Variant base64Variant19 = new com.fasterxml.jackson.core.Base64Variant(base64Variant5, "com.fasterxml.jackson.core.JsonGenerationException: hi!", true, ' ', 57343);
        int int21 = base64Variant5.decodeBase64Byte((byte) 0);
        com.fasterxml.jackson.core.Base64Variant base64Variant22 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray29 = new char[] { '#', 'a', '4', '4', '#' };
        int int31 = base64Variant22.encodeBase64Chunk(100, charArray29, (int) (short) 1);
        com.fasterxml.jackson.core.Base64Variant base64Variant36 = new com.fasterxml.jackson.core.Base64Variant(base64Variant22, "com.fasterxml.jackson.core.JsonGenerationException: hi!", true, ' ', 57343);
        com.fasterxml.jackson.core.Base64Variant base64Variant37 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        com.fasterxml.jackson.core.Base64Variant base64Variant38 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray45 = new char[] { '#', 'a', '4', '4', '#' };
        int int47 = base64Variant38.encodeBase64Chunk(100, charArray45, (int) (short) 1);
        com.fasterxml.jackson.core.Base64Variant base64Variant52 = new com.fasterxml.jackson.core.Base64Variant(base64Variant38, "com.fasterxml.jackson.core.JsonGenerationException: hi!", true, ' ', 57343);
        com.fasterxml.jackson.core.Base64Variant base64Variant53 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray60 = new char[] { '#', 'a', '4', '4', '#' };
        int int62 = base64Variant53.encodeBase64Chunk(100, charArray60, (int) (short) 1);
        com.fasterxml.jackson.core.Base64Variant base64Variant67 = new com.fasterxml.jackson.core.Base64Variant(base64Variant53, "com.fasterxml.jackson.core.JsonGenerationException: hi!", true, ' ', 57343);
        int int69 = base64Variant53.decodeBase64Byte((byte) 0);
        com.fasterxml.jackson.core.Base64Variant base64Variant70 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        java.lang.String str71 = base64Variant70.missingPaddingMessage();
        com.fasterxml.jackson.core.util.Named[] namedArray72 = new com.fasterxml.jackson.core.util.Named[] { base64Variant0, base64Variant3, base64Variant5, base64Variant22, base64Variant37, base64Variant52, base64Variant53, base64Variant70 };
        java.util.ArrayList<com.fasterxml.jackson.core.util.Named> namedList73 = new java.util.ArrayList<com.fasterxml.jackson.core.util.Named>();
        boolean boolean74 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.core.util.Named>) namedList73, namedArray72);
        java.util.List<java.lang.String> strList76 = com.fasterxml.jackson.core.sym.FieldNameMatcher.stringsFromNames((java.util.List<com.fasterxml.jackson.core.util.Named>) namedList73, false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end" + "'", str4.equals("Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5 + "'", int14 == 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5 + "'", int31 == 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 5 + "'", int47 == 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray60);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end" + "'", str71.equals("Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedArray72);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList76);
    }
}

