import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest79.test080");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        char char1 = base64Variant0.getPaddingChar();
        int int3 = base64Variant0.decodeBase64Char((int) (byte) 1);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder5 = null;
        base64Variant0.decode("", byteArrayBuilder5);
        byte byte7 = base64Variant0.getPaddingByte();
        com.fasterxml.jackson.core.Base64Variant base64Variant10 = new com.fasterxml.jackson.core.Base64Variant(base64Variant0, "hi!", 64);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char1 + "' != '" + '=' + "'", char1 == '=');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + byte7 + "' != '" + (byte) 61 + "'", byte7 == (byte) 61);
    }
}

