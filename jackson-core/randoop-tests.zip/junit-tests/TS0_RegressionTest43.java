import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest43.test044");
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding0 = com.fasterxml.jackson.core.JsonEncoding.UTF16_LE;
        org.junit.Assert.assertTrue("'" + jsonEncoding0 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF16_LE + "'", jsonEncoding0.equals(com.fasterxml.jackson.core.JsonEncoding.UTF16_LE));
    }
}

