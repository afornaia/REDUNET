import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest22.test023");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = jsonFactory0.snapshot();
        java.io.File file2 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding3 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator4 = tokenStreamFactory1.createGenerator(file2, jsonEncoding3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
    }
}

