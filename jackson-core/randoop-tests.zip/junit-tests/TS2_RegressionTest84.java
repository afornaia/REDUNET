import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest84.test085");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate1 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator2 = jsonGeneratorDelegate1.delegate();
        com.fasterxml.jackson.core.JsonParser jsonParser3 = null;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter4 = null;
        com.fasterxml.jackson.core.filter.FilteringParserDelegate filteringParserDelegate7 = new com.fasterxml.jackson.core.filter.FilteringParserDelegate(jsonParser3, tokenFilter4, true, true);
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate1.copyCurrentStructure((com.fasterxml.jackson.core.JsonParser) filteringParserDelegate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonGenerator2);
    }
}

