import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest106.test107");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter1 = null;
        com.fasterxml.jackson.core.filter.FilteringParserDelegate filteringParserDelegate4 = new com.fasterxml.jackson.core.filter.FilteringParserDelegate(jsonParser0, tokenFilter1, false, true);
        java.io.OutputStream outputStream5 = null;
        int int6 = filteringParserDelegate4.releaseBuffered(outputStream5);
        int int7 = filteringParserDelegate4.currentTokenId();
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!" };
        java.util.ArrayList<java.lang.String> strList11 = new java.util.ArrayList<java.lang.String>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList11, strArray10);
        com.fasterxml.jackson.core.sym.BinaryNameMatcher binaryNameMatcher13 = com.fasterxml.jackson.core.sym.BinaryNameMatcher.construct((java.util.List<java.lang.String>) strList11);
        int int14 = binaryNameMatcher13.secondaryQuadCount();
        java.lang.String[] strArray15 = binaryNameMatcher13.nameLookup();
        // The following exception was thrown during execution in test generation
        try {
            int int16 = filteringParserDelegate4.nextFieldName((com.fasterxml.jackson.core.sym.FieldNameMatcher) binaryNameMatcher13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(binaryNameMatcher13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray15);
    }
}

