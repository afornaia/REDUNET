import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest43.test044");
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder1 = new com.fasterxml.jackson.core.util.ByteArrayBuilder();
        byte[] byteArray2 = byteArrayBuilder1.getCurrentSegment();
        int int4 = com.fasterxml.jackson.core.io.NumberOutput.outputInt((int) (byte) 0, byteArray2, 2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }
}

