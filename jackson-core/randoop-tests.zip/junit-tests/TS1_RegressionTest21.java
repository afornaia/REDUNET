import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest21.test022");
        com.fasterxml.jackson.core.json.DupDetector dupDetector0 = null;
        com.fasterxml.jackson.core.json.JsonReadContext jsonReadContext1 = com.fasterxml.jackson.core.json.JsonReadContext.createRootContext(dupDetector0);
        int int2 = jsonReadContext1.getEntryCount();
        boolean boolean3 = jsonReadContext1.hasPathSegment();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonReadContext1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}

