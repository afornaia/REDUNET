import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest37.test038");
        boolean boolean1 = com.fasterxml.jackson.core.io.NumberOutput.notFinite(1.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

