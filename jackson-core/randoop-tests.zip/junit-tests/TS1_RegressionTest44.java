import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest44.test045");
        com.fasterxml.jackson.core.JsonLocation jsonLocation5 = new com.fasterxml.jackson.core.JsonLocation((java.lang.Object) (-1L), (long) ' ', (long) 100, 0, 10);
        int int6 = jsonLocation5.getLineNr();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }
}

