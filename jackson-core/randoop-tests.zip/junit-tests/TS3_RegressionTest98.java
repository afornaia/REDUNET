import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest98 {

    public static boolean debug = false;

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest98.test099");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        int int1 = base64Variant0.getMaxLineLength();
        int int2 = base64Variant0.getMaxLineLength();
        com.fasterxml.jackson.core.util.Named[] namedArray3 = new com.fasterxml.jackson.core.util.Named[] { base64Variant0 };
        java.util.ArrayList<com.fasterxml.jackson.core.util.Named> namedList4 = new java.util.ArrayList<com.fasterxml.jackson.core.util.Named>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.core.util.Named>) namedList4, namedArray3);
        java.util.List<java.lang.String> strList7 = com.fasterxml.jackson.core.sym.FieldNameMatcher.stringsFromNames((java.util.List<com.fasterxml.jackson.core.util.Named>) namedList4, false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList7);
    }
}

