import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest48.test049");
        com.fasterxml.jackson.core.ObjectWriteContext objectWriteContext0 = com.fasterxml.jackson.core.TokenStreamFactory.EMPTY_WRITE_CONTEXT;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder4 = new com.fasterxml.jackson.core.util.ByteArrayBuilder();
        com.fasterxml.jackson.core.SerializableString serializableString5 = null;
        com.fasterxml.jackson.core.util.JsonpCharacterEscapes jsonpCharacterEscapes6 = com.fasterxml.jackson.core.util.JsonpCharacterEscapes.instance();
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter7 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.UTF8JsonGenerator uTF8JsonGenerator10 = new com.fasterxml.jackson.core.json.UTF8JsonGenerator(objectWriteContext0, iOContext1, (int) (byte) -1, 0, (java.io.OutputStream) byteArrayBuilder4, serializableString5, (com.fasterxml.jackson.core.io.CharacterEscapes) jsonpCharacterEscapes6, prettyPrinter7, 0, '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriteContext0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonpCharacterEscapes6);
    }
}

