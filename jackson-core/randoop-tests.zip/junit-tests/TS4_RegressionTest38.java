import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest38.test039");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.json.DupDetector dupDetector1 = com.fasterxml.jackson.core.json.DupDetector.rootDetector(jsonGenerator0);
        com.fasterxml.jackson.core.json.DupDetector dupDetector2 = dupDetector1.child();
        dupDetector2.reset();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dupDetector1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dupDetector2);
    }
}

