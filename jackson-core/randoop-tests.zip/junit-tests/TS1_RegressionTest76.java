import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest76.test077");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        char[] charArray3 = new char[] { ' ' };
        bufferRecycler0.releaseCharBuffer((int) (byte) 1, charArray3);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder5 = new com.fasterxml.jackson.core.util.ByteArrayBuilder(bufferRecycler0);
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler7 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        char[] charArray10 = new char[] { ' ' };
        bufferRecycler7.releaseCharBuffer((int) (byte) 1, charArray10);
        // The following exception was thrown during execution in test generation
        try {
            bufferRecycler0.releaseCharBuffer((int) (byte) -69, charArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: index -69");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray10);
    }
}

