import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest81.test082");
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter0 = com.fasterxml.jackson.core.filter.TokenFilter.INCLUDE_ALL;
        boolean boolean2 = tokenFilter0.includeNumber(10L);
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter4 = tokenFilter0.includeRootValue((int) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenFilter0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenFilter4);
    }
}

