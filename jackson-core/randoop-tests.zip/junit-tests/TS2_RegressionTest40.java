import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest40.test041");
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.Base64Variant base64Variant5 = new com.fasterxml.jackson.core.Base64Variant("Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end", "Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end", false, 'a', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Base64Alphabet length must be exactly 64 (was 131)");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

