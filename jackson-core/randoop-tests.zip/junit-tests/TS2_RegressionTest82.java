import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest82.test083");
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext4 = null;
        java.io.InputStream inputStream5 = null;
        byte[] byteArray8 = new byte[] { (byte) 100, (byte) 100 };
        com.fasterxml.jackson.core.io.MergedStream mergedStream11 = new com.fasterxml.jackson.core.io.MergedStream(iOContext4, inputStream5, byteArray8, 10, 1);
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer12 = com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer.createRoot();
        com.fasterxml.jackson.core.io.IOContext iOContext13 = null;
        java.io.InputStream inputStream14 = null;
        byte[] byteArray17 = new byte[] { (byte) 100, (byte) 100 };
        com.fasterxml.jackson.core.io.MergedStream mergedStream20 = new com.fasterxml.jackson.core.io.MergedStream(iOContext13, inputStream14, byteArray17, 10, 1);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser25 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(objectReadContext0, iOContext1, 5, 10, (java.io.InputStream) mergedStream11, byteQuadsCanonicalizer12, byteArray17, (int) (byte) 1, (int) '#', 57343, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteQuadsCanonicalizer12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray17);
    }
}

