import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest102.test103");
        int int0 = com.fasterxml.jackson.core.util.BufferRecycler.BYTE_READ_IO_BUFFER;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }
}

