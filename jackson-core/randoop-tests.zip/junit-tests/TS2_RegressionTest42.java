import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest42.test043");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        boolean boolean2 = base64Variant0.usesPaddingChar(10);
        char char3 = base64Variant0.getPaddingChar();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char3 + "' != '" + '=' + "'", char3 == '=');
    }
}

