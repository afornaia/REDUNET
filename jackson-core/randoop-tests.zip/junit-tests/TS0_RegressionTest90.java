import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest90.test091");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        char char1 = base64Variant0.getPaddingChar();
        int int3 = base64Variant0.decodeBase64Char((int) (byte) 1);
        boolean boolean4 = base64Variant0.usesPadding();
        java.lang.String str5 = base64Variant0.missingPaddingMessage();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char1 + "' != '" + '=' + "'", char1 == '=');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Unexpected end of base64-encoded String: base64 variant 'PEM' expects padding (one or more '=' characters) at the end" + "'", str5.equals("Unexpected end of base64-encoded String: base64 variant 'PEM' expects padding (one or more '=' characters) at the end"));
    }
}

