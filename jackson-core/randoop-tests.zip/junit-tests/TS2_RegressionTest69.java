import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest69.test070");
        java.lang.Throwable throwable1 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator2 = null;
        com.fasterxml.jackson.core.JsonGenerationException jsonGenerationException3 = new com.fasterxml.jackson.core.JsonGenerationException("hi!", throwable1, jsonGenerator2);
        java.lang.String str4 = jsonGenerationException3.toString();
        java.lang.Object obj5 = jsonGenerationException3.getProcessor();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "com.fasterxml.jackson.core.JsonGenerationException: hi!" + "'", str4.equals("com.fasterxml.jackson.core.JsonGenerationException: hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj5);
    }
}

