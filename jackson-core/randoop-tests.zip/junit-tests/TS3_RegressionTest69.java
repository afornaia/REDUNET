import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest69.test070");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        boolean boolean1 = jsonFactory0.requiresPropertyOrdering();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

