import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest68.test069");
        com.fasterxml.jackson.core.JsonToken jsonToken0 = com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT;
        boolean boolean1 = jsonToken0.isScalarValue();
        org.junit.Assert.assertTrue("'" + jsonToken0 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT + "'", jsonToken0.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NUMBER_FLOAT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

