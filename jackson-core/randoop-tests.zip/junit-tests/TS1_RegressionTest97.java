import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest97.test098");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        java.lang.String str1 = base64Variant0.missingPaddingMessage();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Unexpected end of base64-encoded String: base64 variant 'PEM' expects padding (one or more '=' characters) at the end" + "'", str1.equals("Unexpected end of base64-encoded String: base64 variant 'PEM' expects padding (one or more '=' characters) at the end"));
    }
}

