import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest4.test005");
        char[] charArray6 = new char[] { '#', '#', ' ', ' ', ' ' };
        // The following exception was thrown during execution in test generation
        try {
            int int8 = com.fasterxml.jackson.core.io.NumberOutput.outputInt((int) (byte) -1, charArray6, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray6);
    }
}

