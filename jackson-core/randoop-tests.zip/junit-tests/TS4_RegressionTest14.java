import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest14.test015");
        com.fasterxml.jackson.core.JsonParser.NumberType numberType0 = com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL;
        org.junit.Assert.assertTrue("'" + numberType0 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL + "'", numberType0.equals(com.fasterxml.jackson.core.JsonParser.NumberType.BIG_DECIMAL));
    }
}

