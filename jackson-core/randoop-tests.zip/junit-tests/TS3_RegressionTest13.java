import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest13.test014");
        com.fasterxml.jackson.core.type.WritableTypeId.Inclusion inclusion0 = com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY;
        org.junit.Assert.assertTrue("'" + inclusion0 + "' != '" + com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY + "'", inclusion0.equals(com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY));
    }
}

