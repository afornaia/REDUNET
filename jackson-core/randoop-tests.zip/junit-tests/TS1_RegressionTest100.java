import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest100.test101");
        com.fasterxml.jackson.core.io.NumberInput numberInput0 = new com.fasterxml.jackson.core.io.NumberInput();
    }
}

