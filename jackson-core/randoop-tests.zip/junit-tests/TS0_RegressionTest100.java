import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest100.test101");
        com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer charsToNameCanonicalizer0 = com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer.createRoot();
        int int2 = charsToNameCanonicalizer0.calcHash("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charsToNameCanonicalizer0);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-205390521) + "'", int2 == (-205390521));
    }
}
