import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest33.test034");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        char char1 = base64Variant0.getPaddingChar();
        int int3 = base64Variant0.decodeBase64Char((int) (byte) 1);
        byte[] byteArray5 = com.fasterxml.jackson.core.io.CharTypes.copyHexBytes();
        // The following exception was thrown during execution in test generation
        try {
            int int7 = base64Variant0.encodeBase64Chunk(0, byteArray5, (int) '=');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 61");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char1 + "' != '" + '=' + "'", char1 == '=');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

