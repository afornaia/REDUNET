import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest104.test105");
        com.fasterxml.jackson.core.json.JsonFactoryBuilder jsonFactoryBuilder0 = com.fasterxml.jackson.core.json.JsonFactory.builder();
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory1 = jsonFactoryBuilder0.build();
        com.fasterxml.jackson.core.TokenStreamFactory.Feature feature2 = com.fasterxml.jackson.core.TokenStreamFactory.Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING;
        com.fasterxml.jackson.core.json.JsonFactoryBuilder jsonFactoryBuilder3 = jsonFactoryBuilder0.disable(feature2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonFactoryBuilder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonFactory1);
        org.junit.Assert.assertTrue("'" + feature2 + "' != '" + com.fasterxml.jackson.core.TokenStreamFactory.Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING + "'", feature2.equals(com.fasterxml.jackson.core.TokenStreamFactory.Feature.USE_THREAD_LOCAL_FOR_BUFFER_RECYCLING));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonFactoryBuilder3);
    }
}

