import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest10.test011");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        char[] charArray6 = new char[] { 'a', '#', '#' };
        // The following exception was thrown during execution in test generation
        try {
            int int8 = base64Variant0.encodeBase64Partial(0, 10, charArray6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray6);
    }
}

