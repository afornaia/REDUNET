import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest65.test066");
        java.io.DataOutput dataOutput0 = null;
        com.fasterxml.jackson.core.io.DataOutputAsStream dataOutputAsStream1 = new com.fasterxml.jackson.core.io.DataOutputAsStream(dataOutput0);
    }
}

