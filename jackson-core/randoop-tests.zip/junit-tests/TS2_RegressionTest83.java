import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest83.test084");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter1 = null;
        com.fasterxml.jackson.core.filter.FilteringParserDelegate filteringParserDelegate4 = new com.fasterxml.jackson.core.filter.FilteringParserDelegate(jsonParser0, tokenFilter1, true, true);
        com.fasterxml.jackson.core.JsonToken jsonToken5 = filteringParserDelegate4.currentToken();
        com.fasterxml.jackson.core.JsonLocation jsonLocation7 = null;
        com.fasterxml.jackson.core.JsonParseException jsonParseException8 = new com.fasterxml.jackson.core.JsonParseException((com.fasterxml.jackson.core.JsonParser) filteringParserDelegate4, "Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end", jsonLocation7);
        java.lang.Throwable[] throwableArray9 = jsonParseException8.getSuppressed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonToken5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray9);
    }
}

