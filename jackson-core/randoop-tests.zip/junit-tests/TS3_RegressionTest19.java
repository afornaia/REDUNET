import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest19.test020");
        com.fasterxml.jackson.core.JsonParser jsonParser0 = null;
        com.fasterxml.jackson.core.util.JsonParserDelegate jsonParserDelegate1 = new com.fasterxml.jackson.core.util.JsonParserDelegate(jsonParser0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = jsonParserDelegate1.getTypeId();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

