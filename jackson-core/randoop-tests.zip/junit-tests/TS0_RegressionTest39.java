import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest39.test040");
        com.fasterxml.jackson.core.ObjectReadContext.Base base0 = new com.fasterxml.jackson.core.ObjectReadContext.Base();
        com.fasterxml.jackson.core.JsonParser jsonParser1 = null;
        com.fasterxml.jackson.core.type.ResolvedType resolvedType2 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.ObjectReadContext objectReadContext3 = base0.readValue(jsonParser1, resolvedType2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Operation not supported by `ObjectReadContext` of type com.fasterxml.jackson.core.ObjectReadContext$Base");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
    }
}

