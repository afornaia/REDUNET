import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest79.test080");
        com.fasterxml.jackson.core.json.DupDetector dupDetector0 = null;
        com.fasterxml.jackson.core.util.SimpleTokenWriteContext simpleTokenWriteContext1 = com.fasterxml.jackson.core.util.SimpleTokenWriteContext.createRootContext(dupDetector0);
        com.fasterxml.jackson.core.io.IOContext iOContext2 = null;
        java.io.InputStream inputStream3 = null;
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100 };
        com.fasterxml.jackson.core.io.MergedStream mergedStream9 = new com.fasterxml.jackson.core.io.MergedStream(iOContext2, inputStream3, byteArray6, 10, 1);
        com.fasterxml.jackson.core.util.SimpleTokenWriteContext simpleTokenWriteContext10 = simpleTokenWriteContext1.createChildArrayContext((java.lang.Object) 1);
        com.fasterxml.jackson.core.JsonPointer jsonPointer11 = com.fasterxml.jackson.core.JsonPointer.empty();
        boolean boolean13 = jsonPointer11.matchesElement((int) '#');
        java.lang.String str14 = jsonPointer11.toString();
        boolean boolean16 = jsonPointer11.matchesProperty("com.fasterxml.jackson.core.JsonGenerationException: hi!");
        simpleTokenWriteContext10.setCurrentValue((java.lang.Object) jsonPointer11);
        boolean boolean19 = jsonPointer11.matchesElement(5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(simpleTokenWriteContext1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(simpleTokenWriteContext10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }
}

