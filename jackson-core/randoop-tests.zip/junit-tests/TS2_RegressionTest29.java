import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest29.test030");
        com.fasterxml.jackson.core.JsonParser.NumberType numberType0 = com.fasterxml.jackson.core.JsonParser.NumberType.INT;
        org.junit.Assert.assertTrue("'" + numberType0 + "' != '" + com.fasterxml.jackson.core.JsonParser.NumberType.INT + "'", numberType0.equals(com.fasterxml.jackson.core.JsonParser.NumberType.INT));
    }
}

