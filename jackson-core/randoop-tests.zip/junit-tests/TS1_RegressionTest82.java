import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest82.test083");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler2 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature3 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding5 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext6 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler2, (java.lang.Object) streamWriteFeature3, true, jsonEncoding5);
        byte[] byteArray7 = iOContext6.allocWriteEncodingBuffer();
        int int9 = base64Variant0.encodeBase64Chunk(10, byteArray7, 0);
        boolean boolean11 = base64Variant0.usesPaddingChar(10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler2);
        org.junit.Assert.assertTrue("'" + streamWriteFeature3 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT + "'", streamWriteFeature3.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

