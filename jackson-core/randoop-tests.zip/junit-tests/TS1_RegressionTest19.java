import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest19.test020");
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter0 = com.fasterxml.jackson.core.filter.TokenFilter.INCLUDE_ALL;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter2 = tokenFilter0.includeRootValue((int) (byte) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenFilter0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenFilter2);
    }
}

