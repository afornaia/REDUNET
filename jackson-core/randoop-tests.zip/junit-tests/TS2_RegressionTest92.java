import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest92.test093");
        com.fasterxml.jackson.core.io.SerializedString serializedString1 = new com.fasterxml.jackson.core.io.SerializedString("Unexpected end of base64-encoded String: base64 variant 'MIME-NO-LINEFEEDS' expects padding (one or more '=' characters) at the end");
        com.fasterxml.jackson.core.io.IOContext iOContext2 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext3 = null;
        java.io.InputStream inputStream4 = null;
        byte[] byteArray7 = new byte[] { (byte) 100, (byte) 100 };
        com.fasterxml.jackson.core.io.MergedStream mergedStream10 = new com.fasterxml.jackson.core.io.MergedStream(iOContext3, inputStream4, byteArray7, 10, 1);
        byte[] byteArray13 = new byte[] { (byte) -1 };
        com.fasterxml.jackson.core.io.UTF32Reader uTF32Reader17 = new com.fasterxml.jackson.core.io.UTF32Reader(iOContext2, inputStream4, false, byteArray13, 1, (int) '=', true);
        int int19 = serializedString1.appendUnquotedUTF8(byteArray13, (int) (short) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }
}

