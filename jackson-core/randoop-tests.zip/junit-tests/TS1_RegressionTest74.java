import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest74.test075");
        java.util.Locale locale0 = null;
        com.fasterxml.jackson.core.Base64Variant base64Variant1 = com.fasterxml.jackson.core.Base64Variants.PEM;
        com.fasterxml.jackson.core.util.Named[] namedArray2 = new com.fasterxml.jackson.core.util.Named[] { base64Variant1 };
        java.util.ArrayList<com.fasterxml.jackson.core.util.Named> namedList3 = new java.util.ArrayList<com.fasterxml.jackson.core.util.Named>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.core.util.Named>) namedList3, namedArray2);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.sym.SimpleNameMatcher simpleNameMatcher6 = com.fasterxml.jackson.core.sym.SimpleNameMatcher.constructCaseInsensitive(locale0, (java.util.List<com.fasterxml.jackson.core.util.Named>) namedList3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}

