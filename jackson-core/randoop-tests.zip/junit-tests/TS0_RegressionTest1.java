import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest1.test002");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding3 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext4 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) (byte) 10, true, jsonEncoding3);
    }
}

