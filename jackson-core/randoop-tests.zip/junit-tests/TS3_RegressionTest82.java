import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest82.test083");
        java.lang.Object obj0 = null;
        com.fasterxml.jackson.core.JsonToken jsonToken1 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        java.lang.String str2 = jsonToken1.asString();
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId3 = new com.fasterxml.jackson.core.type.WritableTypeId(obj0, jsonToken1);
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory4 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str5 = jsonFactory4.getFormatName();
        java.io.InputStream inputStream6 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser7 = jsonFactory4.createParser(inputStream6);
        com.fasterxml.jackson.core.JsonToken jsonToken8 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        com.fasterxml.jackson.core.io.JsonEOFException jsonEOFException10 = new com.fasterxml.jackson.core.io.JsonEOFException(jsonParser7, jsonToken8, "true");
        writableTypeId3.id = jsonEOFException10;
        java.lang.String str12 = jsonEOFException10.getOriginalMessage();
        org.junit.Assert.assertTrue("'" + jsonToken1 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken1.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "true" + "'", str2.equals("true"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JSON" + "'", str5.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser7);
        org.junit.Assert.assertTrue("'" + jsonToken8 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken8.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "true" + "'", str12.equals("true"));
    }
}

