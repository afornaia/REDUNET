import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest49.test050");
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature0 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET;
        boolean boolean1 = streamWriteFeature0.enabledByDefault();
        org.junit.Assert.assertTrue("'" + streamWriteFeature0 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET + "'", streamWriteFeature0.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

