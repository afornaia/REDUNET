import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest69.test070");
        com.fasterxml.jackson.core.JsonLocation jsonLocation4 = new com.fasterxml.jackson.core.JsonLocation((java.lang.Object) (byte) -69, (long) (short) 0, (int) '4', 1);
        int int5 = jsonLocation4.getLineNr();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }
}

