import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest17.test018");
        com.fasterxml.jackson.core.json.JsonWriteFeature jsonWriteFeature0 = com.fasterxml.jackson.core.json.JsonWriteFeature.QUOTE_FIELD_NAMES;
        org.junit.Assert.assertTrue("'" + jsonWriteFeature0 + "' != '" + com.fasterxml.jackson.core.json.JsonWriteFeature.QUOTE_FIELD_NAMES + "'", jsonWriteFeature0.equals(com.fasterxml.jackson.core.json.JsonWriteFeature.QUOTE_FIELD_NAMES));
    }
}

