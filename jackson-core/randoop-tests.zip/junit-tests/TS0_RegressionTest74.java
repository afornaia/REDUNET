import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest74.test075");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!", "hi!" };
        java.util.ArrayList<java.lang.String> strList3 = new java.util.ArrayList<java.lang.String>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList3, strArray2);
        com.fasterxml.jackson.core.sym.BinaryNameMatcher binaryNameMatcher5 = com.fasterxml.jackson.core.sym.BinaryNameMatcher.construct((java.util.List<java.lang.String>) strList3);
        int int6 = binaryNameMatcher5.secondaryQuadCount();
        java.lang.String[] strArray7 = binaryNameMatcher5.nameLookup();
        int[] intArray11 = new int[] { (byte) 57, 500, (byte) 100 };
        // The following exception was thrown during execution in test generation
        try {
            int int13 = binaryNameMatcher5.calcHash(intArray11, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(binaryNameMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray11);
    }
}

