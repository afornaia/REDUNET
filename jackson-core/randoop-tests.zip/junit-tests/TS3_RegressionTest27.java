import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest27.test028");
        com.fasterxml.jackson.core.Version version0 = com.fasterxml.jackson.core.json.PackageVersion.VERSION;
        boolean boolean1 = version0.isSnapshot();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

