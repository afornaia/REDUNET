import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest7.test008");
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.async.NonBlockingJsonParser nonBlockingJsonParser5 = new com.fasterxml.jackson.core.json.async.NonBlockingJsonParser(objectReadContext0, iOContext1, 10, (int) (byte) -1, byteQuadsCanonicalizer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

