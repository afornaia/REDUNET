import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest68.test069");
        com.fasterxml.jackson.core.JsonToken jsonToken1 = null;
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId2 = new com.fasterxml.jackson.core.type.WritableTypeId((java.lang.Object) (short) 0, jsonToken1);
        com.fasterxml.jackson.core.JsonToken jsonToken3 = null;
        writableTypeId2.valueShape = jsonToken3;
    }
}

