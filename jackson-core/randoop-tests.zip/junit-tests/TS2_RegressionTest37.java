import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest37.test038");
        com.fasterxml.jackson.core.util.MinimalPrettyPrinter minimalPrettyPrinter1 = new com.fasterxml.jackson.core.util.MinimalPrettyPrinter("");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator2 = null;
        minimalPrettyPrinter1.beforeArrayValues(jsonGenerator2);
        com.fasterxml.jackson.core.util.Separators separators7 = new com.fasterxml.jackson.core.util.Separators('4', 'a', '#');
        com.fasterxml.jackson.core.util.MinimalPrettyPrinter minimalPrettyPrinter8 = minimalPrettyPrinter1.setSeparators(separators7);
        com.fasterxml.jackson.core.util.Separators separators10 = separators7.withObjectEntrySeparator(' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(minimalPrettyPrinter8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(separators10);
    }
}

