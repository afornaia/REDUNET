import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest58.test059");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate1 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0);
        com.fasterxml.jackson.core.JsonToken jsonToken3 = com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT;
        char[] charArray4 = jsonToken3.asCharArray();
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId5 = new com.fasterxml.jackson.core.type.WritableTypeId((java.lang.Object) false, jsonToken3);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.type.WritableTypeId writableTypeId6 = jsonGeneratorDelegate1.writeTypePrefix(writableTypeId5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + jsonToken3 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT + "'", jsonToken3.equals(com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(charArray4);
    }
}

