import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest74.test075");
        com.fasterxml.jackson.core.JsonPointer jsonPointer0 = com.fasterxml.jackson.core.JsonPointer.empty();
        boolean boolean2 = jsonPointer0.matchesElement((int) '#');
        java.lang.String str3 = jsonPointer0.toString();
        com.fasterxml.jackson.core.JsonPointer jsonPointer4 = jsonPointer0.tail();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonPointer4);
    }
}

