import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest24.test025");
        byte[] byteArray7 = new byte[] { (byte) 100, (byte) -17, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        // The following exception was thrown during execution in test generation
        try {
            int int9 = com.fasterxml.jackson.core.io.NumberOutput.outputLong((long) 'a', byteArray7, (int) (byte) -17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -17");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
    }
}

