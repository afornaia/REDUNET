import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest35.test036");
        char[] charArray4 = new char[] { '#', ' ', ' ', 'a' };
        // The following exception was thrown during execution in test generation
        try {
            java.math.BigDecimal bigDecimal7 = com.fasterxml.jackson.core.io.NumberInput.parseBigDecimal(charArray4, (int) 'a', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray4);
    }
}

