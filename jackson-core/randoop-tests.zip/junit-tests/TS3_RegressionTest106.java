import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest106.test107");
        com.fasterxml.jackson.core.filter.JsonPointerBasedFilter jsonPointerBasedFilter1 = new com.fasterxml.jackson.core.filter.JsonPointerBasedFilter("");
        boolean boolean3 = jsonPointerBasedFilter1.includeNumber((float) 3);
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter5 = jsonPointerBasedFilter1.includeProperty("true");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(tokenFilter5);
    }
}

