import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest94 {

    public static boolean debug = false;

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest94.test095");
        com.fasterxml.jackson.core.ObjectWriteContext objectWriteContext0 = null;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler1 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature2 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding4 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext5 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler1, (java.lang.Object) streamWriteFeature2, true, jsonEncoding4);
        byte[] byteArray6 = iOContext5.allocWriteEncodingBuffer();
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding7 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext8 = iOContext5.setEncoding(jsonEncoding7);
        java.io.Writer writer11 = null;
        com.fasterxml.jackson.core.io.SerializedString serializedString12 = com.fasterxml.jackson.core.util.DefaultPrettyPrinter.DEFAULT_ROOT_VALUE_SEPARATOR;
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter13 = null;
        com.fasterxml.jackson.core.util.JsonpCharacterEscapes jsonpCharacterEscapes14 = com.fasterxml.jackson.core.util.JsonpCharacterEscapes.instance();
        com.fasterxml.jackson.core.json.WriterBasedJsonGenerator writerBasedJsonGenerator17 = new com.fasterxml.jackson.core.json.WriterBasedJsonGenerator(objectWriteContext0, iOContext5, (int) (byte) -1, (int) (byte) 1, writer11, (com.fasterxml.jackson.core.SerializableString) serializedString12, prettyPrinter13, (com.fasterxml.jackson.core.io.CharacterEscapes) jsonpCharacterEscapes14, 1, 'a');
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator19 = writerBasedJsonGenerator17.setHighestNonEscapedChar((int) (short) 10);
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator19.writeObjectField("", (java.lang.Object) 0.0f);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: Can not write a field name, expecting a value");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler1);
        org.junit.Assert.assertTrue("'" + streamWriteFeature2 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT + "'", streamWriteFeature2.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iOContext8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializedString12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonpCharacterEscapes14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator19);
    }
}

