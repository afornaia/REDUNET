import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest65.test066");
        byte[] byteArray0 = new byte[] {};
        java.nio.charset.Charset charset1 = null;
        com.fasterxml.jackson.core.util.RequestPayload requestPayload2 = new com.fasterxml.jackson.core.util.RequestPayload(byteArray0, charset1);
        java.lang.Object obj3 = requestPayload2.getRawPayload();
        java.lang.Object obj4 = requestPayload2.getRawPayload();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj4);
    }
}

