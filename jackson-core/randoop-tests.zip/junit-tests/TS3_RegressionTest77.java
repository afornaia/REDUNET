import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest77.test078");
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer0 = com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer.createRoot();
        int[] intArray1 = new int[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = byteQuadsCanonicalizer0.findName(intArray1, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteQuadsCanonicalizer0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray1);
    }
}

