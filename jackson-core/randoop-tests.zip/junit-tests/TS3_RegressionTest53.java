import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest53.test054");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = jsonFactory0.snapshot();
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext2 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser3 = jsonFactory0.createNonBlockingByteArrayParser(objectReadContext2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
    }
}

