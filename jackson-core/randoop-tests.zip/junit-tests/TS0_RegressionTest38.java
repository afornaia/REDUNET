import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest38.test039");
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature0 = com.fasterxml.jackson.core.StreamWriteFeature.STRICT_DUPLICATE_DETECTION;
        org.junit.Assert.assertTrue("'" + streamWriteFeature0 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.STRICT_DUPLICATE_DETECTION + "'", streamWriteFeature0.equals(com.fasterxml.jackson.core.StreamWriteFeature.STRICT_DUPLICATE_DETECTION));
    }
}

