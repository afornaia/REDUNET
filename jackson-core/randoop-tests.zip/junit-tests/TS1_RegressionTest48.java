import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest48.test049");
        com.fasterxml.jackson.core.util.InternCache internCache0 = com.fasterxml.jackson.core.util.InternCache.instance;
        java.lang.Throwable throwable2 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator3 = null;
        com.fasterxml.jackson.core.JsonGenerationException jsonGenerationException4 = new com.fasterxml.jackson.core.JsonGenerationException("hi!", throwable2, jsonGenerator3);
        boolean boolean5 = internCache0.containsKey((java.lang.Object) jsonGenerationException4);
        java.util.function.ToLongFunction<java.util.Map.Entry<java.lang.String, java.lang.String>> strEntryToLongFunction7 = null;
        java.util.function.LongBinaryOperator longBinaryOperator9 = null;
        // The following exception was thrown during execution in test generation
        try {
            long long10 = internCache0.reduceEntriesToLong((long) (byte) 10, strEntryToLongFunction7, (long) (byte) 10, longBinaryOperator9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(internCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

