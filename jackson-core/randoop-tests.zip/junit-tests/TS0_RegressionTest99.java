import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest99.test100");
        com.fasterxml.jackson.core.io.NumberInput numberInput0 = new com.fasterxml.jackson.core.io.NumberInput();
    }
}

