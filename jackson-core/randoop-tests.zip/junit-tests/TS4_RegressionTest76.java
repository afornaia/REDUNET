import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest76.test077");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate2 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0, false);
        double[] doubleArray4 = new double[] { (-1.0f) };
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate2.writeArray(doubleArray4, (int) ' ', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray4);
    }
}

