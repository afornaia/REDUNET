import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest0.test001");
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature0 = com.fasterxml.jackson.core.StreamWriteFeature.IGNORE_UNKNOWN;
        org.junit.Assert.assertTrue("'" + streamWriteFeature0 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.IGNORE_UNKNOWN + "'", streamWriteFeature0.equals(com.fasterxml.jackson.core.StreamWriteFeature.IGNORE_UNKNOWN));
    }
}

