import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest105.test106");
        java.lang.Object obj0 = null;
        com.fasterxml.jackson.core.JsonToken jsonToken1 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        java.lang.String str2 = jsonToken1.asString();
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId3 = new com.fasterxml.jackson.core.type.WritableTypeId(obj0, jsonToken1);
        java.lang.Object obj4 = writableTypeId3.forValue;
        org.junit.Assert.assertTrue("'" + jsonToken1 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken1.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "true" + "'", str2.equals("true"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj4);
    }
}

