import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest89.test090");
        com.fasterxml.jackson.core.json.JsonFactoryBuilder jsonFactoryBuilder0 = com.fasterxml.jackson.core.json.JsonFactory.builder();
        com.fasterxml.jackson.core.json.JsonWriteFeature jsonWriteFeature1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.JsonFactoryBuilder jsonFactoryBuilder3 = jsonFactoryBuilder0.configure(jsonWriteFeature1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonFactoryBuilder0);
    }
}

