import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest67.test068");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.PEM;
        char char1 = base64Variant0.getPaddingChar();
        int int3 = base64Variant0.decodeBase64Char((int) (byte) 1);
        int int4 = base64Variant0.getMaxLineLength();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char1 + "' != '" + '=' + "'", char1 == '=');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 64 + "'", int4 == 64);
    }
}

