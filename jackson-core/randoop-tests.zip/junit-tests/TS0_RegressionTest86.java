import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest86.test087");
        com.fasterxml.jackson.core.TokenStreamContext tokenStreamContext0 = null;
        com.fasterxml.jackson.core.JsonPointer jsonPointer2 = com.fasterxml.jackson.core.JsonPointer.forPath(tokenStreamContext0, true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer2);
    }
}

