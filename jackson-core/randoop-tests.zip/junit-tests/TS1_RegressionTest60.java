import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest60.test061");
        com.fasterxml.jackson.core.util.DefaultPrettyPrinter.NopIndenter nopIndenter0 = com.fasterxml.jackson.core.util.DefaultPrettyPrinter.NopIndenter.instance();
        boolean boolean1 = nopIndenter0.isInline();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nopIndenter0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

