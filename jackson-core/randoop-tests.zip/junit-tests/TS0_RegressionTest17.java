import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest17.test018");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate2 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0, true);
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate4 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate((com.fasterxml.jackson.core.JsonGenerator) jsonGeneratorDelegate2, true);
        byte[] byteArray10 = new byte[] { (byte) 10, (byte) 10, (byte) -1, (byte) 0, (byte) 0 };
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate2.writeUTF8String(byteArray10, 3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
    }
}

