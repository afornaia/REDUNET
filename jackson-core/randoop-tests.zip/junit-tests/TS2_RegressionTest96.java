import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest96.test097");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate1 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0);
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator2 = jsonGeneratorDelegate1.delegate();
        com.fasterxml.jackson.core.json.DupDetector dupDetector3 = com.fasterxml.jackson.core.json.DupDetector.rootDetector((com.fasterxml.jackson.core.JsonGenerator) jsonGeneratorDelegate1);
        com.fasterxml.jackson.core.json.DupDetector dupDetector6 = null;
        com.fasterxml.jackson.core.json.JsonReadContext jsonReadContext7 = com.fasterxml.jackson.core.json.JsonReadContext.createRootContext((int) ' ', (int) (byte) -1, dupDetector6);
        com.fasterxml.jackson.core.json.JsonReadContext jsonReadContext10 = jsonReadContext7.createChildObjectContext((int) (short) 1, (int) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate1.writeEmbeddedObject((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonGenerator2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dupDetector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonReadContext7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonReadContext10);
    }
}

