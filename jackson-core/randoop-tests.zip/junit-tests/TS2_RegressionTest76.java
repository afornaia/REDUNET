import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest76.test077");
        com.fasterxml.jackson.core.Base64Variant base64Variant0 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray7 = new char[] { '#', 'a', '4', '4', '#' };
        int int9 = base64Variant0.encodeBase64Chunk(100, charArray7, (int) (short) 1);
        com.fasterxml.jackson.core.Base64Variant base64Variant14 = new com.fasterxml.jackson.core.Base64Variant(base64Variant0, "com.fasterxml.jackson.core.JsonGenerationException: hi!", true, ' ', 57343);
        int int16 = base64Variant0.decodeBase64Byte((byte) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }
}

