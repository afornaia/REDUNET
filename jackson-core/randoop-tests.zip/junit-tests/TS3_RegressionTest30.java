import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest30.test031");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str1 = jsonFactory0.getFormatName();
        java.io.InputStream inputStream2 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser3 = jsonFactory0.createParser(inputStream2);
        com.fasterxml.jackson.core.JsonToken jsonToken4 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        com.fasterxml.jackson.core.io.JsonEOFException jsonEOFException6 = new com.fasterxml.jackson.core.io.JsonEOFException(jsonParser3, jsonToken4, "true");
        java.lang.String str7 = jsonEOFException6.toString();
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory8 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str9 = jsonFactory8.getFormatName();
        java.io.InputStream inputStream10 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser11 = jsonFactory8.createParser(inputStream10);
        com.fasterxml.jackson.core.JsonToken jsonToken12 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        com.fasterxml.jackson.core.io.JsonEOFException jsonEOFException14 = new com.fasterxml.jackson.core.io.JsonEOFException(jsonParser11, jsonToken12, "true");
        java.lang.String str15 = jsonEOFException14.toString();
        jsonEOFException6.addSuppressed((java.lang.Throwable) jsonEOFException14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSON" + "'", str1.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser3);
        org.junit.Assert.assertTrue("'" + jsonToken4 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken4.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "com.fasterxml.jackson.core.io.JsonEOFException: true\n at [Source: UNKNOWN; line: 1, column: 1]" + "'", str7.equals("com.fasterxml.jackson.core.io.JsonEOFException: true\n at [Source: UNKNOWN; line: 1, column: 1]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JSON" + "'", str9.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser11);
        org.junit.Assert.assertTrue("'" + jsonToken12 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken12.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "com.fasterxml.jackson.core.io.JsonEOFException: true\n at [Source: UNKNOWN; line: 1, column: 1]" + "'", str15.equals("com.fasterxml.jackson.core.io.JsonEOFException: true\n at [Source: UNKNOWN; line: 1, column: 1]"));
    }
}

