import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest44.test045");
        java.lang.Throwable throwable1 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator2 = null;
        com.fasterxml.jackson.core.JsonGenerationException jsonGenerationException3 = new com.fasterxml.jackson.core.JsonGenerationException("hi!", throwable1, jsonGenerator2);
        com.fasterxml.jackson.core.JsonLocation jsonLocation4 = jsonGenerationException3.getLocation();
        java.lang.String str5 = jsonGenerationException3.getOriginalMessage();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonLocation4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }
}

