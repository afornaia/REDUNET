import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest96.test097");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = jsonFactory0.snapshot();
        java.io.InputStream inputStream2 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser3 = jsonFactory0.createParser(inputStream2);
        boolean boolean4 = jsonParser3.canSynthesizeNulls();
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory6 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str7 = jsonFactory6.getFormatName();
        com.fasterxml.jackson.core.JsonLocation jsonLocation11 = new com.fasterxml.jackson.core.JsonLocation((java.lang.Object) str7, 0L, (int) (short) 100, (-1));
        java.lang.String str12 = jsonLocation11.sourceDescription();
        com.fasterxml.jackson.core.JsonParseException jsonParseException13 = new com.fasterxml.jackson.core.JsonParseException(jsonParser3, "true", jsonLocation11);
        long long14 = jsonLocation11.getByteOffset();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "JSON" + "'", str7.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "(String)\"JSON\"" + "'", str12.equals("(String)\"JSON\""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }
}

