import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest107.test108");
        com.fasterxml.jackson.core.ObjectReadContext.Base base0 = new com.fasterxml.jackson.core.ObjectReadContext.Base();
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler1 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext4 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler1, (java.lang.Object) (byte) 100, false);
        boolean boolean5 = iOContext4.isResourceManaged();
        java.io.DataInput dataInput8 = null;
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer9 = com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer.createRoot();
        boolean boolean10 = byteQuadsCanonicalizer9.maybeDirty();
        com.fasterxml.jackson.core.json.UTF8DataInputJsonParser uTF8DataInputJsonParser12 = new com.fasterxml.jackson.core.json.UTF8DataInputJsonParser((com.fasterxml.jackson.core.ObjectReadContext) base0, iOContext4, 55296, 55296, dataInput8, byteQuadsCanonicalizer9, 100);
        com.fasterxml.jackson.core.util.RequestPayload requestPayload13 = null;
        uTF8DataInputJsonParser12.setRequestPayloadOnError(requestPayload13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteQuadsCanonicalizer9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }
}

