import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest59.test060");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str1 = jsonFactory0.getFormatName();
        java.io.InputStream inputStream2 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser3 = jsonFactory0.createParser(inputStream2);
        com.fasterxml.jackson.core.JsonToken jsonToken4 = com.fasterxml.jackson.core.JsonToken.VALUE_TRUE;
        com.fasterxml.jackson.core.io.JsonEOFException jsonEOFException6 = new com.fasterxml.jackson.core.io.JsonEOFException(jsonParser3, jsonToken4, "true");
        com.fasterxml.jackson.core.util.RequestPayload requestPayload7 = jsonEOFException6.getRequestPayload();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSON" + "'", str1.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser3);
        org.junit.Assert.assertTrue("'" + jsonToken4 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_TRUE + "'", jsonToken4.equals(com.fasterxml.jackson.core.JsonToken.VALUE_TRUE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(requestPayload7);
    }
}

