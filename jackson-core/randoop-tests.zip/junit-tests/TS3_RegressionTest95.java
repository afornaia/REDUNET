import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest95.test096");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = jsonFactory0.snapshot();
        java.io.InputStream inputStream2 = null;
        com.fasterxml.jackson.core.JsonParser jsonParser3 = jsonFactory0.createParser(inputStream2);
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 0, (byte) 1, (byte) 100 };
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder10 = com.fasterxml.jackson.core.util.ByteArrayBuilder.fromInitial(byteArray8, (int) '4');
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding11 = com.fasterxml.jackson.core.JsonEncoding.UTF16_LE;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator12 = jsonFactory0.createGenerator((java.io.OutputStream) byteArrayBuilder10, jsonEncoding11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonParser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArrayBuilder10);
        org.junit.Assert.assertTrue("'" + jsonEncoding11 + "' != '" + com.fasterxml.jackson.core.JsonEncoding.UTF16_LE + "'", jsonEncoding11.equals(com.fasterxml.jackson.core.JsonEncoding.UTF16_LE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator12);
    }
}

