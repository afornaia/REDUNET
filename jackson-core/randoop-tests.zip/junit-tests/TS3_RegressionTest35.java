import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest35.test036");
        com.fasterxml.jackson.core.TokenStreamFactory.Feature feature0 = com.fasterxml.jackson.core.TokenStreamFactory.Feature.INTERN_FIELD_NAMES;
        org.junit.Assert.assertTrue("'" + feature0 + "' != '" + com.fasterxml.jackson.core.TokenStreamFactory.Feature.INTERN_FIELD_NAMES + "'", feature0.equals(com.fasterxml.jackson.core.TokenStreamFactory.Feature.INTERN_FIELD_NAMES));
    }
}

