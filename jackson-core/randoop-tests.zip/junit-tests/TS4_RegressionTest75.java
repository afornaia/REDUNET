import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest75.test076");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate2 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0, false);
        com.fasterxml.jackson.core.JsonParser jsonParser3 = null;
        com.fasterxml.jackson.core.filter.TokenFilter tokenFilter4 = null;
        com.fasterxml.jackson.core.filter.FilteringParserDelegate filteringParserDelegate7 = new com.fasterxml.jackson.core.filter.FilteringParserDelegate(jsonParser3, tokenFilter4, true, true);
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate2.copyCurrentEvent((com.fasterxml.jackson.core.JsonParser) filteringParserDelegate7);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: No current event to copy");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        // Expected exception.
        }
    }
}

