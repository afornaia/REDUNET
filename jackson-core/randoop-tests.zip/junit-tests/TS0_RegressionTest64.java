import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest64 {

    public static boolean debug = false;

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest64.test065");
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext0 = null;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler1 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext4 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler1, (java.lang.Object) (byte) 100, false);
        boolean boolean5 = iOContext4.isResourceManaged();
        java.io.Reader reader8 = null;
        com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer charsToNameCanonicalizer9 = com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer.createRoot();
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.ReaderBasedJsonParser readerBasedJsonParser10 = new com.fasterxml.jackson.core.json.ReaderBasedJsonParser(objectReadContext0, iOContext4, 500, (-205392273), reader8, charsToNameCanonicalizer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charsToNameCanonicalizer9);
    }
}

