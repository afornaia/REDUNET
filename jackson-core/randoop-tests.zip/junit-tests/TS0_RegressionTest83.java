import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest83.test084");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate2 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0, true);
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate4 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate((com.fasterxml.jackson.core.JsonGenerator) jsonGeneratorDelegate2, true);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.FormatSchema formatSchema5 = jsonGeneratorDelegate2.getSchema();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

