import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest101.test102");
        java.lang.String[] strArray2 = new java.lang.String[] { "hi!", "hi!" };
        java.util.ArrayList<java.lang.String> strList3 = new java.util.ArrayList<java.lang.String>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList3, strArray2);
        com.fasterxml.jackson.core.sym.BinaryNameMatcher binaryNameMatcher5 = com.fasterxml.jackson.core.sym.BinaryNameMatcher.construct((java.util.List<java.lang.String>) strList3);
        java.lang.String str6 = binaryNameMatcher5.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(binaryNameMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[com.fasterxml.jackson.core.sym.BinaryNameMatcher: size=2, hashSize=8, 1/1/0/0 pri/sec/ter/spill (=2), total:2]" + "'", str6.equals("[com.fasterxml.jackson.core.sym.BinaryNameMatcher: size=2, hashSize=8, 1/1/0/0 pri/sec/ter/spill (=2), total:2]"));
    }
}

