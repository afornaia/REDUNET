import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest61.test062");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator0 = null;
        com.fasterxml.jackson.core.util.JsonGeneratorDelegate jsonGeneratorDelegate2 = new com.fasterxml.jackson.core.util.JsonGeneratorDelegate(jsonGenerator0, false);
        com.fasterxml.jackson.core.json.DupDetector dupDetector3 = com.fasterxml.jackson.core.json.DupDetector.rootDetector((com.fasterxml.jackson.core.JsonGenerator) jsonGeneratorDelegate2);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder5 = new com.fasterxml.jackson.core.util.ByteArrayBuilder();
        byte[] byteArray6 = byteArrayBuilder5.getCurrentSegment();
        // The following exception was thrown during execution in test generation
        try {
            jsonGeneratorDelegate2.writeBinaryField("hi!", byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dupDetector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
    }
}

