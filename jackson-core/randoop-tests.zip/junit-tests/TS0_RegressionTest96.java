import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest96.test097");
        com.fasterxml.jackson.core.JsonToken jsonToken0 = com.fasterxml.jackson.core.JsonToken.END_ARRAY;
        boolean boolean1 = jsonToken0.isStructStart();
        org.junit.Assert.assertTrue("'" + jsonToken0 + "' != '" + com.fasterxml.jackson.core.JsonToken.END_ARRAY + "'", jsonToken0.equals(com.fasterxml.jackson.core.JsonToken.END_ARRAY));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

