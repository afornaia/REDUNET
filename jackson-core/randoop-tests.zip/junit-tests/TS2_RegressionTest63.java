import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest63.test064");
        com.fasterxml.jackson.core.type.WritableTypeId.Inclusion inclusion0 = com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY;
        org.junit.Assert.assertTrue("'" + inclusion0 + "' != '" + com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY + "'", inclusion0.equals(com.fasterxml.jackson.core.type.WritableTypeId.Inclusion.PAYLOAD_PROPERTY));
    }
}

