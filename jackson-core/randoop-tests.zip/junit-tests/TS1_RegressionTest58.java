import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest58.test059");
        com.fasterxml.jackson.core.util.InternCache internCache0 = com.fasterxml.jackson.core.util.InternCache.instance;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler1 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        char[] charArray4 = new char[] { ' ' };
        bufferRecycler1.releaseCharBuffer((int) (byte) 1, charArray4);
        com.fasterxml.jackson.core.util.ByteArrayBuilder byteArrayBuilder6 = new com.fasterxml.jackson.core.util.ByteArrayBuilder(bufferRecycler1);
        boolean boolean7 = internCache0.containsValue((java.lang.Object) byteArrayBuilder6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(internCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

