import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest54.test055");
        com.fasterxml.jackson.core.json.DupDetector dupDetector2 = null;
        com.fasterxml.jackson.core.util.SimpleTokenReadContext simpleTokenReadContext3 = com.fasterxml.jackson.core.util.SimpleTokenReadContext.createRootContext((int) (byte) 10, 3, dupDetector2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(simpleTokenReadContext3);
    }
}

