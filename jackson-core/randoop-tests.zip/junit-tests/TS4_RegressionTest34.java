import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest34.test035");
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature0 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET;
        org.junit.Assert.assertTrue("'" + streamWriteFeature0 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET + "'", streamWriteFeature0.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_TARGET));
    }
}

