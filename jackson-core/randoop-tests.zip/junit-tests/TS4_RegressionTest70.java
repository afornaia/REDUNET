import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest70.test071");
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator1 = null;
        com.fasterxml.jackson.core.JsonGenerationException jsonGenerationException2 = new com.fasterxml.jackson.core.JsonGenerationException("hi!", jsonGenerator1);
        java.lang.String str3 = jsonGenerationException2.toString();
        jsonGenerationException2.clearLocation();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "com.fasterxml.jackson.core.JsonGenerationException: hi!" + "'", str3.equals("com.fasterxml.jackson.core.JsonGenerationException: hi!"));
    }
}

