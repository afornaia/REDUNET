import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest66.test067");
        com.fasterxml.jackson.core.JsonToken jsonToken1 = com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT;
        char[] charArray2 = jsonToken1.asCharArray();
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId3 = new com.fasterxml.jackson.core.type.WritableTypeId((java.lang.Object) false, jsonToken1);
        com.fasterxml.jackson.core.JsonToken jsonToken4 = writableTypeId3.valueShape;
        org.junit.Assert.assertTrue("'" + jsonToken1 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT + "'", jsonToken1.equals(com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(charArray2);
        org.junit.Assert.assertTrue("'" + jsonToken4 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT + "'", jsonToken4.equals(com.fasterxml.jackson.core.JsonToken.VALUE_EMBEDDED_OBJECT));
    }
}

