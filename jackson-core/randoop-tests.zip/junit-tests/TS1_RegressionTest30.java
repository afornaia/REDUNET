import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest30.test031");
        com.fasterxml.jackson.core.util.JsonpCharacterEscapes jsonpCharacterEscapes0 = com.fasterxml.jackson.core.util.JsonpCharacterEscapes.instance();
        com.fasterxml.jackson.core.SerializableString serializableString2 = jsonpCharacterEscapes0.getEscapeSequence((int) ' ');
        com.fasterxml.jackson.core.SerializableString serializableString4 = jsonpCharacterEscapes0.getEscapeSequence((int) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonpCharacterEscapes0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableString2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableString4);
    }
}

