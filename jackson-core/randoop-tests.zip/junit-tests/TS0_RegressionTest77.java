import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest77.test078");
        com.fasterxml.jackson.core.util.InternCache internCache0 = com.fasterxml.jackson.core.util.InternCache.instance;
        java.util.Set<java.util.Map.Entry<java.lang.String, java.lang.String>> strEntrySet1 = internCache0.entrySet();
        java.util.function.ToDoubleFunction<java.util.Map.Entry<java.lang.String, java.lang.String>> strEntryToDoubleFunction3 = null;
        java.util.function.DoubleBinaryOperator doubleBinaryOperator5 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double6 = internCache0.reduceEntriesToDouble((long) 55296, strEntryToDoubleFunction3, (double) 55296, doubleBinaryOperator5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(internCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strEntrySet1);
    }
}

