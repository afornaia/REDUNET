import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest80.test081");
        com.fasterxml.jackson.core.util.SimpleTokenReadContext simpleTokenReadContext1 = null;
        com.fasterxml.jackson.core.json.DupDetector dupDetector2 = null;
        com.fasterxml.jackson.core.util.SimpleTokenReadContext simpleTokenReadContext5 = new com.fasterxml.jackson.core.util.SimpleTokenReadContext((int) (short) 100, simpleTokenReadContext1, dupDetector2, (int) (byte) 1, (int) (short) 10);
        java.lang.Object obj6 = simpleTokenReadContext5.getCurrentValue();
        com.fasterxml.jackson.core.util.SimpleTokenReadContext simpleTokenReadContext9 = simpleTokenReadContext5.createChildArrayContext((int) (short) -1, (int) ' ');
        com.fasterxml.jackson.core.JsonPointer jsonPointer11 = simpleTokenReadContext9.pathAsPointer(false);
        com.fasterxml.jackson.core.JsonPointer jsonPointer12 = jsonPointer11.last();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(simpleTokenReadContext9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jsonPointer12);
    }
}

