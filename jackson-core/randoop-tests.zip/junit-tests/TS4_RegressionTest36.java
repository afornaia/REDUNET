import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest36.test037");
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        java.io.InputStream inputStream4 = null;
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer5 = null;
        byte[] byteArray11 = new byte[] { (byte) 0, (byte) 10, (byte) 10, (byte) 10, (byte) -1 };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.UTF8StreamJsonParser uTF8StreamJsonParser16 = new com.fasterxml.jackson.core.json.UTF8StreamJsonParser(objectReadContext0, iOContext1, (int) (short) 1, 0, inputStream4, byteQuadsCanonicalizer5, byteArray11, (int) (short) 0, 2, (int) (short) 100, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

