import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest89.test090");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature1 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding3 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext4 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler0, (java.lang.Object) streamWriteFeature1, true, jsonEncoding3);
        byte[] byteArray5 = iOContext4.allocWriteEncodingBuffer();
        com.fasterxml.jackson.core.JsonToken jsonToken6 = com.fasterxml.jackson.core.JsonToken.VALUE_NULL;
        com.fasterxml.jackson.core.type.WritableTypeId writableTypeId7 = new com.fasterxml.jackson.core.type.WritableTypeId((java.lang.Object) iOContext4, jsonToken6);
        java.lang.Class<?> wildcardClass8 = writableTypeId7.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler0);
        org.junit.Assert.assertTrue("'" + streamWriteFeature1 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT + "'", streamWriteFeature1.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        org.junit.Assert.assertTrue("'" + jsonToken6 + "' != '" + com.fasterxml.jackson.core.JsonToken.VALUE_NULL + "'", jsonToken6.equals(com.fasterxml.jackson.core.JsonToken.VALUE_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }
}

