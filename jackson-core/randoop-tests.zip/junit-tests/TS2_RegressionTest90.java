import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest90.test091");
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler0 = new com.fasterxml.jackson.core.util.BufferRecycler();
        // The following exception was thrown during execution in test generation
        try {
            char[] charArray2 = bufferRecycler0.allocCharBuffer(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
    }
}

