import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest26.test027");
        boolean boolean1 = com.fasterxml.jackson.core.io.NumberOutput.notFinite((float) '4');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

