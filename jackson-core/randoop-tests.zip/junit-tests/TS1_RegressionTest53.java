import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest53.test054");
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext0 = null;
        com.fasterxml.jackson.core.util.BufferRecycler bufferRecycler1 = com.fasterxml.jackson.core.util.BufferRecyclers.getBufferRecycler();
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature2 = com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding4 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext5 = new com.fasterxml.jackson.core.io.IOContext(bufferRecycler1, (java.lang.Object) streamWriteFeature2, true, jsonEncoding4);
        java.io.Reader reader8 = null;
        com.fasterxml.jackson.core.sym.CharsToNameCanonicalizer charsToNameCanonicalizer9 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.json.ReaderBasedJsonParser readerBasedJsonParser10 = new com.fasterxml.jackson.core.json.ReaderBasedJsonParser(objectReadContext0, iOContext5, 0, (int) (byte) 100, reader8, charsToNameCanonicalizer9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bufferRecycler1);
        org.junit.Assert.assertTrue("'" + streamWriteFeature2 + "' != '" + com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT + "'", streamWriteFeature2.equals(com.fasterxml.jackson.core.StreamWriteFeature.AUTO_CLOSE_CONTENT));
    }
}

