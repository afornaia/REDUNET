import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest87.test088");
        com.fasterxml.jackson.core.io.IOContext iOContext0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        java.io.InputStream inputStream2 = null;
        byte[] byteArray5 = new byte[] { (byte) 100, (byte) 100 };
        com.fasterxml.jackson.core.io.MergedStream mergedStream8 = new com.fasterxml.jackson.core.io.MergedStream(iOContext1, inputStream2, byteArray5, 10, 1);
        byte[] byteArray11 = new byte[] { (byte) -1 };
        com.fasterxml.jackson.core.io.UTF32Reader uTF32Reader15 = new com.fasterxml.jackson.core.io.UTF32Reader(iOContext0, inputStream2, false, byteArray11, 1, (int) '=', true);
        com.fasterxml.jackson.core.Base64Variant base64Variant16 = com.fasterxml.jackson.core.Base64Variants.MIME_NO_LINEFEEDS;
        char[] charArray23 = new char[] { '#', 'a', '4', '4', '#' };
        int int25 = base64Variant16.encodeBase64Chunk(100, charArray23, (int) (short) 1);
        // The following exception was thrown during execution in test generation
        try {
            int int28 = uTF32Reader15.read(charArray23, (int) '=', 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: read(buf,61,4), cbuf[5]");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(base64Variant16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5 + "'", int25 == 5);
    }
}

