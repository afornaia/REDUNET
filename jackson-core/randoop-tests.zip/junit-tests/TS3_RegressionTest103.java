import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest103.test104");
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer0 = com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer.createRoot();
        byteQuadsCanonicalizer0.release();
        int int2 = byteQuadsCanonicalizer0.hashSeed();
        com.fasterxml.jackson.core.sym.ByteQuadsCanonicalizer byteQuadsCanonicalizer4 = byteQuadsCanonicalizer0.makeChild((int) 'a');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteQuadsCanonicalizer0);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-205256443) + "'", int2 == (-205256443));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteQuadsCanonicalizer4);
    }
}
