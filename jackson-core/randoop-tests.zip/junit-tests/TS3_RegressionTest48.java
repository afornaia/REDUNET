import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest48.test049");
        com.fasterxml.jackson.core.json.JsonFactory jsonFactory0 = new com.fasterxml.jackson.core.json.JsonFactory();
        java.lang.String str1 = jsonFactory0.getFormatName();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator2 = jsonFactory0.getInputDecorator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JSON" + "'", str1.equals("JSON"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(inputDecorator2);
    }
}

