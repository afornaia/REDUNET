import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest33.test034");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
    }
}

