import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest36.test037");
        org.apache.commons.math4.Field<org.apache.commons.math4.util.BigReal> bigRealField0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.ArrayFieldVector<org.apache.commons.math4.util.BigReal> bigRealArrayFieldVector2 = new org.apache.commons.math4.linear.ArrayFieldVector<org.apache.commons.math4.util.BigReal>(bigRealField0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

