import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest152 {

    public static boolean debug = false;

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest152.test153");
        org.apache.commons.math4.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math4.linear.ArrayRealVector((int) ' ');
        org.apache.commons.math4.linear.RealVector realVector3 = arrayRealVector1.mapMultiply((double) (byte) 0);
        double double5 = arrayRealVector1.getEntry((int) (short) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realVector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }
}

