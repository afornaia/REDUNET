import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest142 {

    public static boolean debug = false;

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest142.test143");
        double[] doubleArray1 = new double[] { 'a' };
        int int2 = org.apache.commons.math4.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math4.linear.ArrayRealVector arrayRealVector3 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math4.linear.ArrayRealVector(doubleArray1, arrayRealVector3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525407 + "'", int2 == 1079525407);
    }
}

