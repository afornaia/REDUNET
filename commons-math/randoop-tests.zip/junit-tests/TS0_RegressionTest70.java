import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest70.test071");
        double double1 = org.apache.commons.math4.util.FastMath.asinh((double) 'a');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }
}

