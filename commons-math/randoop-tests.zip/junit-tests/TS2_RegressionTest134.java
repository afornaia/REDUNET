import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest134 {

    public static boolean debug = false;

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest134.test135");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure5 = derivativeStructure4.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure11 = derivativeStructure10.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure16 = derivativeStructure15.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure20 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray21 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure15, derivativeStructure20 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix22 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray21);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure26 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure27 = derivativeStructure26.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure31 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray32 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure26, derivativeStructure31 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix33 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray32);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure34 = derivativeStructure10.linearCombination(derivativeStructureArray21, derivativeStructureArray32);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure36 = derivativeStructure34.multiply((double) (byte) 100);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure37 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure((double) 0, derivativeStructure4, (double) 1079525407, derivativeStructure34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure36);
    }
}

