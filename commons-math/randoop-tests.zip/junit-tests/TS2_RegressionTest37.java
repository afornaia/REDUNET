import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest37.test038");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = derivativeStructure3.cbrt();
        double[] doubleArray9 = new double[] { (byte) 1, (byte) -1, (byte) 0, (-1.0d) };
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = derivativeStructure4.compose(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
    }
}

