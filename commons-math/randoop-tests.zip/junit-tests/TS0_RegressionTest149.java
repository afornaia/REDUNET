import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest149 {

    public static boolean debug = false;

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest149.test150");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10L, localizedFormats3 };
        org.apache.commons.math4.exception.MathArithmeticException mathArithmeticException5 = new org.apache.commons.math4.exception.MathArithmeticException((org.apache.commons.math4.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math4.stat.regression.ModelSpecificationException modelSpecificationException6 = new org.apache.commons.math4.stat.regression.ModelSpecificationException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats1.equals(org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats3.equals(org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray4);
    }
}

