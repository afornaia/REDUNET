import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest151 {

    public static boolean debug = false;

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest151.test152");
        org.apache.commons.math4.ml.distance.DistanceMeasure distanceMeasure2 = null;
        org.apache.commons.rng.UniformRandomProvider uniformRandomProvider3 = null;
        org.apache.commons.math4.ml.clustering.KMeansPlusPlusClusterer.EmptyClusterStrategy emptyClusterStrategy4 = null;
        org.apache.commons.math4.ml.clustering.KMeansPlusPlusClusterer<org.apache.commons.math4.ml.clustering.DoublePoint> doublePointKMeansPlusPlusClusterer5 = new org.apache.commons.math4.ml.clustering.KMeansPlusPlusClusterer<org.apache.commons.math4.ml.clustering.DoublePoint>((int) (byte) -1, (int) (short) -1, distanceMeasure2, uniformRandomProvider3, emptyClusterStrategy4);
        int int6 = doublePointKMeansPlusPlusClusterer5.getK();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }
}

