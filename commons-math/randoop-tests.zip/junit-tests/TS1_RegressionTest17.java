import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest17.test018");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray7 = new double[] { '#' };
        double[] doubleArray10 = new double[] { 100.0f, 10 };
        double[] doubleArray13 = new double[] { 100.0f, 10 };
        double[] doubleArray16 = new double[] { 100.0f, 10 };
        double[] doubleArray19 = new double[] { 100.0f, 10 };
        double[] doubleArray22 = new double[] { 100.0f, 10 };
        double[] doubleArray25 = new double[] { 100.0f, 10 };
        double[][] doubleArray26 = new double[][] { doubleArray10, doubleArray13, doubleArray16, doubleArray19, doubleArray22, doubleArray25 };
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.interpolation.PiecewiseBicubicSplineInterpolatingFunction piecewiseBicubicSplineInterpolatingFunction27 = new org.apache.commons.math4.analysis.interpolation.PiecewiseBicubicSplineInterpolatingFunction(doubleArray3, doubleArray7, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.InsufficientDataException; message: insufficient data");
        } catch (org.apache.commons.math4.exception.InsufficientDataException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray26);
    }
}

