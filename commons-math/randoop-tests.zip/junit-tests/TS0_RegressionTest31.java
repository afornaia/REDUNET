import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest31.test032");
        org.apache.commons.math4.analysis.solvers.AllowedSolution allowedSolution0 = org.apache.commons.math4.analysis.solvers.AllowedSolution.ANY_SIDE;
        org.junit.Assert.assertTrue("'" + allowedSolution0 + "' != '" + org.apache.commons.math4.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution0.equals(org.apache.commons.math4.analysis.solvers.AllowedSolution.ANY_SIDE));
    }
}

