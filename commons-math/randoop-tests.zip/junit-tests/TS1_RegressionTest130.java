import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest130.test131");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.ml.clustering.FuzzyKMeansClusterer<org.apache.commons.math4.ml.clustering.DoublePoint> doublePointFuzzyKMeansClusterer2 = new org.apache.commons.math4.ml.clustering.FuzzyKMeansClusterer<org.apache.commons.math4.ml.clustering.DoublePoint>((-32767), 0.3d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: 0.3 is smaller than, or equal to, the minimum (1)");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
    }
}

