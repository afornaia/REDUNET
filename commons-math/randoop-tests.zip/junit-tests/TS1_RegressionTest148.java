import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest148 {

    public static boolean debug = false;

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest148.test149");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        org.apache.commons.math4.linear.RealMatrix realMatrix5 = org.apache.commons.math4.linear.MatrixUtils.createRealMatrixWithDiagonal(doubleArray3);
        double[] doubleArray9 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray9);
        double[] doubleArray13 = new double[] { 97, (-1.0f) };
        double double14 = org.apache.commons.math4.stat.StatUtils.geometricMean(doubleArray13);
        double[] doubleArray15 = org.apache.commons.math4.util.MathArrays.convolve(doubleArray9, doubleArray13);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray3, doubleArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray15);
    }
}

