import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest12.test013");
        org.apache.commons.math4.analysis.function.Asinh asinh0 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray7 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair8 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh0, doubleArray7);
        // The following exception was thrown during execution in test generation
        try {
            double double10 = org.apache.commons.math4.stat.StatUtils.percentile(doubleArray7, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: out of bounds quantile value: -1, must be in (0, 100]");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair8);
    }
}

