import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest125.test126");
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics0 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics();
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics1 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics((org.apache.commons.math4.stat.descriptive.DescriptiveStatistics) synchronizedDescriptiveStatistics0);
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics2 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics();
        // The following exception was thrown during execution in test generation
        try {
            double double3 = org.apache.commons.math4.stat.inference.InferenceTestUtils.tTest((org.apache.commons.math4.stat.descriptive.StatisticalSummary) synchronizedDescriptiveStatistics0, (org.apache.commons.math4.stat.descriptive.StatisticalSummary) synchronizedDescriptiveStatistics2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: insufficient data for t statistic, needs at least 2, got 0");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
    }
}

