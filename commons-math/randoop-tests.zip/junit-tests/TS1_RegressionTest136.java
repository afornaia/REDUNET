import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest136 {

    public static boolean debug = false;

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest136.test137");
        org.apache.commons.math4.fitting.leastsquares.MultivariateJacobianFunction multivariateJacobianFunction0 = null;
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math4.linear.OpenMapRealVector((-1));
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        boolean boolean5 = openMapRealVector4.isNaN();
        org.apache.commons.math4.linear.RealVector realVector7 = openMapRealVector4.mapMultiplyToSelf(1.0E-8d);
        org.apache.commons.math4.optim.ConvergenceChecker<org.apache.commons.math4.fitting.leastsquares.LeastSquaresProblem.Evaluation> evaluationConvergenceChecker8 = null;
        org.apache.commons.math4.fitting.leastsquares.LeastSquaresProblem leastSquaresProblem11 = org.apache.commons.math4.fitting.leastsquares.LeastSquaresFactory.create(multivariateJacobianFunction0, (org.apache.commons.math4.linear.RealVector) openMapRealVector2, realVector7, evaluationConvergenceChecker8, 0, (int) (short) 100);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realVector7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(leastSquaresProblem11);
    }
}

