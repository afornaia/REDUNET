import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest128 {

    public static boolean debug = false;

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest128.test129");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray7 = new double[] { 97, (-1.0f) };
        double double8 = org.apache.commons.math4.stat.StatUtils.geometricMean(doubleArray7);
        double[] doubleArray9 = org.apache.commons.math4.util.MathArrays.convolve(doubleArray3, doubleArray7);
        double[] doubleArray10 = org.apache.commons.math4.util.MathArrays.unique(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray10);
    }
}

