import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest100.test101");
        float[] floatArray6 = new float[] { 100, 100, ' ', 10, (-1L), 1.0f };
        float[] floatArray9 = new float[] { (-1.0f), (byte) 0 };
        boolean boolean10 = org.apache.commons.math4.util.MathArrays.equalsIncludingNaN(floatArray6, floatArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(floatArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(floatArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }
}

