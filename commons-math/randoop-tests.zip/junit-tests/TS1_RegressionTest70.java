import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest70.test071");
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math4.linear.OpenMapRealVector((-1));
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math4.linear.OpenMapRealVector((-1));
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.RealVector realVector4 = openMapRealVector1.projection((org.apache.commons.math4.linear.RealVector) openMapRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math4.exception.MathArithmeticException e) {
        // Expected exception.
        }
    }
}

