import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest130.test131");
        double double2 = org.apache.commons.math4.util.FastMath.max((double) (-32768L), (double) (-1.0f));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }
}

