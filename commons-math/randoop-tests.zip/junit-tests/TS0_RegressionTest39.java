import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest39.test040");
        org.apache.commons.math4.geometry.euclidean.threed.RotationOrder rotationOrder0 = org.apache.commons.math4.geometry.euclidean.threed.RotationOrder.YZX;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(rotationOrder0);
    }
}

