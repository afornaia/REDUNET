import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest6.test007");
        double[] doubleArray6 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray6, false);
        org.apache.commons.math4.linear.RealVector realVector9 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math4.linear.RealMatrix) diagonalMatrix8, realVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
    }
}

