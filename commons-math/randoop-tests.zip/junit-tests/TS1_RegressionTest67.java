import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest67.test068");
        double[] doubleArray4 = new double[] { (byte) 1, 0L, ' ', 100L };
        double[] doubleArray9 = new double[] { (byte) 1, 0L, ' ', 100L };
        double[] doubleArray14 = new double[] { (byte) 1, 0L, ' ', 100L };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math4.stat.correlation.Covariance covariance16 = new org.apache.commons.math4.stat.correlation.Covariance(doubleArray15);
        org.apache.commons.math4.stat.correlation.Covariance covariance18 = new org.apache.commons.math4.stat.correlation.Covariance(doubleArray15, false);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex21 = new org.apache.commons.math4.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(doubleArray15, (double) ' ', (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray15);
    }
}

