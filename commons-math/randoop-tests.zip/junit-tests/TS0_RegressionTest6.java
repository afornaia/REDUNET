import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest6.test007");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.differentiation.FiniteDifferencesDifferentiator finiteDifferencesDifferentiator4 = new org.apache.commons.math4.analysis.differentiation.FiniteDifferencesDifferentiator((int) (byte) 100, (double) 100.0f, (double) (short) 100, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooLargeException; message: 9,900 is larger than, or equal to, the maximum (-101)");
        } catch (org.apache.commons.math4.exception.NumberIsTooLargeException e) {
        // Expected exception.
        }
    }
}

