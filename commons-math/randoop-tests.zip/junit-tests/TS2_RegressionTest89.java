import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest89.test090");
        org.apache.commons.math4.stat.inference.MannWhitneyUTest mannWhitneyUTest0 = new org.apache.commons.math4.stat.inference.MannWhitneyUTest();
        double[] doubleArray3 = new double[] { 10.0d, ' ' };
        double[] doubleArray4 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair5 = new org.apache.commons.math4.optim.PointVectorValuePair(doubleArray3, doubleArray4);
        double[] doubleArray6 = pointVectorValuePair5.getPointRef();
        double[] doubleArray8 = new double[] { 'a' };
        int int9 = org.apache.commons.math4.util.MathUtils.hash(doubleArray8);
        double double10 = mannWhitneyUTest0.mannWhitneyU(doubleArray6, doubleArray8);
        java.lang.Iterable<org.apache.commons.math4.ml.neuralnet.Neuron> neuronIterable11 = null;
        org.apache.commons.math4.ml.distance.EarthMoversDistance earthMoversDistance12 = new org.apache.commons.math4.ml.distance.EarthMoversDistance();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.util.Pair<org.apache.commons.math4.ml.neuralnet.Neuron, org.apache.commons.math4.ml.neuralnet.Neuron> neuronPair13 = org.apache.commons.math4.ml.neuralnet.MapUtils.findBestAndSecondBest(doubleArray6, neuronIterable11, (org.apache.commons.math4.ml.distance.DistanceMeasure) earthMoversDistance12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1079525407 + "'", int9 == 1079525407);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
    }
}

