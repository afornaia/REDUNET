import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest152 {

    public static boolean debug = false;

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest152.test153");
        org.apache.commons.math4.stat.inference.MannWhitneyUTest mannWhitneyUTest0 = new org.apache.commons.math4.stat.inference.MannWhitneyUTest();
        double[] doubleArray3 = new double[] { 10.0d, ' ' };
        double[] doubleArray4 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair5 = new org.apache.commons.math4.optim.PointVectorValuePair(doubleArray3, doubleArray4);
        double[] doubleArray6 = pointVectorValuePair5.getPointRef();
        double[] doubleArray8 = new double[] { 'a' };
        int int9 = org.apache.commons.math4.util.MathUtils.hash(doubleArray8);
        double double10 = mannWhitneyUTest0.mannWhitneyU(doubleArray6, doubleArray8);
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics11 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics(doubleArray6);
        double double13 = org.apache.commons.math4.stat.StatUtils.populationVariance(doubleArray6, (double) (short) 100);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1079525407 + "'", int9 == 1079525407);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 121.0d + "'", double13 == 121.0d);
    }
}

