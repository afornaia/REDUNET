import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest44.test045");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        org.apache.commons.math4.linear.RealMatrix realMatrix5 = org.apache.commons.math4.linear.MatrixUtils.createRealMatrixWithDiagonal(doubleArray3);
        org.apache.commons.math4.stat.ranking.TiesStrategy tiesStrategy6 = null;
        org.apache.commons.math4.stat.ranking.NaturalRanking naturalRanking7 = new org.apache.commons.math4.stat.ranking.NaturalRanking(tiesStrategy6);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.stat.correlation.SpearmansCorrelation spearmansCorrelation8 = new org.apache.commons.math4.stat.correlation.SpearmansCorrelation(realMatrix5, (org.apache.commons.math4.stat.ranking.RankingAlgorithm) naturalRanking7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix5);
    }
}

