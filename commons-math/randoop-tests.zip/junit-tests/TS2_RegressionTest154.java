import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest154 {

    public static boolean debug = false;

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest154.test155");
        org.apache.commons.math4.analysis.differentiation.SparseGradient sparseGradient2 = org.apache.commons.math4.analysis.differentiation.SparseGradient.createVariable(10, (double) 10.0f);
        double double3 = sparseGradient2.getReal();
        org.apache.commons.math4.analysis.differentiation.SparseGradient sparseGradient4 = sparseGradient2.toRadians();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sparseGradient2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sparseGradient4);
    }
}

