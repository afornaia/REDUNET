import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest108.test109");
        org.apache.commons.math4.stat.descriptive.SummaryStatistics summaryStatistics0 = null;
        org.apache.commons.math4.stat.descriptive.SummaryStatistics summaryStatistics1 = null;
        org.apache.commons.math4.stat.descriptive.AggregateSummaryStatistics aggregateSummaryStatistics2 = new org.apache.commons.math4.stat.descriptive.AggregateSummaryStatistics(summaryStatistics0, summaryStatistics1);
        double double3 = aggregateSummaryStatistics2.getVariance();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }
}

