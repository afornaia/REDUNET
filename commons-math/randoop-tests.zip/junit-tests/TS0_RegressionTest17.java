import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest17.test018");
        org.apache.commons.math4.stat.ranking.NaNStrategy naNStrategy0 = null;
        org.apache.commons.rng.UniformRandomProvider uniformRandomProvider1 = null;
        org.apache.commons.math4.stat.ranking.NaturalRanking naturalRanking2 = new org.apache.commons.math4.stat.ranking.NaturalRanking(naNStrategy0, uniformRandomProvider1);
    }
}

