import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest59.test060");
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics1 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics(descriptiveStatistics0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
    }
}

