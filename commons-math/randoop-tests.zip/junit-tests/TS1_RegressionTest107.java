import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest107.test108");
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math4.linear.OpenMapRealVector((-1));
        org.apache.commons.math4.linear.RealVectorChangingVisitor realVectorChangingVisitor2 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double5 = openMapRealVector1.walkInOptimizedOrder(realVectorChangingVisitor2, (-1), (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
    }
}

