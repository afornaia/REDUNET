import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest159 {

    public static boolean debug = false;

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest159.test160");
        char[] charArray6 = new char[] { ' ', ' ', 'a', '4', ' ', '#' };
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.util.BigReal bigReal7 = new org.apache.commons.math4.util.BigReal(charArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: null");
        } catch (java.lang.NumberFormatException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray6);
    }
}

