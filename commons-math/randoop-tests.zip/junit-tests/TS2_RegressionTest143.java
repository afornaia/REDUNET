import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest143 {

    public static boolean debug = false;

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest143.test144");
        org.apache.commons.math4.analysis.BivariateFunction bivariateFunction0 = null;
        org.apache.commons.math4.analysis.function.Sinc sinc1 = new org.apache.commons.math4.analysis.function.Sinc();
        org.apache.commons.math4.analysis.MultivariateFunction multivariateFunction3 = org.apache.commons.math4.analysis.FunctionUtils.collector(bivariateFunction0, (org.apache.commons.math4.analysis.UnivariateFunction) sinc1, (double) 10.0f);
        org.apache.commons.math4.analysis.BivariateFunction bivariateFunction4 = null;
        org.apache.commons.math4.analysis.function.Sinc sinc5 = new org.apache.commons.math4.analysis.function.Sinc();
        org.apache.commons.math4.analysis.MultivariateFunction multivariateFunction7 = org.apache.commons.math4.analysis.FunctionUtils.collector(bivariateFunction4, (org.apache.commons.math4.analysis.UnivariateFunction) sinc5, (double) 10.0f);
        org.apache.commons.math4.analysis.function.Atan atan8 = new org.apache.commons.math4.analysis.function.Atan();
        org.apache.commons.math4.analysis.UnivariateFunction univariateFunction10 = org.apache.commons.math4.analysis.FunctionUtils.derivative((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) atan8, (int) '4');
        org.apache.commons.math4.analysis.function.Atan atan11 = new org.apache.commons.math4.analysis.function.Atan();
        org.apache.commons.math4.analysis.UnivariateFunction univariateFunction13 = org.apache.commons.math4.analysis.FunctionUtils.derivative((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) atan11, (int) '4');
        org.apache.commons.math4.analysis.function.Sinc sinc14 = new org.apache.commons.math4.analysis.function.Sinc();
        org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction[] univariateDifferentiableFunctionArray15 = new org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction[] { sinc1, sinc5, atan8, atan11, sinc14 };
        org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction univariateDifferentiableFunction16 = org.apache.commons.math4.analysis.FunctionUtils.multiply(univariateDifferentiableFunctionArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multivariateFunction3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multivariateFunction7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateFunction10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateFunction13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunction16);
    }
}

