import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest84.test085");
        double[] doubleArray4 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray9 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray14 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math4.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math4.linear.Array2DRowRealMatrix(doubleArray15);
        double[] doubleArray21 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray26 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray31 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[][] doubleArray32 = new double[][] { doubleArray21, doubleArray26, doubleArray31 };
        org.apache.commons.math4.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math4.linear.Array2DRowRealMatrix(doubleArray32);
        double[] doubleArray38 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray43 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray48 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[][] doubleArray49 = new double[][] { doubleArray38, doubleArray43, doubleArray48 };
        org.apache.commons.math4.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math4.linear.Array2DRowRealMatrix(doubleArray49);
        org.apache.commons.math4.linear.RealVector realVector51 = null;
        double[] doubleArray56 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray61 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray66 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[][] doubleArray67 = new double[][] { doubleArray56, doubleArray61, doubleArray66 };
        org.apache.commons.math4.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math4.linear.Array2DRowRealMatrix(doubleArray67);
        org.apache.commons.math4.filter.DefaultProcessModel defaultProcessModel69 = new org.apache.commons.math4.filter.DefaultProcessModel((org.apache.commons.math4.linear.RealMatrix) array2DRowRealMatrix16, (org.apache.commons.math4.linear.RealMatrix) array2DRowRealMatrix33, (org.apache.commons.math4.linear.RealMatrix) array2DRowRealMatrix50, realVector51, (org.apache.commons.math4.linear.RealMatrix) array2DRowRealMatrix68);
        org.apache.commons.math4.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor70 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double71 = array2DRowRealMatrix33.walkInOptimizedOrder(realMatrixPreservingVisitor70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray66);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray67);
    }
}

