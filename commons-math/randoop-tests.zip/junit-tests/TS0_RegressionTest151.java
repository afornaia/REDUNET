import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest151 {

    public static boolean debug = false;

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest151.test152");
        org.apache.commons.math4.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math4.linear.ArrayRealVector((int) ' ');
        org.apache.commons.math4.linear.RealVector realVector3 = arrayRealVector1.mapMultiply((double) (byte) 0);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math4.linear.OpenMapRealVector(realVector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realVector3);
    }
}

