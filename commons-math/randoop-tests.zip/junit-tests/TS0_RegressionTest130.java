import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest130.test131");
        org.apache.commons.math4.analysis.function.Log10 log10_0 = new org.apache.commons.math4.analysis.function.Log10();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.solvers.UnivariateSolverUtils.verifyBracketing((org.apache.commons.math4.analysis.UnivariateFunction) log10_0, (double) 100L, (double) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [100, 1]");
        } catch (org.apache.commons.math4.exception.NumberIsTooLargeException e) {
        // Expected exception.
        }
    }
}

