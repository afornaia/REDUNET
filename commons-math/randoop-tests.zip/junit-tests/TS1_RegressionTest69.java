import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest69.test070");
        double double0 = org.apache.commons.math4.optim.nonlinear.scalar.noderiv.BOBYQAOptimizer.DEFAULT_INITIAL_RADIUS;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 10.0d + "'", double0 == 10.0d);
    }
}

