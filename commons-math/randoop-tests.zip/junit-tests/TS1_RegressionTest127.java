import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest127 {

    public static boolean debug = false;

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest127.test128");
        org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator graggBulirschStoerIntegrator4 = new org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator(10.0d, (double) 10, (double) (-1.0f), (double) (short) 100);
        int int5 = graggBulirschStoerIntegrator4.getMaxEvaluations();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2147483647 + "'", int5 == 2147483647);
    }
}

