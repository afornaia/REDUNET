import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest122 {

    public static boolean debug = false;

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest122.test123");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.Number number2 = null;
        org.apache.commons.math4.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math4.exception.OutOfRangeException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, number2, (java.lang.Number) 1079525407);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
    }
}

