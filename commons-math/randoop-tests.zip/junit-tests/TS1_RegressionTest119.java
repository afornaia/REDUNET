import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest119.test120");
        double double0 = org.apache.commons.math4.analysis.interpolation.LoessInterpolator.DEFAULT_BANDWIDTH;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.3d + "'", double0 == 0.3d);
    }
}

