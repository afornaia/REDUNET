import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest36.test037");
        int[] intArray6 = new int[] { 10, (short) 0, (byte) 1, (short) 100, 0, (byte) 1 };
        int[] intArray11 = new int[] { (short) 100, (byte) -1, (short) 0, (short) 100 };
        // The following exception was thrown during execution in test generation
        try {
            int int12 = org.apache.commons.math4.util.MathArrays.distance1(intArray6, intArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 6 != 4");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray11);
    }
}

