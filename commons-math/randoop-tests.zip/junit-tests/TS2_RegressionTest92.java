import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest92.test093");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math4.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math4.linear.RealVectorFormat("hi!", "", "hi!", numberFormat3);
        java.lang.String str5 = realVectorFormat4.getSeparator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }
}

