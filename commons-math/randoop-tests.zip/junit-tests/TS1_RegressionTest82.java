import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest82.test083");
        org.apache.commons.math4.ml.clustering.FuzzyKMeansClusterer<org.apache.commons.math4.ml.clustering.Clusterable> clusterableFuzzyKMeansClusterer2 = new org.apache.commons.math4.ml.clustering.FuzzyKMeansClusterer<org.apache.commons.math4.ml.clustering.Clusterable>((int) (short) 0, 10.0d);
    }
}

