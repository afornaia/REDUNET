import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest71.test072");
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D0 = null;
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D1 = null;
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D2 = null;
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D3 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.geometry.euclidean.threed.FieldRotation<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldRotation4 = new org.apache.commons.math4.geometry.euclidean.threed.FieldRotation<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructureFieldVector3D0, derivativeStructureFieldVector3D1, derivativeStructureFieldVector3D2, derivativeStructureFieldVector3D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

