import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest92.test093");
        org.apache.commons.math4.analysis.function.Asinh asinh0 = new org.apache.commons.math4.analysis.function.Asinh();
        org.apache.commons.math4.analysis.function.Log10 log10_1 = new org.apache.commons.math4.analysis.function.Log10();
        org.apache.commons.math4.ml.neuralnet.FeatureInitializer featureInitializer4 = org.apache.commons.math4.ml.neuralnet.FeatureInitializerFactory.function((org.apache.commons.math4.analysis.UnivariateFunction) log10_1, (double) (short) 0, (double) ' ');
        org.apache.commons.math4.analysis.function.Asinh asinh5 = new org.apache.commons.math4.analysis.function.Asinh();
        org.apache.commons.math4.analysis.UnivariateFunction[] univariateFunctionArray6 = new org.apache.commons.math4.analysis.UnivariateFunction[] { asinh0, log10_1, asinh5 };
        org.apache.commons.math4.analysis.UnivariateFunction univariateFunction7 = org.apache.commons.math4.analysis.FunctionUtils.add(univariateFunctionArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureInitializer4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateFunctionArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateFunction7);
    }
}

