import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest116.test117");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10 };
        org.apache.commons.math4.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math4.exception.MathRuntimeException(throwable1, (org.apache.commons.math4.exception.util.Localizable) localizedFormats2, objArray4);
        org.apache.commons.math4.exception.NullArgumentException nullArgumentException6 = new org.apache.commons.math4.exception.NullArgumentException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray4);
    }
}

