import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest86.test087");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10L, localizedFormats2 };
        org.apache.commons.math4.exception.MathArithmeticException mathArithmeticException4 = new org.apache.commons.math4.exception.MathArithmeticException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math4.exception.NoDataException noDataException5 = new org.apache.commons.math4.exception.NoDataException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats2.equals(org.apache.commons.math4.exception.util.LocalizedFormats.CANNOT_PARSE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray3);
    }
}

