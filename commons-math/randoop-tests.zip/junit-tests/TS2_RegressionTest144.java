import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest144 {

    public static boolean debug = false;

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest144.test145");
        java.text.NumberFormat numberFormat3 = null;
        org.apache.commons.math4.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math4.linear.RealVectorFormat("hi!", "", "hi!", numberFormat3);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.ArrayRealVector arrayRealVector6 = realVectorFormat4.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

