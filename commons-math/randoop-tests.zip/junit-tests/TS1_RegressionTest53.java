import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest53.test054");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray8 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray8);
        double double12 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray8, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds13 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray3, doubleArray8);
        double double14 = org.apache.commons.math4.stat.StatUtils.geometricMean(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3367.0d + "'", double12 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }
}

