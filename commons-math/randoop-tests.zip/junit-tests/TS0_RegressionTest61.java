import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest61.test062");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        double[] doubleArray2 = new double[] {};
        double double3 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray2);
        org.apache.commons.math4.optim.linear.Relationship relationship4 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint6 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray2, relationship4, (double) 100);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.integration.gauss.SymmetricGaussIntegrator symmetricGaussIntegrator7 = new org.apache.commons.math4.analysis.integration.gauss.SymmetricGaussIntegrator(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }
}

