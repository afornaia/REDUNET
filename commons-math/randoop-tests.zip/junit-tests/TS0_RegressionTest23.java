import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest23.test024");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        double[] doubleArray2 = new double[] {};
        double double3 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray2);
        org.apache.commons.math4.optim.linear.Relationship relationship4 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint6 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray2, relationship4, (double) 100);
        double[] doubleArray7 = new double[] {};
        double double8 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray7);
        double[][] doubleArray9 = new double[][] { doubleArray0, doubleArray2, doubleArray7 };
        java.util.ArrayList<double[]> doubleArrayList10 = new java.util.ArrayList<double[]>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<double[]>) doubleArrayList10, doubleArray9);
        // The following exception was thrown during execution in test generation
        try {
            double double12 = org.apache.commons.math4.stat.inference.InferenceTestUtils.oneWayAnovaFValue((java.util.Collection<double[]>) doubleArrayList10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: two or more values required in each category, one has 0");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }
}

