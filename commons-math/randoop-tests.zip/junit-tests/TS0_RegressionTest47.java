import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest47.test048");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }
}

