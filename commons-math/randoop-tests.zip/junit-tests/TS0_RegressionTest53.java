import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest53.test054");
        double[] doubleArray1 = new double[] {};
        double double2 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray1);
        org.apache.commons.math4.optim.linear.Relationship relationship3 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint5 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray1, relationship3, (double) 100);
        // The following exception was thrown during execution in test generation
        try {
            double double6 = org.apache.commons.math4.stat.inference.InferenceTestUtils.t((double) 10, doubleArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: insufficient data for t statistic, needs at least 2, got 0");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }
}

