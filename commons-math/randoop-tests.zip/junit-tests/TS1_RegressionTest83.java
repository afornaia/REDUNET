import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest83.test084");
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics0 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics();
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics1 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics((org.apache.commons.math4.stat.descriptive.DescriptiveStatistics) synchronizedDescriptiveStatistics0);
        double double3 = synchronizedDescriptiveStatistics0.getPercentile((double) 1L);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }
}

