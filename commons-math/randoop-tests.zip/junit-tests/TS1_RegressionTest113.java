import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest113.test114");
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        // The following exception was thrown during execution in test generation
        try {
            double double4 = openMapRealVector1.cosine((org.apache.commons.math4.linear.RealVector) openMapRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math4.exception.MathArithmeticException e) {
        // Expected exception.
        }
    }
}

