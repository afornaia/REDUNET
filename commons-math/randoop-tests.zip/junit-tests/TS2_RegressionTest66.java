import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest66.test067");
        org.apache.commons.math4.analysis.interpolation.PiecewiseBicubicSplineInterpolator piecewiseBicubicSplineInterpolator0 = new org.apache.commons.math4.analysis.interpolation.PiecewiseBicubicSplineInterpolator();
    }
}

