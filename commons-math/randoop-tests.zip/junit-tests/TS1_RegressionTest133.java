import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest133 {

    public static boolean debug = false;

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest133.test134");
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics0 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics();
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics1 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics(synchronizedDescriptiveStatistics0);
        double double2 = synchronizedDescriptiveStatistics0.getSum();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }
}

