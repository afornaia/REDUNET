import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest81.test082");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.integration.IterativeLegendreGaussIntegrator iterativeLegendreGaussIntegrator3 = new org.apache.commons.math4.analysis.integration.IterativeLegendreGaussIntegrator((int) 'a', (int) (byte) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math4.exception.NotStrictlyPositiveException e) {
        // Expected exception.
        }
    }
}

