import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest65.test066");
        org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator graggBulirschStoerIntegrator4 = new org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator(10.0d, (double) 10, (double) (-1.0f), (double) (short) 100);
        org.apache.commons.math4.ode.events.EventHandler eventHandler5 = null;
        org.apache.commons.math4.analysis.solvers.SecantSolver secantSolver10 = new org.apache.commons.math4.analysis.solvers.SecantSolver((double) ' ');
        graggBulirschStoerIntegrator4.addEventHandler(eventHandler5, (double) (byte) 100, 10.0d, (int) (byte) 10, (org.apache.commons.math4.analysis.solvers.UnivariateSolver) secantSolver10);
        org.apache.commons.math4.ode.sampling.StepHandler stepHandler12 = null;
        graggBulirschStoerIntegrator4.addStepHandler(stepHandler12);
        graggBulirschStoerIntegrator4.setControlFactors(Double.NEGATIVE_INFINITY, (double) (short) 1, (double) 10L, (double) (short) 10);
    }
}

