import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest101.test102");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.differentiation.FiniteDifferencesDifferentiator finiteDifferencesDifferentiator2 = new org.apache.commons.math4.analysis.differentiation.FiniteDifferencesDifferentiator((int) '4', Double.NEGATIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: -∞ is smaller than the minimum (0)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
    }
}

