import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest42.test043");
        org.apache.commons.math4.optim.nonlinear.scalar.GoalType goalType0 = org.apache.commons.math4.optim.nonlinear.scalar.GoalType.MINIMIZE;
        org.junit.Assert.assertTrue("'" + goalType0 + "' != '" + org.apache.commons.math4.optim.nonlinear.scalar.GoalType.MINIMIZE + "'", goalType0.equals(org.apache.commons.math4.optim.nonlinear.scalar.GoalType.MINIMIZE));
    }
}

