import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest111.test112");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        org.apache.commons.math4.optim.linear.Relationship relationship2 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint4 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray0, relationship2, (double) 100);
        double[][] doubleArray5 = new double[][] { doubleArray0 };
        java.util.ArrayList<double[]> doubleArrayList6 = new java.util.ArrayList<double[]>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<double[]>) doubleArrayList6, doubleArray5);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean9 = org.apache.commons.math4.stat.inference.InferenceTestUtils.oneWayAnovaTest((java.util.Collection<double[]>) doubleArrayList6, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: out of bounds significance level 1, must be between 0 and 0.5");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }
}

