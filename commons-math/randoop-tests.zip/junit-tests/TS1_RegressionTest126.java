import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest126 {

    public static boolean debug = false;

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest126.test127");
        org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D.HorizontalDirection horizontalDirection0 = org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D.HorizontalDirection.LEFT;
        org.junit.Assert.assertTrue("'" + horizontalDirection0 + "' != '" + org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D.HorizontalDirection.LEFT + "'", horizontalDirection0.equals(org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D.HorizontalDirection.LEFT));
    }
}

