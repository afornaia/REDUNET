import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest17.test018");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure7 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure11 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure19 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure23 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray24 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure3, derivativeStructure7, derivativeStructure11, derivativeStructure15, derivativeStructure19, derivativeStructure23 };
        org.apache.commons.math4.linear.FieldVector<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector25 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.ArrayFieldVector<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureArrayFieldVector26 = new org.apache.commons.math4.linear.ArrayFieldVector<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructureArray24, derivativeStructureFieldVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray24);
    }
}

