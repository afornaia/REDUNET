import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest118 {

    public static boolean debug = false;

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest118.test119");
        long[] longArray4 = new long[] { (byte) -1, (-1), '4', (byte) 1 };
        long[] longArray9 = new long[] { (byte) -1, (-1), '4', (byte) 1 };
        long[] longArray14 = new long[] { (byte) -1, (-1), '4', (byte) 1 };
        long[] longArray19 = new long[] { (byte) -1, (-1), '4', (byte) 1 };
        long[] longArray24 = new long[] { (byte) -1, (-1), '4', (byte) 1 };
        long[][] longArray25 = new long[][] { longArray4, longArray9, longArray14, longArray19, longArray24 };
        org.apache.commons.math4.util.MathArrays.checkRectangular(longArray25);
        // The following exception was thrown during execution in test generation
        try {
            double double27 = org.apache.commons.math4.stat.inference.InferenceTestUtils.chiSquare(longArray25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray25);
    }
}

