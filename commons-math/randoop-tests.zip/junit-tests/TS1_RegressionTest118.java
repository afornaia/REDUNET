import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest118 {

    public static boolean debug = false;

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest118.test119");
        org.apache.commons.math4.stat.ranking.NaNStrategy naNStrategy0 = null;
        org.apache.commons.rng.UniformRandomProvider uniformRandomProvider1 = null;
        org.apache.commons.math4.stat.ranking.NaturalRanking naturalRanking2 = new org.apache.commons.math4.stat.ranking.NaturalRanking(naNStrategy0, uniformRandomProvider1);
    }
}

