import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest74.test075");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.geometry.euclidean.threed.Vector3D vector3D4 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure8 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure9 = derivativeStructure8.cbrt();
        org.apache.commons.geometry.euclidean.threed.Vector3D vector3D10 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure14 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = derivativeStructure14.cbrt();
        org.apache.commons.geometry.euclidean.threed.Vector3D vector3D16 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure20 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure21 = derivativeStructure20.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure25 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure26 = derivativeStructure25.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure30 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray31 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure25, derivativeStructure30 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix32 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray31);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure36 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure37 = derivativeStructure36.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure41 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray42 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure36, derivativeStructure41 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix43 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray42);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure44 = derivativeStructure20.linearCombination(derivativeStructureArray31, derivativeStructureArray42);
        org.apache.commons.geometry.euclidean.threed.Vector3D vector3D45 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D46 = new org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructure3, vector3D4, derivativeStructure9, vector3D10, derivativeStructure14, vector3D16, derivativeStructure20, vector3D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure44);
    }
}

