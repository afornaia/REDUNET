import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest119.test120");
        org.apache.commons.math4.stat.ranking.NaNStrategy naNStrategy0 = org.apache.commons.math4.stat.ranking.NaNStrategy.FAILED;
        org.junit.Assert.assertTrue("'" + naNStrategy0 + "' != '" + org.apache.commons.math4.stat.ranking.NaNStrategy.FAILED + "'", naNStrategy0.equals(org.apache.commons.math4.stat.ranking.NaNStrategy.FAILED));
    }
}

