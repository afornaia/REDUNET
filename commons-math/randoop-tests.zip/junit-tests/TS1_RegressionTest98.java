import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest98 {

    public static boolean debug = false;

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest98.test099");
        org.apache.commons.math4.util.IterationManager iterationManager1 = new org.apache.commons.math4.util.IterationManager((int) 'a');
        org.apache.commons.math4.linear.SymmLQ symmLQ4 = new org.apache.commons.math4.linear.SymmLQ(iterationManager1, (double) '4', false);
        double[] doubleArray8 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray8);
        double double13 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray8, 0, 0);
        org.apache.commons.math4.linear.JacobiPreconditioner jacobiPreconditioner15 = new org.apache.commons.math4.linear.JacobiPreconditioner(doubleArray8, true);
        double[] doubleArray19 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray19);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray19);
        double double24 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray19, 0, 0);
        org.apache.commons.math4.linear.JacobiPreconditioner jacobiPreconditioner26 = new org.apache.commons.math4.linear.JacobiPreconditioner(doubleArray19, true);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        boolean boolean29 = openMapRealVector28.isNaN();
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        double double32 = openMapRealVector28.getL1Distance((org.apache.commons.math4.linear.RealVector) openMapRealVector31);
        org.apache.commons.math4.linear.RealVector realVector33 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.RealVector realVector34 = symmLQ4.solve((org.apache.commons.math4.linear.RealLinearOperator) jacobiPreconditioner15, (org.apache.commons.math4.linear.RealLinearOperator) jacobiPreconditioner26, (org.apache.commons.math4.linear.RealVector) openMapRealVector31, realVector33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }
}

