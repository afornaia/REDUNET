import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest115 {

    public static boolean debug = false;

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest115.test116");
        org.apache.commons.math4.ode.events.EventHandler eventHandler0 = null;
        org.apache.commons.math4.ode.events.FilterType filterType1 = null;
        org.apache.commons.math4.ode.events.EventFilter eventFilter2 = new org.apache.commons.math4.ode.events.EventFilter(eventHandler0, filterType1);
    }
}

