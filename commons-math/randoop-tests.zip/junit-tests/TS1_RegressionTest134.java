import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest134 {

    public static boolean debug = false;

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest134.test135");
        org.apache.commons.math4.util.MathArrays.OrderDirection orderDirection0 = org.apache.commons.math4.util.MathArrays.OrderDirection.INCREASING;
        org.junit.Assert.assertTrue("'" + orderDirection0 + "' != '" + org.apache.commons.math4.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection0.equals(org.apache.commons.math4.util.MathArrays.OrderDirection.INCREASING));
    }
}

