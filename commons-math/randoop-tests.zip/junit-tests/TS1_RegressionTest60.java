import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest60.test061");
        org.apache.commons.math4.stat.descriptive.moment.Variance variance1 = new org.apache.commons.math4.stat.descriptive.moment.Variance(false);
        org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver(0.0d);
        boolean boolean4 = variance1.equals((java.lang.Object) 0.0d);
        variance1.increment((double) '4');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}

