import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest142 {

    public static boolean debug = false;

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest142.test143");
        org.apache.commons.math4.stat.descriptive.rank.Percentile percentile0 = new org.apache.commons.math4.stat.descriptive.rank.Percentile();
    }
}

