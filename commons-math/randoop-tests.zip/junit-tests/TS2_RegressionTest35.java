import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest35.test036");
        org.apache.commons.math4.geometry.euclidean.threed.RotationOrder rotationOrder0 = null;
        org.apache.commons.math4.geometry.euclidean.threed.RotationConvention rotationConvention1 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure5 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure6 = derivativeStructure5.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure11 = derivativeStructure10.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.geometry.euclidean.threed.FieldRotation<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldRotation16 = new org.apache.commons.math4.geometry.euclidean.threed.FieldRotation<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(rotationOrder0, rotationConvention1, derivativeStructure5, derivativeStructure11, derivativeStructure15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure11);
    }
}

