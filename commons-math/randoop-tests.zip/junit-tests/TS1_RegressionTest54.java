import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest54.test055");
        org.apache.commons.math4.stat.descriptive.moment.Variance variance1 = new org.apache.commons.math4.stat.descriptive.moment.Variance(false);
        double[] doubleArray7 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray7);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray7);
        double double12 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray7, 0, 0);
        double[] doubleArray16 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray16);
        org.apache.commons.math4.linear.RealMatrix realMatrix18 = org.apache.commons.math4.linear.MatrixUtils.createRealMatrixWithDiagonal(doubleArray16);
        org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator graggBulirschStoerIntegrator19 = new org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator((double) '#', (double) (-1), doubleArray7, doubleArray16);
        // The following exception was thrown during execution in test generation
        try {
            variance1.incrementAll(doubleArray7, (-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: start position (-1)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix18);
    }
}

