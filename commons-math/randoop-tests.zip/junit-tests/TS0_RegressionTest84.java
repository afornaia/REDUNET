import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest84.test085");
        org.apache.commons.math4.analysis.integration.RombergIntegrator rombergIntegrator0 = new org.apache.commons.math4.analysis.integration.RombergIntegrator();
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10 };
        org.apache.commons.math4.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math4.exception.MathRuntimeException(throwable1, (org.apache.commons.math4.exception.util.Localizable) localizedFormats2, objArray4);
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.integration.UnivariateIntegrator, java.lang.RuntimeException> univariateIntegratorPair6 = new org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.integration.UnivariateIntegrator, java.lang.RuntimeException>((org.apache.commons.math4.analysis.integration.UnivariateIntegrator) rombergIntegrator0, (java.lang.RuntimeException) mathRuntimeException5);
        java.io.ObjectInputStream objectInputStream8 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) mathRuntimeException5, "hi!", objectInputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray4);
    }
}

