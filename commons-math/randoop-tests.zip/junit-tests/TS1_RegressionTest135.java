import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest135 {

    public static boolean debug = false;

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest135.test136");
        org.apache.commons.math4.ml.distance.DistanceMeasure distanceMeasure1 = null;
        org.apache.commons.math4.ml.neuralnet.twod.util.TopographicErrorHistogram topographicErrorHistogram2 = new org.apache.commons.math4.ml.neuralnet.twod.util.TopographicErrorHistogram(false, distanceMeasure1);
        org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D neuronSquareMesh2D3 = null;
        double[] doubleArray7 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray7);
        double[] doubleArray12 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray12);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray12);
        double double16 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray12, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds17 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray7, doubleArray12);
        double[] doubleArray21 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray21);
        double[] doubleArray26 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray26);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray26);
        double double30 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray26, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds31 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray21, doubleArray26);
        double[] doubleArray35 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray35);
        double[] doubleArray40 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray40);
        double[] doubleArray45 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray45);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray45);
        double double49 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray45, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds50 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray40, doubleArray45);
        double[] doubleArray54 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray54);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray54);
        double double58 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray54, (double) 1.0f);
        double[] doubleArray62 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray62);
        double[] doubleArray67 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray67);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray67);
        double double71 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray67, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds72 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray62, doubleArray67);
        double[][] doubleArray73 = new double[][] { doubleArray7, doubleArray26, doubleArray35, doubleArray40, doubleArray54, doubleArray67 };
        java.util.ArrayList<double[]> doubleArrayList74 = new java.util.ArrayList<double[]>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<double[]>) doubleArrayList74, doubleArray73);
        double double76 = org.apache.commons.math4.stat.inference.InferenceTestUtils.oneWayAnovaFValue((java.util.Collection<double[]>) doubleArrayList74);
        // The following exception was thrown during execution in test generation
        try {
            double[][] doubleArray77 = topographicErrorHistogram2.computeImage(neuronSquareMesh2D3, (java.lang.Iterable<double[]>) doubleArrayList74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3367.0d + "'", double16 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3367.0d + "'", double30 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3367.0d + "'", double49 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray54);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 3367.0d + "'", double58 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray67);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 3367.0d + "'", double71 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray73);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }
}

