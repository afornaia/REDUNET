import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest33.test034");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.genetics.UniformCrossover<org.apache.commons.math4.optim.MaxIter> maxIterUniformCrossover1 = new org.apache.commons.math4.genetics.UniformCrossover<org.apache.commons.math4.optim.MaxIter>((double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: crossover rate (100)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
    }
}

