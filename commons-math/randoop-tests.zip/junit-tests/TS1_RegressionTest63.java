import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest63.test064");
        int[] intArray2 = new int[] { (byte) 10, 1 };
        int[] intArray8 = new int[] { ' ', 1, (byte) 10, 1072693248, (-1) };
        // The following exception was thrown during execution in test generation
        try {
            int int9 = org.apache.commons.math4.util.MathArrays.distance1(intArray2, intArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 2 != 5");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray8);
    }
}

