import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest53.test054");
        org.apache.commons.math4.analysis.function.Atan atan0 = new org.apache.commons.math4.analysis.function.Atan();
        org.apache.commons.math4.analysis.UnivariateFunction univariateFunction2 = org.apache.commons.math4.analysis.FunctionUtils.derivative((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) atan0, (int) '4');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateFunction2);
    }
}

