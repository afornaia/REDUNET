import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest75.test076");
        org.apache.commons.math4.linear.RealMatrix realMatrix0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.RealMatrix realMatrix2 = org.apache.commons.math4.linear.MatrixUtils.inverse(realMatrix0, 5.267884728309446d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
    }
}

