import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest151 {

    public static boolean debug = false;

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest151.test152");
        double[] doubleArray4 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray9 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[] doubleArray14 = new double[] { (byte) 10, 1, (-32767), 10 };
        double[][] doubleArray15 = new double[][] { doubleArray4, doubleArray9, doubleArray14 };
        org.apache.commons.math4.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math4.linear.Array2DRowRealMatrix(doubleArray15);
        org.apache.commons.math4.linear.RealMatrix realMatrix17 = array2DRowRealMatrix16.copy();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix17);
    }
}

