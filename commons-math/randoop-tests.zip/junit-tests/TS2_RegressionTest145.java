import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest145 {

    public static boolean debug = false;

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest145.test146");
        org.apache.commons.math4.linear.RealVector realVector2 = null;
        org.apache.commons.math4.linear.RealVector realVector3 = null;
        org.apache.commons.math4.linear.RealVector realVector4 = null;
        org.apache.commons.math4.linear.DefaultIterativeLinearSolverEvent defaultIterativeLinearSolverEvent6 = new org.apache.commons.math4.linear.DefaultIterativeLinearSolverEvent((java.lang.Object) '#', (int) (byte) 0, realVector2, realVector3, realVector4, (double) 100.0f);
    }
}

