import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest122 {

    public static boolean debug = false;

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest122.test123");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        double[] doubleArray7 = new double[] { 97, (-1.0f) };
        double double8 = org.apache.commons.math4.stat.StatUtils.geometricMean(doubleArray7);
        double[] doubleArray9 = org.apache.commons.math4.util.MathArrays.convolve(doubleArray3, doubleArray7);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.util.MathArrays.checkPositive(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotStrictlyPositiveException; message: -100 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math4.exception.NotStrictlyPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
    }
}

