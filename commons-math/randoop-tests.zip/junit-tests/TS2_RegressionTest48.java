import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest48.test049");
        org.apache.commons.math4.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math4.optim.nonlinear.scalar.noderiv.NelderMeadSimplex((int) (byte) 10, (double) '#', (double) 1079525407, 100.0d, (double) 100.0f);
    }
}

