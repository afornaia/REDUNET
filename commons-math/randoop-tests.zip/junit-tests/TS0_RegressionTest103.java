import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest103.test104");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        double[] doubleArray2 = new double[] {};
        double double3 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray2);
        org.apache.commons.math4.optim.linear.Relationship relationship4 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint6 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray2, relationship4, (double) 100);
        double[] doubleArray12 = new double[] { ' ', 100L, (short) 0, ' ', 100 };
        org.apache.commons.math4.util.MathArrays.checkNotNaN(doubleArray12);
        org.apache.commons.math4.analysis.function.Asinh asinh14 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray21 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair22 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh14, doubleArray21);
        double[][] doubleArray23 = new double[][] { doubleArray0, doubleArray2, doubleArray12, doubleArray21 };
        java.util.ArrayList<double[]> doubleArrayList24 = new java.util.ArrayList<double[]>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<double[]>) doubleArrayList24, doubleArray23);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean27 = org.apache.commons.math4.stat.inference.InferenceTestUtils.oneWayAnovaTest((java.util.Collection<double[]>) doubleArrayList24, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: out of bounds significance level 0, must be between 0 and 0.5");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }
}

