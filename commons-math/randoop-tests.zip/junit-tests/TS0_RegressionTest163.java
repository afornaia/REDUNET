import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest163 {

    public static boolean debug = false;

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest163.test164");
        org.apache.commons.math4.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math4.linear.MatrixDimensionMismatchException((int) (short) 10, (int) (byte) 10, (int) ' ', (int) (byte) 10);
        int int5 = matrixDimensionMismatchException4.getWrongRowDimension();
        java.lang.Integer[] intArray6 = matrixDimensionMismatchException4.getWrongDimensions();
        int int8 = matrixDimensionMismatchException4.getExpectedDimension(0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
    }
}

