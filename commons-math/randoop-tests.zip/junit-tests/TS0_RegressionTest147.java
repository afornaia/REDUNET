import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest147 {

    public static boolean debug = false;

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest147.test148");
        org.apache.commons.math4.geometry.euclidean.threed.RotationOrder rotationOrder0 = org.apache.commons.math4.geometry.euclidean.threed.RotationOrder.YZY;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(rotationOrder0);
    }
}

