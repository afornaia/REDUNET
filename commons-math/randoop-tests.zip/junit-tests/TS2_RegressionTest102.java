import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest102.test103");
        org.apache.commons.math4.Field<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureField0 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure5 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure6 = derivativeStructure5.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure11 = derivativeStructure10.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray16 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure10, derivativeStructure15 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix17 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray16);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure21 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure22 = derivativeStructure21.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure26 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray27 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure21, derivativeStructure26 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix28 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray27);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure29 = derivativeStructure5.linearCombination(derivativeStructureArray16, derivativeStructureArray27);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.util.OpenIntToFieldHashMap<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureOpenIntToFieldHashMap30 = new org.apache.commons.math4.util.OpenIntToFieldHashMap<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructureField0, (-1), derivativeStructure5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure29);
    }
}

