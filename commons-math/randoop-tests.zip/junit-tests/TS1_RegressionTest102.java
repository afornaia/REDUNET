import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest102.test103");
        org.apache.commons.math4.analysis.function.Pow pow0 = new org.apache.commons.math4.analysis.function.Pow();
        org.apache.commons.math4.analysis.MultivariateFunction multivariateFunction2 = org.apache.commons.math4.analysis.FunctionUtils.collector((org.apache.commons.math4.analysis.BivariateFunction) pow0, (double) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multivariateFunction2);
    }
}

