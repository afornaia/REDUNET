import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest4.test005");
        long[] longArray3 = new long[] { (short) 100, 1, (byte) 10 };
        long[] longArray9 = new long[] { (short) 100, ' ', (byte) -1, 1, (byte) -1 };
        // The following exception was thrown during execution in test generation
        try {
            double double10 = org.apache.commons.math4.stat.inference.InferenceTestUtils.chiSquareTestDataSetsComparison(longArray3, longArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray9);
    }
}

