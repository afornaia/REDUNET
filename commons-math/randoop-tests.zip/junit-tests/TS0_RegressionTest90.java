import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest90.test091");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
    }
}

