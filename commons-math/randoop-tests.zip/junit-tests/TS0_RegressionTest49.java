import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest49.test050");
        org.apache.commons.math4.stat.descriptive.StatisticalSummary statisticalSummary0 = null;
        org.apache.commons.math4.stat.descriptive.StatisticalSummary statisticalSummary1 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean3 = org.apache.commons.math4.stat.inference.InferenceTestUtils.tTest(statisticalSummary0, statisticalSummary1, (double) 1L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: significance level (1)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
    }
}

