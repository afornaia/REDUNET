import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest78.test079");
        double[] doubleArray5 = new double[] { 10.0d, ' ' };
        double[] doubleArray6 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair7 = new org.apache.commons.math4.optim.PointVectorValuePair(doubleArray5, doubleArray6);
        double[] doubleArray9 = new double[] { 'a' };
        int int10 = org.apache.commons.math4.util.MathUtils.hash(doubleArray9);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.ode.nonstiff.AdamsMoultonIntegrator adamsMoultonIntegrator11 = new org.apache.commons.math4.ode.nonstiff.AdamsMoultonIntegrator((int) (short) -1, (double) 0.0f, (double) 100L, doubleArray6, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1079525407 + "'", int10 == 1079525407);
    }
}

