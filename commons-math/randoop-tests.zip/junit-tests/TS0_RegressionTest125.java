import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest125.test126");
        double[] doubleArray5 = new double[] { ' ', 100L, (short) 0, ' ', 100 };
        org.apache.commons.math4.util.MathArrays.checkNotNaN(doubleArray5);
        org.apache.commons.math4.analysis.function.Asinh asinh7 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray14 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair15 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh7, doubleArray14);
        double[] doubleArray16 = new double[] {};
        double double17 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray16);
        double[] doubleArray18 = new double[] {};
        double double19 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray18);
        org.apache.commons.math4.analysis.function.Asinh asinh20 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray27 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair28 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh20, doubleArray27);
        org.apache.commons.math4.special.BesselJ.BesselJResult besselJResult30 = new org.apache.commons.math4.special.BesselJ.BesselJResult(doubleArray27, (int) (short) -1);
        double[] doubleArray36 = new double[] { ' ', 100L, (short) 0, ' ', 100 };
        org.apache.commons.math4.util.MathArrays.checkNotNaN(doubleArray36);
        double double38 = org.apache.commons.math4.stat.StatUtils.product(doubleArray36);
        double[][] doubleArray39 = new double[][] { doubleArray5, doubleArray14, doubleArray16, doubleArray18, doubleArray27, doubleArray36 };
        java.util.ArrayList<double[]> doubleArrayList40 = new java.util.ArrayList<double[]>();
        boolean boolean41 = java.util.Collections.addAll((java.util.Collection<double[]>) doubleArrayList40, doubleArray39);
        // The following exception was thrown during execution in test generation
        try {
            double double42 = org.apache.commons.math4.stat.inference.InferenceTestUtils.oneWayAnovaPValue((java.util.Collection<double[]>) doubleArrayList40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: two or more values required in each category, one has 0");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }
}

