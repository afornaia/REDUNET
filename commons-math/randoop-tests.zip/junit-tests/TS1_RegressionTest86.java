import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest86.test087");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex multiDirectionalSimplex2 = new org.apache.commons.math4.optim.nonlinear.scalar.noderiv.MultiDirectionalSimplex(0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.ZeroException; message: zero not allowed here");
        } catch (org.apache.commons.math4.exception.ZeroException e) {
        // Expected exception.
        }
    }
}

