import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest161 {

    public static boolean debug = false;

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest161.test162");
        org.apache.commons.math4.analysis.differentiation.DSCompiler dSCompiler2 = org.apache.commons.math4.analysis.differentiation.DSCompiler.getCompiler((int) (short) 0, (int) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dSCompiler2);
    }
}

