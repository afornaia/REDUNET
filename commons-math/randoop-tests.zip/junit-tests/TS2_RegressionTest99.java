import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest99.test100");
        org.apache.commons.math4.ml.neuralnet.SquareNeighbourhood squareNeighbourhood4 = null;
        org.apache.commons.math4.ml.neuralnet.FeatureInitializer featureInitializer5 = null;
        org.apache.commons.math4.ml.neuralnet.FeatureInitializer[] featureInitializerArray6 = new org.apache.commons.math4.ml.neuralnet.FeatureInitializer[] { featureInitializer5 };
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D neuronSquareMesh2D7 = new org.apache.commons.math4.ml.neuralnet.twod.NeuronSquareMesh2D(0, false, (int) (byte) 10, false, squareNeighbourhood4, featureInitializerArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (2)");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureInitializerArray6);
    }
}

