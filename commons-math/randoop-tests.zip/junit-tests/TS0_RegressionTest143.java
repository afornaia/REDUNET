import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest143 {

    public static boolean debug = false;

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest143.test144");
        org.apache.commons.math4.analysis.integration.RombergIntegrator rombergIntegrator0 = new org.apache.commons.math4.analysis.integration.RombergIntegrator();
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 10 };
        org.apache.commons.math4.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math4.exception.MathRuntimeException(throwable1, (org.apache.commons.math4.exception.util.Localizable) localizedFormats2, objArray4);
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.integration.UnivariateIntegrator, java.lang.RuntimeException> univariateIntegratorPair6 = new org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.integration.UnivariateIntegrator, java.lang.RuntimeException>((org.apache.commons.math4.analysis.integration.UnivariateIntegrator) rombergIntegrator0, (java.lang.RuntimeException) mathRuntimeException5);
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math4.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.apache.commons.numbers.complex.Complex[] complexArray8 = new org.apache.commons.numbers.complex.Complex[] {};
        double[][] doubleArray9 = org.apache.commons.math4.transform.TransformUtils.createRealImaginaryArray(complexArray8);
        org.apache.commons.math4.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math4.exception.MathIllegalStateException((java.lang.Throwable) mathRuntimeException5, (org.apache.commons.math4.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats2.equals(org.apache.commons.math4.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats7.equals(org.apache.commons.math4.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(complexArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
    }
}

