import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest20.test021");
        org.apache.commons.math4.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math4.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) (-1.0f), true);
    }
}

