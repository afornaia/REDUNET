import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest69.test070");
        org.apache.commons.math4.distribution.EmpiricalDistribution empiricalDistribution1 = new org.apache.commons.math4.distribution.EmpiricalDistribution(10);
        boolean boolean2 = empiricalDistribution1.isSupportConnected();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }
}

