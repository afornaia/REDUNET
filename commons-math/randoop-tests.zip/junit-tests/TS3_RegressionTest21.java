import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest21.test022");
        java.util.Random random0 = null;
        org.apache.commons.rng.UniformRandomProvider uniformRandomProvider1 = org.apache.commons.math4.random.RandomUtils.asUniformRandomProvider(random0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(uniformRandomProvider1);
    }
}

