import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest81.test082");
        int[] intArray0 = new int[] {};
        int[] intArray7 = new int[] { 1, (short) 100, (byte) -1, (-1), (short) 1, 0 };
        // The following exception was thrown during execution in test generation
        try {
            double double8 = org.apache.commons.math4.util.MathArrays.distance(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray7);
    }
}

