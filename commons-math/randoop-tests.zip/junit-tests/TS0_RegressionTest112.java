import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest112.test113");
        org.apache.commons.math4.fitting.leastsquares.LeastSquaresProblem leastSquaresProblem0 = null;
        org.apache.commons.math4.util.IntegerSequence.Incrementor incrementor1 = null;
        org.apache.commons.math4.fitting.leastsquares.LeastSquaresProblem leastSquaresProblem2 = org.apache.commons.math4.fitting.leastsquares.LeastSquaresFactory.countEvaluations(leastSquaresProblem0, incrementor1);
        org.apache.commons.math4.fitting.leastsquares.LeastSquaresAdapter leastSquaresAdapter3 = new org.apache.commons.math4.fitting.leastsquares.LeastSquaresAdapter(leastSquaresProblem2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(leastSquaresProblem2);
    }
}

