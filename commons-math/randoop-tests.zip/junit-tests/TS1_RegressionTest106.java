import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest106.test107");
        org.apache.commons.math4.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math4.optim.SimpleVectorValueChecker(Double.NaN, (double) (short) -1, (int) 'a');
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair5 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair6 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean7 = simpleVectorValueChecker3.converged((int) (short) -1, pointVectorValuePair5, pointVectorValuePair6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

