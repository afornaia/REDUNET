import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest69.test070");
        org.apache.commons.math4.stat.ranking.NaturalRanking naturalRanking0 = new org.apache.commons.math4.stat.ranking.NaturalRanking();
    }
}

