import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest9.test010");
        org.apache.commons.math4.stat.correlation.StorelessCovariance storelessCovariance2 = new org.apache.commons.math4.stat.correlation.StorelessCovariance((int) (byte) 10, false);
    }
}

