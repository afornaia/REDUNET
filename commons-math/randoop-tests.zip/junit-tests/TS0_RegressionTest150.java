import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest150 {

    public static boolean debug = false;

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest150.test151");
        org.apache.commons.math4.analysis.function.Exp exp0 = new org.apache.commons.math4.analysis.function.Exp();
    }
}

