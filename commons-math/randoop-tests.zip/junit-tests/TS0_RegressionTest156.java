import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest156 {

    public static boolean debug = false;

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest156.test157");
        org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator graggBulirschStoerIntegrator4 = new org.apache.commons.math4.ode.nonstiff.GraggBulirschStoerIntegrator((double) (short) 1, (double) (short) 10, 1.0E-12d, (double) (byte) 100);
    }
}

