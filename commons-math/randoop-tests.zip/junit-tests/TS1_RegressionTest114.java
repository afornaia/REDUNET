import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest114 {

    public static boolean debug = false;

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest114.test115");
        org.apache.commons.math4.analysis.solvers.LaguerreSolver laguerreSolver2 = new org.apache.commons.math4.analysis.solvers.LaguerreSolver((double) (byte) 10, (double) (short) 1);
        org.apache.commons.math4.analysis.polynomials.PolynomialFunction polynomialFunction4 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double8 = laguerreSolver2.solve(100, polynomialFunction4, (double) (short) -1, (double) (-1.0f), 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
    }
}

