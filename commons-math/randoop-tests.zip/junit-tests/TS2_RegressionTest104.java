import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest104.test105");
        org.apache.commons.math4.analysis.BivariateFunction bivariateFunction0 = null;
        org.apache.commons.math4.analysis.function.Sinc sinc1 = new org.apache.commons.math4.analysis.function.Sinc();
        org.apache.commons.math4.analysis.MultivariateFunction multivariateFunction3 = org.apache.commons.math4.analysis.FunctionUtils.collector(bivariateFunction0, (org.apache.commons.math4.analysis.UnivariateFunction) sinc1, (double) 10.0f);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multivariateFunction3);
    }
}

