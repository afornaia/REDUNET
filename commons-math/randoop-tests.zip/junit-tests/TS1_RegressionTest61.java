import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest61.test062");
        org.apache.commons.math4.stat.descriptive.moment.Variance variance1 = new org.apache.commons.math4.stat.descriptive.moment.Variance(false);
        org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver(0.0d);
        boolean boolean4 = variance1.equals((java.lang.Object) 0.0d);
        org.apache.commons.math4.stat.descriptive.moment.Variance variance5 = new org.apache.commons.math4.stat.descriptive.moment.Variance(variance1);
        double[] doubleArray9 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray9);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray9);
        double double14 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray9, 0, 0);
        org.apache.commons.math4.linear.JacobiPreconditioner jacobiPreconditioner16 = new org.apache.commons.math4.linear.JacobiPreconditioner(doubleArray9, true);
        // The following exception was thrown during execution in test generation
        try {
            double double19 = variance5.evaluate(doubleArray9, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooLargeException; message: subarray ends after array end");
        } catch (org.apache.commons.math4.exception.NumberIsTooLargeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }
}

