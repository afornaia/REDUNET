import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest125.test126");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = derivativeStructure3.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure8 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure9 = derivativeStructure8.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure13 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray14 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure8, derivativeStructure13 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix15 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray14);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure19 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure20 = derivativeStructure19.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure24 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray25 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure19, derivativeStructure24 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix26 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray25);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure27 = derivativeStructure3.linearCombination(derivativeStructureArray14, derivativeStructureArray25);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure29 = derivativeStructure27.multiply((double) (byte) 100);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure30 = derivativeStructure27.asinh();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure30);
    }
}

