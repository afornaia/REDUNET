import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest120 {

    public static boolean debug = false;

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest120.test121");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = derivativeStructure3.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure5 = derivativeStructure3.sinh();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure5);
    }
}

