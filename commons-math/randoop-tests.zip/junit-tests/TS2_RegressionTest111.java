import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest111.test112");
        double[] doubleArray1 = new double[] { 'a' };
        int int2 = org.apache.commons.math4.util.MathUtils.hash(doubleArray1);
        org.apache.commons.math4.stat.inference.MannWhitneyUTest mannWhitneyUTest3 = new org.apache.commons.math4.stat.inference.MannWhitneyUTest();
        double[] doubleArray6 = new double[] { 10.0d, ' ' };
        double[] doubleArray7 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair8 = new org.apache.commons.math4.optim.PointVectorValuePair(doubleArray6, doubleArray7);
        double[] doubleArray9 = pointVectorValuePair8.getPointRef();
        double[] doubleArray11 = new double[] { 'a' };
        int int12 = org.apache.commons.math4.util.MathUtils.hash(doubleArray11);
        double double13 = mannWhitneyUTest3.mannWhitneyU(doubleArray9, doubleArray11);
        // The following exception was thrown during execution in test generation
        try {
            double double15 = org.apache.commons.math4.stat.StatUtils.varianceDifference(doubleArray1, doubleArray11, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (2)");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079525407 + "'", int2 == 1079525407);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1079525407 + "'", int12 == 1079525407);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.0d + "'", double13 == 2.0d);
    }
}

