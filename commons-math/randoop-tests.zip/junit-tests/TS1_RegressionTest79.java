import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest79.test080");
        double[] doubleArray6 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray6);
        double[] doubleArray11 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray11);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray11);
        double double15 = org.apache.commons.math4.stat.StatUtils.variance(doubleArray11, (double) 1.0f);
        org.apache.commons.math4.optim.SimpleBounds simpleBounds16 = new org.apache.commons.math4.optim.SimpleBounds(doubleArray6, doubleArray11);
        org.apache.commons.math4.ml.clustering.DoublePoint doublePoint17 = new org.apache.commons.math4.ml.clustering.DoublePoint(doubleArray11);
        double[] doubleArray21 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray21);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray21);
        double double24 = org.apache.commons.math4.stat.StatUtils.sumDifference(doubleArray11, doubleArray21);
        double[] doubleArray28 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray28);
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray28);
        double double33 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray28, 0, 0);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.ode.nonstiff.AdamsBashforthIntegrator adamsBashforthIntegrator34 = new org.apache.commons.math4.ode.nonstiff.AdamsBashforthIntegrator(0, (double) (byte) 0, (double) 0.0f, doubleArray21, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative size");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3367.0d + "'", double15 == 3367.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }
}

