import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest85.test086");
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure3 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = derivativeStructure3.cbrt();
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D5 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure9 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = derivativeStructure9.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure14 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure15 = derivativeStructure14.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure19 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray20 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure14, derivativeStructure19 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix21 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray20);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure25 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure26 = derivativeStructure25.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure30 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray31 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure25, derivativeStructure30 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix32 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray31);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure33 = derivativeStructure9.linearCombination(derivativeStructureArray20, derivativeStructureArray31);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure34 = derivativeStructure33.atan();
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D35 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure39 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure40 = derivativeStructure39.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure44 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure45 = derivativeStructure44.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure49 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray50 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure44, derivativeStructure49 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix51 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray50);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure55 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure56 = derivativeStructure55.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure60 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray61 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure55, derivativeStructure60 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix62 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray61);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure63 = derivativeStructure39.linearCombination(derivativeStructureArray50, derivativeStructureArray61);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure65 = derivativeStructure63.multiply((double) (byte) 100);
        org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D66 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldVector3D67 = new org.apache.commons.math4.geometry.euclidean.threed.FieldVector3D<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructure3, derivativeStructureFieldVector3D5, derivativeStructure34, derivativeStructureFieldVector3D35, derivativeStructure65, derivativeStructureFieldVector3D66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure63);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure65);
    }
}

