import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest137 {

    public static boolean debug = false;

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest137.test138");
        org.apache.commons.math4.analysis.function.Asinh asinh0 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray7 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair8 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh0, doubleArray7);
        org.apache.commons.math4.special.BesselJ.BesselJResult besselJResult10 = new org.apache.commons.math4.special.BesselJ.BesselJResult(doubleArray7, (int) (short) -1);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math4.linear.OpenMapRealVector(doubleArray7);
        double[] doubleArray12 = new double[] {};
        double double13 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray12);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math4.linear.OpenMapRealVector(doubleArray12);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector11.add(openMapRealVector14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 6 != 0");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }
}

