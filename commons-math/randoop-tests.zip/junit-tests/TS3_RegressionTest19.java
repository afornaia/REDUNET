import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest19.test020");
        org.apache.commons.math4.ode.nonstiff.MidpointIntegrator midpointIntegrator1 = new org.apache.commons.math4.ode.nonstiff.MidpointIntegrator((double) '4');
        org.apache.commons.math4.ode.FirstOrderDifferentialEquations firstOrderDifferentialEquations2 = null;
        double[] doubleArray10 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray10, false);
        double[] doubleArray19 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix21 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray19, false);
        double[] doubleArray22 = diagonalMatrix12.operate(doubleArray19);
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray24 = midpointIntegrator1.singleStep(firstOrderDifferentialEquations2, (double) '#', doubleArray22, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray22);
    }
}

