import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest90.test091");
        org.apache.commons.math4.optim.linear.NonNegativeConstraint nonNegativeConstraint1 = new org.apache.commons.math4.optim.linear.NonNegativeConstraint(false);
    }
}

