import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest124 {

    public static boolean debug = false;

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest124.test125");
        long[] longArray3 = new long[] { (byte) 10, (short) -1, 'a' };
        long[] longArray7 = new long[] { 1L, '4', (short) 1 };
        // The following exception was thrown during execution in test generation
        try {
            double double8 = org.apache.commons.math4.stat.inference.InferenceTestUtils.chiSquareTestDataSetsComparison(longArray3, longArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: -1 is smaller than the minimum (0)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray7);
    }
}

