import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest123 {

    public static boolean debug = false;

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest123.test124");
        org.apache.commons.math4.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math4.exception.NumberIsTooSmallException((java.lang.Number) (-1.0d), (java.lang.Number) (-1L), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }
}

