import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest120 {

    public static boolean debug = false;

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest120.test121");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.ARRAY_ZERO_LENGTH_OR_NULL_NOT_ALLOWED;
        org.apache.commons.math4.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math4.exception.NotPositiveException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        org.apache.commons.math4.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math4.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        boolean boolean7 = openMapRealVector6.isNaN();
        org.apache.commons.math4.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math4.linear.OpenMapRealVector((int) (byte) 0);
        double double10 = openMapRealVector6.getL1Distance((org.apache.commons.math4.linear.RealVector) openMapRealVector9);
        exceptionContext3.setValue("hi!", (java.lang.Object) double10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.ARRAY_ZERO_LENGTH_OR_NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.ARRAY_ZERO_LENGTH_OR_NULL_NOT_ALLOWED));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }
}

