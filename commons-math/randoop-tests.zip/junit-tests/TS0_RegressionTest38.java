import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest38.test039");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        // The following exception was thrown during execution in test generation
        try {
            double[] doubleArray4 = org.apache.commons.math4.stat.StatUtils.mode(doubleArray0, (int) '4', (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: length (-1)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }
}

