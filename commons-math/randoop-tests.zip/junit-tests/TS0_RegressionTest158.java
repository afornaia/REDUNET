import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest158 {

    public static boolean debug = false;

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest158.test159");
        org.apache.commons.rng.UniformRandomProvider uniformRandomProvider0 = null;
        org.apache.commons.math4.genetics.GeneticAlgorithm.setRandomGenerator(uniformRandomProvider0);
    }
}

