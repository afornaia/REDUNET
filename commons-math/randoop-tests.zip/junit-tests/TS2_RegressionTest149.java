import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest149 {

    public static boolean debug = false;

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest149.test150");
        double[] doubleArray2 = new double[] { 10.0d, ' ' };
        double[] doubleArray3 = null;
        org.apache.commons.math4.optim.PointVectorValuePair pointVectorValuePair4 = new org.apache.commons.math4.optim.PointVectorValuePair(doubleArray2, doubleArray3);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.optim.nonlinear.scalar.noderiv.NelderMeadSimplex nelderMeadSimplex5 = new org.apache.commons.math4.optim.nonlinear.scalar.noderiv.NelderMeadSimplex(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray2);
    }
}

