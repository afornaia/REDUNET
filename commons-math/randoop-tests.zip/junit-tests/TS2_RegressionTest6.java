import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest6.test007");
        org.apache.commons.math4.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math4.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        java.lang.Number number1 = null;
        org.apache.commons.math4.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math4.exception.NotStrictlyPositiveException((org.apache.commons.math4.exception.util.Localizable) localizedFormats0, number1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math4.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math4.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }
}

