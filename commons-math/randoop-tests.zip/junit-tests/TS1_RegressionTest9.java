import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest9.test010");
        double[] doubleArray5 = new double[] { (short) 100, (-1.0f), 'a', ' ', 1.0f };
        double[] doubleArray9 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray9);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean12 = org.apache.commons.math4.stat.inference.InferenceTestUtils.tTest(doubleArray5, doubleArray9, 1.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: significance level (1)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
    }
}

