import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest34.test035");
        org.apache.commons.math4.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math4.linear.MatrixDimensionMismatchException((int) (short) 10, (int) (byte) 10, (int) ' ', (int) (byte) 10);
        java.lang.Integer[] intArray5 = matrixDimensionMismatchException4.getExpectedDimensions();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray5);
    }
}

