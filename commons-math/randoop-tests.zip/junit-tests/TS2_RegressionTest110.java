import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest110.test111");
        org.apache.commons.math4.Field<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureField0 = null;
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure4 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure5 = derivativeStructure4.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure9 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure10 = derivativeStructure9.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure14 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray15 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure9, derivativeStructure14 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix16 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray15);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure20 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure21 = derivativeStructure20.cbrt();
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure25 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure(100, (int) (short) 1, (double) '4');
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] derivativeStructureArray26 = new org.apache.commons.math4.analysis.differentiation.DerivativeStructure[] { derivativeStructure20, derivativeStructure25 };
        org.apache.commons.math4.linear.FieldMatrix<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureFieldMatrix27 = org.apache.commons.math4.linear.MatrixUtils.createColumnFieldMatrix(derivativeStructureArray26);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure28 = derivativeStructure4.linearCombination(derivativeStructureArray15, derivativeStructureArray26);
        org.apache.commons.math4.analysis.differentiation.DerivativeStructure derivativeStructure29 = derivativeStructure28.atan();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.ode.nonstiff.ClassicalRungeKuttaFieldIntegrator<org.apache.commons.math4.analysis.differentiation.DerivativeStructure> derivativeStructureClassicalRungeKuttaFieldIntegrator30 = new org.apache.commons.math4.ode.nonstiff.ClassicalRungeKuttaFieldIntegrator<org.apache.commons.math4.analysis.differentiation.DerivativeStructure>(derivativeStructureField0, derivativeStructure29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructureFieldMatrix27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(derivativeStructure29);
    }
}

