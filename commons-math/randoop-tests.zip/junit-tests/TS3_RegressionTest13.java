import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest13.test014");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math4.genetics.ElitisticListPopulation((int) (byte) 1, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
    }
}

