import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest108.test109");
        org.apache.commons.math4.optim.SimpleVectorValueChecker simpleVectorValueChecker3 = new org.apache.commons.math4.optim.SimpleVectorValueChecker(Double.NaN, (double) (short) -1, (int) 'a');
        double double4 = simpleVectorValueChecker3.getAbsoluteThreshold();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }
}

