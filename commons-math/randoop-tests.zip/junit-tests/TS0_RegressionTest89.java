import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest89.test090");
        org.apache.commons.math4.analysis.function.Log10 log10_0 = new org.apache.commons.math4.analysis.function.Log10();
        org.apache.commons.math4.ml.neuralnet.FeatureInitializer featureInitializer3 = org.apache.commons.math4.ml.neuralnet.FeatureInitializerFactory.function((org.apache.commons.math4.analysis.UnivariateFunction) log10_0, (double) (short) 0, (double) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureInitializer3);
    }
}

