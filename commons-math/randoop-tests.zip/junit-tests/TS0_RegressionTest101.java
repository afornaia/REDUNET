import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest101.test102");
        org.apache.commons.math4.analysis.solvers.BrentSolver brentSolver3 = new org.apache.commons.math4.analysis.solvers.BrentSolver((double) (short) 1, 1.0d, (double) (byte) 10);
        double double4 = brentSolver3.getMin();
        double double5 = brentSolver3.getMax();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }
}

