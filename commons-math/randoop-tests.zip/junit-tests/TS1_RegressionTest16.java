import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest16.test017");
        org.apache.commons.math4.stat.descriptive.moment.SemiVariance semiVariance0 = null;
        org.apache.commons.math4.stat.descriptive.moment.SemiVariance semiVariance1 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.stat.descriptive.moment.SemiVariance.copy(semiVariance0, semiVariance1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math4.exception.NullArgumentException e) {
        // Expected exception.
        }
    }
}

