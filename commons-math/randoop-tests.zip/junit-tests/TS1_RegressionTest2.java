import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest2.test003");
        org.apache.commons.math4.ode.events.Action action0 = org.apache.commons.math4.ode.events.Action.RESET_DERIVATIVES;
        org.junit.Assert.assertTrue("'" + action0 + "' != '" + org.apache.commons.math4.ode.events.Action.RESET_DERIVATIVES + "'", action0.equals(org.apache.commons.math4.ode.events.Action.RESET_DERIVATIVES));
    }
}

