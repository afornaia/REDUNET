import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest87.test088");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        double[] doubleArray6 = new double[] { 100, (byte) 100, (short) 1, 10 };
        // The following exception was thrown during execution in test generation
        try {
            double double7 = org.apache.commons.math4.stat.inference.InferenceTestUtils.kolmogorovSmirnovTest(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.InsufficientDataException; message: sample contains 0 observed points, at least 2 are required");
        } catch (org.apache.commons.math4.exception.InsufficientDataException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
    }
}

