import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest96.test097");
        double[] doubleArray0 = new double[] {};
        double double1 = org.apache.commons.math4.stat.StatUtils.sum(doubleArray0);
        org.apache.commons.math4.optim.linear.Relationship relationship2 = null;
        org.apache.commons.math4.optim.linear.LinearConstraint linearConstraint4 = new org.apache.commons.math4.optim.linear.LinearConstraint(doubleArray0, relationship2, (double) 100);
        org.apache.commons.math4.analysis.function.Asinh asinh5 = new org.apache.commons.math4.analysis.function.Asinh();
        double[] doubleArray12 = new double[] { 1.0f, 10L, (-1.0f), 10.0d, '4', (short) 1 };
        org.apache.commons.math4.util.Pair<org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction, double[]> univariateDifferentiableFunctionPair13 = org.apache.commons.math4.util.Pair.create((org.apache.commons.math4.analysis.differentiation.UnivariateDifferentiableFunction) asinh5, doubleArray12);
        org.apache.commons.math4.random.NormalizedRandomGenerator normalizedRandomGenerator14 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.random.UncorrelatedRandomVectorGenerator uncorrelatedRandomVectorGenerator15 = new org.apache.commons.math4.random.UncorrelatedRandomVectorGenerator(doubleArray0, doubleArray12, normalizedRandomGenerator14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 0 != 6");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(univariateDifferentiableFunctionPair13);
    }
}

