import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest100.test101");
        long[] longArray1 = new long[] { 10 };
        long[] longArray7 = new long[] { ' ', '#', 97, '#', (short) -1 };
        // The following exception was thrown during execution in test generation
        try {
            double double8 = org.apache.commons.math4.stat.inference.InferenceTestUtils.gDataSetsComparison(longArray1, longArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math4.exception.DimensionMismatchException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray7);
    }
}

