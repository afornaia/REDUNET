import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest63.test064");
        float[] floatArray0 = new float[] {};
        float[] floatArray7 = new float[] { 10, (byte) 0, (-1.0f), (short) -1, (short) 10, 100.0f };
        boolean boolean8 = org.apache.commons.math4.util.MathArrays.equalsIncludingNaN(floatArray0, floatArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(floatArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(floatArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }
}

