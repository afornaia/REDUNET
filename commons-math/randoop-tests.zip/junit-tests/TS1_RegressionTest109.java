import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest109 {

    public static boolean debug = false;

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest109.test110");
        org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics synchronizedDescriptiveStatistics0 = new org.apache.commons.math4.stat.descriptive.SynchronizedDescriptiveStatistics();
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics1 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics((org.apache.commons.math4.stat.descriptive.DescriptiveStatistics) synchronizedDescriptiveStatistics0);
        org.apache.commons.math4.stat.descriptive.moment.Variance variance3 = new org.apache.commons.math4.stat.descriptive.moment.Variance(false);
        org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver5 = new org.apache.commons.math4.analysis.solvers.RegulaFalsiSolver(0.0d);
        boolean boolean6 = variance3.equals((java.lang.Object) 0.0d);
        double double7 = synchronizedDescriptiveStatistics0.apply((org.apache.commons.math4.stat.descriptive.UnivariateStatistic) variance3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }
}

