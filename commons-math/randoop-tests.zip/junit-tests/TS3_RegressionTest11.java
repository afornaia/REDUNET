import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest11.test012");
        double[] doubleArray6 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix8 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray6, false);
        double[] doubleArray15 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix17 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray15, false);
        double[] doubleArray18 = diagonalMatrix8.operate(doubleArray15);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.RectangularCholeskyDecomposition rectangularCholeskyDecomposition20 = new org.apache.commons.math4.linear.RectangularCholeskyDecomposition((org.apache.commons.math4.linear.RealMatrix) diagonalMatrix8, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.linear.NonPositiveDefiniteMatrixException; message: -1 is smaller than, or equal to, the minimum (-1): not positive definite matrix: value -1 at index 3");
        } catch (org.apache.commons.math4.linear.NonPositiveDefiniteMatrixException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray18);
    }
}

