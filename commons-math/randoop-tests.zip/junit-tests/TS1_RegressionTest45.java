import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest45 {

    public static boolean debug = false;

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest45.test046");
        double[] doubleArray0 = new double[] {};
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean3 = org.apache.commons.math4.util.MathArrays.verifyValues(doubleArray0, (-1), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NotPositiveException; message: start position (-1)");
        } catch (org.apache.commons.math4.exception.NotPositiveException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray0);
    }
}

