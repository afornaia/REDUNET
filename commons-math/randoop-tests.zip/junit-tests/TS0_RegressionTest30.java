import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest30.test031");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.solvers.BracketingNthOrderBrentSolver bracketingNthOrderBrentSolver4 = new org.apache.commons.math4.analysis.solvers.BracketingNthOrderBrentSolver((double) 1, (double) 'a', 0.0d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (2)");
        } catch (org.apache.commons.math4.exception.NumberIsTooSmallException e) {
        // Expected exception.
        }
    }
}

