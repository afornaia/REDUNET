import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest111.test112");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.analysis.integration.MidPointIntegrator midPointIntegrator2 = new org.apache.commons.math4.analysis.integration.MidPointIntegrator(10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (63)");
        } catch (org.apache.commons.math4.exception.NumberIsTooLargeException e) {
        // Expected exception.
        }
    }
}

