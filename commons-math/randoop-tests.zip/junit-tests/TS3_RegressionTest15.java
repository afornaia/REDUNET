import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest15.test016");
        org.apache.commons.math4.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math4.linear.BlockRealMatrix((int) '#', (int) (byte) 1);
        double[] doubleArray10 = new double[] { (byte) 10, (-1), 10.0d, (byte) 100, (-1), (-1.0f) };
        org.apache.commons.math4.linear.DiagonalMatrix diagonalMatrix12 = new org.apache.commons.math4.linear.DiagonalMatrix(doubleArray10, false);
        // The following exception was thrown during execution in test generation
        try {
            blockRealMatrix2.setColumnMatrix((int) (byte) 1, (org.apache.commons.math4.linear.RealMatrix) diagonalMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math4.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math4.exception.OutOfRangeException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray10);
    }
}

