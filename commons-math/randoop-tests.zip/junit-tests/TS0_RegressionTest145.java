import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest145 {

    public static boolean debug = false;

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest145.test146");
        double double0 = org.apache.commons.math4.linear.CholeskyDecomposition.DEFAULT_RELATIVE_SYMMETRY_THRESHOLD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-15d + "'", double0 == 1.0E-15d);
    }
}

