import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest129 {

    public static boolean debug = false;

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest129.test130");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 1.0d };
        org.apache.commons.math4.stat.descriptive.DescriptiveStatistics descriptiveStatistics2 = new org.apache.commons.math4.stat.descriptive.DescriptiveStatistics(doubleArray1);
        descriptiveStatistics2.addValue((double) (-1L));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray1);
    }
}

