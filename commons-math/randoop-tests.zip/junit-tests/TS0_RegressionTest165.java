import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest165 {

    public static boolean debug = false;

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest165.test166");
        org.apache.commons.math4.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math4.dfp.DfpField.RoundingMode.ROUND_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math4.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode0.equals(org.apache.commons.math4.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }
}

