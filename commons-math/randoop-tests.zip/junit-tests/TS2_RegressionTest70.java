import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest70.test071");
        org.apache.commons.math4.linear.NonSquareOperatorException nonSquareOperatorException2 = new org.apache.commons.math4.linear.NonSquareOperatorException(1, (int) (short) -1);
    }
}

