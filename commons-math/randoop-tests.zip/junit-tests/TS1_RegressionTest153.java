import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest153 {

    public static boolean debug = false;

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest153.test154");
        double[] doubleArray3 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray3);
        org.apache.commons.math4.linear.RealMatrix realMatrix5 = org.apache.commons.math4.linear.MatrixUtils.createRealMatrixWithDiagonal(doubleArray3);
        double[] doubleArray9 = new double[] { 100.0d, 0L, (-1L) };
        org.apache.commons.math4.util.MathUtils.checkFinite(doubleArray9);
        org.apache.commons.math4.linear.RealMatrix realMatrix11 = org.apache.commons.math4.linear.MatrixUtils.createRealMatrixWithDiagonal(doubleArray9);
        realMatrix5.checkMultiply((org.apache.commons.math4.linear.AnyMatrix) realMatrix11);
        java.io.ObjectOutputStream objectOutputStream13 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.math4.linear.MatrixUtils.serializeRealMatrix(realMatrix11, objectOutputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(realMatrix11);
    }
}

