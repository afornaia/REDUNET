import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest148 {

    public static boolean debug = false;

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest148.test149");
        double[] doubleArray5 = new double[] { ' ', 100L, (short) 0, ' ', 100 };
        org.apache.commons.math4.util.MathArrays.checkNotNaN(doubleArray5);
        org.apache.commons.math4.util.MathArrays.OrderDirection orderDirection7 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean10 = org.apache.commons.math4.util.MathArrays.checkOrder(doubleArray5, orderDirection7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(doubleArray5);
    }
}

