import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest2.test003");
        org.apache.commons.math4.stat.descriptive.rank.Percentile.EstimationType estimationType0 = org.apache.commons.math4.stat.descriptive.rank.Percentile.EstimationType.R_6;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(estimationType0);
    }
}

