import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest42.test043");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = junit.framework.JUnit4TestAdapterCache.getDefault();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache1 = junit.framework.JUnit4TestAdapterCache.getDefault();
        jUnit4TestAdapterCache0.putAll((java.util.Map<org.junit.runner.Description, junit.framework.Test>) jUnit4TestAdapterCache1);
        boolean boolean5 = jUnit4TestAdapterCache1.remove((java.lang.Object) 0.0d, (java.lang.Object) (-1L));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnit4TestAdapterCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnit4TestAdapterCache1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

