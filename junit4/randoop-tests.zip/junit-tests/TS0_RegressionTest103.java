import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest103.test104");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = junit.framework.JUnit4TestAdapterCache.getDefault();
        java.util.Collection<junit.framework.Test> testCollection1 = jUnit4TestAdapterCache0.values();
        junit.framework.TestResult testResult2 = null;
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter3 = null;
        org.junit.runner.notification.RunNotifier runNotifier4 = jUnit4TestAdapterCache0.getNotifier(testResult2, jUnit4TestAdapter3);
        org.junit.runner.Description description5 = null;
        runNotifier4.fireTestFinished(description5);
        java.io.PrintStream printStream7 = null;
        org.junit.internal.TextListener textListener8 = new org.junit.internal.TextListener(printStream7);
        org.junit.runner.Description description12 = org.junit.runner.Description.createTestDescription("4.13-SNAPSHOT", "categories [all]", (java.io.Serializable) 100.0f);
        textListener8.testRunStarted(description12);
        runNotifier4.fireTestFinished(description12);
        boolean boolean15 = description12.isSuite();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnit4TestAdapterCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }
}

