import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest83.test084");
        junit.textui.ResultPrinter resultPrinter0 = null;
        junit.textui.TestRunner testRunner1 = new junit.textui.TestRunner(resultPrinter0);
        java.lang.String str3 = testRunner1.extractClassName("");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache4 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult5 = new junit.framework.TestResult();
        junit.framework.Test test6 = null;
        junit.framework.AssertionFailedError assertionFailedError7 = null;
        testResult5.addFailure(test6, assertionFailedError7);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter9 = null;
        org.junit.runner.notification.RunNotifier runNotifier10 = jUnit4TestAdapterCache4.getNotifier(testResult5, jUnit4TestAdapter9);
        junit.framework.Test test11 = null;
        org.junit.internal.runners.InitializationError initializationError13 = new org.junit.internal.runners.InitializationError("");
        testResult5.addError(test11, (java.lang.Throwable) initializationError13);
        junit.framework.TestSuite testSuite15 = new junit.framework.TestSuite();
        junit.framework.Test test16 = null;
        junit.extensions.TestSetup testSetup17 = new junit.extensions.TestSetup(test16);
        junit.extensions.TestSetup testSetup19 = org.junit.internal.Checks.notNull(testSetup17, "hi!");
        junit.framework.TestResult testResult20 = new junit.framework.TestResult();
        testSuite15.runTest((junit.framework.Test) testSetup17, testResult20);
        junit.framework.Protectable protectable22 = null;
        testResult5.runProtected((junit.framework.Test) testSetup17, protectable22);
        junit.framework.AssertionFailedError assertionFailedError24 = new junit.framework.AssertionFailedError();
        testRunner1.addFailure((junit.framework.Test) testSetup17, assertionFailedError24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup19);
    }
}

