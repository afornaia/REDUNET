import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest49.test50");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray2 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray1;
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray1, "hi!");
        junit.framework.TestResult testResult5 = junit.textui.TestRunner.run((junit.framework.Test) testSuite4);
        testResult5.stop();
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration7 = testResult5.failures();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration7);
    }
}

