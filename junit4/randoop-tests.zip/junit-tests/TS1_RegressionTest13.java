import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest13.test14");
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException0 = new org.junit.runner.manipulation.InvalidOrderingException();
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException1 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) invalidOrderingException0);
    }
}

