import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest60.test061");
        org.junit.runner.notification.RunNotifier runNotifier0 = new org.junit.runner.notification.RunNotifier();
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        org.junit.runner.Result result4 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray2);
        runNotifier0.fireTestRunFinished(result4);
        org.junit.runner.notification.Failure failure6 = null;
        runNotifier0.fireTestAssumptionFailed(failure6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result4);
    }
}

