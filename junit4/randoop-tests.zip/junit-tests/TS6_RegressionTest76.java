import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest76.test077");
        org.junit.internal.runners.InitializationError initializationError1 = new org.junit.internal.runners.InitializationError("");
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException3 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) couldNotGenerateValueException2);
        org.junit.ComparisonFailure comparisonFailure7 = new org.junit.ComparisonFailure("expected:<()> but was:<0>", "hi!", "{}");
        org.junit.ComparisonFailure comparisonFailure11 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        java.lang.String str12 = comparisonFailure11.getActual();
        java.lang.Throwable[] throwableArray13 = new java.lang.Throwable[] { initializationError1, couldNotGenerateValueException3, comparisonFailure7, comparisonFailure11 };
        org.junit.internal.runners.InitializationError initializationError14 = new org.junit.internal.runners.InitializationError(throwableArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray13);
    }
}

