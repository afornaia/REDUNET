import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest71.test072");
        java.lang.String str1 = junit.runner.BaseTestRunner.truncate("4.13-SNAPSHOT");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.13-SNAPSHOT" + "'", str1.equals("4.13-SNAPSHOT"));
    }
}

