import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest91 {

    public static boolean debug = false;

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest91.test092");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache2 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj3 = jUnit4TestAdapterCache2.clone();
        java.util.Set<java.util.Map.Entry<org.junit.runner.Description, junit.framework.Test>> descriptionEntrySet4 = jUnit4TestAdapterCache2.entrySet();
        junit.framework.Test test6 = null;
        junit.extensions.TestSetup testSetup7 = new junit.extensions.TestSetup(test6);
        junit.framework.Test test8 = jUnit4TestAdapterCache2.getOrDefault((java.lang.Object) 0.0d, test6);
        jUnit4TestAdapterCache0.putAll((java.util.Map<org.junit.runner.Description, junit.framework.Test>) jUnit4TestAdapterCache2);
        org.junit.runner.manipulation.Sorter sorter10 = org.junit.runner.manipulation.Sorter.NULL;
        org.junit.runner.Description description14 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams16 = new org.junit.runner.FilterFactoryParams(description14, "");
        org.junit.runner.Description description17 = description14.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description17);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache19 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult20 = new junit.framework.TestResult();
        junit.framework.Test test21 = null;
        junit.framework.AssertionFailedError assertionFailedError22 = null;
        testResult20.addFailure(test21, assertionFailedError22);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter24 = null;
        org.junit.runner.notification.RunNotifier runNotifier25 = jUnit4TestAdapterCache19.getNotifier(testResult20, jUnit4TestAdapter24);
        org.junit.runner.Description description29 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams31 = new org.junit.runner.FilterFactoryParams(description29, "");
        org.junit.runner.Description description32 = description29.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description32);
        runNotifier25.fireTestSuiteFinished(description32);
        int int35 = sorter10.compare(description17, description32);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache36 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult37 = new junit.framework.TestResult();
        junit.framework.Test test38 = null;
        junit.framework.AssertionFailedError assertionFailedError39 = null;
        testResult37.addFailure(test38, assertionFailedError39);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter41 = null;
        org.junit.runner.notification.RunNotifier runNotifier42 = jUnit4TestAdapterCache36.getNotifier(testResult37, jUnit4TestAdapter41);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache43 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult44 = new junit.framework.TestResult();
        junit.framework.Test test45 = null;
        junit.framework.AssertionFailedError assertionFailedError46 = null;
        testResult44.addFailure(test45, assertionFailedError46);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter48 = null;
        org.junit.runner.notification.RunNotifier runNotifier49 = jUnit4TestAdapterCache43.getNotifier(testResult44, jUnit4TestAdapter48);
        org.junit.runner.Description description53 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams55 = new org.junit.runner.FilterFactoryParams(description53, "");
        org.junit.runner.Description description56 = description53.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description56);
        runNotifier49.fireTestSuiteFinished(description56);
        junit.framework.TestSuite testSuite59 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite60 = new junit.framework.TestSuite();
        boolean boolean61 = jUnit4TestAdapterCache36.replace(description56, (junit.framework.Test) testSuite59, (junit.framework.Test) testSuite60);
        junit.framework.Test test62 = jUnit4TestAdapterCache0.putIfAbsent(description17, (junit.framework.Test) testSuite60);
        java.lang.String str63 = testSuite60.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj3.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionEntrySet4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sorter10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test62);
    }
}

