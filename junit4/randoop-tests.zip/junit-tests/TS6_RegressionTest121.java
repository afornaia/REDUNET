import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest121 {

    public static boolean debug = false;

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest121.test122");
        java.lang.Object obj2 = null;
        org.junit.Assert.assertNotSame("", (java.lang.Object) (short) 100, obj2);
    }
}

