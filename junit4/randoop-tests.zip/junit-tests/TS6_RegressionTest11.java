import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest11.test012");
        org.junit.internal.runners.InitializationError initializationError1 = new org.junit.internal.runners.InitializationError("");
        java.lang.Throwable throwable2 = null;
        org.junit.experimental.max.CouldNotReadCoreException couldNotReadCoreException3 = new org.junit.experimental.max.CouldNotReadCoreException(throwable2);
        java.lang.Throwable[] throwableArray4 = new java.lang.Throwable[] { initializationError1, throwable2 };
        java.util.ArrayList<java.lang.Throwable> throwableList5 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList5, throwableArray4);
        org.junit.runners.model.InitializationError initializationError7 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList5);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeNoException((java.lang.Throwable) initializationError7);
            org.junit.Assert.fail("Expected exception of type org.junit.AssumptionViolatedException; message: got: <org.junit.runners.model.InitializationError>, expected: null");
        } catch (org.junit.AssumptionViolatedException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

