import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest53.test54");
        java.io.File file0 = null;
        org.junit.rules.TemporaryFolder temporaryFolder1 = new org.junit.rules.TemporaryFolder(file0);
        java.lang.String[] strArray4 = new java.lang.String[] { "hi!", "org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n" };
        // The following exception was thrown during execution in test generation
        try {
            java.io.File file5 = temporaryFolder1.newFolder(strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: the temporary folder has not yet been created");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray4);
    }
}

