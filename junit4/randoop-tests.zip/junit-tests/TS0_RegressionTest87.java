import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest87.test088");
        junit.framework.TestResult testResult0 = new junit.framework.TestResult();
        java.io.PrintStream printStream1 = null;
        junit.textui.ResultPrinter resultPrinter2 = new junit.textui.ResultPrinter(printStream1);
        junit.textui.TestRunner testRunner3 = new junit.textui.TestRunner(resultPrinter2);
        testResult0.removeListener((junit.framework.TestListener) resultPrinter2);
        junit.framework.TestResult testResult5 = new junit.framework.TestResult();
        java.io.PrintStream printStream6 = null;
        junit.textui.ResultPrinter resultPrinter7 = new junit.textui.ResultPrinter(printStream6);
        junit.textui.TestRunner testRunner8 = new junit.textui.TestRunner(resultPrinter7);
        testResult5.removeListener((junit.framework.TestListener) resultPrinter7);
        testResult0.removeListener((junit.framework.TestListener) resultPrinter7);
    }
}

