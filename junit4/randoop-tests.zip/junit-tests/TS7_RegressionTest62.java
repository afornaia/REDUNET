import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest62 {

    public static boolean debug = false;

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest62.test063");
        org.junit.experimental.results.PrintableResult printableResult1 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher2 = org.junit.experimental.results.ResultMatchers.isSuccessful();
        org.junit.AssumptionViolatedException assumptionViolatedException3 = new org.junit.AssumptionViolatedException(printableResult1, printableResultMatcher2);
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException4 = new org.junit.runner.manipulation.InvalidOrderingException("hi!", (java.lang.Throwable) assumptionViolatedException3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher2);
    }
}

