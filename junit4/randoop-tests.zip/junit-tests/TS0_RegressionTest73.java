import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest73.test074");
        org.junit.rules.Stopwatch stopwatch0 = new org.junit.rules.Stopwatch();
        org.junit.rules.Stopwatch stopwatch1 = new org.junit.rules.Stopwatch();
        org.junit.runners.model.Statement statement2 = null;
        org.junit.runner.Description description3 = null;
        org.junit.runners.model.Statement statement4 = stopwatch1.apply(statement2, description3);
        org.junit.runner.Description description8 = org.junit.runner.Description.createTestDescription("4.13-SNAPSHOT", "categories [all]", (java.io.Serializable) 100.0f);
        java.util.Collection<java.lang.annotation.Annotation> annotationCollection9 = description8.getAnnotations();
        org.junit.runners.model.Statement statement10 = stopwatch0.apply(statement4, description8);
        java.lang.String str11 = description8.getDisplayName();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationCollection9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "categories [all](4.13-SNAPSHOT)" + "'", str11.equals("categories [all](4.13-SNAPSHOT)"));
    }
}

