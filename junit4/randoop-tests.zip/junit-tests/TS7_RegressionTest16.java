import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest16.test017");
        org.hamcrest.Matcher<java.lang.String> strMatcher3 = org.junit.matchers.JUnitMatchers.containsString("hi!");
        org.junit.runner.Description description4 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description5 = description4.childlessCopy();
        java.lang.Object[] objArray12 = new java.lang.Object[] { 1.0d, 0L, 1L, (byte) 0, 10L };
        java.lang.String str13 = org.junit.experimental.theories.internal.ParameterizedAssertionError.join("", objArray12);
        java.lang.Throwable throwable15 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException16 = new org.junit.AssumptionViolatedException("", throwable15);
        java.lang.Throwable throwable18 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException19 = new org.junit.AssumptionViolatedException("", throwable18);
        assumptionViolatedException16.addSuppressed((java.lang.Throwable) assumptionViolatedException19);
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException21 = new org.junit.TestCouldNotBeSkippedException((org.junit.internal.AssumptionViolatedException) assumptionViolatedException16);
        org.junit.internal.InexactComparisonCriteria inexactComparisonCriteria23 = new org.junit.internal.InexactComparisonCriteria((double) 1.0f);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100, "hi!", description5, "", testCouldNotBeSkippedException21, inexactComparisonCriteria23 };
        java.lang.String str25 = org.junit.experimental.theories.internal.ParameterizedAssertionError.join("hi!", objArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMatcher3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1.001010" + "'", str13.equals("1.001010"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray24);
    }
}

