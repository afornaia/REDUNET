import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest50.test51");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description1 = null;
        junit.framework.Test test2 = null;
        junit.framework.Test test3 = null;
        boolean boolean4 = jUnit4TestAdapterCache0.replace(description1, test2, test3);
        org.junit.runner.Description description5 = null;
        java.lang.Class[] classArray7 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray8 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray7;
        junit.framework.TestSuite testSuite10 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray7, "hi!");
        java.lang.Class[] classArray12 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray13 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray12;
        junit.framework.TestSuite testSuite15 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray12, "hi!");
        java.lang.Class[] classArray17 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray18 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray17;
        junit.framework.TestSuite testSuite20 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray17, "hi!");
        junit.framework.TestResult testResult21 = null;
        testSuite15.runTest((junit.framework.Test) testSuite20, testResult21);
        boolean boolean23 = jUnit4TestAdapterCache0.replace(description5, (junit.framework.Test) testSuite10, (junit.framework.Test) testSuite20);
        org.junit.runner.Description description24 = null;
        java.lang.Class[] classArray26 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray27 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray26;
        junit.framework.TestSuite testSuite29 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray26, "hi!");
        junit.framework.TestResult testResult30 = junit.textui.TestRunner.run((junit.framework.Test) testSuite29);
        java.lang.Class[] classArray32 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray33 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray32;
        junit.framework.TestSuite testSuite35 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray32, "hi!");
        java.lang.Class[] classArray37 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray38 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray37;
        junit.framework.TestSuite testSuite40 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray37, "hi!");
        junit.framework.TestResult testResult41 = null;
        testSuite35.runTest((junit.framework.Test) testSuite40, testResult41);
        java.lang.Class[] classArray44 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray45 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray44;
        junit.framework.TestSuite testSuite47 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray44, "hi!");
        junit.framework.TestResult testResult48 = junit.textui.TestRunner.run((junit.framework.Test) testSuite47);
        testSuite29.runTest((junit.framework.Test) testSuite35, testResult48);
        junit.framework.Test test50 = jUnit4TestAdapterCache0.putIfAbsent(description24, (junit.framework.Test) testSuite35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test50);
    }
}

