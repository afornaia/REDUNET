import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest129 {

    public static boolean debug = false;

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest129.test130");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        java.util.Set<java.util.Map.Entry<org.junit.runner.Description, junit.framework.Test>> descriptionEntrySet2 = jUnit4TestAdapterCache0.entrySet();
        junit.framework.Test test4 = null;
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup(test4);
        junit.framework.Test test6 = jUnit4TestAdapterCache0.getOrDefault((java.lang.Object) 0.0d, test4);
        java.util.concurrent.TimeUnit timeUnit8 = null;
        org.junit.rules.Timeout timeout9 = new org.junit.rules.Timeout((long) (short) 1, timeUnit8);
        boolean boolean10 = jUnit4TestAdapterCache0.containsKey((java.lang.Object) (short) 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionEntrySet2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }
}

