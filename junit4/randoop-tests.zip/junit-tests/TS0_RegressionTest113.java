import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest113.test114");
        org.junit.rules.ErrorCollector errorCollector0 = new org.junit.rules.ErrorCollector();
        java.lang.Throwable throwable1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable1);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException3 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException2);
        errorCollector0.addError((java.lang.Throwable) couldNotGenerateValueException2);
        org.junit.rules.DisableOnDebug disableOnDebug5 = new org.junit.rules.DisableOnDebug((org.junit.rules.TestRule) errorCollector0);
    }
}

