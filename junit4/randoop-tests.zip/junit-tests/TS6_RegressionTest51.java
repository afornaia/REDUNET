import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest51.test052");
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException0 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException1 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) couldNotGenerateValueException0);
        java.lang.Throwable throwable2 = null;
        org.junit.experimental.max.CouldNotReadCoreException couldNotReadCoreException3 = null; // flaky: new org.junit.experimental.max.CouldNotReadCoreException(throwable2);
        java.lang.String str4 = null; // flaky: org.junit.internal.Throwables.getTrimmedStackTrace((java.lang.Throwable) couldNotReadCoreException3);
        junit.framework.AssertionFailedError assertionFailedError5 = new junit.framework.AssertionFailedError();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException6 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException7 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) couldNotGenerateValueException6);
        org.junit.ComparisonFailure comparisonFailure11 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray13, objArray14);
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError16 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) comparisonFailure11, "hi!", objArray13);
        org.junit.internal.runners.InitializationError initializationError18 = new org.junit.internal.runners.InitializationError("");
        org.junit.ComparisonFailure comparisonFailure22 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray24, objArray25);
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError27 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) comparisonFailure22, "hi!", objArray24);
        org.junit.internal.runners.InitializationError initializationError29 = new org.junit.internal.runners.InitializationError("");
        java.lang.Throwable throwable30 = null;
        org.junit.experimental.max.CouldNotReadCoreException couldNotReadCoreException31 = new org.junit.experimental.max.CouldNotReadCoreException(throwable30);
        java.lang.Throwable[] throwableArray32 = new java.lang.Throwable[] { initializationError29, throwable30 };
        java.util.ArrayList<java.lang.Throwable> throwableList33 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList33, throwableArray32);
        org.junit.runners.model.InitializationError initializationError35 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList33);
        java.lang.Throwable[] throwableArray36 = new java.lang.Throwable[] { couldNotGenerateValueException0, couldNotReadCoreException3, assertionFailedError5, couldNotGenerateValueException7, parameterizedAssertionError16, initializationError18, comparisonFailure22, initializationError35 };
        java.util.ArrayList<java.lang.Throwable> throwableList37 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList37, throwableArray36);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.model.MultipleFailureException.assertEmpty((java.util.List<java.lang.Throwable>) throwableList37);
            org.junit.Assert.fail("Expected exception of type org.junit.internal.runners.model.MultipleFailureException; message: There were 8 errors:\n  org.junit.experimental.theories.PotentialAssignment$CouldNotGenerateValueException(null)\n  org.junit.experimental.max.CouldNotReadCoreException(null)\n  junit.framework.AssertionFailedError(null)\n  org.junit.experimental.theories.PotentialAssignment$CouldNotGenerateValueException(org.junit.experimental.theories.PotentialAssignment$CouldNotGenerateValueException)\n  org.junit.experimental.theories.internal.ParameterizedAssertionError(hi!())\n  org.junit.internal.runners.InitializationError(null)\n  org.junit.ComparisonFailure(hi! expected: java.lang.String<hi!> but was: java.lang.String<hi!>)\n  org.junit.runners.model.InitializationError(null)");
        } catch (org.junit.internal.runners.model.MultipleFailureException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.junit.experimental.max.CouldNotReadCoreException\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n" + "'", str4.equals("org.junit.experimental.max.CouldNotReadCoreException\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }
}
