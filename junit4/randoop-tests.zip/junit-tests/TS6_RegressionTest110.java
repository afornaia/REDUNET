import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest110.test111");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache7 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult8 = new junit.framework.TestResult();
        junit.framework.Test test9 = null;
        junit.framework.AssertionFailedError assertionFailedError10 = null;
        testResult8.addFailure(test9, assertionFailedError10);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter12 = null;
        org.junit.runner.notification.RunNotifier runNotifier13 = jUnit4TestAdapterCache7.getNotifier(testResult8, jUnit4TestAdapter12);
        org.junit.runner.Description description17 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams19 = new org.junit.runner.FilterFactoryParams(description17, "");
        org.junit.runner.Description description20 = description17.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description20);
        runNotifier13.fireTestSuiteFinished(description20);
        junit.framework.TestSuite testSuite23 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite24 = new junit.framework.TestSuite();
        boolean boolean25 = jUnit4TestAdapterCache0.replace(description20, (junit.framework.Test) testSuite23, (junit.framework.Test) testSuite24);
        // The following exception was thrown during execution in test generation
        try {
            junit.framework.Test test27 = testSuite23.testAt(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Array index out of range: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }
}

