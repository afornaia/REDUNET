import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest38.test039");
        junit.framework.TestResult testResult0 = new junit.framework.TestResult();
        int int1 = testResult0.errorCount();
        int int2 = testResult0.runCount();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

