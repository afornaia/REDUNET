import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest50.test051");
        org.junit.rules.ErrorCollector errorCollector1 = new org.junit.rules.ErrorCollector();
        java.lang.Throwable throwable2 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException3 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable2);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException4 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException3);
        errorCollector1.addError((java.lang.Throwable) couldNotGenerateValueException3);
        junit.framework.Assert.assertNotSame((java.lang.Object) (short) 100, (java.lang.Object) couldNotGenerateValueException3);
    }
}

