import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest71.test72");
        java.lang.Iterable<? super org.junit.runners.model.RunnerBuilder> wildcardIterable1 = null;
        org.junit.internal.builders.JUnit3Builder jUnit3Builder2 = new org.junit.internal.builders.JUnit3Builder();
        org.hamcrest.Matcher<java.lang.Iterable<? super org.junit.runners.model.RunnerBuilder>> wildcardIterableMatcher3 = org.junit.matchers.JUnitMatchers.hasItem((org.junit.runners.model.RunnerBuilder) jUnit3Builder2);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeThat("hi!", wildcardIterable1, wildcardIterableMatcher3);
            org.junit.Assert.fail("Expected exception of type org.junit.AssumptionViolatedException; message: hi!: got: null, expected: a collection containing <org.junit.internal.builders.JUnit3Builder@55a80634>");
        } catch (org.junit.AssumptionViolatedException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher3);
    }
}

