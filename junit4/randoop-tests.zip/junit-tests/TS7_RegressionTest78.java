import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest78.test079");
        junit.extensions.ActiveTestSuite activeTestSuite0 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite0);
        int int2 = testSetup1.countTestCases();
        junit.framework.TestResult testResult3 = junit.textui.TestRunner.run((junit.framework.Test) testSetup1);
        junit.extensions.ActiveTestSuite activeTestSuite4 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite4);
        junit.framework.AssertionFailedError assertionFailedError6 = null;
        testResult3.addFailure((junit.framework.Test) activeTestSuite4, assertionFailedError6);
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration8 = testResult3.errors();
        junit.extensions.ActiveTestSuite activeTestSuite9 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup10 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite9);
        testResult3.startTest((junit.framework.Test) activeTestSuite9);
        // The following exception was thrown during execution in test generation
        try {
            junit.framework.Test test13 = activeTestSuite9.testAt((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Array index out of range: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration8);
    }
}

