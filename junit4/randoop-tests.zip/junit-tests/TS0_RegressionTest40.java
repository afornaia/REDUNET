import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest40.test041");
        org.junit.runner.manipulation.Ordering.Factory factory0 = null;
        org.junit.runner.Description description4 = org.junit.runner.Description.createTestDescription("4.13-SNAPSHOT", "categories [all]", (java.io.Serializable) 100.0f);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runner.manipulation.Ordering ordering5 = org.junit.runner.manipulation.Ordering.definedBy(factory0, description4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: factory cannot be null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description4);
    }
}

