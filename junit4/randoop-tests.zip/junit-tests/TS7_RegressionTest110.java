import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest110.test111");
        org.junit.runners.MethodSorters methodSorters0 = org.junit.runners.MethodSorters.DEFAULT;
        java.util.Comparator<java.lang.reflect.Method> methodComparator1 = methodSorters0.getComparator();
        org.junit.Assert.assertTrue("'" + methodSorters0 + "' != '" + org.junit.runners.MethodSorters.DEFAULT + "'", methodSorters0.equals(org.junit.runners.MethodSorters.DEFAULT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(methodComparator1);
    }
}

