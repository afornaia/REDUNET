import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest62 {

    public static boolean debug = false;

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest62.test063");
        java.util.List<java.lang.Throwable> throwableList0 = null;
        org.junit.runners.model.InitializationError initializationError1 = new org.junit.runners.model.InitializationError(throwableList0);
    }
}

