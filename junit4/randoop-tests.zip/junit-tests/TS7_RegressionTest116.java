import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest116.test117");
        org.junit.internal.builders.AllDefaultPossibilitiesBuilder allDefaultPossibilitiesBuilder1 = new org.junit.internal.builders.AllDefaultPossibilitiesBuilder(false);
        org.junit.internal.builders.AnnotatedBuilder annotatedBuilder2 = new org.junit.internal.builders.AnnotatedBuilder((org.junit.runners.model.RunnerBuilder) allDefaultPossibilitiesBuilder1);
        java.lang.Class[] classArray4 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray5 = (java.lang.Class<?>[]) classArray4;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter6 = org.junit.experimental.categories.Categories.CategoryFilter.include((java.lang.Class<?>[]) classArray4);
        org.junit.runners.Suite suite7 = new org.junit.runners.Suite((org.junit.runners.model.RunnerBuilder) annotatedBuilder2, (java.lang.Class<?>[]) classArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter6);
    }
}

