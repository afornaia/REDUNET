import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest127 {

    public static boolean debug = false;

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest127.test128");
        org.junit.runners.MethodSorters methodSorters0 = org.junit.runners.MethodSorters.DEFAULT;
        java.lang.reflect.Method method1 = null;
        org.junit.internal.runners.TestClass testClass2 = null;
        org.junit.internal.runners.TestMethod testMethod3 = new org.junit.internal.runners.TestMethod(method1, testClass2);
        org.junit.runner.notification.RunNotifier runNotifier4 = new org.junit.runner.notification.RunNotifier();
        org.junit.runner.notification.Failure failure5 = null;
        runNotifier4.fireTestAssumptionFailed(failure5);
        org.junit.runner.JUnitCore jUnitCore7 = new org.junit.runner.JUnitCore();
        java.lang.Class[] classArray9 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray10 = (java.lang.Class<?>[]) classArray9;
        org.junit.runner.Result result11 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray9);
        org.junit.runner.notification.RunListener runListener12 = result11.createListener();
        jUnitCore7.addListener(runListener12);
        runNotifier4.addListener(runListener12);
        java.lang.Class[] classArray16 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray17 = (java.lang.Class<?>[]) classArray16;
        org.junit.runner.Result result18 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray16);
        org.junit.runner.notification.RunListener runListener19 = result18.createListener();
        runNotifier4.addListener(runListener19);
        org.junit.runner.Description description21 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description22 = description21.childlessCopy();
        boolean boolean23 = description21.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher24 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher25 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher24);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher26 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher25);
        boolean boolean27 = description21.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher26);
        java.util.ArrayList<org.junit.runner.Description> descriptionList28 = description21.getChildren();
        org.junit.internal.runners.MethodRoadie methodRoadie29 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) methodSorters0, testMethod3, runNotifier4, description21);
        runNotifier4.pleaseStop();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache31 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description32 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description33 = description32.childlessCopy();
        boolean boolean34 = description32.isSuite();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache35 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description36 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description37 = description36.childlessCopy();
        boolean boolean38 = description36.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher39 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher40 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher39);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher41 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher40);
        boolean boolean42 = description36.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher41);
        java.lang.Class<?> wildcardClass43 = description36.getTestClass();
        junit.framework.Test test44 = jUnit4TestAdapterCache35.asTest(description36);
        junit.framework.Test test45 = jUnit4TestAdapterCache31.replace(description32, test44);
        runNotifier4.fireTestSuiteStarted(description32);
        org.junit.Assert.assertTrue("'" + methodSorters0 + "' != '" + org.junit.runners.MethodSorters.DEFAULT + "'", methodSorters0.equals(org.junit.runners.MethodSorters.DEFAULT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionList28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test45);
    }
}

