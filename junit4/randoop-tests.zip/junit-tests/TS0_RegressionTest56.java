import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest56.test057");
        java.lang.Throwable throwable1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable1);
        java.lang.Throwable[] throwableArray3 = new java.lang.Throwable[] { couldNotGenerateValueException2 };
        java.util.ArrayList<java.lang.Throwable> throwableList4 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList4, throwableArray3);
        org.junit.internal.runners.InitializationError initializationError6 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList4);
        org.junit.internal.AssumptionViolatedException assumptionViolatedException8 = null;
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException9 = new org.junit.TestCouldNotBeSkippedException(assumptionViolatedException8);
        java.lang.Throwable[] throwableArray10 = testCouldNotBeSkippedException9.getSuppressed();
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError11 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) initializationError6, "", (java.lang.Object[]) throwableArray10);
        java.lang.Throwable[] throwableArray12 = initializationError6.getSuppressed();
        org.junit.AssumptionViolatedException assumptionViolatedException13 = new org.junit.AssumptionViolatedException("hi!", (java.lang.Throwable) initializationError6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray12);
    }
}

