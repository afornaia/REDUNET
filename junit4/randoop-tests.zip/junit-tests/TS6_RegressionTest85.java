import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest85.test086");
        junit.framework.TestResult testResult0 = new junit.framework.TestResult();
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration1 = testResult0.errors();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration1);
    }
}

