import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest1.test002");
        java.lang.Throwable throwable1 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException2 = new org.junit.AssumptionViolatedException("", throwable1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Throwable throwable4 = org.junit.internal.Checks.notNull(throwable1, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: hi!");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

