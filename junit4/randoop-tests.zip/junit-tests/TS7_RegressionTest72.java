import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest72.test073");
        org.junit.internal.builders.JUnit4Builder jUnit4Builder0 = new org.junit.internal.builders.JUnit4Builder();
        org.junit.internal.builders.AnnotatedBuilder annotatedBuilder1 = new org.junit.internal.builders.AnnotatedBuilder((org.junit.runners.model.RunnerBuilder) jUnit4Builder0);
    }
}

