import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest44.test045");
        org.hamcrest.Matcher[] matcherArray1 = new org.hamcrest.Matcher[0];
        @SuppressWarnings("unchecked")
        org.hamcrest.Matcher<? super org.junit.runner.JUnitCore>[] wildcardMatcherArray2 = (org.hamcrest.Matcher<? super org.junit.runner.JUnitCore>[]) matcherArray1;
        org.hamcrest.Matcher<java.lang.Iterable<org.junit.runner.JUnitCore>> jUnitCoreIterableMatcher3 = org.junit.matchers.JUnitMatchers.hasItems((org.hamcrest.Matcher<? super org.junit.runner.JUnitCore>[]) matcherArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(matcherArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMatcherArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnitCoreIterableMatcher3);
    }
}

