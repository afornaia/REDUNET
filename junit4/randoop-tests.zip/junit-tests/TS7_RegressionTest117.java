import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest117.test118");
        junit.extensions.ActiveTestSuite activeTestSuite0 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite0);
        int int2 = testSetup1.countTestCases();
        junit.framework.TestResult testResult3 = junit.textui.TestRunner.run((junit.framework.Test) testSetup1);
        junit.extensions.ActiveTestSuite activeTestSuite4 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite4);
        int int6 = testSetup5.countTestCases();
        junit.framework.TestResult testResult7 = junit.textui.TestRunner.run((junit.framework.Test) testSetup5);
        junit.extensions.ActiveTestSuite activeTestSuite8 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup9 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite8);
        junit.framework.AssertionFailedError assertionFailedError10 = null;
        testResult7.addFailure((junit.framework.Test) activeTestSuite8, assertionFailedError10);
        testResult3.endTest((junit.framework.Test) activeTestSuite8);
        junit.extensions.ActiveTestSuite activeTestSuite13 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup14 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite13);
        int int15 = testSetup14.countTestCases();
        junit.framework.TestResult testResult16 = junit.textui.TestRunner.run((junit.framework.Test) testSetup14);
        activeTestSuite8.run(testResult16);
        java.io.PrintStream printStream18 = null;
        junit.textui.ResultPrinter resultPrinter19 = new junit.textui.ResultPrinter(printStream18);
        testResult16.removeListener((junit.framework.TestListener) resultPrinter19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult16);
    }
}

