import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest119.test120");
        java.lang.Throwable throwable1 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException2 = new org.junit.AssumptionViolatedException("", throwable1);
        java.lang.Throwable throwable4 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException5 = new org.junit.AssumptionViolatedException("", throwable4);
        assumptionViolatedException2.addSuppressed((java.lang.Throwable) assumptionViolatedException5);
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException7 = new org.junit.TestCouldNotBeSkippedException((org.junit.internal.AssumptionViolatedException) assumptionViolatedException2);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException8 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) assumptionViolatedException2);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException9 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) filterNotCreatedException8);
        org.junit.internal.runners.statements.Fail fail10 = new org.junit.internal.runners.statements.Fail((java.lang.Throwable) filterNotCreatedException8);
    }
}

