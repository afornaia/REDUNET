import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest46.test47");
        org.junit.rules.TemporaryFolder temporaryFolder0 = new org.junit.rules.TemporaryFolder();
        org.junit.rules.ExpectedException expectedException1 = org.junit.rules.ExpectedException.none();
        org.junit.runners.model.Statement statement2 = null;
        org.junit.runner.Description description3 = null;
        org.junit.runners.model.Statement statement4 = expectedException1.apply(statement2, description3);
        org.junit.runner.Description description5 = null;
        org.junit.runners.model.Statement statement6 = temporaryFolder0.apply(statement2, description5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement6);
    }
}

