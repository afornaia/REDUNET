import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest67.test068");
        java.io.File file1 = null;
        org.junit.rules.TemporaryFolder temporaryFolder2 = new org.junit.rules.TemporaryFolder(file1);
        temporaryFolder2.create();
        java.lang.String[] strArray10 = new java.lang.String[] { "hi!", "hi!", "", "hi!", "", "hi!" };
        java.io.File file11 = temporaryFolder2.newFolder(strArray10);
        java.lang.String str13 = junit.framework.Assert.format("", (java.lang.Object) temporaryFolder2, (java.lang.Object) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(file11);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file11.getParent(), "/tmp/junit8533958533132544650/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file11.toString(), "/tmp/junit8533958533132544650/hi!/hi!/hi!/hi!");
    }
}
