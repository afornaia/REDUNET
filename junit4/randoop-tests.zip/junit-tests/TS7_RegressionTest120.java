import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest120 {

    public static boolean debug = false;

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest120.test121");
        java.util.Comparator<java.lang.reflect.Method> methodComparator0 = org.junit.internal.MethodSorter.DEFAULT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(methodComparator0);
    }
}

