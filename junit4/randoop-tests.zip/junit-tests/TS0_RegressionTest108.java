import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest108.test109");
        junit.framework.Test test0 = null;
        java.lang.Throwable throwable1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable1);
        junit.framework.TestFailure testFailure3 = new junit.framework.TestFailure(test0, throwable1);
        junit.framework.Test test4 = testFailure3.failedTest();
        java.lang.Throwable throwable5 = testFailure3.thrownException();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(throwable5);
    }
}

