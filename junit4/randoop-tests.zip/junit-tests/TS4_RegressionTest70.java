import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest70.test71");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description1 = null;
        junit.framework.Test test2 = null;
        junit.framework.Test test3 = null;
        boolean boolean4 = jUnit4TestAdapterCache0.replace(description1, test2, test3);
        org.junit.runner.Description description5 = null;
        java.lang.Class[] classArray7 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray8 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray7;
        junit.framework.TestSuite testSuite10 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray7, "hi!");
        java.lang.Class[] classArray12 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray13 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray12;
        junit.framework.TestSuite testSuite15 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray12, "hi!");
        java.lang.Class[] classArray17 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray18 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray17;
        junit.framework.TestSuite testSuite20 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray17, "hi!");
        junit.framework.TestResult testResult21 = null;
        testSuite15.runTest((junit.framework.Test) testSuite20, testResult21);
        boolean boolean23 = jUnit4TestAdapterCache0.replace(description5, (junit.framework.Test) testSuite10, (junit.framework.Test) testSuite20);
        java.lang.Class[] classArray26 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray27 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray26;
        junit.framework.TestSuite testSuite29 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray26, "hi!");
        java.lang.Class[] classArray31 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray32 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray31;
        junit.framework.TestSuite testSuite34 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray31, "hi!");
        junit.framework.TestResult testResult35 = null;
        testSuite29.runTest((junit.framework.Test) testSuite34, testResult35);
        junit.extensions.TestDecorator testDecorator37 = new junit.extensions.TestDecorator((junit.framework.Test) testSuite29);
        junit.framework.Test test38 = jUnit4TestAdapterCache0.getOrDefault((java.lang.Object) 10, (junit.framework.Test) testSuite29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test38);
    }
}

