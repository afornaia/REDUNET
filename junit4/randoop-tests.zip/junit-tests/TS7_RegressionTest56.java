import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest56.test057");
        java.lang.Throwable throwable2 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException3 = null; // flaky: new org.junit.AssumptionViolatedException("", throwable2);
        java.lang.Throwable throwable5 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException6 = new org.junit.AssumptionViolatedException("", throwable5);
// flaky:         assumptionViolatedException3.addSuppressed((java.lang.Throwable) assumptionViolatedException6);
        org.junit.AssumptionViolatedException assumptionViolatedException8 = new org.junit.AssumptionViolatedException("hi!", (java.lang.Throwable) assumptionViolatedException3);
        java.lang.String str9 = null; // flaky: junit.runner.BaseTestRunner.getFilteredTrace((java.lang.Throwable) assumptionViolatedException3);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.junit.AssumptionViolatedException: \n\tat sun.reflect.GeneratedConstructorAccessor4.newInstance(Unknown Source)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n\tSuppressed: org.junit.AssumptionViolatedException: \n\t\t... 18 more\n" + "'", str9.equals("org.junit.AssumptionViolatedException: \n\tat sun.reflect.GeneratedConstructorAccessor4.newInstance(Unknown Source)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n\tSuppressed: org.junit.AssumptionViolatedException: \n\t\t... 18 more\n"));
    }
}
