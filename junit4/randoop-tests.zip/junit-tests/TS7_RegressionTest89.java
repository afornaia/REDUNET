import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest89.test090");
        junit.extensions.ActiveTestSuite activeTestSuite0 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite0);
        int int2 = testSetup1.countTestCases();
        junit.framework.TestResult testResult3 = junit.textui.TestRunner.run((junit.framework.Test) testSetup1);
        junit.extensions.ActiveTestSuite activeTestSuite4 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite4);
        junit.framework.AssertionFailedError assertionFailedError6 = null;
        testResult3.addFailure((junit.framework.Test) activeTestSuite4, assertionFailedError6);
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration8 = testResult3.errors();
        junit.extensions.ActiveTestSuite activeTestSuite9 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup10 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite9);
        testResult3.startTest((junit.framework.Test) activeTestSuite9);
        junit.framework.Test test12 = null;
        org.junit.internal.runners.JUnit38ClassRunner jUnit38ClassRunner13 = new org.junit.internal.runners.JUnit38ClassRunner(test12);
        org.junit.runner.manipulation.Orderer orderer14 = null;
        jUnit38ClassRunner13.order(orderer14);
        org.junit.runner.notification.RunNotifier runNotifier16 = new org.junit.runner.notification.RunNotifier();
        java.lang.Class[] classArray18 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray19 = (java.lang.Class<?>[]) classArray18;
        org.junit.runner.Result result20 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray18);
        runNotifier16.fireTestRunFinished(result20);
        junit.framework.TestListener testListener22 = jUnit38ClassRunner13.createAdaptingListener(runNotifier16);
        testResult3.removeListener(testListener22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testListener22);
    }
}

