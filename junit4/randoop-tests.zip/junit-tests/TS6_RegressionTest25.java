import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest25.test026");
        org.junit.runner.Description description3 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams5 = new org.junit.runner.FilterFactoryParams(description3, "");
        boolean boolean6 = description3.isTest();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

