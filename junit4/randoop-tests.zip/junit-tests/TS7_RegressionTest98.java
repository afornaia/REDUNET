import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest98 {

    public static boolean debug = false;

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest98.test099");
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher0 = null;
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher1 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher0);
    }
}

