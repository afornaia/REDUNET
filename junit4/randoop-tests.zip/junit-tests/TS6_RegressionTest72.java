import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest72.test073");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray2, objArray3);
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray5, objArray6);
        org.junit.Assert.assertEquals(objArray2, objArray6);
        java.lang.String str9 = org.junit.experimental.theories.internal.ParameterizedAssertionError.join("", objArray2);
        junit.textui.ResultPrinter resultPrinter10 = null;
        junit.textui.TestRunner testRunner11 = new junit.textui.TestRunner(resultPrinter10);
        java.lang.String str13 = testRunner11.extractClassName("");
        testRunner11.testEnded("hi!");
        testRunner11.testEnded("");
        junit.textui.TestRunner testRunner19 = org.junit.internal.Checks.notNull(testRunner11, "suite");
        java.lang.String str20 = junit.framework.Assert.format("suite", (java.lang.Object) "", (java.lang.Object) testRunner11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testRunner19);
    }
}

