import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest53.test054");
        java.lang.String str1 = junit.runner.BaseTestRunner.truncate("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "hi!" + "'", str1.equals("hi!"));
    }
}

