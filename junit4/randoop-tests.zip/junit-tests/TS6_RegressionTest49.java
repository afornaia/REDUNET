import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest49.test050");
        org.junit.internal.runners.InitializationError initializationError2 = new org.junit.internal.runners.InitializationError("");
        org.hamcrest.Matcher<java.lang.String> strMatcher3 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher4 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher3);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeThat("{}", (java.lang.Throwable) initializationError2, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

