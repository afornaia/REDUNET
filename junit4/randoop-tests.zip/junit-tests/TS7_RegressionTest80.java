import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest80.test081");
        java.lang.Throwable throwable1 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException2 = new org.junit.AssumptionViolatedException("", throwable1);
        java.lang.Throwable throwable4 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException5 = new org.junit.AssumptionViolatedException("", throwable4);
        assumptionViolatedException2.addSuppressed((java.lang.Throwable) assumptionViolatedException5);
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException7 = new org.junit.TestCouldNotBeSkippedException((org.junit.internal.AssumptionViolatedException) assumptionViolatedException2);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException8 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) assumptionViolatedException2);
        org.junit.internal.runners.statements.Fail fail9 = new org.junit.internal.runners.statements.Fail((java.lang.Throwable) assumptionViolatedException2);
        org.junit.internal.runners.statements.FailOnTimeout failOnTimeout11 = new org.junit.internal.runners.statements.FailOnTimeout((org.junit.runners.model.Statement) fail9, (long) ' ');
    }
}

