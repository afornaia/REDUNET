import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest66.test067");
        org.junit.internal.runners.statements.FailOnTimeout.Builder builder0 = org.junit.internal.runners.statements.FailOnTimeout.builder();
        org.junit.runners.model.Statement statement1 = null;
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray2 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList3 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList3, frameworkMethodArray2);
        org.junit.internal.runners.statements.RunAfters runAfters6 = new org.junit.internal.runners.statements.RunAfters(statement1, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList3, (java.lang.Object) (short) -1);
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray7 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList8 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList8, frameworkMethodArray7);
        org.junit.experimental.theories.suppliers.TestedOnSupplier testedOnSupplier10 = new org.junit.experimental.theories.suppliers.TestedOnSupplier();
        org.junit.internal.runners.statements.RunBefores runBefores11 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) runAfters6, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList8, (java.lang.Object) testedOnSupplier10);
        org.junit.internal.runners.statements.FailOnTimeout failOnTimeout12 = builder0.build((org.junit.runners.model.Statement) runAfters6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(failOnTimeout12);
    }
}

