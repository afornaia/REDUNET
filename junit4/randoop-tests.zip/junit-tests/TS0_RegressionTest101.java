import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest101.test102");
        org.junit.runner.JUnitCore jUnitCore0 = new org.junit.runner.JUnitCore();
        junit.framework.TestSuite testSuite2 = new junit.framework.TestSuite("expected:<[]> but was:<[hi!]>");
        org.junit.runner.Result result3 = jUnitCore0.run((junit.framework.Test) testSuite2);
        int int4 = testSuite2.countTestCases();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }
}

