import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest4.test05");
        java.lang.Throwable[] throwableArray0 = new java.lang.Throwable[] {};
        java.util.ArrayList<java.lang.Throwable> throwableList1 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList1, throwableArray0);
        org.junit.internal.runners.InitializationError initializationError3 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList1);
        java.lang.Throwable[] throwableArray4 = new java.lang.Throwable[] { initializationError3 };
        java.util.ArrayList<java.lang.Throwable> throwableList5 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList5, throwableArray4);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.model.MultipleFailureException.assertEmpty((java.util.List<java.lang.Throwable>) throwableList5);
            org.junit.Assert.fail("Expected exception of type org.junit.internal.runners.InitializationError; message: null");
        } catch (org.junit.internal.runners.InitializationError e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

