import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest115 {

    public static boolean debug = false;

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest115.test116");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        java.util.Set<java.util.Map.Entry<org.junit.runner.Description, junit.framework.Test>> descriptionEntrySet2 = jUnit4TestAdapterCache0.entrySet();
        junit.framework.Test test4 = null;
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup(test4);
        junit.framework.Test test6 = jUnit4TestAdapterCache0.getOrDefault((java.lang.Object) 0.0d, test4);
        java.lang.String str7 = jUnit4TestAdapterCache0.toString();
        java.io.File file8 = null;
        org.junit.rules.TemporaryFolder temporaryFolder9 = new org.junit.rules.TemporaryFolder(file8);
        temporaryFolder9.create();
        java.lang.String[] strArray17 = new java.lang.String[] { "hi!", "hi!", "", "hi!", "", "hi!" };
        java.io.File file18 = temporaryFolder9.newFolder(strArray17);
        boolean boolean19 = jUnit4TestAdapterCache0.equals((java.lang.Object) strArray17);
        junit.framework.TestSuite testSuite20 = new junit.framework.TestSuite();
        junit.framework.Test test21 = null;
        junit.extensions.TestSetup testSetup22 = new junit.extensions.TestSetup(test21);
        junit.extensions.TestSetup testSetup24 = org.junit.internal.Checks.notNull(testSetup22, "hi!");
        junit.framework.TestResult testResult25 = new junit.framework.TestResult();
        testSuite20.runTest((junit.framework.Test) testSetup22, testResult25);
        org.junit.ComparisonFailure comparisonFailure30 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        boolean boolean31 = jUnit4TestAdapterCache0.remove((java.lang.Object) testSuite20, (java.lang.Object) "hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionEntrySet2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(file18);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file18.getParent(), "/tmp/junit1462973812894786548/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file18.toString(), "/tmp/junit1462973812894786548/hi!/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }
}
