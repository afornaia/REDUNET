import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest87.test88");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray2 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray1;
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray1, "hi!");
        junit.framework.TestResult testResult5 = junit.textui.TestRunner.run((junit.framework.Test) testSuite4);
        java.lang.Class[] classArray7 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray8 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray7;
        junit.framework.TestSuite testSuite10 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray7, "hi!");
        java.lang.Class[] classArray12 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray13 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray12;
        junit.framework.TestSuite testSuite15 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray12, "hi!");
        junit.framework.TestResult testResult16 = null;
        testSuite10.runTest((junit.framework.Test) testSuite15, testResult16);
        java.lang.Class[] classArray19 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray20 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray19;
        junit.framework.TestSuite testSuite22 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray19, "hi!");
        junit.framework.TestResult testResult23 = junit.textui.TestRunner.run((junit.framework.Test) testSuite22);
        testSuite4.runTest((junit.framework.Test) testSuite10, testResult23);
        java.lang.Class[] classArray26 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray27 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray26;
        junit.framework.TestSuite testSuite29 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray26, "hi!");
        junit.extensions.TestSetup testSetup30 = new junit.extensions.TestSetup((junit.framework.Test) testSuite29);
        junit.framework.Test test31 = testSetup30.getTest();
        junit.framework.AssertionFailedError assertionFailedError33 = new junit.framework.AssertionFailedError("org.junit.experimental.theories.PotentialAssignment$CouldNotGenerateValueException: org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\nCaused by: org.junit.AssumptionViolatedException: hi!\n\t... 19 more\n");
        testResult23.addFailure(test31, assertionFailedError33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test31);
    }
}

