import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest84.test085");
        org.hamcrest.Matcher<java.lang.String> strMatcher0 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher1 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher0);
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher2 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching((org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher2);
    }
}

