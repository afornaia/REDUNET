import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest90.test091");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray7, objArray8);
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray10, objArray11);
        org.junit.Assert.assertEquals(objArray7, objArray11);
        boolean boolean14 = jUnit4TestAdapterCache0.equals((java.lang.Object) objArray11);
        org.junit.ComparisonFailure comparisonFailure18 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray20, objArray21);
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError23 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) comparisonFailure18, "hi!", objArray20);
        org.junit.Assert.assertArrayEquals(objArray11, objArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray21);
    }
}

