import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest54.test055");
        java.lang.Throwable throwable0 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException1 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable0);
        java.lang.Throwable throwable2 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException3 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable2);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException4 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException3);
        java.lang.Throwable throwable5 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException6 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable5);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException7 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException6);
        java.lang.Throwable[] throwableArray8 = new java.lang.Throwable[] { couldNotGenerateValueException1, couldNotGenerateValueException3, filterNotCreatedException7 };
        java.util.ArrayList<java.lang.Throwable> throwableList9 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList9, throwableArray8);
        org.junit.internal.runners.InitializationError initializationError11 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList9);
        org.junit.internal.runners.statements.Fail fail12 = new org.junit.internal.runners.statements.Fail((java.lang.Throwable) initializationError11);
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray13 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList14 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList14, frameworkMethodArray13);
        org.junit.internal.runners.statements.RunBefores runBefores17 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) fail12, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList14, (java.lang.Object) "4.13-SNAPSHOT");
        java.lang.Throwable throwable18 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException19 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable18);
        java.lang.Throwable throwable20 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException21 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable20);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException22 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException21);
        java.lang.Throwable throwable23 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException24 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable23);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException25 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException24);
        java.lang.Throwable[] throwableArray26 = new java.lang.Throwable[] { couldNotGenerateValueException19, couldNotGenerateValueException21, filterNotCreatedException25 };
        java.util.ArrayList<java.lang.Throwable> throwableList27 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean28 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList27, throwableArray26);
        org.junit.internal.runners.InitializationError initializationError29 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList27);
        org.junit.internal.runners.statements.Fail fail30 = new org.junit.internal.runners.statements.Fail((java.lang.Throwable) initializationError29);
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray31 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList32 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList32, frameworkMethodArray31);
        org.junit.internal.runners.statements.RunBefores runBefores35 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) fail30, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList32, (java.lang.Object) "4.13-SNAPSHOT");
        org.junit.internal.runners.statements.RunBefores runBefores37 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) runBefores17, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList32, (java.lang.Object) (short) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }
}

