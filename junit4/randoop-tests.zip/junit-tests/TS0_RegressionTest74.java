import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest74.test075");
        java.util.Comparator<org.junit.runner.Description> descriptionComparator0 = null;
        org.junit.runner.manipulation.Sorter sorter1 = new org.junit.runner.manipulation.Sorter(descriptionComparator0);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator2 = null;
        org.junit.runner.manipulation.Sorter sorter3 = new org.junit.runner.manipulation.Sorter(descriptionComparator2);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator4 = sorter1.thenComparing((java.util.Comparator<org.junit.runner.Description>) sorter3);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator5 = null;
        org.junit.runner.manipulation.Sorter sorter6 = new org.junit.runner.manipulation.Sorter(descriptionComparator5);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator7 = null;
        org.junit.runner.manipulation.Sorter sorter8 = new org.junit.runner.manipulation.Sorter(descriptionComparator7);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator9 = sorter6.thenComparing((java.util.Comparator<org.junit.runner.Description>) sorter8);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator10 = sorter1.thenComparing((java.util.Comparator<org.junit.runner.Description>) sorter8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator10);
    }
}

