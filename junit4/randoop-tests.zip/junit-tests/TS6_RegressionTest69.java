import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest69.test070");
        junit.textui.ResultPrinter resultPrinter0 = null;
        junit.textui.TestRunner testRunner1 = new junit.textui.TestRunner(resultPrinter0);
        java.lang.String str3 = testRunner1.extractClassName("");
        testRunner1.testStarted("expected:<()> but was:<0>");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache6 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult7 = new junit.framework.TestResult();
        junit.framework.Test test8 = null;
        junit.framework.AssertionFailedError assertionFailedError9 = null;
        testResult7.addFailure(test8, assertionFailedError9);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter11 = null;
        org.junit.runner.notification.RunNotifier runNotifier12 = jUnit4TestAdapterCache6.getNotifier(testResult7, jUnit4TestAdapter11);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache13 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult14 = new junit.framework.TestResult();
        junit.framework.Test test15 = null;
        junit.framework.AssertionFailedError assertionFailedError16 = null;
        testResult14.addFailure(test15, assertionFailedError16);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter18 = null;
        org.junit.runner.notification.RunNotifier runNotifier19 = jUnit4TestAdapterCache13.getNotifier(testResult14, jUnit4TestAdapter18);
        org.junit.runner.Description description23 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams25 = new org.junit.runner.FilterFactoryParams(description23, "");
        org.junit.runner.Description description26 = description23.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description26);
        runNotifier19.fireTestSuiteFinished(description26);
        junit.framework.TestSuite testSuite29 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite30 = new junit.framework.TestSuite();
        boolean boolean31 = jUnit4TestAdapterCache6.replace(description26, (junit.framework.Test) testSuite29, (junit.framework.Test) testSuite30);
        junit.framework.TestResult testResult32 = new junit.framework.TestResult();
        junit.framework.Test test33 = null;
        junit.framework.AssertionFailedError assertionFailedError34 = null;
        testResult32.addFailure(test33, assertionFailedError34);
        junit.framework.Test test36 = null;
        junit.extensions.TestSetup testSetup37 = new junit.extensions.TestSetup(test36);
        junit.extensions.TestSetup testSetup38 = new junit.extensions.TestSetup(test36);
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException39 = new org.junit.runner.manipulation.InvalidOrderingException();
        testResult32.addError((junit.framework.Test) testSetup38, (java.lang.Throwable) invalidOrderingException39);
        testRunner1.addError((junit.framework.Test) testSuite29, (java.lang.Throwable) invalidOrderingException39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }
}

