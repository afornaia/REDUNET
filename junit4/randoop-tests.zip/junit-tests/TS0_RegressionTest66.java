import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest66.test067");
        java.lang.Throwable throwable0 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException1 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable0);
        java.lang.Throwable throwable2 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException3 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable2);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException4 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException3);
        java.lang.Throwable throwable5 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException6 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable5);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException7 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException6);
        java.lang.Throwable[] throwableArray8 = new java.lang.Throwable[] { couldNotGenerateValueException1, couldNotGenerateValueException3, filterNotCreatedException7 };
        java.util.ArrayList<java.lang.Throwable> throwableList9 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList9, throwableArray8);
        org.junit.internal.runners.InitializationError initializationError11 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList9);
        java.io.PrintStream printStream13 = null;
        org.junit.internal.TextListener textListener14 = new org.junit.internal.TextListener(printStream13);
        java.lang.Object[] objArray15 = new java.lang.Object[] { printStream13 };
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError16 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) initializationError11, "org.junit.TestCouldNotBeSkippedException: Test could not be skipped due to other failures\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n", objArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray15);
    }
}

