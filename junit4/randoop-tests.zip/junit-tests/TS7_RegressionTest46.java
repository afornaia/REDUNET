import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest46.test047");
        org.hamcrest.Matcher<org.junit.internal.AssumptionViolatedException> assumptionViolatedExceptionMatcher0 = null;
        org.junit.internal.matchers.StacktracePrintingMatcher<org.junit.internal.AssumptionViolatedException> assumptionViolatedExceptionStacktracePrintingMatcher1 = new org.junit.internal.matchers.StacktracePrintingMatcher<org.junit.internal.AssumptionViolatedException>(assumptionViolatedExceptionMatcher0);
        org.hamcrest.Matcher<? super java.lang.Throwable> wildcardMatcher2 = null;
        org.hamcrest.Matcher[] matcherArray4 = new org.hamcrest.Matcher[1];
        @SuppressWarnings("unchecked")
        org.hamcrest.Matcher<? super java.lang.Throwable>[] wildcardMatcherArray5 = (org.hamcrest.Matcher<? super java.lang.Throwable>[]) matcherArray4;
        wildcardMatcherArray5[0] = wildcardMatcher2;
        org.hamcrest.Matcher<java.lang.Iterable<java.lang.Throwable>> throwableIterableMatcher8 = org.junit.matchers.JUnitMatchers.hasItems(wildcardMatcherArray5);
        org.hamcrest.Description description9 = null;
        // The following exception was thrown during execution in test generation
        try {
            assumptionViolatedExceptionStacktracePrintingMatcher1.describeMismatch((java.lang.Object) wildcardMatcherArray5, description9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(matcherArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMatcherArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableIterableMatcher8);
    }
}

