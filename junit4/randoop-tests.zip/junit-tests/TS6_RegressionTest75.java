import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest75.test076");
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache2 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult3 = new junit.framework.TestResult();
        junit.framework.Test test4 = null;
        junit.framework.AssertionFailedError assertionFailedError5 = null;
        testResult3.addFailure(test4, assertionFailedError5);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter7 = null;
        org.junit.runner.notification.RunNotifier runNotifier8 = jUnit4TestAdapterCache2.getNotifier(testResult3, jUnit4TestAdapter7);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache9 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult10 = new junit.framework.TestResult();
        junit.framework.Test test11 = null;
        junit.framework.AssertionFailedError assertionFailedError12 = null;
        testResult10.addFailure(test11, assertionFailedError12);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter14 = null;
        org.junit.runner.notification.RunNotifier runNotifier15 = jUnit4TestAdapterCache9.getNotifier(testResult10, jUnit4TestAdapter14);
        org.junit.runner.Description description19 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams21 = new org.junit.runner.FilterFactoryParams(description19, "");
        org.junit.runner.Description description22 = description19.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description22);
        runNotifier15.fireTestSuiteFinished(description22);
        junit.framework.TestSuite testSuite25 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite26 = new junit.framework.TestSuite();
        boolean boolean27 = jUnit4TestAdapterCache2.replace(description22, (junit.framework.Test) testSuite25, (junit.framework.Test) testSuite26);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache28 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult29 = new junit.framework.TestResult();
        junit.framework.Test test30 = null;
        junit.framework.AssertionFailedError assertionFailedError31 = null;
        testResult29.addFailure(test30, assertionFailedError31);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter33 = null;
        org.junit.runner.notification.RunNotifier runNotifier34 = jUnit4TestAdapterCache28.getNotifier(testResult29, jUnit4TestAdapter33);
        org.junit.runner.Description description38 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams40 = new org.junit.runner.FilterFactoryParams(description38, "");
        org.junit.runner.Description description41 = description38.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description41);
        runNotifier34.fireTestSuiteFinished(description41);
        org.junit.runner.Description description47 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams49 = new org.junit.runner.FilterFactoryParams(description47, "");
        org.junit.runner.Description description50 = description47.childlessCopy();
        runNotifier34.fireTestFinished(description50);
        org.junit.internal.runners.InitializationError initializationError53 = new org.junit.internal.runners.InitializationError("");
        org.junit.runner.notification.Failure failure54 = new org.junit.runner.notification.Failure(description50, (java.lang.Throwable) initializationError53);
        testResult1.addError((junit.framework.Test) testSuite26, (java.lang.Throwable) initializationError53);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache56 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult57 = new junit.framework.TestResult();
        junit.framework.Test test58 = null;
        junit.framework.AssertionFailedError assertionFailedError59 = null;
        testResult57.addFailure(test58, assertionFailedError59);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter61 = null;
        org.junit.runner.notification.RunNotifier runNotifier62 = jUnit4TestAdapterCache56.getNotifier(testResult57, jUnit4TestAdapter61);
        junit.framework.Test test63 = null;
        org.junit.internal.runners.InitializationError initializationError65 = new org.junit.internal.runners.InitializationError("");
        testResult57.addError(test63, (java.lang.Throwable) initializationError65);
        junit.framework.TestSuite testSuite67 = new junit.framework.TestSuite();
        junit.framework.Test test68 = null;
        junit.extensions.TestSetup testSetup69 = new junit.extensions.TestSetup(test68);
        junit.extensions.TestSetup testSetup71 = org.junit.internal.Checks.notNull(testSetup69, "hi!");
        junit.framework.TestResult testResult72 = new junit.framework.TestResult();
        testSuite67.runTest((junit.framework.Test) testSetup69, testResult72);
        junit.framework.Protectable protectable74 = null;
        testResult57.runProtected((junit.framework.Test) testSetup69, protectable74);
        junit.framework.Assert.assertNotSame("hi!", (java.lang.Object) testSuite26, (java.lang.Object) protectable74);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup71);
    }
}

