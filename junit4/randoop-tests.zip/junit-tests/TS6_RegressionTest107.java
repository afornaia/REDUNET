import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest107.test108");
        org.junit.internal.InexactComparisonCriteria inexactComparisonCriteria1 = new org.junit.internal.InexactComparisonCriteria((double) 97);
        java.lang.Object obj2 = inexactComparisonCriteria1.fDelta;
        java.lang.Object obj3 = inexactComparisonCriteria1.fDelta;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 97.0d + "'", obj2.equals(97.0d));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 97.0d + "'", obj3.equals(97.0d));
    }
}

