import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest33.test034");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        testResult1.stop();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
    }
}

