import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest79.test80");
        org.junit.runner.notification.RunNotifier runNotifier0 = new org.junit.runner.notification.RunNotifier();
        org.junit.runner.Result result1 = new org.junit.runner.Result();
        runNotifier0.fireTestRunFinished(result1);
        org.junit.runner.Description description3 = null;
        org.junit.internal.runners.model.EachTestNotifier eachTestNotifier4 = new org.junit.internal.runners.model.EachTestNotifier(runNotifier0, description3);
    }
}

