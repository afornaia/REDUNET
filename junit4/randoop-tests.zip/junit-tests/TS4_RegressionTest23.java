import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest23.test24");
        org.junit.runner.Description description0 = null;
        org.junit.runner.manipulation.Filter filter1 = org.junit.runner.manipulation.Filter.matchMethodDescription(description0);
        java.lang.Class[] classArray3 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray4 = (java.lang.Class<?>[]) classArray3;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter5 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray4);
        filter1.apply((java.lang.Object) categoryFilter5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter5);
    }
}

