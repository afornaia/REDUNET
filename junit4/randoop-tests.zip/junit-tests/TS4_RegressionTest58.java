import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest58.test59");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache1 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description2 = null;
        junit.framework.Test test3 = null;
        junit.framework.Test test4 = null;
        boolean boolean5 = jUnit4TestAdapterCache1.replace(description2, test3, test4);
        jUnit4TestAdapterCache0.putAll((java.util.Map<org.junit.runner.Description, junit.framework.Test>) jUnit4TestAdapterCache1);
        java.util.Collection<junit.framework.Test> testCollection7 = jUnit4TestAdapterCache0.values();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection7);
    }
}

