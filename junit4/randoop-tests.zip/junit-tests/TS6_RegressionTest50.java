import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest50.test051");
        org.junit.ComparisonFailure comparisonFailure3 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.junit.Assert.assertArrayEquals(objArray5, objArray6);
        org.junit.experimental.theories.internal.ParameterizedAssertionError parameterizedAssertionError8 = new org.junit.experimental.theories.internal.ParameterizedAssertionError((java.lang.Throwable) comparisonFailure3, "hi!", objArray5);
        org.junit.Assume.assumeNotNull(objArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray6);
    }
}

