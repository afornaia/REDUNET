import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest106.test107");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        java.util.Set<java.util.Map.Entry<org.junit.runner.Description, junit.framework.Test>> descriptionEntrySet2 = jUnit4TestAdapterCache0.entrySet();
        int int3 = jUnit4TestAdapterCache0.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionEntrySet2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}

