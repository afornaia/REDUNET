import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest104.test105");
        org.junit.rules.ExpectedException expectedException0 = org.junit.rules.ExpectedException.none();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher1 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher2 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher1);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher3 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher2);
        expectedException0.expect(printableResultMatcher2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher2);
    }
}

