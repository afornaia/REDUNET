import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest4.test005");
        java.lang.Class<?> wildcardClass1 = null;
        java.lang.Class[] classArray3 = new java.lang.Class[1];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray4 = (java.lang.Class<?>[]) classArray3;
        wildcardClassArray4[0] = wildcardClass1;
        // The following exception was thrown during execution in test generation
        try {
            org.junit.experimental.categories.Categories.CategoryFilter categoryFilter7 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(true, wildcardClassArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: has null category");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray4);
    }
}

