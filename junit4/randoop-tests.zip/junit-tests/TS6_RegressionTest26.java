import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest26.test027");
        java.io.File file0 = null;
        org.junit.rules.TemporaryFolder temporaryFolder1 = new org.junit.rules.TemporaryFolder(file0);
        temporaryFolder1.create();
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "hi!", "", "hi!", "", "hi!" };
        java.io.File file10 = temporaryFolder1.newFolder(strArray9);
        org.junit.rules.TemporaryFolder temporaryFolder11 = new org.junit.rules.TemporaryFolder(file10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(file10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file10.getParent(), "/tmp/junit4412654570155185612/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file10.toString(), "/tmp/junit4412654570155185612/hi!/hi!/hi!/hi!");
    }
}
