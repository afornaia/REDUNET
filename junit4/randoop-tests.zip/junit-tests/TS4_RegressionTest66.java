import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest66.test67");
        junit.extensions.ActiveTestSuite activeTestSuite0 = new junit.extensions.ActiveTestSuite();
    }
}

