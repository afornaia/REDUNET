import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest11.test12");
        org.junit.runners.MethodSorters methodSorters0 = org.junit.runners.MethodSorters.JVM;
        org.junit.Assert.assertTrue("'" + methodSorters0 + "' != '" + org.junit.runners.MethodSorters.JVM + "'", methodSorters0.equals(org.junit.runners.MethodSorters.JVM));
    }
}

