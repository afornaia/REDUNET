import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest114 {

    public static boolean debug = false;

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest114.test115");
        org.junit.internal.runners.TestMethod testMethod1 = null;
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache2 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult3 = new junit.framework.TestResult();
        junit.framework.Test test4 = null;
        junit.framework.AssertionFailedError assertionFailedError5 = null;
        testResult3.addFailure(test4, assertionFailedError5);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter7 = null;
        org.junit.runner.notification.RunNotifier runNotifier8 = jUnit4TestAdapterCache2.getNotifier(testResult3, jUnit4TestAdapter7);
        org.junit.runner.Description description12 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams14 = new org.junit.runner.FilterFactoryParams(description12, "");
        org.junit.runner.Description description15 = description12.childlessCopy();
        org.junit.internal.runners.MethodRoadie methodRoadie16 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) '#', testMethod1, runNotifier8, description12);
        // The following exception was thrown during execution in test generation
        try {
            methodRoadie16.run();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description15);
    }
}

