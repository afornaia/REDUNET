import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest52.test053");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = junit.framework.JUnit4TestAdapterCache.getDefault();
        java.util.Collection<junit.framework.Test> testCollection1 = jUnit4TestAdapterCache0.values();
        int int2 = jUnit4TestAdapterCache0.size();
        java.util.Collection<junit.framework.Test> testCollection3 = jUnit4TestAdapterCache0.values();
        org.junit.runner.Description description4 = null;
        junit.framework.Test test5 = null;
        junit.framework.Test test6 = null;
        boolean boolean7 = jUnit4TestAdapterCache0.replace(description4, test5, test6);
        org.junit.runner.Description description8 = org.junit.runner.Description.TEST_MECHANISM;
        java.util.List<junit.framework.Test> testList9 = jUnit4TestAdapterCache0.asTestList(description8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnit4TestAdapterCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testList9);
    }
}

