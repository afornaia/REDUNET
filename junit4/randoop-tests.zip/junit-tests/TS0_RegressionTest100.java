import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest100.test101");
        java.lang.reflect.Method method0 = null;
        org.junit.internal.runners.TestClass testClass1 = null;
        org.junit.internal.runners.TestMethod testMethod2 = new org.junit.internal.runners.TestMethod(method0, testClass1);
        // The following exception was thrown during execution in test generation
        try {
            testMethod2.invoke((java.lang.Object) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

