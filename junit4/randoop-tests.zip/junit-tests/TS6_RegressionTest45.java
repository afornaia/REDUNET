import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest45 {

    public static boolean debug = false;

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest45.test046");
        org.junit.runner.Description description4 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams6 = new org.junit.runner.FilterFactoryParams(description4, "");
        org.junit.runner.Description description7 = description4.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description7);
        java.lang.String str10 = junit.framework.Assert.format("", (java.lang.Object) description7, (java.lang.Object) (byte) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "expected:<()> but was:<0>" + "'", str10.equals("expected:<()> but was:<0>"));
    }
}

