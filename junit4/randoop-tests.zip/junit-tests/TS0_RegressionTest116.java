import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest116.test117");
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter4 = org.junit.experimental.categories.Categories.CategoryFilter.exclude((java.lang.Class<?>[]) classArray2);
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter5 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(true, (java.lang.Class<?>[]) classArray2);
        junit.framework.TestSuite testSuite7 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray2, "-0.001");
        junit.framework.TestResult testResult8 = new junit.framework.TestResult();
        testSuite7.run(testResult8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter5);
    }
}

