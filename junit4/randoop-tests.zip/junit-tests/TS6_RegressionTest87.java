import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest87.test088");
        org.hamcrest.Matcher<? super org.junit.experimental.categories.Categories.CategoryFilter> wildcardMatcher0 = null;
        org.hamcrest.Matcher[] matcherArray2 = new org.hamcrest.Matcher[1];
        @SuppressWarnings("unchecked")
        org.hamcrest.Matcher<? super org.junit.experimental.categories.Categories.CategoryFilter>[] wildcardMatcherArray3 = (org.hamcrest.Matcher<? super org.junit.experimental.categories.Categories.CategoryFilter>[]) matcherArray2;
        wildcardMatcherArray3[0] = wildcardMatcher0;
        org.hamcrest.Matcher<java.lang.Iterable<org.junit.experimental.categories.Categories.CategoryFilter>> categoryFilterIterableMatcher6 = org.junit.matchers.JUnitMatchers.hasItems(wildcardMatcherArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(matcherArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMatcherArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilterIterableMatcher6);
    }
}

