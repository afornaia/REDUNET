import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest112.test113");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache7 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult8 = new junit.framework.TestResult();
        junit.framework.Test test9 = null;
        junit.framework.AssertionFailedError assertionFailedError10 = null;
        testResult8.addFailure(test9, assertionFailedError10);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter12 = null;
        org.junit.runner.notification.RunNotifier runNotifier13 = jUnit4TestAdapterCache7.getNotifier(testResult8, jUnit4TestAdapter12);
        org.junit.runner.Description description17 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams19 = new org.junit.runner.FilterFactoryParams(description17, "");
        org.junit.runner.Description description20 = description17.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description20);
        runNotifier13.fireTestSuiteFinished(description20);
        junit.framework.TestSuite testSuite23 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite24 = new junit.framework.TestSuite();
        boolean boolean25 = jUnit4TestAdapterCache0.replace(description20, (junit.framework.Test) testSuite23, (junit.framework.Test) testSuite24);
        org.junit.runner.Description description29 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams31 = new org.junit.runner.FilterFactoryParams(description29, "");
        org.junit.runner.Description description32 = description29.childlessCopy();
        junit.framework.Test test33 = null;
        junit.extensions.TestSetup testSetup34 = new junit.extensions.TestSetup(test33);
        junit.framework.Test test35 = jUnit4TestAdapterCache0.put(description32, (junit.framework.Test) testSetup34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test35);
    }
}

