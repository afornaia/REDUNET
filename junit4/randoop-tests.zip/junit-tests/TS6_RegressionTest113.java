import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest113.test114");
        junit.framework.Test test0 = null;
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup(test0);
        junit.extensions.TestSetup testSetup3 = org.junit.internal.Checks.notNull(testSetup1, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            junit.framework.TestResult testResult4 = junit.textui.TestRunner.run((junit.framework.Test) testSetup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup3);
    }
}

