import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest96.test097");
        junit.framework.TestSuite testSuite1 = new junit.framework.TestSuite("expected:<[]> but was:<[hi!]>");
        // The following exception was thrown during execution in test generation
        try {
            junit.framework.Test test3 = testSuite1.testAt((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Array index out of range: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
    }
}

