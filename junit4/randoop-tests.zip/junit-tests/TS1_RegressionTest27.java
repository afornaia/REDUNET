import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest27.test28");
        org.junit.runner.Runner runner0 = null;
        org.junit.runner.Request request1 = org.junit.runner.Request.runner(runner0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(request1);
    }
}

