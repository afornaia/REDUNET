import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest10.test011");
        java.lang.Throwable throwable0 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException1 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable0);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException2 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Exception exception3 = org.junit.internal.Throwables.rethrowAsException((java.lang.Throwable) filterNotCreatedException2);
            org.junit.Assert.fail("Expected exception of type org.junit.runner.FilterFactory.FilterNotCreatedException; message: null");
        } catch (org.junit.runner.FilterFactory.FilterNotCreatedException e) {
        // Expected exception.
        }
    }
}

