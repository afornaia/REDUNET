import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest39.test40");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray2 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray1;
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray1, "hi!");
        java.lang.Class[] classArray6 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray7 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray6;
        junit.framework.TestSuite testSuite9 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray6, "hi!");
        junit.framework.TestResult testResult10 = null;
        testSuite4.runTest((junit.framework.Test) testSuite9, testResult10);
        // The following exception was thrown during execution in test generation
        try {
            junit.framework.Test test13 = testSuite4.testAt(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: Array index out of range: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray7);
    }
}

