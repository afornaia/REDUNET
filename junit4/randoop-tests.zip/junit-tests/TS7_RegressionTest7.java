import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest7.test008");
        org.junit.runner.JUnitCore jUnitCore0 = new org.junit.runner.JUnitCore();
        org.junit.runner.Computer computer1 = null;
        java.lang.Class<?> wildcardClass2 = null;
        java.lang.Class[] classArray4 = new java.lang.Class[1];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray5 = (java.lang.Class<?>[]) classArray4;
        wildcardClassArray5[0] = wildcardClass2;
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runner.Result result8 = jUnitCore0.run(computer1, wildcardClassArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray5);
    }
}

