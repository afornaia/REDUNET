import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest67.test068");
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher0 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher1 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher1);
    }
}

