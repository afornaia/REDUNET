import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest107.test108");
        org.junit.runner.JUnitCore jUnitCore0 = new org.junit.runner.JUnitCore();
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        org.junit.runner.Result result4 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray2);
        org.junit.runner.notification.RunListener runListener5 = result4.createListener();
        jUnitCore0.addListener(runListener5);
        java.lang.String str7 = jUnitCore0.getVersion();
        junit.framework.Test test8 = null;
        org.junit.internal.runners.JUnit38ClassRunner jUnit38ClassRunner9 = new org.junit.internal.runners.JUnit38ClassRunner(test8);
        org.junit.runner.manipulation.Alphanumeric alphanumeric10 = new org.junit.runner.manipulation.Alphanumeric();
        java.util.Comparator<org.junit.runner.Description> descriptionComparator11 = alphanumeric10.reversed();
        java.util.Comparator<org.junit.runner.Description> descriptionComparator12 = alphanumeric10.reversed();
        jUnit38ClassRunner9.sort((org.junit.runner.manipulation.Sorter) alphanumeric10);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runner.Result result14 = jUnitCore0.run((org.junit.runner.Runner) jUnit38ClassRunner9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "4.13-SNAPSHOT" + "'", str7.equals("4.13-SNAPSHOT"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator12);
    }
}

