import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest23.test024");
        org.junit.runners.model.Statement statement0 = null;
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray1 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList2 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList2, frameworkMethodArray1);
        org.junit.internal.runners.statements.RunAfters runAfters5 = new org.junit.internal.runners.statements.RunAfters(statement0, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList2, (java.lang.Object) (short) -1);
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray6 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList7 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList7, frameworkMethodArray6);
        org.junit.experimental.theories.suppliers.TestedOnSupplier testedOnSupplier9 = new org.junit.experimental.theories.suppliers.TestedOnSupplier();
        org.junit.internal.runners.statements.RunBefores runBefores10 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) runAfters5, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList7, (java.lang.Object) testedOnSupplier9);
        org.hamcrest.Matcher<java.lang.Iterable<? super org.junit.internal.runners.statements.RunBefores>> wildcardIterableMatcher11 = org.junit.matchers.JUnitMatchers.hasItem(runBefores10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher11);
    }
}

