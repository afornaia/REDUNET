import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest130.test131");
        junit.framework.Test test1 = null;
        junit.extensions.TestSetup testSetup2 = new junit.extensions.TestSetup(test1);
        junit.extensions.TestSetup testSetup4 = org.junit.internal.Checks.notNull(testSetup2, "hi!");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache7 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.Test test9 = jUnit4TestAdapterCache7.get((java.lang.Object) (byte) 100);
        org.hamcrest.Matcher<java.lang.String> strMatcher10 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher11 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher10);
        org.junit.internal.AssumptionViolatedException assumptionViolatedException12 = new org.junit.internal.AssumptionViolatedException("org.junit.experimental.max.CouldNotReadCoreException\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n", false, (java.lang.Object) test9, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher11);
        junit.framework.TestFailure testFailure13 = new junit.framework.TestFailure((junit.framework.Test) testSetup2, (java.lang.Throwable) assumptionViolatedException12);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assert.assertNull("hi!", (java.lang.Object) testSetup2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test9);
    }
}

