import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest81.test082");
        org.junit.internal.runners.InitializationError initializationError2 = new org.junit.internal.runners.InitializationError("");
        java.lang.Throwable throwable3 = null;
        org.junit.experimental.max.CouldNotReadCoreException couldNotReadCoreException4 = new org.junit.experimental.max.CouldNotReadCoreException(throwable3);
        java.lang.Throwable[] throwableArray5 = new java.lang.Throwable[] { initializationError2, throwable3 };
        java.util.ArrayList<java.lang.Throwable> throwableList6 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean7 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList6, throwableArray5);
        org.junit.runners.model.InitializationError initializationError8 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList6);
        org.junit.internal.AssumptionViolatedException assumptionViolatedException9 = new org.junit.internal.AssumptionViolatedException("hi!", (java.lang.Throwable) initializationError8);
        org.hamcrest.Matcher<java.lang.String> strMatcher10 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher11 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher10);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError> initializationErrorThrowableCauseMatcher12 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError>((org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher11);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assert.assertThat(initializationError8, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }
}

