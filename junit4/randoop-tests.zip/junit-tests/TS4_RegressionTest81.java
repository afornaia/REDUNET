import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest81.test82");
        org.junit.runner.notification.RunNotifier runNotifier0 = new org.junit.runner.notification.RunNotifier();
        org.junit.runner.Result result1 = new org.junit.runner.Result();
        runNotifier0.fireTestRunFinished(result1);
        org.junit.runner.Description description3 = null;
        runNotifier0.fireTestIgnored(description3);
    }
}

