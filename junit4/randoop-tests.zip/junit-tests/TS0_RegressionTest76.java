import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest76.test077");
        junit.runner.BaseTestRunner.setPreference("categories [all](4.13-SNAPSHOT)", "suite");
    }
}

