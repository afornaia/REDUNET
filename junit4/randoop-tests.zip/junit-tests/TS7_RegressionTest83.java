import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest83.test084");
        java.lang.Class<?> wildcardClass0 = null;
        java.lang.Class[] classArray2 = new java.lang.Class[1];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        wildcardClassArray3[0] = wildcardClass0;
        // The following exception was thrown during execution in test generation
        try {
            org.junit.experimental.categories.Categories.CategoryFilter categoryFilter6 = org.junit.experimental.categories.Categories.CategoryFilter.include(wildcardClassArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: has null category");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
    }
}

