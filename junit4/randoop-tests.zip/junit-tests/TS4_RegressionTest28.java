import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest28.test29");
        java.io.File file0 = null;
        org.junit.rules.TemporaryFolder temporaryFolder1 = new org.junit.rules.TemporaryFolder(file0);
        // The following exception was thrown during execution in test generation
        try {
            java.io.File file2 = temporaryFolder1.newFile();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: the temporary folder has not yet been created");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
    }
}

