import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest58.test059");
        org.junit.runners.model.FrameworkMethod frameworkMethod0 = null;
        java.lang.Object obj1 = null;
        org.junit.internal.runners.statements.InvokeMethod invokeMethod2 = new org.junit.internal.runners.statements.InvokeMethod(frameworkMethod0, obj1);
    }
}

