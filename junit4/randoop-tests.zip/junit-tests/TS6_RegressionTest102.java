import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest102.test103");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        org.junit.internal.runners.TestMethod testMethod8 = null;
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache9 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult10 = new junit.framework.TestResult();
        junit.framework.Test test11 = null;
        junit.framework.AssertionFailedError assertionFailedError12 = null;
        testResult10.addFailure(test11, assertionFailedError12);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter14 = null;
        org.junit.runner.notification.RunNotifier runNotifier15 = jUnit4TestAdapterCache9.getNotifier(testResult10, jUnit4TestAdapter14);
        org.junit.runner.Description description19 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams21 = new org.junit.runner.FilterFactoryParams(description19, "");
        org.junit.runner.Description description22 = description19.childlessCopy();
        org.junit.internal.runners.MethodRoadie methodRoadie23 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) '#', testMethod8, runNotifier15, description19);
        runNotifier6.fireTestSuiteStarted(description19);
        org.junit.runner.FilterFactoryParams filterFactoryParams26 = new org.junit.runner.FilterFactoryParams(description19, "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description22);
    }
}

