import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest122 {

    public static boolean debug = false;

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest122.test123");
        java.lang.AssertionError assertionError1 = null;
        org.junit.internal.ArrayComparisonFailure arrayComparisonFailure3 = new org.junit.internal.ArrayComparisonFailure("hi!", assertionError1, (int) 'a');
        arrayComparisonFailure3.addDimension((int) (byte) -1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = arrayComparisonFailure3.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

