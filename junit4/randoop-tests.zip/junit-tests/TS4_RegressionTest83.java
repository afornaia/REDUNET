import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest83.test84");
        org.junit.runners.model.RunnerBuilder runnerBuilder0 = null;
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray3 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray2;
        junit.framework.TestSuite testSuite5 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray2, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.Suite suite6 = new org.junit.runners.Suite(runnerBuilder0, (java.lang.Class<?>[]) classArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
    }
}

