import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest87.test088");
        org.junit.runner.notification.RunNotifier runNotifier0 = new org.junit.runner.notification.RunNotifier();
        org.junit.runner.notification.Failure failure1 = null;
        runNotifier0.fireTestAssumptionFailed(failure1);
        org.junit.runner.JUnitCore jUnitCore3 = new org.junit.runner.JUnitCore();
        java.lang.Class[] classArray5 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray6 = (java.lang.Class<?>[]) classArray5;
        org.junit.runner.Result result7 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray5);
        org.junit.runner.notification.RunListener runListener8 = result7.createListener();
        jUnitCore3.addListener(runListener8);
        runNotifier0.addListener(runListener8);
        java.lang.Class[] classArray12 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray13 = (java.lang.Class<?>[]) classArray12;
        org.junit.runner.Result result14 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray12);
        org.junit.runner.notification.RunListener runListener15 = result14.createListener();
        runNotifier0.addListener(runListener15);
        org.junit.runner.notification.Failure failure17 = null;
        runListener15.testFailure(failure17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener15);
    }
}

