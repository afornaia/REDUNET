import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest123 {

    public static boolean debug = false;

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest123.test124");
        junit.extensions.ActiveTestSuite activeTestSuite0 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite0);
        int int2 = testSetup1.countTestCases();
        junit.framework.TestResult testResult3 = junit.textui.TestRunner.run((junit.framework.Test) testSetup1);
        junit.extensions.ActiveTestSuite activeTestSuite4 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite4);
        junit.framework.AssertionFailedError assertionFailedError6 = null;
        testResult3.addFailure((junit.framework.Test) activeTestSuite4, assertionFailedError6);
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration8 = testResult3.errors();
        junit.extensions.ActiveTestSuite activeTestSuite9 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup10 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite9);
        int int11 = testSetup10.countTestCases();
        junit.framework.TestResult testResult12 = junit.textui.TestRunner.run((junit.framework.Test) testSetup10);
        junit.extensions.ActiveTestSuite activeTestSuite13 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup14 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite13);
        junit.framework.AssertionFailedError assertionFailedError15 = null;
        testResult12.addFailure((junit.framework.Test) activeTestSuite13, assertionFailedError15);
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration17 = testResult12.errors();
        junit.extensions.ActiveTestSuite activeTestSuite18 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup19 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite18);
        testResult12.startTest((junit.framework.Test) activeTestSuite18);
        java.lang.Throwable throwable23 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException24 = new org.junit.AssumptionViolatedException("", throwable23);
        java.lang.Throwable throwable26 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException27 = new org.junit.AssumptionViolatedException("", throwable26);
        assumptionViolatedException24.addSuppressed((java.lang.Throwable) assumptionViolatedException27);
        org.junit.AssumptionViolatedException assumptionViolatedException29 = new org.junit.AssumptionViolatedException("hi!", (java.lang.Throwable) assumptionViolatedException24);
        testResult3.addError((junit.framework.Test) activeTestSuite18, (java.lang.Throwable) assumptionViolatedException29);
        org.junit.runners.model.InitializationError initializationError31 = new org.junit.runners.model.InitializationError((java.lang.Throwable) assumptionViolatedException29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration17);
    }
}

