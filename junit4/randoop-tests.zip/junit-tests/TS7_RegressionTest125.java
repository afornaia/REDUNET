import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest125.test126");
        junit.framework.Test test0 = null;
        org.junit.internal.runners.JUnit38ClassRunner jUnit38ClassRunner1 = new org.junit.internal.runners.JUnit38ClassRunner(test0);
        org.junit.runner.notification.RunNotifier runNotifier2 = new org.junit.runner.notification.RunNotifier();
        java.lang.Class[] classArray4 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray5 = (java.lang.Class<?>[]) classArray4;
        org.junit.runner.Result result6 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray4);
        runNotifier2.fireTestRunFinished(result6);
        junit.framework.TestListener testListener8 = jUnit38ClassRunner1.createAdaptingListener(runNotifier2);
        org.junit.runners.MethodSorters methodSorters9 = org.junit.runners.MethodSorters.DEFAULT;
        java.lang.reflect.Method method10 = null;
        org.junit.internal.runners.TestClass testClass11 = null;
        org.junit.internal.runners.TestMethod testMethod12 = new org.junit.internal.runners.TestMethod(method10, testClass11);
        org.junit.runner.notification.RunNotifier runNotifier13 = new org.junit.runner.notification.RunNotifier();
        org.junit.runner.notification.Failure failure14 = null;
        runNotifier13.fireTestAssumptionFailed(failure14);
        org.junit.runner.JUnitCore jUnitCore16 = new org.junit.runner.JUnitCore();
        java.lang.Class[] classArray18 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray19 = (java.lang.Class<?>[]) classArray18;
        org.junit.runner.Result result20 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray18);
        org.junit.runner.notification.RunListener runListener21 = result20.createListener();
        jUnitCore16.addListener(runListener21);
        runNotifier13.addListener(runListener21);
        java.lang.Class[] classArray25 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray26 = (java.lang.Class<?>[]) classArray25;
        org.junit.runner.Result result27 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray25);
        org.junit.runner.notification.RunListener runListener28 = result27.createListener();
        runNotifier13.addListener(runListener28);
        org.junit.runner.Description description30 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description31 = description30.childlessCopy();
        boolean boolean32 = description30.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher33 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher34 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher33);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher35 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher34);
        boolean boolean36 = description30.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher35);
        java.util.ArrayList<org.junit.runner.Description> descriptionList37 = description30.getChildren();
        org.junit.internal.runners.MethodRoadie methodRoadie38 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) methodSorters9, testMethod12, runNotifier13, description30);
        junit.framework.TestListener testListener39 = jUnit38ClassRunner1.createAdaptingListener(runNotifier13);
        org.junit.runner.Description description40 = org.junit.runner.Description.EMPTY;
        boolean boolean41 = description40.isEmpty();
        runNotifier13.fireTestStarted(description40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testListener8);
        org.junit.Assert.assertTrue("'" + methodSorters9 + "' != '" + org.junit.runners.MethodSorters.DEFAULT + "'", methodSorters9.equals(org.junit.runners.MethodSorters.DEFAULT));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionList37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testListener39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }
}

