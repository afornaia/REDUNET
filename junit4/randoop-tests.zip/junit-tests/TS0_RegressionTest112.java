import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest112.test113");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = junit.framework.JUnit4TestAdapterCache.getDefault();
        java.util.Collection<junit.framework.Test> testCollection1 = jUnit4TestAdapterCache0.values();
        junit.framework.TestResult testResult2 = null;
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter3 = null;
        org.junit.runner.notification.RunNotifier runNotifier4 = jUnit4TestAdapterCache0.getNotifier(testResult2, jUnit4TestAdapter3);
        org.junit.runner.Description description8 = org.junit.runner.Description.createTestDescription("4.13-SNAPSHOT", "categories [all]", (java.io.Serializable) 100.0f);
        java.util.Collection<java.lang.annotation.Annotation> annotationCollection9 = description8.getAnnotations();
        java.lang.String str10 = description8.getClassName();
        junit.framework.Test test11 = jUnit4TestAdapterCache0.asTest(description8);
        junit.extensions.RepeatedTest repeatedTest13 = new junit.extensions.RepeatedTest(test11, (int) (byte) 0);
        junit.framework.TestResult testResult14 = new junit.framework.TestResult();
        java.io.PrintStream printStream15 = null;
        junit.textui.ResultPrinter resultPrinter16 = new junit.textui.ResultPrinter(printStream15);
        junit.textui.TestRunner testRunner17 = new junit.textui.TestRunner(resultPrinter16);
        testResult14.removeListener((junit.framework.TestListener) resultPrinter16);
        repeatedTest13.run(testResult14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jUnit4TestAdapterCache0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationCollection9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4.13-SNAPSHOT" + "'", str10.equals("4.13-SNAPSHOT"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test11);
    }
}

