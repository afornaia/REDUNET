import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest48.test49");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray2 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray1;
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray1, "hi!");
        junit.framework.TestResult testResult5 = junit.textui.TestRunner.run((junit.framework.Test) testSuite4);
        java.lang.Class[] classArray7 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray8 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray7;
        junit.framework.TestSuite testSuite10 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray7, "hi!");
        java.lang.Class[] classArray12 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray13 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray12;
        junit.framework.TestSuite testSuite15 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray12, "hi!");
        junit.framework.TestResult testResult16 = null;
        testSuite10.runTest((junit.framework.Test) testSuite15, testResult16);
        java.lang.Class[] classArray19 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray20 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray19;
        junit.framework.TestSuite testSuite22 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray19, "hi!");
        junit.framework.TestResult testResult23 = junit.textui.TestRunner.run((junit.framework.Test) testSuite22);
        testSuite4.runTest((junit.framework.Test) testSuite10, testResult23);
        int int25 = testSuite10.testCount();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }
}

