import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest33.test34");
        org.junit.experimental.results.ResultMatchers resultMatchers0 = new org.junit.experimental.results.ResultMatchers();
    }
}

