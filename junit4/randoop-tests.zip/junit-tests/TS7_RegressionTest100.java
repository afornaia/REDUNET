import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest100.test101");
        org.junit.rules.TemporaryFolder temporaryFolder0 = new org.junit.rules.TemporaryFolder();
        // The following exception was thrown during execution in test generation
        try {
            java.io.File file2 = temporaryFolder0.newFolder("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: the temporary folder has not yet been created");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
    }
}

