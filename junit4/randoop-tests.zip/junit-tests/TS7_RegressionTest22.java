import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest22.test023");
        junit.framework.Test test0 = null;
        org.junit.internal.runners.JUnit38ClassRunner jUnit38ClassRunner1 = new org.junit.internal.runners.JUnit38ClassRunner(test0);
        // The following exception was thrown during execution in test generation
        try {
            int int2 = jUnit38ClassRunner1.testCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

