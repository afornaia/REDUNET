import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest109 {

    public static boolean debug = false;

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest109.test110");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter3 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray2);
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter4 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter4);
    }
}

