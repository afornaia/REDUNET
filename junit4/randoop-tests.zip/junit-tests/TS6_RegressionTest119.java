import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest119.test120");
        org.hamcrest.Matcher<java.lang.String> strMatcher0 = null;
        org.hamcrest.Matcher<org.junit.runner.manipulation.InvalidOrderingException> invalidOrderingExceptionMatcher1 = org.junit.internal.matchers.ThrowableMessageMatcher.hasMessage(strMatcher0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(invalidOrderingExceptionMatcher1);
    }
}

