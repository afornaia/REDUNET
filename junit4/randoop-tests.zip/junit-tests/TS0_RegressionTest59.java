import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest59.test060");
        java.util.concurrent.TimeUnit timeUnit1 = null;
        org.junit.rules.Timeout timeout2 = new org.junit.rules.Timeout((long) (byte) 10, timeUnit1);
        org.junit.rules.DisableOnDebug disableOnDebug3 = new org.junit.rules.DisableOnDebug((org.junit.rules.TestRule) timeout2);
    }
}

