import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest61.test62");
        java.lang.reflect.Method method0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.model.FrameworkMethod frameworkMethod1 = new org.junit.runners.model.FrameworkMethod(method0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: FrameworkMethod cannot be created without an underlying method.");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

