import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest14.test15");
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException0 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        java.lang.Throwable[] throwableArray1 = new java.lang.Throwable[] { couldNotGenerateValueException0 };
        java.util.ArrayList<java.lang.Throwable> throwableList2 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList2, throwableArray1);
        org.junit.runners.model.InitializationError initializationError4 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

