import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest5.test06");
        java.lang.reflect.Method method0 = null;
        org.junit.internal.runners.TestClass testClass1 = null;
        org.junit.internal.runners.TestMethod testMethod2 = new org.junit.internal.runners.TestMethod(method0, testClass1);
    }
}

