import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest84.test85");
        org.junit.rules.ExpectedException expectedException0 = org.junit.rules.ExpectedException.none();
        org.junit.runners.model.Statement statement1 = null;
        org.junit.runner.Description description2 = null;
        org.junit.runners.model.Statement statement3 = expectedException0.apply(statement1, description2);
        org.hamcrest.Matcher<java.lang.String> strMatcher4 = null;
        expectedException0.expectMessage(strMatcher4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement3);
    }
}

