import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest14.test015");
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException1 = new org.junit.runner.manipulation.InvalidOrderingException("");
    }
}

