import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest85.test086");
        org.junit.runner.JUnitCore jUnitCore0 = new org.junit.runner.JUnitCore();
        java.lang.String str1 = jUnitCore0.getVersion();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "4.13-SNAPSHOT" + "'", str1.equals("4.13-SNAPSHOT"));
    }
}

