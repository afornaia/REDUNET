import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest18.test19");
        org.junit.internal.InexactComparisonCriteria inexactComparisonCriteria1 = new org.junit.internal.InexactComparisonCriteria((double) ' ');
    }
}

