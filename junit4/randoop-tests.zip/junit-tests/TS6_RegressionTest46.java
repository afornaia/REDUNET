import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest46.test047");
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException0 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException1 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) couldNotGenerateValueException0);
    }
}

