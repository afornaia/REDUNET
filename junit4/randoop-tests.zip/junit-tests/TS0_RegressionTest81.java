import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest81.test082");
        org.junit.rules.Timeout.Builder builder0 = org.junit.rules.Timeout.builder();
        java.util.concurrent.TimeUnit timeUnit2 = null;
        org.junit.rules.Timeout.Builder builder3 = builder0.withTimeout(1L, timeUnit2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
    }
}

