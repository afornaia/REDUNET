import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest28.test029");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass1 = org.junit.internal.Classes.getClass("suite");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassNotFoundException; message: suite");
        } catch (java.lang.ClassNotFoundException e) {
        // Expected exception.
        }
    }
}

