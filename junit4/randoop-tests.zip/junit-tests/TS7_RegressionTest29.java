import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest29.test030");
        java.lang.Throwable throwable1 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException2 = new org.junit.AssumptionViolatedException("", throwable1);
        org.junit.experimental.max.CouldNotReadCoreException couldNotReadCoreException3 = new org.junit.experimental.max.CouldNotReadCoreException(throwable1);
    }
}

