import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest25.test026");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter3 = org.junit.experimental.categories.Categories.CategoryFilter.exclude((java.lang.Class<?>[]) classArray1);
        java.lang.String str4 = categoryFilter3.describe();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "categories [all]" + "'", str4.equals("categories [all]"));
    }
}

