import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest93.test094");
        junit.framework.ComparisonCompactor comparisonCompactor3 = new junit.framework.ComparisonCompactor((int) (short) -1, "4.13-SNAPSHOT", "-0.001");
    }
}

