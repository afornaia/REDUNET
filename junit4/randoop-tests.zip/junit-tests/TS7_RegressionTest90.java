import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest90.test091");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter3 = org.junit.experimental.categories.Categories.CategoryFilter.include((java.lang.Class<?>[]) classArray1);
        org.junit.runner.Description description4 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description5 = description4.childlessCopy();
        boolean boolean6 = description4.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher7 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher8 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher7);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher9 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher8);
        boolean boolean10 = description4.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher9);
        java.lang.Class<?> wildcardClass11 = description4.getTestClass();
        java.lang.String str12 = description4.getMethodName();
        boolean boolean13 = categoryFilter3.shouldRun(description4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }
}

