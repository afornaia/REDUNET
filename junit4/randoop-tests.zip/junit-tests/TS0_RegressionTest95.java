import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest95.test096");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass1 = org.junit.internal.Classes.getClass("org.junit.TestCouldNotBeSkippedException: Test could not be skipped due to other failures\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassNotFoundException; message: org.junit.TestCouldNotBeSkippedException: Test could not be skipped due to other failures\n	at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n	at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n	at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n	at java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n	at randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n	at randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n	at randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n	at randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n	at randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n	at randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n	at randoop.sequence.Statement.execute(Statement.java:163)\n	at randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n	at randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n	at randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n	at randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n	at randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n	at randoop.main.GenTests.handle(GenTests.java:467)\n	at randoop.main.Main.nonStaticMain(Main.java:66)\n	at randoop.main.Main.main(Main.java:30)\n");
        } catch (java.lang.ClassNotFoundException e) {
        // Expected exception.
        }
    }
}

