import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest121 {

    public static boolean debug = false;

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest121.test122");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description1 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description2 = description1.childlessCopy();
        boolean boolean3 = description1.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher4 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher5 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher4);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher6 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher5);
        boolean boolean7 = description1.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher6);
        java.lang.Class<?> wildcardClass8 = description1.getTestClass();
        junit.framework.Test test9 = jUnit4TestAdapterCache0.asTest(description1);
        java.util.Set<org.junit.runner.Description> descriptionSet10 = jUnit4TestAdapterCache0.keySet();
        org.junit.runner.Description description11 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description12 = description11.childlessCopy();
        boolean boolean13 = description11.isSuite();
        boolean boolean14 = description11.isEmpty();
        junit.extensions.ActiveTestSuite activeTestSuite15 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup16 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite15);
        int int17 = testSetup16.countTestCases();
        junit.framework.TestResult testResult18 = junit.textui.TestRunner.run((junit.framework.Test) testSetup16);
        junit.extensions.ActiveTestSuite activeTestSuite19 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup20 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite19);
        int int21 = testSetup20.countTestCases();
        junit.framework.TestResult testResult22 = junit.textui.TestRunner.run((junit.framework.Test) testSetup20);
        junit.extensions.ActiveTestSuite activeTestSuite23 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup24 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite23);
        junit.framework.AssertionFailedError assertionFailedError25 = null;
        testResult22.addFailure((junit.framework.Test) activeTestSuite23, assertionFailedError25);
        testResult18.endTest((junit.framework.Test) activeTestSuite23);
        junit.extensions.ActiveTestSuite activeTestSuite28 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup29 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite28);
        int int30 = testSetup29.countTestCases();
        junit.framework.TestResult testResult31 = junit.textui.TestRunner.run((junit.framework.Test) testSetup29);
        junit.extensions.ActiveTestSuite activeTestSuite32 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup33 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite32);
        junit.framework.AssertionFailedError assertionFailedError34 = null;
        testResult31.addFailure((junit.framework.Test) activeTestSuite32, assertionFailedError34);
        java.util.Enumeration<junit.framework.TestFailure> testFailureEnumeration36 = testResult31.errors();
        junit.extensions.ActiveTestSuite activeTestSuite37 = new junit.extensions.ActiveTestSuite();
        junit.extensions.TestSetup testSetup38 = new junit.extensions.TestSetup((junit.framework.Test) activeTestSuite37);
        testResult31.startTest((junit.framework.Test) activeTestSuite37);
        java.lang.String str40 = activeTestSuite37.toString();
        boolean boolean41 = jUnit4TestAdapterCache0.replace(description11, (junit.framework.Test) activeTestSuite23, (junit.framework.Test) activeTestSuite37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionSet10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testFailureEnumeration36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }
}

