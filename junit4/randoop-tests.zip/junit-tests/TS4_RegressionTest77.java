import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest77.test78");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray2 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray1;
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray1, "hi!");
        junit.framework.TestResult testResult5 = junit.textui.TestRunner.run((junit.framework.Test) testSuite4);
        testResult5.stop();
        java.lang.Class[] classArray8 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray9 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray8;
        junit.framework.TestSuite testSuite11 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray8, "hi!");
        junit.framework.TestResult testResult12 = junit.textui.TestRunner.run((junit.framework.Test) testSuite11);
        junit.framework.AssertionFailedError assertionFailedError14 = new junit.framework.AssertionFailedError("org.junit.experimental.theories.PotentialAssignment$CouldNotGenerateValueException: org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\nCaused by: org.junit.AssumptionViolatedException: hi!\n\t... 19 more\n");
        testResult5.addFailure((junit.framework.Test) testSuite11, assertionFailedError14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testResult12);
    }
}

