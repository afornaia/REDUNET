import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest102.test103");
        org.junit.runner.Description description0 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description1 = description0.childlessCopy();
        java.lang.Throwable throwable4 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException5 = new org.junit.AssumptionViolatedException("", throwable4);
        java.lang.Throwable throwable7 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException8 = new org.junit.AssumptionViolatedException("", throwable7);
        assumptionViolatedException5.addSuppressed((java.lang.Throwable) assumptionViolatedException8);
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException10 = new org.junit.TestCouldNotBeSkippedException((org.junit.internal.AssumptionViolatedException) assumptionViolatedException5);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException11 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) assumptionViolatedException5);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException12 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) filterNotCreatedException11);
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException13 = new org.junit.runner.manipulation.InvalidOrderingException("hi!", (java.lang.Throwable) filterNotCreatedException11);
        org.junit.runner.notification.Failure failure14 = new org.junit.runner.notification.Failure(description0, (java.lang.Throwable) filterNotCreatedException11);
        org.junit.runner.manipulation.Filter filter15 = org.junit.runner.manipulation.Filter.matchMethodDescription(description0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter15);
    }
}

