import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest19.test20");
        junit.framework.AssertionFailedError assertionFailedError1 = new junit.framework.AssertionFailedError("4.13-SNAPSHOT");
    }
}

