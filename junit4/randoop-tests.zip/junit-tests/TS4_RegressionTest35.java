import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest35.test36");
        org.junit.runners.model.TestClass testClass1 = null;
        org.junit.rules.ExpectedException expectedException3 = org.junit.rules.ExpectedException.none();
        org.junit.runners.MethodSorters methodSorters4 = org.junit.runners.MethodSorters.JVM;
        java.lang.Class[] classArray6 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray7 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray6;
        junit.framework.TestSuite testSuite9 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray6, "hi!");
        java.lang.Class[] classArray11 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray12 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray11;
        junit.framework.TestSuite testSuite14 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray11, "hi!");
        junit.framework.TestResult testResult15 = null;
        testSuite9.runTest((junit.framework.Test) testSuite14, testResult15);
        org.junit.rules.ExpectedException expectedException17 = org.junit.rules.ExpectedException.none();
        boolean boolean18 = expectedException17.isAnyExceptionExpected();
        org.junit.rules.ExpectedException expectedException20 = expectedException17.reportMissingExceptionWithMessage("hi!");
        org.junit.runners.MethodSorters methodSorters22 = org.junit.runners.MethodSorters.JVM;
        java.io.File file24 = null;
        org.junit.rules.TemporaryFolder temporaryFolder25 = new org.junit.rules.TemporaryFolder(file24);
        org.junit.AssumptionViolatedException assumptionViolatedException27 = null; // flaky: new org.junit.AssumptionViolatedException("hi!");
        java.lang.String str28 = null; // flaky: org.junit.internal.Throwables.getStacktrace((java.lang.Throwable) assumptionViolatedException27);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException29 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) assumptionViolatedException27);
        junit.textui.ResultPrinter resultPrinter31 = null;
        junit.textui.TestRunner testRunner32 = new junit.textui.TestRunner(resultPrinter31);
        org.junit.rules.ErrorCollector errorCollector34 = new org.junit.rules.ErrorCollector();
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException35 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        java.lang.Throwable[] throwableArray36 = new java.lang.Throwable[] { couldNotGenerateValueException35 };
        java.util.ArrayList<java.lang.Throwable> throwableList37 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean38 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList37, throwableArray36);
        org.junit.runners.model.InitializationError initializationError39 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList37);
        org.junit.AssumptionViolatedException assumptionViolatedException41 = null; // flaky: new org.junit.AssumptionViolatedException("hi!");
        java.lang.String str42 = null; // flaky: org.junit.internal.Throwables.getStacktrace((java.lang.Throwable) assumptionViolatedException41);
        java.io.File file46 = null;
        org.junit.rules.TemporaryFolder temporaryFolder47 = new org.junit.rules.TemporaryFolder(file46);
        java.lang.Class[] classArray51 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray52 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray51;
        junit.framework.TestSuite testSuite54 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray51, "hi!");
        java.lang.Class[] classArray56 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray57 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray56;
        junit.framework.TestSuite testSuite59 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray56, "hi!");
        junit.framework.TestResult testResult60 = null;
        testSuite54.runTest((junit.framework.Test) testSuite59, testResult60);
        java.lang.Class[] classArray63 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray64 = (java.lang.Class<?>[]) classArray63;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter65 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray64);
        java.lang.Class[] classArray68 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray69 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray68;
        junit.framework.TestSuite testSuite71 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray68, "hi!");
        org.junit.rules.Timeout timeout73 = org.junit.rules.Timeout.millis(1L);
        org.junit.rules.RuleChain ruleChain74 = org.junit.rules.RuleChain.outerRule((org.junit.rules.TestRule) timeout73);
        java.lang.Class[] classArray76 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray77 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray76;
        junit.framework.TestSuite testSuite79 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray76, "hi!");
        java.lang.Object[] objArray80 = new java.lang.Object[] { (byte) 1, expectedException3, methodSorters4, testSuite14, "hi!", true, methodSorters22, (short) -1, file24, couldNotGenerateValueException29, (-1.0d), testRunner32, '#', errorCollector34, initializationError39, str42, (short) 100, 0L, true, file46, (byte) -1, (byte) 1, testResult60, categoryFilter65, 0.0f, testSuite71, ruleChain74, testSuite79 };
        java.util.ArrayList<java.lang.Object> objList81 = new java.util.ArrayList<java.lang.Object>();
        boolean boolean82 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) objList81, objArray80);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.parameterized.TestWithParameters testWithParameters83 = new org.junit.runners.parameterized.TestWithParameters("org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n", testClass1, (java.util.List<java.lang.Object>) objList81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: The test class is missing.");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException3);
        org.junit.Assert.assertTrue("'" + methodSorters4 + "' != '" + org.junit.runners.MethodSorters.JVM + "'", methodSorters4.equals(org.junit.runners.MethodSorters.JVM));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException20);
        org.junit.Assert.assertTrue("'" + methodSorters22 + "' != '" + org.junit.runners.MethodSorters.JVM + "'", methodSorters22.equals(org.junit.runners.MethodSorters.JVM));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n" + "'", str28.equals("org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n" + "'", str42.equals("org.junit.AssumptionViolatedException: hi!\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray52);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray57);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray63);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray64);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter65);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray68);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(timeout73);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ruleChain74);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray76);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray77);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray80);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
    }
}
