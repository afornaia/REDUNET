import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest41.test042");
        org.junit.runner.Description description3 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        junit.framework.TestSuite testSuite4 = new junit.framework.TestSuite();
        junit.framework.Test test5 = null;
        junit.extensions.TestSetup testSetup6 = new junit.extensions.TestSetup(test5);
        junit.extensions.TestSetup testSetup8 = org.junit.internal.Checks.notNull(testSetup6, "hi!");
        junit.framework.TestResult testResult9 = new junit.framework.TestResult();
        testSuite4.runTest((junit.framework.Test) testSetup6, testResult9);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assert.assertEquals((java.lang.Object) description3, (java.lang.Object) testSetup6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup8);
    }
}

