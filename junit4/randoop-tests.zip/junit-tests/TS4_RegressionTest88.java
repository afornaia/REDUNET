import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest88 {

    public static boolean debug = false;

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest88.test89");
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray3 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray2;
        junit.framework.TestSuite testSuite5 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray2, "hi!");
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter6 = org.junit.experimental.categories.Categories.CategoryFilter.include(false, (java.lang.Class<?>[]) classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter6);
    }
}

