import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest29.test030");
        junit.framework.AssertionFailedError assertionFailedError1 = new junit.framework.AssertionFailedError("4.13-SNAPSHOT");
    }
}

