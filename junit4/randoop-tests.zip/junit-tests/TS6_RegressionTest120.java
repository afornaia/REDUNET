import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest120 {

    public static boolean debug = false;

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest120.test121");
        org.junit.runner.manipulation.Sorter sorter0 = org.junit.runner.manipulation.Sorter.NULL;
        org.junit.runner.Description description4 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams6 = new org.junit.runner.FilterFactoryParams(description4, "");
        org.junit.runner.Description description7 = description4.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description7);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache9 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult10 = new junit.framework.TestResult();
        junit.framework.Test test11 = null;
        junit.framework.AssertionFailedError assertionFailedError12 = null;
        testResult10.addFailure(test11, assertionFailedError12);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter14 = null;
        org.junit.runner.notification.RunNotifier runNotifier15 = jUnit4TestAdapterCache9.getNotifier(testResult10, jUnit4TestAdapter14);
        org.junit.runner.Description description19 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams21 = new org.junit.runner.FilterFactoryParams(description19, "");
        org.junit.runner.Description description22 = description19.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description22);
        runNotifier15.fireTestSuiteFinished(description22);
        int int25 = sorter0.compare(description7, description22);
        org.junit.runner.manipulation.Sorter sorter26 = org.junit.runner.manipulation.Sorter.NULL;
        org.junit.runner.manipulation.Ordering ordering28 = org.junit.internal.Checks.notNull((org.junit.runner.manipulation.Ordering) sorter26, "");
        java.util.Comparator<org.junit.runner.Description> descriptionComparator29 = sorter0.thenComparing((java.util.Comparator<org.junit.runner.Description>) sorter26);
        java.util.Comparator<org.junit.runner.Description> descriptionComparator30 = descriptionComparator29.reversed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sorter0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sorter26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ordering28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator30);
    }
}

