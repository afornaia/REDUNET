import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest4.test05");
        org.junit.runners.model.InitializationError initializationError1 = new org.junit.runners.model.InitializationError("");
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeNoException((java.lang.Throwable) initializationError1);
            org.junit.Assert.fail("Expected exception of type org.junit.AssumptionViolatedException; message: got: <org.junit.runners.model.InitializationError>, expected: null");
        } catch (org.junit.AssumptionViolatedException e) {
        // Expected exception.
        }
    }
}

