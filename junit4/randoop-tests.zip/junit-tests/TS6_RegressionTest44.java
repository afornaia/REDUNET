import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest44.test045");
        org.junit.ComparisonFailure comparisonFailure3 = new org.junit.ComparisonFailure("hi!", "hi!", "hi!");
        org.hamcrest.Matcher<java.lang.String> strMatcher4 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher5 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher4);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeThat((java.lang.Throwable) comparisonFailure3, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

