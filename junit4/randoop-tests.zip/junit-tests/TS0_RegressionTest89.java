import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest89.test090");
        org.junit.rules.ErrorCollector errorCollector0 = new org.junit.rules.ErrorCollector();
        java.lang.Throwable throwable1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable1);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException3 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException2);
        errorCollector0.addError((java.lang.Throwable) filterNotCreatedException3);
        java.lang.Throwable throwable5 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException6 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable5);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException7 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException6);
        errorCollector0.addError((java.lang.Throwable) couldNotGenerateValueException6);
        java.lang.Throwable throwable9 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException10 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable9);
        java.lang.Throwable throwable11 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException12 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable11);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException13 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException12);
        java.lang.Throwable throwable14 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException15 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable14);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException16 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException15);
        java.lang.Throwable[] throwableArray17 = new java.lang.Throwable[] { couldNotGenerateValueException10, couldNotGenerateValueException12, filterNotCreatedException16 };
        java.util.ArrayList<java.lang.Throwable> throwableList18 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList18, throwableArray17);
        org.junit.internal.runners.InitializationError initializationError20 = new org.junit.internal.runners.InitializationError((java.util.List<java.lang.Throwable>) throwableList18);
        org.junit.internal.runners.statements.Fail fail21 = new org.junit.internal.runners.statements.Fail((java.lang.Throwable) initializationError20);
        org.junit.runners.model.FrameworkMethod[] frameworkMethodArray22 = new org.junit.runners.model.FrameworkMethod[] {};
        java.util.ArrayList<org.junit.runners.model.FrameworkMethod> frameworkMethodList23 = new java.util.ArrayList<org.junit.runners.model.FrameworkMethod>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<org.junit.runners.model.FrameworkMethod>) frameworkMethodList23, frameworkMethodArray22);
        org.junit.internal.runners.statements.RunBefores runBefores26 = new org.junit.internal.runners.statements.RunBefores((org.junit.runners.model.Statement) fail21, (java.util.List<org.junit.runners.model.FrameworkMethod>) frameworkMethodList23, (java.lang.Object) "4.13-SNAPSHOT");
        org.junit.runner.Description description30 = org.junit.runner.Description.createTestDescription("4.13-SNAPSHOT", "categories [all]", (java.io.Serializable) 100.0f);
        java.util.Collection<java.lang.annotation.Annotation> annotationCollection31 = description30.getAnnotations();
        org.junit.runners.model.Statement statement32 = errorCollector0.apply((org.junit.runners.model.Statement) runBefores26, description30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(frameworkMethodArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationCollection31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement32);
    }
}

