import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest101.test102");
        org.junit.rules.Timeout timeout1 = new org.junit.rules.Timeout((int) (byte) 1);
        org.junit.runners.model.Statement statement2 = null;
        org.junit.runner.Description description3 = null;
        org.junit.runners.model.Statement statement4 = timeout1.apply(statement2, description3);
        org.junit.rules.Timeout timeout6 = new org.junit.rules.Timeout((int) (byte) 1);
        org.junit.runners.model.Statement statement7 = null;
        org.junit.runner.Description description8 = null;
        org.junit.runners.model.Statement statement9 = timeout6.apply(statement7, description8);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache10 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult11 = new junit.framework.TestResult();
        junit.framework.Test test12 = null;
        junit.framework.AssertionFailedError assertionFailedError13 = null;
        testResult11.addFailure(test12, assertionFailedError13);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter15 = null;
        org.junit.runner.notification.RunNotifier runNotifier16 = jUnit4TestAdapterCache10.getNotifier(testResult11, jUnit4TestAdapter15);
        org.junit.internal.runners.TestMethod testMethod18 = null;
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache19 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult20 = new junit.framework.TestResult();
        junit.framework.Test test21 = null;
        junit.framework.AssertionFailedError assertionFailedError22 = null;
        testResult20.addFailure(test21, assertionFailedError22);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter24 = null;
        org.junit.runner.notification.RunNotifier runNotifier25 = jUnit4TestAdapterCache19.getNotifier(testResult20, jUnit4TestAdapter24);
        org.junit.runner.Description description29 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams31 = new org.junit.runner.FilterFactoryParams(description29, "");
        org.junit.runner.Description description32 = description29.childlessCopy();
        org.junit.internal.runners.MethodRoadie methodRoadie33 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) '#', testMethod18, runNotifier25, description29);
        runNotifier16.fireTestSuiteStarted(description29);
        org.junit.runners.model.Statement statement35 = timeout1.apply(statement9, description29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement35);
    }
}

