import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest86.test087");
        junit.framework.TestSuite testSuite0 = new junit.framework.TestSuite();
        junit.framework.Test test1 = null;
        junit.extensions.TestSetup testSetup2 = new junit.extensions.TestSetup(test1);
        junit.extensions.TestSetup testSetup4 = org.junit.internal.Checks.notNull(testSetup2, "hi!");
        junit.framework.TestResult testResult5 = new junit.framework.TestResult();
        testSuite0.runTest((junit.framework.Test) testSetup2, testResult5);
        junit.extensions.TestDecorator testDecorator7 = new junit.extensions.TestDecorator((junit.framework.Test) testSetup2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup4);
    }
}

