import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest74.test075");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        org.junit.runner.Result result3 = org.junit.runner.JUnitCore.runClasses((java.lang.Class<?>[]) classArray1);
        org.junit.runner.notification.RunListener runListener4 = result3.createListener();
        org.junit.runner.notification.Failure failure5 = null;
        runListener4.testAssumptionFailure(failure5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(result3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runListener4);
    }
}

