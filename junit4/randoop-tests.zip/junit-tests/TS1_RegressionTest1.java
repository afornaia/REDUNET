import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest1.test02");
        org.junit.runner.notification.RunNotifier runNotifier0 = null;
        org.junit.internal.runners.TestClass testClass1 = null;
        org.junit.runner.Description description2 = null;
        java.lang.Runnable runnable3 = null;
        org.junit.internal.runners.ClassRoadie classRoadie4 = new org.junit.internal.runners.ClassRoadie(runNotifier0, testClass1, description2, runnable3);
    }
}

