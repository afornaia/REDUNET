import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest103.test104");
        java.lang.Throwable throwable2 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException3 = new org.junit.AssumptionViolatedException("", throwable2);
        java.lang.Throwable throwable5 = null;
        org.junit.AssumptionViolatedException assumptionViolatedException6 = new org.junit.AssumptionViolatedException("", throwable5);
        assumptionViolatedException3.addSuppressed((java.lang.Throwable) assumptionViolatedException6);
        org.junit.TestCouldNotBeSkippedException testCouldNotBeSkippedException8 = new org.junit.TestCouldNotBeSkippedException((org.junit.internal.AssumptionViolatedException) assumptionViolatedException3);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException9 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) assumptionViolatedException3);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException10 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException((java.lang.Throwable) filterNotCreatedException9);
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException11 = new org.junit.runner.manipulation.InvalidOrderingException("hi!", (java.lang.Throwable) filterNotCreatedException9);
        java.lang.Throwable[] throwableArray12 = filterNotCreatedException9.getSuppressed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray12);
    }
}

