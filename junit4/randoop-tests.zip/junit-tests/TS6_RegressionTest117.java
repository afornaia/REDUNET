import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest117.test118");
        junit.framework.TestResult testResult0 = new junit.framework.TestResult();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache1 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult2 = new junit.framework.TestResult();
        junit.framework.Test test3 = null;
        junit.framework.AssertionFailedError assertionFailedError4 = null;
        testResult2.addFailure(test3, assertionFailedError4);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter6 = null;
        org.junit.runner.notification.RunNotifier runNotifier7 = jUnit4TestAdapterCache1.getNotifier(testResult2, jUnit4TestAdapter6);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache8 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult9 = new junit.framework.TestResult();
        junit.framework.Test test10 = null;
        junit.framework.AssertionFailedError assertionFailedError11 = null;
        testResult9.addFailure(test10, assertionFailedError11);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter13 = null;
        org.junit.runner.notification.RunNotifier runNotifier14 = jUnit4TestAdapterCache8.getNotifier(testResult9, jUnit4TestAdapter13);
        org.junit.runner.Description description18 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams20 = new org.junit.runner.FilterFactoryParams(description18, "");
        org.junit.runner.Description description21 = description18.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description21);
        runNotifier14.fireTestSuiteFinished(description21);
        junit.framework.TestSuite testSuite24 = new junit.framework.TestSuite();
        junit.framework.TestSuite testSuite25 = new junit.framework.TestSuite();
        boolean boolean26 = jUnit4TestAdapterCache1.replace(description21, (junit.framework.Test) testSuite24, (junit.framework.Test) testSuite25);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache27 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult28 = new junit.framework.TestResult();
        junit.framework.Test test29 = null;
        junit.framework.AssertionFailedError assertionFailedError30 = null;
        testResult28.addFailure(test29, assertionFailedError30);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter32 = null;
        org.junit.runner.notification.RunNotifier runNotifier33 = jUnit4TestAdapterCache27.getNotifier(testResult28, jUnit4TestAdapter32);
        org.junit.runner.Description description37 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams39 = new org.junit.runner.FilterFactoryParams(description37, "");
        org.junit.runner.Description description40 = description37.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description40);
        runNotifier33.fireTestSuiteFinished(description40);
        org.junit.runner.Description description46 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams48 = new org.junit.runner.FilterFactoryParams(description46, "");
        org.junit.runner.Description description49 = description46.childlessCopy();
        runNotifier33.fireTestFinished(description49);
        org.junit.internal.runners.InitializationError initializationError52 = new org.junit.internal.runners.InitializationError("");
        org.junit.runner.notification.Failure failure53 = new org.junit.runner.notification.Failure(description49, (java.lang.Throwable) initializationError52);
        testResult0.addError((junit.framework.Test) testSuite25, (java.lang.Throwable) initializationError52);
        org.hamcrest.Matcher<java.lang.String> strMatcher55 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher56 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher55);
        throwableThrowableMessageMatcher56._dont_implement_Matcher___instead_extend_BaseMatcher_();
        // The following exception was thrown during execution in test generation
        try {
            org.junit.Assume.assumeThat((java.lang.Throwable) initializationError52, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description46);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description49);
    }
}

