import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest96.test097");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult1 = new junit.framework.TestResult();
        junit.framework.Test test2 = null;
        junit.framework.AssertionFailedError assertionFailedError3 = null;
        testResult1.addFailure(test2, assertionFailedError3);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter5 = null;
        org.junit.runner.notification.RunNotifier runNotifier6 = jUnit4TestAdapterCache0.getNotifier(testResult1, jUnit4TestAdapter5);
        org.junit.runner.Description description10 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams12 = new org.junit.runner.FilterFactoryParams(description10, "");
        org.junit.runner.Description description13 = description10.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description13);
        runNotifier6.fireTestSuiteFinished(description13);
        org.junit.internal.runners.TestClass testClass16 = null;
        org.junit.runner.Description description20 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        java.lang.Runnable runnable21 = null;
        org.junit.internal.runners.ClassRoadie classRoadie22 = new org.junit.internal.runners.ClassRoadie(runNotifier6, testClass16, description20, runnable21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description20);
    }
}

