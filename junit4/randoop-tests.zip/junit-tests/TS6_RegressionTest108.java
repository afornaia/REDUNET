import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest108.test109");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache2 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult3 = new junit.framework.TestResult();
        junit.framework.Test test4 = null;
        junit.framework.AssertionFailedError assertionFailedError5 = null;
        testResult3.addFailure(test4, assertionFailedError5);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter7 = null;
        org.junit.runner.notification.RunNotifier runNotifier8 = jUnit4TestAdapterCache2.getNotifier(testResult3, jUnit4TestAdapter7);
        org.junit.runner.Description description12 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams14 = new org.junit.runner.FilterFactoryParams(description12, "");
        org.junit.runner.Description description15 = description12.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description15);
        runNotifier8.fireTestSuiteFinished(description15);
        org.junit.runner.Description description21 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams23 = new org.junit.runner.FilterFactoryParams(description21, "");
        org.junit.runner.Description description24 = description21.childlessCopy();
        runNotifier8.fireTestFinished(description24);
        org.junit.internal.runners.InitializationError initializationError27 = new org.junit.internal.runners.InitializationError("");
        org.junit.runner.notification.Failure failure28 = new org.junit.runner.notification.Failure(description24, (java.lang.Throwable) initializationError27);
        org.junit.runner.Description description29 = failure28.getDescription();
        junit.framework.Test test30 = null;
        junit.extensions.TestSetup testSetup31 = new junit.extensions.TestSetup(test30);
        junit.extensions.TestSetup testSetup32 = new junit.extensions.TestSetup(test30);
        junit.framework.Test test33 = jUnit4TestAdapterCache0.replace(description29, (junit.framework.Test) testSetup32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test33);
    }
}

