import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest30.test031");
        java.lang.Class[] classArray2 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter4 = org.junit.experimental.categories.Categories.CategoryFilter.exclude((java.lang.Class<?>[]) classArray2);
        java.lang.Class[] classArray8 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray9 = (java.lang.Class<?>[]) classArray8;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter10 = org.junit.experimental.categories.Categories.CategoryFilter.exclude((java.lang.Class<?>[]) classArray8);
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter11 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(true, (java.lang.Class<?>[]) classArray8);
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter12 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(false, (java.lang.Class<?>[]) classArray8);
        org.junit.Assert.assertArrayEquals("categories [all]", (java.lang.Object[]) classArray2, (java.lang.Object[]) classArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter12);
    }
}

