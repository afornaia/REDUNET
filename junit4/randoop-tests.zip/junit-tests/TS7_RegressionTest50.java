import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest50.test051");
        java.lang.Throwable throwable0 = null;
        org.junit.runners.model.InitializationError initializationError1 = new org.junit.runners.model.InitializationError(throwable0);
        org.junit.runner.manipulation.InvalidOrderingException invalidOrderingException3 = new org.junit.runner.manipulation.InvalidOrderingException("");
        java.lang.Throwable[] throwableArray4 = new java.lang.Throwable[] { initializationError1, invalidOrderingException3 };
        java.util.ArrayList<java.lang.Throwable> throwableList5 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList5, throwableArray4);
        org.junit.internal.runners.model.MultipleFailureException multipleFailureException7 = new org.junit.internal.runners.model.MultipleFailureException((java.util.List<java.lang.Throwable>) throwableList5);
        org.junit.runners.model.MultipleFailureException multipleFailureException8 = new org.junit.runners.model.MultipleFailureException((java.util.List<java.lang.Throwable>) throwableList5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

