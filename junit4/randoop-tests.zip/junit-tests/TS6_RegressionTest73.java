import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest73.test074");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.util.Collection<junit.framework.Test> testCollection1 = jUnit4TestAdapterCache0.values();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testCollection1);
    }
}

