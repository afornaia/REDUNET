import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest18.test019");
        org.junit.internal.ExactComparisonCriteria exactComparisonCriteria0 = new org.junit.internal.ExactComparisonCriteria();
    }
}

