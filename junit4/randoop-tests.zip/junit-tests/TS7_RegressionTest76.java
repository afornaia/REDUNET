import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest76.test077");
        org.hamcrest.Matcher<? super java.lang.Throwable> wildcardMatcher1 = null;
        org.hamcrest.Matcher[] matcherArray3 = new org.hamcrest.Matcher[1];
        @SuppressWarnings("unchecked")
        org.hamcrest.Matcher<? super java.lang.Throwable>[] wildcardMatcherArray4 = (org.hamcrest.Matcher<? super java.lang.Throwable>[]) matcherArray3;
        wildcardMatcherArray4[0] = wildcardMatcher1;
        org.hamcrest.Matcher<java.lang.Iterable<java.lang.Throwable>> throwableIterableMatcher7 = org.junit.matchers.JUnitMatchers.hasItems(wildcardMatcherArray4);
        java.lang.String str8 = org.junit.experimental.theories.internal.ParameterizedAssertionError.join("1.001010", (java.lang.Object[]) wildcardMatcherArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(matcherArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMatcherArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableIterableMatcher7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "null" + "'", str8.equals("null"));
    }
}

