import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest79.test080");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description1 = org.junit.runner.Description.EMPTY;
        org.junit.runner.Description description2 = description1.childlessCopy();
        boolean boolean3 = description1.isSuite();
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher4 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher5 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher4);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException> multipleFailureExceptionThrowableCauseMatcher6 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.runners.model.MultipleFailureException>(printableResultMatcher5);
        boolean boolean7 = description1.equals((java.lang.Object) multipleFailureExceptionThrowableCauseMatcher6);
        java.lang.Class<?> wildcardClass8 = description1.getTestClass();
        junit.framework.Test test9 = jUnit4TestAdapterCache0.asTest(description1);
        int int10 = jUnit4TestAdapterCache0.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(test9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }
}

