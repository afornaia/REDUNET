import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest39.test040");
        org.junit.runners.model.TestClass testClass0 = null;
        org.junit.experimental.theories.internal.SpecificDataPointsSupplier specificDataPointsSupplier1 = new org.junit.experimental.theories.internal.SpecificDataPointsSupplier(testClass0);
    }
}

