import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest86.test87");
        java.io.File file0 = null;
        org.junit.rules.TemporaryFolder temporaryFolder1 = new org.junit.rules.TemporaryFolder(file0);
        org.junit.rules.ExpectedException expectedException2 = org.junit.rules.ExpectedException.none();
        org.junit.runners.model.Statement statement3 = null;
        org.junit.runner.Description description4 = null;
        org.junit.runners.model.Statement statement5 = expectedException2.apply(statement3, description4);
        junit.framework.Assert.assertNotNull((java.lang.Object) statement5);
        org.junit.runner.Description description7 = null;
        org.junit.runners.model.Statement statement8 = temporaryFolder1.apply(statement5, description7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expectedException2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(statement8);
    }
}

