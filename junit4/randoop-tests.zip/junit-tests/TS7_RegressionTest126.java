import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest126 {

    public static boolean debug = false;

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest126.test127");
        java.lang.annotation.Annotation[] annotationArray1 = new java.lang.annotation.Annotation[] {};
        org.junit.runner.Description description2 = org.junit.runner.Description.createSuiteDescription("1.001010", annotationArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description2);
    }
}

