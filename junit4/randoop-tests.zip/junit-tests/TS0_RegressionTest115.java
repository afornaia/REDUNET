import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest115 {

    public static boolean debug = false;

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest115.test116");
        org.hamcrest.Matcher<java.lang.Iterable<? super java.io.Serializable>> wildcardIterableMatcher1 = org.junit.matchers.JUnitMatchers.hasItem((java.io.Serializable) true);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError> initializationErrorThrowableCauseMatcher2 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError>(wildcardIterableMatcher1);
        initializationErrorThrowableCauseMatcher2._dont_implement_Matcher___instead_extend_BaseMatcher_();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher1);
    }
}

