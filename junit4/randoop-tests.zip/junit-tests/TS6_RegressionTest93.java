import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest93.test094");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache0 = new junit.framework.JUnit4TestAdapterCache();
        java.lang.Object obj1 = jUnit4TestAdapterCache0.clone();
        java.util.Set<java.util.Map.Entry<org.junit.runner.Description, junit.framework.Test>> descriptionEntrySet2 = jUnit4TestAdapterCache0.entrySet();
        junit.framework.Test test4 = null;
        junit.extensions.TestSetup testSetup5 = new junit.extensions.TestSetup(test4);
        junit.framework.Test test6 = jUnit4TestAdapterCache0.getOrDefault((java.lang.Object) 0.0d, test4);
        java.lang.String str7 = jUnit4TestAdapterCache0.toString();
        org.junit.internal.runners.TestMethod testMethod9 = null;
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache10 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult11 = new junit.framework.TestResult();
        junit.framework.Test test12 = null;
        junit.framework.AssertionFailedError assertionFailedError13 = null;
        testResult11.addFailure(test12, assertionFailedError13);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter15 = null;
        org.junit.runner.notification.RunNotifier runNotifier16 = jUnit4TestAdapterCache10.getNotifier(testResult11, jUnit4TestAdapter15);
        org.junit.runner.Description description20 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams22 = new org.junit.runner.FilterFactoryParams(description20, "");
        org.junit.runner.Description description23 = description20.childlessCopy();
        org.junit.internal.runners.MethodRoadie methodRoadie24 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) '#', testMethod9, runNotifier16, description20);
        java.io.File file25 = null;
        org.junit.rules.TemporaryFolder temporaryFolder26 = new org.junit.rules.TemporaryFolder(file25);
        temporaryFolder26.create();
        java.lang.String[] strArray34 = new java.lang.String[] { "hi!", "hi!", "", "hi!", "", "hi!" };
        java.io.File file35 = temporaryFolder26.newFolder(strArray34);
        org.junit.experimental.max.MaxHistory maxHistory36 = org.junit.experimental.max.MaxHistory.forFolder(file35);
        boolean boolean37 = jUnit4TestAdapterCache0.remove((java.lang.Object) description20, (java.lang.Object) maxHistory36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj1.toString(), "{}");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionEntrySet2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(file35);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file35.getParent(), "/tmp/junit8093938708327549244/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertEquals(file35.toString(), "/tmp/junit8093938708327549244/hi!/hi!/hi!/hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(maxHistory36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }
}
