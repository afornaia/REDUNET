import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest86.test087");
        org.hamcrest.Matcher<java.lang.Iterable<? super java.io.Serializable>> wildcardIterableMatcher1 = org.junit.matchers.JUnitMatchers.hasItem((java.io.Serializable) true);
        org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError> initializationErrorThrowableCauseMatcher2 = new org.junit.internal.matchers.ThrowableCauseMatcher<org.junit.internal.runners.InitializationError>(wildcardIterableMatcher1);
        org.junit.experimental.theories.internal.BooleanSupplier booleanSupplier3 = new org.junit.experimental.theories.internal.BooleanSupplier();
        org.hamcrest.Description description4 = null;
        // The following exception was thrown during execution in test generation
        try {
            initializationErrorThrowableCauseMatcher2.describeMismatch((java.lang.Object) booleanSupplier3, description4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher1);
    }
}

