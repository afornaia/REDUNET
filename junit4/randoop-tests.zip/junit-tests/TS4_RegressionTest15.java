import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest15.test16");
        org.junit.runners.model.TestClass testClass1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        java.lang.Class[] classArray6 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<? extends junit.framework.TestCase>[] wildcardClassArray7 = (java.lang.Class<? extends junit.framework.TestCase>[]) classArray6;
        junit.framework.TestSuite testSuite9 = new junit.framework.TestSuite((java.lang.Class<? extends junit.framework.TestCase>[]) classArray6, "hi!");
        org.junit.rules.Timeout timeout11 = org.junit.rules.Timeout.millis(1L);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException12 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        java.lang.Throwable[] throwableArray13 = new java.lang.Throwable[] { couldNotGenerateValueException12 };
        java.util.ArrayList<java.lang.Throwable> throwableList14 = new java.util.ArrayList<java.lang.Throwable>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.Throwable>) throwableList14, throwableArray13);
        org.junit.runners.model.InitializationError initializationError16 = new org.junit.runners.model.InitializationError((java.util.List<java.lang.Throwable>) throwableList14);
        org.junit.runners.MethodSorters methodSorters17 = org.junit.runners.MethodSorters.JVM;
        java.util.Comparator<org.junit.runner.Description> descriptionComparator21 = null;
        org.junit.runner.manipulation.Sorter sorter22 = new org.junit.runner.manipulation.Sorter(descriptionComparator21);
        org.junit.internal.builders.JUnit3Builder jUnit3Builder27 = new org.junit.internal.builders.JUnit3Builder();
        org.hamcrest.Matcher<java.lang.Iterable<? super org.junit.runners.model.RunnerBuilder>> wildcardIterableMatcher28 = org.junit.matchers.JUnitMatchers.hasItem((org.junit.runners.model.RunnerBuilder) jUnit3Builder27);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache33 = new junit.framework.JUnit4TestAdapterCache();
        org.junit.runner.Description description34 = null;
        junit.framework.Test test35 = null;
        junit.framework.Test test36 = null;
        boolean boolean37 = jUnit4TestAdapterCache33.replace(description34, test35, test36);
        org.junit.runner.Computer computer40 = org.junit.experimental.ParallelComputer.methods();
        org.junit.rules.Timeout timeout42 = org.junit.rules.Timeout.millis(1L);
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException43 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException();
        org.junit.runner.notification.RunNotifier runNotifier45 = null;
        org.junit.internal.runners.TestClass testClass46 = null;
        org.junit.runner.Description description47 = null;
        java.lang.Runnable runnable48 = null;
        org.junit.internal.runners.ClassRoadie classRoadie49 = new org.junit.internal.runners.ClassRoadie(runNotifier45, testClass46, description47, runnable48);
        org.junit.AssumptionViolatedException assumptionViolatedException53 = new org.junit.AssumptionViolatedException("hi!");
        org.junit.internal.builders.JUnit3Builder jUnit3Builder54 = new org.junit.internal.builders.JUnit3Builder();
        org.junit.runners.model.TestClass testClass57 = null;
        org.junit.experimental.theories.internal.SpecificDataPointsSupplier specificDataPointsSupplier58 = new org.junit.experimental.theories.internal.SpecificDataPointsSupplier(testClass57);
        java.lang.Object[] objArray59 = new java.lang.Object[] { couldNotGenerateValueException2, 1, '#', testSuite9, timeout11, initializationError16, methodSorters17, true, "", (short) 1, sorter22, (byte) 10, (short) -1, 10.0f, '#', jUnit3Builder27, (-1.0d), "", (short) 1, '4', description34, 'a', '4', computer40, timeout42, couldNotGenerateValueException43, (-1.0f), description47, (short) 0, 100, "hi!", jUnit3Builder54, false, (-1.0f), specificDataPointsSupplier58 };
        java.util.ArrayList<java.lang.Object> objList60 = new java.util.ArrayList<java.lang.Object>();
        boolean boolean61 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) objList60, objArray59);
        // The following exception was thrown during execution in test generation
        try {
            org.junit.runners.parameterized.TestWithParameters testWithParameters62 = new org.junit.runners.parameterized.TestWithParameters("", testClass1, (java.util.List<java.lang.Object>) objList60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: The test class is missing.");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(timeout11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + methodSorters17 + "' != '" + org.junit.runners.MethodSorters.JVM + "'", methodSorters17.equals(org.junit.runners.MethodSorters.JVM));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(computer40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(timeout42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
    }
}

