import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest52.test053");
        org.junit.runners.MethodSorters methodSorters0 = org.junit.runners.MethodSorters.JVM;
        java.util.Comparator<java.lang.reflect.Method> methodComparator1 = methodSorters0.getComparator();
        org.junit.Assert.assertTrue("'" + methodSorters0 + "' != '" + org.junit.runners.MethodSorters.JVM + "'", methodSorters0.equals(org.junit.runners.MethodSorters.JVM));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(methodComparator1);
    }
}

