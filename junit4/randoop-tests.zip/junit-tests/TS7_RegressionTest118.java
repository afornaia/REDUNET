import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest118 {

    public static boolean debug = false;

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest118.test119");
        org.junit.experimental.results.PrintableResult printableResult1 = null;
        org.hamcrest.Matcher<java.lang.Throwable> throwableMatcher4 = null;
        org.hamcrest.Matcher<org.junit.experimental.results.PrintableResult> printableResultMatcher5 = org.junit.experimental.results.ResultMatchers.hasSingleFailureMatching(throwableMatcher4);
        org.junit.internal.AssumptionViolatedException assumptionViolatedException6 = new org.junit.internal.AssumptionViolatedException("hi!", (java.lang.Object) 1L, printableResultMatcher5);
        org.junit.AssumptionViolatedException assumptionViolatedException7 = new org.junit.AssumptionViolatedException("1.001010", printableResult1, printableResultMatcher5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(printableResultMatcher5);
    }
}

