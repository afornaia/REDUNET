import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest94 {

    public static boolean debug = false;

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest94.test095");
        java.io.PrintStream printStream0 = null;
        junit.textui.ResultPrinter resultPrinter1 = new junit.textui.ResultPrinter(printStream0);
        junit.textui.TestRunner testRunner2 = new junit.textui.TestRunner(resultPrinter1);
        java.lang.String str4 = testRunner2.elapsedTimeAsString((long) (-1));
        testRunner2.testStarted("4.13-SNAPSHOT");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "-0.001" + "'", str4.equals("-0.001"));
    }
}

