import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest65.test066");
        org.junit.rules.ErrorCollector errorCollector0 = new org.junit.rules.ErrorCollector();
        java.lang.Throwable throwable1 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException2 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable1);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException3 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException2);
        errorCollector0.addError((java.lang.Throwable) filterNotCreatedException3);
        java.lang.Throwable throwable5 = null;
        org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException couldNotGenerateValueException6 = new org.junit.experimental.theories.PotentialAssignment.CouldNotGenerateValueException(throwable5);
        org.junit.runner.FilterFactory.FilterNotCreatedException filterNotCreatedException7 = new org.junit.runner.FilterFactory.FilterNotCreatedException((java.lang.Exception) couldNotGenerateValueException6);
        errorCollector0.addError((java.lang.Throwable) couldNotGenerateValueException6);
        java.lang.Iterable<? super java.io.Serializable> wildcardIterable9 = null;
        java.lang.Iterable<? super java.io.Serializable> wildcardIterable10 = null;
        org.hamcrest.Matcher<java.lang.Iterable<? super java.io.Serializable>> wildcardIterableMatcher12 = org.junit.matchers.JUnitMatchers.hasItem((java.io.Serializable) true);
        org.junit.AssumptionViolatedException assumptionViolatedException13 = new org.junit.AssumptionViolatedException(wildcardIterable10, wildcardIterableMatcher12);
        errorCollector0.checkThat(wildcardIterable9, wildcardIterableMatcher12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableMatcher12);
    }
}

