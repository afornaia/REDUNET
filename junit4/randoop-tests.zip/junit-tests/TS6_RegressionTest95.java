import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest95.test096");
        org.junit.internal.InexactComparisonCriteria inexactComparisonCriteria1 = new org.junit.internal.InexactComparisonCriteria((double) 97);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache3 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache4 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult5 = new junit.framework.TestResult();
        junit.framework.Test test6 = null;
        junit.framework.AssertionFailedError assertionFailedError7 = null;
        testResult5.addFailure(test6, assertionFailedError7);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter9 = null;
        org.junit.runner.notification.RunNotifier runNotifier10 = jUnit4TestAdapterCache4.getNotifier(testResult5, jUnit4TestAdapter9);
        org.junit.internal.runners.TestMethod testMethod12 = null;
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache13 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult14 = new junit.framework.TestResult();
        junit.framework.Test test15 = null;
        junit.framework.AssertionFailedError assertionFailedError16 = null;
        testResult14.addFailure(test15, assertionFailedError16);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter18 = null;
        org.junit.runner.notification.RunNotifier runNotifier19 = jUnit4TestAdapterCache13.getNotifier(testResult14, jUnit4TestAdapter18);
        org.junit.runner.Description description23 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams25 = new org.junit.runner.FilterFactoryParams(description23, "");
        org.junit.runner.Description description26 = description23.childlessCopy();
        org.junit.internal.runners.MethodRoadie methodRoadie27 = new org.junit.internal.runners.MethodRoadie((java.lang.Object) '#', testMethod12, runNotifier19, description23);
        runNotifier10.fireTestSuiteStarted(description23);
        org.junit.runner.manipulation.Sorter sorter29 = org.junit.runner.manipulation.Sorter.NULL;
        org.junit.runner.Description description33 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams35 = new org.junit.runner.FilterFactoryParams(description33, "");
        org.junit.runner.Description description36 = description33.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description36);
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache38 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.TestResult testResult39 = new junit.framework.TestResult();
        junit.framework.Test test40 = null;
        junit.framework.AssertionFailedError assertionFailedError41 = null;
        testResult39.addFailure(test40, assertionFailedError41);
        junit.framework.JUnit4TestAdapter jUnit4TestAdapter43 = null;
        org.junit.runner.notification.RunNotifier runNotifier44 = jUnit4TestAdapterCache38.getNotifier(testResult39, jUnit4TestAdapter43);
        org.junit.runner.Description description48 = org.junit.runner.Description.createTestDescription("", "", (java.io.Serializable) (-1));
        org.junit.runner.FilterFactoryParams filterFactoryParams50 = new org.junit.runner.FilterFactoryParams(description48, "");
        org.junit.runner.Description description51 = description48.childlessCopy();
        org.junit.Assert.assertNotNull((java.lang.Object) description51);
        runNotifier44.fireTestSuiteFinished(description51);
        int int54 = sorter29.compare(description36, description51);
        org.junit.runner.manipulation.Sorter sorter55 = org.junit.runner.manipulation.Sorter.NULL;
        org.junit.runner.manipulation.Ordering ordering57 = org.junit.internal.Checks.notNull((org.junit.runner.manipulation.Ordering) sorter55, "");
        java.util.Comparator<org.junit.runner.Description> descriptionComparator58 = sorter29.thenComparing((java.util.Comparator<org.junit.runner.Description>) sorter55);
        boolean boolean59 = description23.equals((java.lang.Object) sorter55);
        // The following exception was thrown during execution in test generation
        try {
            inexactComparisonCriteria1.arrayEquals("4.13-SNAPSHOT", (java.lang.Object) jUnit4TestAdapterCache3, (java.lang.Object) boolean59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sorter29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(runNotifier44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(description51);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sorter55);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ordering57);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(descriptionComparator58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }
}

