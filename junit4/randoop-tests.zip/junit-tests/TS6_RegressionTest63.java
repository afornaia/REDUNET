import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest63.test064");
        junit.framework.Test test0 = null;
        junit.extensions.TestSetup testSetup1 = new junit.extensions.TestSetup(test0);
        junit.extensions.TestSetup testSetup3 = org.junit.internal.Checks.notNull(testSetup1, "hi!");
        junit.framework.Test test4 = testSetup1.getTest();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test4);
    }
}

