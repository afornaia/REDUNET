import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest47.test48");
        org.junit.rules.Timeout timeout1 = org.junit.rules.Timeout.millis(1L);
        org.junit.rules.RuleChain ruleChain2 = org.junit.rules.RuleChain.outerRule((org.junit.rules.TestRule) timeout1);
        org.junit.rules.RuleChain ruleChain3 = org.junit.rules.RuleChain.outerRule((org.junit.rules.TestRule) ruleChain2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(timeout1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ruleChain2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ruleChain3);
    }
}

