import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest35.test036");
        org.junit.runner.manipulation.Filter filter0 = org.junit.runner.manipulation.Filter.ALL;
        org.junit.runner.manipulation.Filter filter1 = org.junit.runner.manipulation.Filter.ALL;
        org.junit.runner.manipulation.Filter filter2 = filter0.intersect(filter1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter2);
    }
}

