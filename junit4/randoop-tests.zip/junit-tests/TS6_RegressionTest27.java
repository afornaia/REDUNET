import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest27.test028");
        junit.textui.ResultPrinter resultPrinter0 = null;
        junit.textui.TestRunner testRunner1 = new junit.textui.TestRunner(resultPrinter0);
        junit.framework.Test test2 = null;
        junit.extensions.TestSetup testSetup3 = new junit.extensions.TestSetup(test2);
        junit.extensions.TestSetup testSetup5 = org.junit.internal.Checks.notNull(testSetup3, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            testRunner1.startTest((junit.framework.Test) testSetup3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(testSetup5);
    }
}

