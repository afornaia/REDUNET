import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest101.test102");
        org.junit.runners.parameterized.BlockJUnit4ClassRunnerWithParametersFactory blockJUnit4ClassRunnerWithParametersFactory0 = new org.junit.runners.parameterized.BlockJUnit4ClassRunnerWithParametersFactory();
    }
}

