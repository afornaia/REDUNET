import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest59.test060");
        junit.framework.JUnit4TestAdapterCache jUnit4TestAdapterCache2 = new junit.framework.JUnit4TestAdapterCache();
        junit.framework.Test test4 = jUnit4TestAdapterCache2.get((java.lang.Object) (byte) 100);
        org.hamcrest.Matcher<java.lang.String> strMatcher5 = null;
        org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable> throwableThrowableMessageMatcher6 = new org.junit.internal.matchers.ThrowableMessageMatcher<java.lang.Throwable>(strMatcher5);
        org.junit.internal.AssumptionViolatedException assumptionViolatedException7 = new org.junit.internal.AssumptionViolatedException("org.junit.experimental.max.CouldNotReadCoreException\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat randoop.util.ConstructorReflectionCode.runReflectionCodeRaw(ConstructorReflectionCode.java:51)\n\tat randoop.util.ReflectionCode.runReflectionCode(ReflectionCode.java:59)\n\tat randoop.util.ReflectionExecutor.executeReflectionCodeUnThreaded(ReflectionExecutor.java:162)\n\tat randoop.util.ReflectionExecutor.executeReflectionCode(ReflectionExecutor.java:93)\n\tat randoop.operation.ConstructorCall.execute(ConstructorCall.java:181)\n\tat randoop.operation.TypedOperation.execute(TypedOperation.java:273)\n\tat randoop.sequence.Statement.execute(Statement.java:163)\n\tat randoop.sequence.ExecutableSequence.executeStatement(ExecutableSequence.java:405)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:302)\n\tat randoop.sequence.ExecutableSequence.execute(ExecutableSequence.java:230)\n\tat randoop.generation.ForwardGenerator.step(ForwardGenerator.java:211)\n\tat randoop.generation.AbstractGenerator.createAndClassifySequences(AbstractGenerator.java:304)\n\tat randoop.main.GenTests.handle(GenTests.java:467)\n\tat randoop.main.Main.nonStaticMain(Main.java:66)\n\tat randoop.main.Main.main(Main.java:30)\n", false, (java.lang.Object) test4, (org.hamcrest.Matcher<java.lang.Throwable>) throwableThrowableMessageMatcher6);
        org.hamcrest.Description description8 = null;
        // The following exception was thrown during execution in test generation
        try {
            throwableThrowableMessageMatcher6.describeTo(description8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(test4);
    }
}

