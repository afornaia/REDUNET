import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest116.test117");
        org.junit.runner.Request request0 = null;
        java.util.Random random1 = null;
        org.junit.runner.manipulation.Ordering ordering2 = org.junit.runner.manipulation.Ordering.shuffledBy(random1);
        org.junit.internal.requests.OrderingRequest orderingRequest3 = new org.junit.internal.requests.OrderingRequest(request0, ordering2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(ordering2);
    }
}

