import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest100.test101");
        java.lang.Class[] classArray1 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray2 = (java.lang.Class<?>[]) classArray1;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter3 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray2);
        java.lang.Class[] classArray5 = new java.lang.Class[0];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray6 = (java.lang.Class<?>[]) classArray5;
        org.junit.experimental.categories.Categories.CategoryFilter categoryFilter7 = org.junit.experimental.categories.Categories.CategoryFilter.exclude(wildcardClassArray6);
        org.junit.runner.manipulation.Filter filter8 = categoryFilter3.intersect((org.junit.runner.manipulation.Filter) categoryFilter7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(categoryFilter7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(filter8);
    }
}

