import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest60.test61");
        org.apache.commons.cli.Option option3 = new org.apache.commons.cli.Option("", false, "usage: ");
        char char4 = option3.getValueSeparator();
        java.lang.String str5 = option3.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char4 + "' != '" + '\u0000' + "'", char4 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[ option:   :: usage:  :: class java.lang.String ]" + "'", str5.equals("[ option:   :: usage:  :: class java.lang.String ]"));
    }
}

