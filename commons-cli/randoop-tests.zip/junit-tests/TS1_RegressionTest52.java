import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest52.test53");
        org.apache.commons.cli.Option option2 = new org.apache.commons.cli.Option("arg", "usage: ");
        option2.setLongOpt("");
        java.lang.String str5 = option2.getOpt();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "arg" + "'", str5.equals("arg"));
    }
}

