import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest12.test13");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "", false, "hi!");
        java.util.List<java.lang.String> strList5 = option4.getValuesList();
        option4.setArgs(100);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList5);
    }
}

