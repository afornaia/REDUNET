import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest48.test49");
        org.apache.commons.cli.CommandLine.Builder builder0 = new org.apache.commons.cli.CommandLine.Builder();
        org.apache.commons.cli.Option option5 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.Class<java.net.URL> uRLClass6 = org.apache.commons.cli.PatternOptionBuilder.URL_VALUE;
        option5.setType(uRLClass6);
        char char8 = option5.getValueSeparator();
        java.lang.String str9 = option5.toString();
        org.apache.commons.cli.CommandLine.Builder builder10 = builder0.addOption(option5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(uRLClass6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\u0000' + "'", char8 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[ option:  hi!  ::  :: class java.net.URL ]" + "'", str9.equals("[ option:  hi!  ::  :: class java.net.URL ]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder10);
    }
}

