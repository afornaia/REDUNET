import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest51.test52");
        org.apache.commons.cli.OptionGroup optionGroup1 = new org.apache.commons.cli.OptionGroup();
        java.util.Collection<java.lang.String> strCollection2 = optionGroup1.getNames();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = org.apache.commons.cli.TypeHandler.createValue("", (java.lang.Object) strCollection2);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.LinkedHashMap$LinkedKeySet cannot be cast to java.lang.Class");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strCollection2);
    }
}

