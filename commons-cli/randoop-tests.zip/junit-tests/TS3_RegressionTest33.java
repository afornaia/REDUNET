import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest33.test34");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String str2 = options1.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[ Options: [ short {a=[ option: a  :: null ], r=[ option: r  :: null ], g=[ option: g  :: null ]} ] [ long {} ]" + "'", str2.equals("[ Options: [ short {a=[ option: a  :: null ], r=[ option: r  :: null ], g=[ option: g  :: null ]} ] [ long {} ]"));
    }
}

