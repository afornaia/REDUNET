import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest76.test77");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        java.lang.String str1 = helpFormatter0.defaultLongOptPrefix;
        helpFormatter0.setLeftPadding(0);
        helpFormatter0.defaultOptPrefix = "usage: ";
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "--" + "'", str1.equals("--"));
    }
}

