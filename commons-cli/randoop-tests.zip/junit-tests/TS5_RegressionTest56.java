import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest56.test57");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option3 = options1.getOption("usage: ");
        java.util.List list4 = options1.getRequiredOptions();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(list4);
    }
}

