import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest38.test39");
        org.apache.commons.cli.CommandLine.Builder builder0 = new org.apache.commons.cli.CommandLine.Builder();
        org.apache.commons.cli.CommandLine.Builder builder2 = builder0.addArg("hi!");
        java.lang.Class<?> wildcardClass3 = builder0.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}

