import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest68.test69");
        // The following exception was thrown during execution in test generation
        try {
            java.net.URL uRL1 = org.apache.commons.cli.TypeHandler.createURL("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: Unable to parse the URL: hi!");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

