import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest32.test33");
        org.apache.commons.cli.Option option2 = new org.apache.commons.cli.Option("arg", "usage: ");
        org.apache.commons.cli.OptionBuilder optionBuilder4 = org.apache.commons.cli.OptionBuilder.withDescription("arg");
        boolean boolean5 = option2.equals((java.lang.Object) "arg");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionBuilder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

