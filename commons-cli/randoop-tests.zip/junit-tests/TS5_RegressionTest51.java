import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest51.test52");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
    }
}

