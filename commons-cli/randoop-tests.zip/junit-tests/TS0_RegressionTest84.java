import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest84.test85");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "", true, "org.apache.commons.cli.AlreadySelectedException: ");
        boolean boolean5 = option4.hasArgName();
        boolean boolean6 = option4.hasLongOpt();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }
}

