import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest60.test61");
        org.apache.commons.cli.BasicParser basicParser0 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Options options1 = new org.apache.commons.cli.Options();
        java.lang.String[] strArray5 = new java.lang.String[] { "", " ", "arg" };
        java.util.Properties properties6 = null;
        org.apache.commons.cli.CommandLine commandLine7 = basicParser0.parse(options1, strArray5, properties6);
        java.lang.String[] strArray9 = commandLine7.getOptionValues("--");
        org.apache.commons.cli.Option option13 = new org.apache.commons.cli.Option("arg", true, "arg");
        java.lang.String str14 = option13.getArgName();
        java.lang.String str15 = commandLine7.getOptionValue(option13);
        boolean boolean17 = commandLine7.hasOption("usage: ");
        boolean boolean19 = commandLine7.hasOption(' ');
        java.lang.String str22 = commandLine7.getOptionValue('a', "usage: ");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "usage: " + "'", str22.equals("usage: "));
    }
}

