import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest66.test67");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create('\u0000');
        org.apache.commons.cli.Option option5 = new org.apache.commons.cli.Option("", false, "usage: ");
        char char6 = option5.getValueSeparator();
        boolean boolean7 = option1.equals((java.lang.Object) char6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char6 + "' != '" + '\u0000' + "'", char6 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

