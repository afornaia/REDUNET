import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest106.test107");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.cli.Option option3 = new org.apache.commons.cli.Option("[ option: arg  [ARG] :: null :: class java.lang.String ]", false, "arg");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The option '[ option: arg  [ARG] :: null :: class java.lang.String ]' contains an illegal character : '['");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

