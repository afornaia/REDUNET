import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest77.test78");
        org.apache.commons.cli.DefaultParser defaultParser1 = new org.apache.commons.cli.DefaultParser(true);
        org.apache.commons.cli.Options options2 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options5 = options2.addOption("arg", "arg");
        java.lang.String[] strArray11 = new java.lang.String[] { "-", "hi!", "--", "hi!", " " };
        org.apache.commons.cli.CommandLine commandLine12 = defaultParser1.parse(options2, strArray11);
        org.apache.commons.cli.Options options13 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options16 = options13.addOption("arg", "arg");
        org.apache.commons.cli.Option option19 = new org.apache.commons.cli.Option("arg", "usage: ");
        option19.setLongOpt("");
        java.lang.String str22 = option19.getLongOpt();
        org.apache.commons.cli.Options options23 = options13.addOption(option19);
        org.apache.commons.cli.BasicParser basicParser24 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Options options25 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.OptionGroup optionGroup26 = new org.apache.commons.cli.OptionGroup();
        org.apache.commons.cli.Options options27 = options25.addOptionGroup(optionGroup26);
        org.apache.commons.cli.DefaultParser defaultParser29 = new org.apache.commons.cli.DefaultParser(true);
        org.apache.commons.cli.Options options30 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options33 = options30.addOption("arg", "arg");
        java.lang.String[] strArray39 = new java.lang.String[] { "-", "hi!", "--", "hi!", " " };
        org.apache.commons.cli.CommandLine commandLine40 = defaultParser29.parse(options30, strArray39);
        java.util.Properties properties41 = null;
        org.apache.commons.cli.CommandLine commandLine43 = basicParser24.parse(options25, strArray39, properties41, true);
        org.apache.commons.cli.CommandLine commandLine45 = defaultParser1.parse(options23, strArray39, true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine45);
    }
}

