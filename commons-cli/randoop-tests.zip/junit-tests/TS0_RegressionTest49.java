import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest49.test50");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Number number1 = org.apache.commons.cli.TypeHandler.createNumber("[ option: a  :: null :: class java.lang.String ]");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: For input string: \"[ option: a  :: null :: class java.lang.String ]\"");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

