import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest14.test15");
        java.lang.Class<java.io.File[]> fileArrayClass1 = org.apache.commons.cli.PatternOptionBuilder.FILES_VALUE;
        org.apache.commons.cli.OptionBuilder optionBuilder2 = org.apache.commons.cli.OptionBuilder.withType(fileArrayClass1);
        // The following exception was thrown during execution in test generation
        try {
            java.io.File[] fileArray3 = org.apache.commons.cli.TypeHandler.createValue("", fileArrayClass1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Not yet implemented");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(fileArrayClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionBuilder2);
    }
}

