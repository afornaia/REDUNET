import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest49.test50");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        int int1 = helpFormatter0.defaultWidth;
        helpFormatter0.setOptPrefix("hi!");
        java.io.PrintWriter printWriter4 = null;
        org.apache.commons.cli.Options options7 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options10 = options7.addOption("arg", "arg");
        // The following exception was thrown during execution in test generation
        try {
            helpFormatter0.printUsage(printWriter4, (int) 'a', " ", options10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 74 + "'", int1 == 74);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options10);
    }
}

