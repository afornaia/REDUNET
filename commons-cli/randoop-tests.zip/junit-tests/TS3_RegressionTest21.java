import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest21.test22");
        org.apache.commons.cli.Option.Builder builder0 = org.apache.commons.cli.Option.builder();
        org.apache.commons.cli.Option.Builder builder2 = builder0.numberOfArgs((int) (byte) 100);
        org.apache.commons.cli.Option.Builder builder3 = builder2.hasArgs();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
    }
}

