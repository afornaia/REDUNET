import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest89.test090");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create("arg");
        java.lang.String str2 = option1.toString();
        java.lang.Object obj3 = option1.getType();
        java.lang.Object obj4 = option1.getType();
        java.lang.Class<java.io.File> fileClass5 = org.apache.commons.cli.PatternOptionBuilder.FILE_VALUE;
        option1.setType(fileClass5);
        java.lang.String str7 = option1.getOpt();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[ option: arg  :: null :: class java.lang.String ]" + "'", str2.equals("[ option: arg  :: null :: class java.lang.String ]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj3.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj4.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(fileClass5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "arg" + "'", str7.equals("arg"));
    }
}

