import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest68.test69");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.String str5 = option4.getOpt();
        java.lang.String[] strArray6 = option4.getValues();
        option4.setArgs((int) (byte) 0);
        java.lang.String str10 = option4.getValue((int) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str10);
    }
}

