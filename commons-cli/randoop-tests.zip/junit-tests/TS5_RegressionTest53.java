import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest53.test54");
        org.apache.commons.cli.OptionBuilder optionBuilder0 = org.apache.commons.cli.OptionBuilder.hasArg();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionBuilder0);
    }
}

