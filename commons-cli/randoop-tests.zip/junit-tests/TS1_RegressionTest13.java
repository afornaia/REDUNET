import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest13.test14");
        // The following exception was thrown during execution in test generation
        try {
            java.util.Date date1 = org.apache.commons.cli.TypeHandler.createDate("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Not yet implemented");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
    }
}

