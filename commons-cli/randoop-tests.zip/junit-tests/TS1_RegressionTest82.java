import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest82.test83");
        org.apache.commons.cli.OptionGroup optionGroup0 = new org.apache.commons.cli.OptionGroup();
        optionGroup0.setRequired(true);
        org.apache.commons.cli.Option option6 = new org.apache.commons.cli.Option("arg", true, "");
        java.lang.Object obj7 = option6.clone();
        optionGroup0.setSelected(option6);
        java.lang.String str10 = option6.getValue((int) (byte) 100);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj7.toString(), "[ option: arg  [ARG] ::  :: class java.lang.String ]");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str10);
    }
}

