import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest85.test86");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        int int1 = helpFormatter0.getWidth();
        java.io.PrintWriter printWriter2 = null;
        org.apache.commons.cli.Options options4 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options7 = options4.addOption("arg", "arg");
        // The following exception was thrown during execution in test generation
        try {
            helpFormatter0.printOptions(printWriter2, (-2), options7, (int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: -2");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 74 + "'", int1 == 74);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options7);
    }
}

