import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest74.test75");
        org.apache.commons.cli.AlreadySelectedException alreadySelectedException1 = new org.apache.commons.cli.AlreadySelectedException("");
        org.apache.commons.cli.OptionGroup optionGroup2 = alreadySelectedException1.getOptionGroup();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(optionGroup2);
    }
}

