import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest48.test49");
        java.lang.Class<java.lang.Object> objClass0 = org.apache.commons.cli.PatternOptionBuilder.OBJECT_VALUE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objClass0);
    }
}

