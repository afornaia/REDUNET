import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest107.test108");
        java.lang.String[] strArray9 = new java.lang.String[] { "[ option: arg  :: null :: class java.lang.String ]", "\n", "arg", "[ option: arg  [ARG] :: null :: class java.lang.String ]", "arg", "[ option: arg  [ARG] :: null :: class java.lang.String ]", "[ option: arg  :: null :: class java.lang.String ]", "-" };
        java.util.ArrayList<java.lang.String> strList10 = new java.util.ArrayList<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList10, strArray9);
        org.apache.commons.cli.AmbiguousOptionException ambiguousOptionException12 = new org.apache.commons.cli.AmbiguousOptionException("[ option: arg [ARG...] :: null :: class java.lang.String ]", (java.util.Collection<java.lang.String>) strList10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }
}

