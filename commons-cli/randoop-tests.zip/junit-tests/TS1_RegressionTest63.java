import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest63.test64");
        org.apache.commons.cli.Options options0 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("arg", true, "arg");
        java.lang.String str5 = option4.getArgName();
        org.apache.commons.cli.Options options6 = options0.addOption(option4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options6);
    }
}

