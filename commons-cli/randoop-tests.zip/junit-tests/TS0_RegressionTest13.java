import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest13.test14");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.Class<java.net.URL> uRLClass5 = org.apache.commons.cli.PatternOptionBuilder.URL_VALUE;
        option4.setType(uRLClass5);
        org.apache.commons.cli.OptionBuilder optionBuilder7 = org.apache.commons.cli.OptionBuilder.withType(uRLClass5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(uRLClass5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionBuilder7);
    }
}

