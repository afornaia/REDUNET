import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest25.test26");
        org.apache.commons.cli.Option option3 = new org.apache.commons.cli.Option("", true, "");
        boolean boolean4 = option3.hasOptionalArg();
        java.lang.Class<java.io.FileInputStream> fileInputStreamClass5 = org.apache.commons.cli.PatternOptionBuilder.EXISTING_FILE_VALUE;
        option3.setType(fileInputStreamClass5);
        option3.setDescription("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(fileInputStreamClass5);
    }
}

