import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest68.test69");
        org.apache.commons.cli.BasicParser basicParser0 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Options options1 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.OptionGroup optionGroup2 = new org.apache.commons.cli.OptionGroup();
        org.apache.commons.cli.Options options3 = options1.addOptionGroup(optionGroup2);
        org.apache.commons.cli.DefaultParser defaultParser5 = new org.apache.commons.cli.DefaultParser(true);
        org.apache.commons.cli.Options options6 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options9 = options6.addOption("arg", "arg");
        java.lang.String[] strArray15 = new java.lang.String[] { "-", "hi!", "--", "hi!", " " };
        org.apache.commons.cli.CommandLine commandLine16 = defaultParser5.parse(options6, strArray15);
        java.util.Properties properties17 = null;
        org.apache.commons.cli.CommandLine commandLine19 = basicParser0.parse(options1, strArray15, properties17, true);
        java.lang.String str21 = commandLine19.getOptionValue("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str21);
    }
}

