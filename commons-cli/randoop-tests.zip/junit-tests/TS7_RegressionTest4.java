import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest4.test005");
        org.apache.commons.cli.OptionBuilder optionBuilder1 = org.apache.commons.cli.OptionBuilder.withDescription(" ");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionBuilder1);
    }
}

