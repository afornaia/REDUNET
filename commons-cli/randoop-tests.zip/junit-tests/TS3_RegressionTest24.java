import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest24.test25");
        org.apache.commons.cli.DefaultParser defaultParser1 = new org.apache.commons.cli.DefaultParser(false);
        org.apache.commons.cli.Options options3 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String[] strArray8 = new java.lang.String[] { "", "-", "hi!", "hi!" };
        java.util.Properties properties9 = null;
        org.apache.commons.cli.CommandLine commandLine10 = defaultParser1.parse(options3, strArray8, properties9);
        org.apache.commons.cli.OptionGroup optionGroup11 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.cli.Options options12 = options3.addOptionGroup(optionGroup11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine10);
    }
}

