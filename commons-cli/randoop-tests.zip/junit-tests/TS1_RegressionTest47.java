import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest47.test48");
        org.apache.commons.cli.Option.Builder builder0 = org.apache.commons.cli.Option.builder();
        java.lang.Class<java.util.Date> dateClass1 = org.apache.commons.cli.PatternOptionBuilder.DATE_VALUE;
        org.apache.commons.cli.Option.Builder builder2 = builder0.type(dateClass1);
        org.apache.commons.cli.Option.Builder builder3 = builder2.required();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dateClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
    }
}

