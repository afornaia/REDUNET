import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest72.test73");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        helpFormatter0.setDescPadding(3);
        java.lang.String str3 = helpFormatter0.defaultArgName;
        java.lang.String str4 = helpFormatter0.getLongOptPrefix();
        helpFormatter0.defaultNewLine = "org.apache.commons.cli.MissingOptionException: arg";
        helpFormatter0.defaultArgName = "arg";
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "arg" + "'", str3.equals("arg"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "--" + "'", str4.equals("--"));
    }
}

