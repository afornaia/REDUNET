import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest6.test07");
        // The following exception was thrown during execution in test generation
        try {
            java.io.FileInputStream fileInputStream1 = org.apache.commons.cli.TypeHandler.openFile("arg");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: Unable to find file: arg");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

