import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest26.test27");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        java.util.Comparator<org.apache.commons.cli.Option> optionComparator1 = helpFormatter0.getOptionComparator();
        helpFormatter0.setLongOptPrefix("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionComparator1);
    }
}

