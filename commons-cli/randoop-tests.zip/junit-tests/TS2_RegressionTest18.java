import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest18.test019");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        helpFormatter0.defaultDescPad = (short) 10;
        int int3 = helpFormatter0.defaultDescPad;
        java.lang.String str4 = helpFormatter0.getNewLine();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "\n" + "'", str4.equals("\n"));
    }
}

