import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest8.test09");
        org.apache.commons.cli.Option option5 = new org.apache.commons.cli.Option("", "", false, "hi!");
        java.util.List<java.lang.String> strList6 = option5.getValuesList();
        org.apache.commons.cli.AmbiguousOptionException ambiguousOptionException7 = new org.apache.commons.cli.AmbiguousOptionException("hi!", (java.util.Collection<java.lang.String>) strList6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList6);
    }
}

