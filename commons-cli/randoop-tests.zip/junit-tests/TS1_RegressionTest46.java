import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest46.test47");
        org.apache.commons.cli.Options options0 = new org.apache.commons.cli.Options();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.cli.Options options3 = options0.addOption("usage: ", " ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The option 'usage: ' contains an illegal character : ':'");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

