import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest79.test80");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option3 = options1.getOption(" ");
        org.apache.commons.cli.OptionGroup optionGroup4 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.cli.Options options5 = options1.addOptionGroup(optionGroup4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option3);
    }
}

