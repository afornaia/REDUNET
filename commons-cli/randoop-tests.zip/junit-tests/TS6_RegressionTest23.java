import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest23.test24");
        org.apache.commons.cli.UnrecognizedOptionException unrecognizedOptionException2 = new org.apache.commons.cli.UnrecognizedOptionException("--", "hi!");
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "hi!" };
        java.util.ArrayList<java.lang.String> strList7 = new java.util.ArrayList<java.lang.String>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList7, strArray6);
        org.apache.commons.cli.AmbiguousOptionException ambiguousOptionException9 = new org.apache.commons.cli.AmbiguousOptionException("hi!", (java.util.Collection<java.lang.String>) strList7);
        unrecognizedOptionException2.addSuppressed((java.lang.Throwable) ambiguousOptionException9);
        java.lang.String str11 = ambiguousOptionException9.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.cli.AmbiguousOptionException: Ambiguous option: 'hi!'  (could be: 'hi!', 'hi!')" + "'", str11.equals("org.apache.commons.cli.AmbiguousOptionException: Ambiguous option: 'hi!'  (could be: 'hi!', 'hi!')"));
    }
}

