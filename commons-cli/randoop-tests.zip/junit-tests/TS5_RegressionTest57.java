import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest57 {

    public static boolean debug = false;

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest57.test58");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option3 = options1.getOption("usage: ");
        org.apache.commons.cli.Option option7 = new org.apache.commons.cli.Option("", false, "usage: ");
        java.lang.Object obj8 = option7.getType();
        option7.setRequired(false);
        org.apache.commons.cli.Options options11 = options1.addOption(option7);
        org.apache.commons.cli.Options options13 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option15 = options13.getOption("usage: ");
        org.apache.commons.cli.Option option19 = new org.apache.commons.cli.Option("", false, "usage: ");
        java.lang.Object obj20 = option19.getType();
        option19.setRequired(false);
        org.apache.commons.cli.Options options23 = options13.addOption(option19);
        java.lang.String str24 = option19.getArgName();
        org.apache.commons.cli.OptionGroup optionGroup25 = options1.getOptionGroup(option19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj8.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj20.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(optionGroup25);
    }
}

