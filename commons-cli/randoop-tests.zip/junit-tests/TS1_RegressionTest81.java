import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest81.test82");
        // The following exception was thrown during execution in test generation
        try {
            java.io.FileInputStream fileInputStream1 = org.apache.commons.cli.TypeHandler.openFile(" ");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: Unable to find file:  ");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

