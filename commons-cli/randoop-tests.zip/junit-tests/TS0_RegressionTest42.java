import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest42.test43");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.Class<java.net.URL> uRLClass5 = org.apache.commons.cli.PatternOptionBuilder.URL_VALUE;
        option4.setType(uRLClass5);
        char char7 = option4.getValueSeparator();
        java.lang.String str8 = option4.toString();
        option4.setDescription("[ option:  hi!  ::  :: class java.net.URL ]");
        boolean boolean11 = option4.hasValueSeparator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(uRLClass5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char7 + "' != '" + '\u0000' + "'", char7 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[ option:  hi!  ::  :: class java.net.URL ]" + "'", str8.equals("[ option:  hi!  ::  :: class java.net.URL ]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

