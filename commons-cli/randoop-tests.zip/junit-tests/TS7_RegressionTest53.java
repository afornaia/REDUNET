import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest53.test054");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create('4');
        org.apache.commons.cli.Option option3 = org.apache.commons.cli.OptionBuilder.create('4');
        option3.setLongOpt(" ");
        java.util.List<java.lang.String> strList6 = option3.getValuesList();
        boolean boolean7 = option1.equals((java.lang.Object) option3);
        boolean boolean8 = option3.hasArg();
        boolean boolean9 = option3.hasArgs();
        boolean boolean10 = option3.hasOptionalArg();
        org.apache.commons.cli.Option option12 = org.apache.commons.cli.OptionBuilder.create('4');
        org.apache.commons.cli.Option option14 = org.apache.commons.cli.OptionBuilder.create('4');
        option14.setLongOpt(" ");
        java.util.List<java.lang.String> strList17 = option14.getValuesList();
        boolean boolean18 = option12.equals((java.lang.Object) option14);
        boolean boolean19 = option14.hasArg();
        boolean boolean20 = option14.hasArgs();
        boolean boolean21 = option14.hasOptionalArg();
        boolean boolean22 = option14.hasArg();
        boolean boolean23 = option3.equals((java.lang.Object) boolean22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }
}

