import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest34.test35");
        org.apache.commons.cli.BasicParser basicParser0 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Options options1 = new org.apache.commons.cli.Options();
        java.lang.String[] strArray5 = new java.lang.String[] { "", " ", "arg" };
        java.util.Properties properties6 = null;
        org.apache.commons.cli.CommandLine commandLine7 = basicParser0.parse(options1, strArray5, properties6);
        org.apache.commons.cli.Option option11 = new org.apache.commons.cli.Option("arg", true, "arg");
        java.lang.String str12 = option11.getArgName();
        option11.setValueSeparator('4');
        java.util.ListIterator<java.lang.String> strItor15 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicParser0.processArgs(option11, strItor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str12);
    }
}

