import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest38.test039");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        java.io.PrintWriter printWriter1 = null;
        org.apache.commons.cli.Options options5 = null;
        // The following exception was thrown during execution in test generation
        try {
            helpFormatter0.printHelp(printWriter1, (int) (short) 0, "", "--", options5, (int) (short) 10, (int) (short) 0, "[ option: arg  :: null :: class java.lang.String ]", false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: cmdLineSyntax not provided");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

