import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest50.test51");
        org.apache.commons.cli.OptionGroup optionGroup0 = new org.apache.commons.cli.OptionGroup();
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("arg", true, "arg");
        java.lang.String str5 = option4.getArgName();
        option4.setValueSeparator('4');
        org.apache.commons.cli.AlreadySelectedException alreadySelectedException8 = new org.apache.commons.cli.AlreadySelectedException(optionGroup0, option4);
        boolean boolean9 = option4.hasArg();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }
}

