import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest3.test004");
        int int0 = org.apache.commons.cli.HelpFormatter.DEFAULT_DESC_PAD;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }
}

