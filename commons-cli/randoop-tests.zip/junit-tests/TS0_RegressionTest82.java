import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest82.test83");
        java.lang.Class<java.io.File> fileClass0 = org.apache.commons.cli.PatternOptionBuilder.FILE_VALUE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(fileClass0);
    }
}

