import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest73.test74");
        org.apache.commons.cli.OptionGroup optionGroup0 = new org.apache.commons.cli.OptionGroup();
        java.util.Collection<java.lang.String> strCollection1 = optionGroup0.getNames();
        org.apache.commons.cli.Option option6 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.String str7 = option6.getOpt();
        java.lang.String[] strArray8 = option6.getValues();
        org.apache.commons.cli.OptionGroup optionGroup9 = optionGroup0.addOption(option6);
        java.util.Collection<org.apache.commons.cli.Option> optionCollection10 = optionGroup0.getOptions();
        optionGroup0.setRequired(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strCollection1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionGroup9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(optionCollection10);
    }
}

