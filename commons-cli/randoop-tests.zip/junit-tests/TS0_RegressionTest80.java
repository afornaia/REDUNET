import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest80.test81");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        java.lang.String str1 = helpFormatter0.defaultOptPrefix;
        java.lang.String str2 = helpFormatter0.getOptPrefix();
        java.lang.String str3 = helpFormatter0.getLongOptSeparator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "-" + "'", str1.equals("-"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-" + "'", str2.equals("-"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + " " + "'", str3.equals(" "));
    }
}

