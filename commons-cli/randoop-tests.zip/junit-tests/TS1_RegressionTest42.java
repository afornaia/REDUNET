import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest42.test43");
        org.apache.commons.cli.Options options0 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.OptionGroup optionGroup1 = new org.apache.commons.cli.OptionGroup();
        org.apache.commons.cli.Options options2 = options0.addOptionGroup(optionGroup1);
        boolean boolean4 = options0.hasLongOption("arg");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}

