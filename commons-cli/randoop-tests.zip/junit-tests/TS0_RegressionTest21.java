import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest21.test22");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.cli.Option option0 = org.apache.commons.cli.OptionBuilder.create();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: must specify longopt");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

