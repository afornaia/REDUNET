import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest78.test79");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.String str5 = option4.getOpt();
        java.lang.String[] strArray6 = option4.getValues();
        boolean boolean7 = option4.hasArg();
        char char8 = option4.getValueSeparator();
        option4.setLongOpt("");
        org.apache.commons.cli.Option option15 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.String str16 = option15.getOpt();
        java.lang.String[] strArray17 = option15.getValues();
        boolean boolean18 = option15.hasArg();
        char char19 = option15.getValueSeparator();
        option15.setLongOpt("");
        java.lang.Class<java.net.URL> uRLClass22 = org.apache.commons.cli.PatternOptionBuilder.URL_VALUE;
        option15.setType(uRLClass22);
        option4.setType(uRLClass22);
        java.lang.String str25 = option4.getArgName();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char8 + "' != '" + '\u0000' + "'", char8 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char19 + "' != '" + '\u0000' + "'", char19 == '\u0000');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(uRLClass22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str25);
    }
}

