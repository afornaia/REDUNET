import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest44.test45");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Options options3 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option5 = options3.getOption("usage: ");
        org.apache.commons.cli.Option option9 = new org.apache.commons.cli.Option("", false, "usage: ");
        java.lang.Object obj10 = option9.getType();
        option9.setRequired(false);
        org.apache.commons.cli.Options options13 = options3.addOption(option9);
        java.lang.String str14 = option9.getArgName();
        org.apache.commons.cli.OptionGroup optionGroup15 = options1.getOptionGroup(option9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj10.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(optionGroup15);
    }
}

