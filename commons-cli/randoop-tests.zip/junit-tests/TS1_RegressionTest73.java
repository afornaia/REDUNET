import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest73.test74");
        org.apache.commons.cli.Option option3 = new org.apache.commons.cli.Option("arg", true, "");
        java.lang.Object obj4 = option3.clone();
        org.apache.commons.cli.Option.Builder builder5 = org.apache.commons.cli.Option.builder();
        java.lang.Class<java.util.Date> dateClass6 = org.apache.commons.cli.PatternOptionBuilder.DATE_VALUE;
        org.apache.commons.cli.Option.Builder builder7 = builder5.type(dateClass6);
        option3.setType(dateClass6);
        option3.setArgs((-1));
        int int11 = option3.getArgs();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj4.toString(), "[ option: arg  [ARG] ::  :: class java.lang.String ]");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dateClass6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }
}

