import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest16.test17");
        // The following exception was thrown during execution in test generation
        try {
            java.io.FileInputStream fileInputStream1 = org.apache.commons.cli.TypeHandler.openFile("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: Unable to find file: hi!");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

