import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest27.test028");
        java.lang.Class<?> wildcardClass0 = org.apache.commons.cli.PatternOptionBuilder.CLASS_VALUE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass0);
    }
}

