import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest52.test053");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create('4');
        org.apache.commons.cli.Option option3 = org.apache.commons.cli.OptionBuilder.create('4');
        option3.setLongOpt(" ");
        java.util.List<java.lang.String> strList6 = option3.getValuesList();
        boolean boolean7 = option1.equals((java.lang.Object) option3);
        boolean boolean8 = option3.hasArg();
        option3.setValueSeparator('a');
        java.lang.Class<?> wildcardClass11 = option3.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass11);
    }
}

