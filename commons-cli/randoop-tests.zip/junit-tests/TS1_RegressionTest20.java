import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest20.test21");
        org.apache.commons.cli.MissingOptionException missingOptionException1 = new org.apache.commons.cli.MissingOptionException("arg");
        org.apache.commons.cli.ParseException parseException3 = new org.apache.commons.cli.ParseException("arg");
        missingOptionException1.addSuppressed((java.lang.Throwable) parseException3);
    }
}

