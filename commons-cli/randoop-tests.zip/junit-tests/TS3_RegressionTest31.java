import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest31.test32");
        org.apache.commons.cli.DefaultParser defaultParser1 = new org.apache.commons.cli.DefaultParser(false);
        org.apache.commons.cli.Options options3 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String[] strArray8 = new java.lang.String[] { "", "-", "hi!", "hi!" };
        java.util.Properties properties9 = null;
        org.apache.commons.cli.CommandLine commandLine10 = defaultParser1.parse(options3, strArray8, properties9);
        org.apache.commons.cli.DefaultParser defaultParser12 = new org.apache.commons.cli.DefaultParser(false);
        org.apache.commons.cli.Options options14 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String[] strArray19 = new java.lang.String[] { "", "-", "hi!", "hi!" };
        java.util.Properties properties20 = null;
        org.apache.commons.cli.CommandLine commandLine21 = defaultParser12.parse(options14, strArray19, properties20);
        org.apache.commons.cli.Options options26 = options14.addOption("", "arg", true, "arg");
        java.lang.String[] strArray32 = new java.lang.String[] { "-", "-", "hi!", "-", "" };
        org.apache.commons.cli.DefaultParser defaultParser34 = new org.apache.commons.cli.DefaultParser(false);
        org.apache.commons.cli.Options options36 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String[] strArray41 = new java.lang.String[] { "", "-", "hi!", "hi!" };
        java.util.Properties properties42 = null;
        org.apache.commons.cli.CommandLine commandLine43 = defaultParser34.parse(options36, strArray41, properties42);
        java.util.Properties properties45 = commandLine43.getOptionProperties("arg");
        org.apache.commons.cli.CommandLine commandLine46 = defaultParser1.parse(options26, strArray32, properties45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(properties45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine46);
    }
}

