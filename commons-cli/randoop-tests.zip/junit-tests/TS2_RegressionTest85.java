import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest85.test086");
        org.apache.commons.cli.BasicParser basicParser0 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Option option2 = org.apache.commons.cli.OptionBuilder.create("arg");
        java.lang.String str3 = option2.toString();
        java.lang.String str4 = option2.getLongOpt();
        java.lang.String str5 = option2.getOpt();
        java.lang.String str6 = option2.getOpt();
        boolean boolean7 = option2.hasValueSeparator();
        java.util.ListIterator<java.lang.String> strItor8 = null;
        // The following exception was thrown during execution in test generation
        try {
            basicParser0.processArgs(option2, strItor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[ option: arg  :: null :: class java.lang.String ]" + "'", str3.equals("[ option: arg  :: null :: class java.lang.String ]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "arg" + "'", str5.equals("arg"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "arg" + "'", str6.equals("arg"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

