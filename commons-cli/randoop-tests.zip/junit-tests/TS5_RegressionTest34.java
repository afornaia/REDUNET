import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest34.test35");
        org.apache.commons.cli.Options options0 = new org.apache.commons.cli.Options();
        java.util.List<java.lang.String> strList2 = options0.getMatchingOptions("");
        org.apache.commons.cli.MissingOptionException missingOptionException3 = new org.apache.commons.cli.MissingOptionException((java.util.List) strList2);
        java.lang.String str4 = missingOptionException3.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.cli.MissingOptionException: Missing required options: " + "'", str4.equals("org.apache.commons.cli.MissingOptionException: Missing required options: "));
    }
}

