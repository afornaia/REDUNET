import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest15.test16");
        org.apache.commons.cli.Option.Builder builder0 = org.apache.commons.cli.Option.builder();
        org.apache.commons.cli.Option.Builder builder2 = builder0.numberOfArgs((int) (byte) 100);
        org.apache.commons.cli.Option.Builder builder4 = builder0.numberOfArgs(0);
        org.apache.commons.cli.Option.Builder builder5 = builder4.required();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
    }
}

