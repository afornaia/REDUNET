import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest15.test016");
        java.lang.Class<java.io.File> fileClass1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.io.File file2 = org.apache.commons.cli.TypeHandler.createValue("arg", fileClass1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.cli.ParseException; message: Unable to handle the class: null");
        } catch (org.apache.commons.cli.ParseException e) {
        // Expected exception.
        }
    }
}

