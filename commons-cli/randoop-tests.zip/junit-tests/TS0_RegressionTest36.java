import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest36.test37");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "", true, "org.apache.commons.cli.AlreadySelectedException: ");
        char char5 = option4.getValueSeparator();
        option4.setValueSeparator(' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + char5 + "' != '" + '\u0000' + "'", char5 == '\u0000');
    }
}

