import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest70.test71");
        org.apache.commons.cli.HelpFormatter helpFormatter0 = new org.apache.commons.cli.HelpFormatter();
        helpFormatter0.setDescPadding(3);
        helpFormatter0.setLongOptSeparator("usage: ");
        java.io.PrintWriter printWriter5 = null;
        org.apache.commons.cli.Options options9 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options12 = options9.addOption("arg", "arg");
        org.apache.commons.cli.Option option15 = new org.apache.commons.cli.Option("arg", "usage: ");
        option15.setLongOpt("");
        java.lang.String str18 = option15.getLongOpt();
        org.apache.commons.cli.Options options19 = options9.addOption(option15);
        // The following exception was thrown during execution in test generation
        try {
            helpFormatter0.printHelp(printWriter5, (int) '#', "hi!", "arg", options19, (int) '\u0000', (int) (short) 1, " ");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options19);
    }
}

