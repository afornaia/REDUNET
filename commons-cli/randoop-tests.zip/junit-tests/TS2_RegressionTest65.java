import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest65.test066");
        org.apache.commons.cli.Option.Builder builder0 = org.apache.commons.cli.Option.builder();
        org.apache.commons.cli.Option.Builder builder2 = builder0.desc("");
        org.apache.commons.cli.Option.Builder builder3 = builder0.hasArg();
        org.apache.commons.cli.Option.Builder builder5 = builder0.hasArg(false);
        org.apache.commons.cli.Option.Builder builder7 = builder0.hasArg(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
    }
}

