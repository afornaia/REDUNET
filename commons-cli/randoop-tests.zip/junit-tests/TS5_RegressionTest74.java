import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest74.test75");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create('a');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
    }
}

