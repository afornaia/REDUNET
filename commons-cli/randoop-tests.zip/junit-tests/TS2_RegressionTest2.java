import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest2.test003");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = org.apache.commons.cli.TypeHandler.createValue("", (java.lang.Object) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to java.lang.Class");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
    }
}

