import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest71.test72");
        org.apache.commons.cli.BasicParser basicParser0 = new org.apache.commons.cli.BasicParser();
        org.apache.commons.cli.Options options1 = new org.apache.commons.cli.Options();
        java.lang.String[] strArray5 = new java.lang.String[] { "", " ", "arg" };
        java.util.Properties properties6 = null;
        org.apache.commons.cli.CommandLine commandLine7 = basicParser0.parse(options1, strArray5, properties6);
        boolean boolean9 = commandLine7.hasOption('4');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }
}

