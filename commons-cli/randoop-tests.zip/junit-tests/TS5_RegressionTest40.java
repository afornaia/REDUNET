import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest40.test41");
        java.lang.String[] strArray3 = new java.lang.String[] { "", " " };
        java.util.ArrayList<java.lang.String> strList4 = new java.util.ArrayList<java.lang.String>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strList4, strArray3);
        org.apache.commons.cli.AmbiguousOptionException ambiguousOptionException6 = new org.apache.commons.cli.AmbiguousOptionException("hi!", (java.util.Collection<java.lang.String>) strList4);
        java.lang.String str7 = ambiguousOptionException6.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.cli.AmbiguousOptionException: Ambiguous option: 'hi!'  (could be: '', ' ')" + "'", str7.equals("org.apache.commons.cli.AmbiguousOptionException: Ambiguous option: 'hi!'  (could be: '', ' ')"));
    }
}

