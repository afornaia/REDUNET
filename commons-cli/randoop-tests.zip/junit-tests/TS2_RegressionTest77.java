import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest77.test078");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create('4');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
    }
}

