import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest47.test48");
        org.apache.commons.cli.Options options1 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("hi!");
        org.apache.commons.cli.Option option3 = options1.getOption("usage: ");
        org.apache.commons.cli.Option option7 = new org.apache.commons.cli.Option("", false, "usage: ");
        java.lang.Object obj8 = option7.getType();
        option7.setRequired(false);
        org.apache.commons.cli.Options options11 = options1.addOption(option7);
        java.lang.String str12 = option7.getArgName();
        java.lang.String str13 = option7.getOpt();
        boolean boolean14 = option7.hasOptionalArg();
        boolean boolean15 = option7.hasArg();
        // The following exception was thrown during execution in test generation
        try {
            int int16 = option7.getId();
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(option3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj8.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }
}

