import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest83.test84");
        org.apache.commons.cli.Options options0 = new org.apache.commons.cli.Options();
        org.apache.commons.cli.Options options3 = options0.addOption("arg", "arg");
        org.apache.commons.cli.Option option6 = new org.apache.commons.cli.Option("arg", "usage: ");
        option6.setLongOpt("");
        java.lang.String str9 = option6.getLongOpt();
        org.apache.commons.cli.Options options10 = options0.addOption(option6);
        java.util.List list11 = options0.getRequiredOptions();
        org.apache.commons.cli.Option option13 = options0.getOption("--");
        java.lang.Object obj14 = option13.getType();
        java.lang.Object obj15 = option13.clone();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(list11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj14.toString(), "class java.lang.String");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj15.toString(), "[ option: arg   :: usage:  :: class java.lang.String ]");
    }
}

