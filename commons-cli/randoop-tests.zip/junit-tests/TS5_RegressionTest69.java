import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest69.test70");
        org.apache.commons.cli.UnrecognizedOptionException unrecognizedOptionException2 = new org.apache.commons.cli.UnrecognizedOptionException("usage: ", "org.apache.commons.cli.AmbiguousOptionException: Ambiguous option: 'hi!'  (could be: '', ' ')");
    }
}

