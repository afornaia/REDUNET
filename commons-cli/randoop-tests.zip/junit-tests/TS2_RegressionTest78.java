import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest78.test079");
        org.apache.commons.cli.Option option1 = org.apache.commons.cli.OptionBuilder.create("arg");
        org.apache.commons.cli.MissingArgumentException missingArgumentException2 = new org.apache.commons.cli.MissingArgumentException(option1);
        java.lang.Object obj3 = null;
        option1.setType(obj3);
        boolean boolean5 = option1.hasArgs();
        java.lang.String str6 = option1.getLongOpt();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(option1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str6);
    }
}

