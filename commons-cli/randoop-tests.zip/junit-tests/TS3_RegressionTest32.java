import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest32.test33");
        org.apache.commons.cli.DefaultParser defaultParser1 = new org.apache.commons.cli.DefaultParser(false);
        org.apache.commons.cli.Options options3 = org.apache.commons.cli.PatternOptionBuilder.parsePattern("arg");
        java.lang.String[] strArray8 = new java.lang.String[] { "", "-", "hi!", "hi!" };
        java.util.Properties properties9 = null;
        org.apache.commons.cli.CommandLine commandLine10 = defaultParser1.parse(options3, strArray8, properties9);
        org.apache.commons.cli.Options options14 = options3.addOption("arg", true, "-");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(commandLine10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(options14);
    }
}

