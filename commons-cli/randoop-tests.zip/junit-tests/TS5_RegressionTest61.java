import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest61.test62");
        org.apache.commons.cli.AlreadySelectedException alreadySelectedException1 = new org.apache.commons.cli.AlreadySelectedException("usage: ");
        org.apache.commons.cli.OptionGroup optionGroup2 = alreadySelectedException1.getOptionGroup();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(optionGroup2);
    }
}

