import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest75.test76");
        org.apache.commons.cli.Option option4 = new org.apache.commons.cli.Option("", "hi!", false, "");
        java.lang.String str5 = option4.getOpt();
        java.lang.String[] strArray6 = option4.getValues();
        boolean boolean7 = option4.hasArg();
        boolean boolean8 = option4.hasLongOpt();
        org.apache.commons.cli.Option.Builder builder9 = org.apache.commons.cli.Option.builder();
        org.apache.commons.cli.Option.Builder builder11 = builder9.longOpt("usage: ");
        org.apache.commons.cli.Option.Builder builder13 = builder11.hasArg(true);
        // The following exception was thrown during execution in test generation
        try {
            option4.setType((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to java.lang.Class");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(strArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder13);
    }
}

