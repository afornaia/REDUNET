import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest51.test052");
        java.lang.Class<java.lang.String> strClass0 = org.apache.commons.cli.PatternOptionBuilder.STRING_VALUE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strClass0);
    }
}

