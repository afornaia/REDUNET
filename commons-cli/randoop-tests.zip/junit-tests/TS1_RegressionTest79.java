import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest79.test80");
        org.apache.commons.cli.Option option3 = new org.apache.commons.cli.Option("arg", true, "arg");
        java.lang.String str4 = option3.getArgName();
        option3.setValueSeparator('4');
        java.lang.String str7 = option3.getDescription();
        java.lang.String str9 = option3.getValue("--");
        boolean boolean10 = option3.hasArgs();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "arg" + "'", str7.equals("arg"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "--" + "'", str9.equals("--"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }
}

