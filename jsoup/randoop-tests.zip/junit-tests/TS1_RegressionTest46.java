import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest46.test047");
        org.jsoup.select.Evaluator.Tag tag1 = new org.jsoup.select.Evaluator.Tag("PUBLIC");
        java.lang.String str2 = tag1.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PUBLIC" + "'", str2.equals("PUBLIC"));
    }
}

