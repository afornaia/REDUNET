import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest101.test102");
        org.jsoup.select.Evaluator.IsLastChild isLastChild0 = new org.jsoup.select.Evaluator.IsLastChild();
        java.io.InputStream inputStream1 = null;
        org.jsoup.parser.Parser parser4 = null;
        org.jsoup.nodes.Document document5 = org.jsoup.helper.DataUtil.load(inputStream1, "#root", "", parser4);
        java.nio.charset.Charset charset6 = null;
        document5.charset(charset6);
        org.jsoup.nodes.Document document10 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str11 = document10.tagName();
        boolean boolean12 = isLastChild0.matches((org.jsoup.nodes.Element) document5, (org.jsoup.nodes.Element) document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#root" + "'", str11.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }
}

