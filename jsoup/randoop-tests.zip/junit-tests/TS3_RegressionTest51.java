import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest51.test052");
        org.jsoup.safety.Whitelist whitelist0 = new org.jsoup.safety.Whitelist();
        java.lang.String[] strArray4 = new java.lang.String[] {};
        boolean boolean5 = org.jsoup.internal.StringUtil.in("", strArray4);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.safety.Whitelist whitelist6 = whitelist0.removeProtocols(" ", ":first-of-type", strArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot remove a protocol that is not set.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

