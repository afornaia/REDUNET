import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest8.test009");
        org.jsoup.safety.Whitelist whitelist0 = org.jsoup.safety.Whitelist.none();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!", "hi!", "hi!", "" };
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.safety.Whitelist whitelist7 = whitelist0.addAttributes("", strArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(whitelist0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray6);
    }
}

