import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest53.test054");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element3 = document2.parent();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.Elements elements5 = element3.getElementsMatchingText("#root");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element3);
    }
}

