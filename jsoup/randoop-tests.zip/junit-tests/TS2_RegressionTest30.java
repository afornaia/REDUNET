import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest30.test031");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Document document3 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element5 = document3.prependText(":first-of-type");
        org.jsoup.nodes.Document document7 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element9 = document7.prependText(":first-of-type");
        org.jsoup.nodes.Element element11 = element9.removeAttr("");
        org.jsoup.nodes.Document document13 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element15 = document13.prependText(":first-of-type");
        org.jsoup.nodes.Element element17 = element15.removeAttr("");
        org.jsoup.nodes.Element[] elementArray18 = new org.jsoup.nodes.Element[] { document1, element5, element11, element17 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList19 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean20 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList19, elementArray18);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element22 = elementList19.remove(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 4");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }
}

