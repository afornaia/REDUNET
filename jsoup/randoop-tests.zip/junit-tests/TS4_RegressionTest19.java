import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest19.test020");
        org.jsoup.parser.ParseSettings parseSettings2 = new org.jsoup.parser.ParseSettings(true, false);
    }
}

