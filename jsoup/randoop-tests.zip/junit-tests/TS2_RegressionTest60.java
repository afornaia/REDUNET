import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest60.test061");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment("", "");
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = document2.parser(parser3);
        java.lang.Object[] objArray6 = new java.lang.Object[] { parser3, (short) 10 };
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.helper.Validate.noNullElements(objArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Array must not contain any null objects");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray6);
    }
}

