import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest70.test071");
        org.jsoup.parser.Parser parser0 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document3 = parser0.parseInput("PUBLIC", "hi!");
        org.jsoup.nodes.DocumentType documentType4 = document3.documentType();
        boolean boolean5 = document3.updateMetaCharsetElement();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(documentType4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

