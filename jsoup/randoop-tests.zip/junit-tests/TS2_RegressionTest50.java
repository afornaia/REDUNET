import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest50.test051");
        org.jsoup.nodes.Document document2 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element4 = document2.prependText(":first-of-type");
        java.lang.String str5 = element4.ownText();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element6 = org.jsoup.select.Selector.selectFirst("#hi!", element4);
            org.junit.Assert.fail("Expected exception of type org.jsoup.select.Selector.SelectorParseException; message: Could not parse query '#hi!': unexpected token at '!'");
        } catch (org.jsoup.select.Selector.SelectorParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + ":first-of-type" + "'", str5.equals(":first-of-type"));
    }
}

