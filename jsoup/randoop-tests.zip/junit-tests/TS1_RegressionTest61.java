import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest61.test062");
        org.jsoup.parser.Parser parser0 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document3 = parser0.parseInput("PUBLIC", "hi!");
        org.jsoup.parser.Parser parser5 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document8 = parser5.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList9 = document8.dataNodes();
        org.jsoup.nodes.Element element11 = document8.prependText("content-encoding");
        org.jsoup.parser.Parser parser12 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document15 = parser12.parseInput("PUBLIC", "hi!");
        org.jsoup.select.Elements elements16 = document15.previousElementSiblings();
        org.jsoup.parser.Parser parser17 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document20 = parser17.parseInput("PUBLIC", "hi!");
        org.jsoup.select.Elements elements21 = document20.previousElementSiblings();
        org.jsoup.nodes.TextNode textNode23 = new org.jsoup.nodes.TextNode("PUBLIC");
        org.jsoup.nodes.Node node25 = textNode23.removeAttr("PUBLIC");
        boolean boolean27 = textNode23.hasAttr("hi!");
        org.jsoup.nodes.TextNode textNode29 = textNode23.text("Content-Type");
        org.jsoup.nodes.Comment comment31 = new org.jsoup.nodes.Comment("hi!");
        org.jsoup.nodes.Node node32 = comment31.empty();
        org.jsoup.nodes.Node[] nodeArray33 = new org.jsoup.nodes.Node[] { document8, document15, document20, textNode23, node32 };
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element34 = document3.insertChildren((int) (byte) 10, nodeArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Insert position out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(textNode29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray33);
    }
}

