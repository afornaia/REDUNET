import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest86.test087");
        org.jsoup.parser.Parser parser0 = org.jsoup.parser.Parser.xmlParser();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser0);
    }
}

