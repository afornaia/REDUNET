import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest58.test059");
        org.jsoup.parser.Parser parser0 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document3 = parser0.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList4 = document3.dataNodes();
        org.jsoup.nodes.Element element6 = document3.prependText("content-encoding");
        org.jsoup.select.Elements elements9 = document3.getElementsByAttributeValueNot("content-encoding", "Content-Encoding");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements9);
    }
}

