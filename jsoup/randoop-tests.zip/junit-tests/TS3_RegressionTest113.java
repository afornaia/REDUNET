import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest113.test114");
        org.jsoup.safety.Whitelist whitelist0 = new org.jsoup.safety.Whitelist();
        org.jsoup.safety.Cleaner cleaner1 = new org.jsoup.safety.Cleaner(whitelist0);
        org.jsoup.nodes.Document document3 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements5 = document3.getElementsByTag("[]");
        org.jsoup.nodes.Element element6 = document3.clone();
        boolean boolean7 = cleaner1.isValid(document3);
        org.jsoup.nodes.Element element9 = document3.removeAttr("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element9);
    }
}

