import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest45 {

    public static boolean debug = false;

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest45.test046");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        org.jsoup.nodes.Element element4 = document1.shallowClone();
        org.jsoup.select.Elements elements6 = element4.getElementsByIndexLessThan((int) (byte) 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements6);
    }
}

