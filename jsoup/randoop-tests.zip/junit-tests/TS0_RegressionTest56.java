import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest56.test057");
        java.io.InputStream inputStream0 = null;
        org.jsoup.nodes.Document document3 = org.jsoup.helper.DataUtil.load(inputStream0, "Content-Encoding", "<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
    }
}

