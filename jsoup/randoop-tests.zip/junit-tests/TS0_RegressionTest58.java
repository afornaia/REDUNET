import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest58.test059");
        java.lang.StringBuilder stringBuilder0 = org.jsoup.internal.StringUtil.borrowBuilder();
        java.lang.String str1 = org.jsoup.internal.StringUtil.releaseBuilder(stringBuilder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringBuilder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(stringBuilder0.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "" + "'", str1.equals(""));
    }
}

