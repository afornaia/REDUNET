import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest89.test090");
        org.jsoup.select.Elements elements0 = new org.jsoup.select.Elements();
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements4 = document2.getElementsByTag("[]");
        java.lang.String str5 = document2.className();
        org.jsoup.nodes.Attributes attributes6 = document2.attributes();
        boolean boolean7 = elements0.add((org.jsoup.nodes.Element) document2);
        org.jsoup.select.Elements elements9 = document2.getElementsByClass("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements9);
    }
}

