import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest32.test033");
        org.jsoup.nodes.Element[] elementArray0 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList1 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList1, elementArray0);
        org.jsoup.nodes.Element element4 = null;
        elementList1.add(0, element4);
        java.util.Iterator<org.jsoup.nodes.Element> elementItor6 = elementList1.iterator();
        elementList1.trimToSize();
        org.jsoup.nodes.Element[] elementArray8 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList9 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList9, elementArray8);
        org.jsoup.nodes.Element element12 = null;
        elementList9.add(0, element12);
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream14 = elementList9.stream();
        boolean boolean16 = elementList9.remove((java.lang.Object) 10);
        int int17 = elementList1.indexOf((java.lang.Object) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementStream14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }
}

