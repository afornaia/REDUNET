import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest67.test068");
        org.jsoup.parser.ParseError[] parseErrorArray0 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList1 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList1, parseErrorArray0);
        int int3 = parseErrorList1.size();
        org.jsoup.nodes.Element[] elementArray4 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList5 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean6 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList5, elementArray4);
        org.jsoup.nodes.Element element8 = null;
        elementList5.add(0, element8);
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream10 = elementList5.stream();
        org.jsoup.parser.ParseError[] parseErrorArray11 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList12 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList12, parseErrorArray11);
        int int14 = parseErrorList12.size();
        java.util.ListIterator<org.jsoup.parser.ParseError> parseErrorItor16 = parseErrorList12.listIterator((int) (short) 0);
        org.jsoup.nodes.Element[] elementArray17 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList18 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean19 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList18, elementArray17);
        org.jsoup.nodes.Element element21 = null;
        elementList18.add(0, element21);
        org.jsoup.nodes.Element[] elementArray23 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList24 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList24, elementArray23);
        org.jsoup.nodes.Element element27 = null;
        elementList24.add(0, element27);
        org.jsoup.nodes.Element[] elementArray29 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList30 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList30, elementArray29);
        org.jsoup.nodes.Element element33 = null;
        elementList30.add(0, element33);
        boolean boolean36 = elementList30.contains((java.lang.Object) (-1));
        java.util.RandomAccess[] randomAccessArray37 = new java.util.RandomAccess[] { parseErrorList12, elementList18, elementList24, elementList30 };
        java.util.RandomAccess[] randomAccessArray38 = elementList5.toArray(randomAccessArray37);
        int int39 = parseErrorList1.indexOf((java.lang.Object) elementList5);
        org.jsoup.parser.ParseError parseError40 = null;
        boolean boolean41 = parseErrorList1.add(parseError40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementStream10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorItor16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(randomAccessArray37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(randomAccessArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }
}

