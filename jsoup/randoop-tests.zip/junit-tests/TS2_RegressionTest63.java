import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest63.test064");
        org.jsoup.nodes.Attributes attributes0 = new org.jsoup.nodes.Attributes();
        org.jsoup.nodes.Attributes attributes3 = attributes0.put("", "PUBLIC");
        java.lang.String str4 = attributes3.html();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + " =\"PUBLIC\"" + "'", str4.equals(" =\"PUBLIC\""));
    }
}

