import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest113.test114");
        org.jsoup.parser.TokenQueue tokenQueue1 = new org.jsoup.parser.TokenQueue("PUBLIC");
        java.lang.String str2 = tokenQueue1.consumeCssIdentifier();
        java.lang.String[] strArray8 = new java.lang.String[] { "public", "hi!", "", ":first-of-type", "#document" };
        java.lang.String str9 = tokenQueue1.consumeToAny(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PUBLIC" + "'", str2.equals("PUBLIC"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }
}

