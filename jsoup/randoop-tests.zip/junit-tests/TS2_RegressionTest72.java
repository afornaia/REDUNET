import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest72.test073");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element3 = document1.prependText(":first-of-type");
        java.lang.String str4 = element3.ownText();
        org.jsoup.nodes.Element element7 = element3.attr("PUBLIC", true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":first-of-type" + "'", str4.equals(":first-of-type"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
    }
}

