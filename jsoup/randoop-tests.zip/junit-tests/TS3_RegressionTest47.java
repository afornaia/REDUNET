import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest47.test048");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        boolean boolean5 = document1.hasSameValue((java.lang.Object) "[]");
        org.jsoup.nodes.Element element7 = document1.val(" ");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
    }
}

