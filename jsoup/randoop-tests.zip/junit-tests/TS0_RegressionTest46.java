import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest46.test047");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = org.jsoup.helper.DataUtil.load(inputStream0, "#root", "", parser3);
        org.jsoup.nodes.Element element6 = document4.closest("Content-Encoding");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element6);
    }
}

