import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest79.test080");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        org.jsoup.select.Elements elements5 = element3.getElementsByTag("hi!");
        java.util.Iterator<org.jsoup.nodes.Element> elementItor6 = elements5.iterator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor6);
    }
}

