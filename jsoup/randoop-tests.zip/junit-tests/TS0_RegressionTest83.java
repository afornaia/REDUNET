import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest83.test084");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node3 = document2.shallowClone();
        org.jsoup.select.Elements elements4 = document2.children();
        java.lang.String str5 = elements4.html();
        org.jsoup.select.Evaluator.IndexEquals indexEquals7 = new org.jsoup.select.Evaluator.IndexEquals((int) (short) 10);
        java.io.InputStream inputStream8 = null;
        org.jsoup.parser.Parser parser11 = null;
        org.jsoup.nodes.Document document12 = org.jsoup.helper.DataUtil.load(inputStream8, "#root", "", parser11);
        org.jsoup.nodes.Document document15 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element16 = document15.parent();
        boolean boolean17 = indexEquals7.matches((org.jsoup.nodes.Element) document12, (org.jsoup.nodes.Element) document15);
        java.util.List<org.jsoup.nodes.Node> nodeList18 = document12.childNodesCopy();
        java.util.List<org.jsoup.nodes.Node> nodeList21 = org.jsoup.parser.Parser.parseXmlFragment("hi!", "hi!");
        org.jsoup.select.Evaluator.IsFirstOfType isFirstOfType22 = new org.jsoup.select.Evaluator.IsFirstOfType();
        org.jsoup.nodes.Document document25 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str26 = document25.tagName();
        java.io.InputStream inputStream27 = null;
        org.jsoup.parser.Parser parser30 = null;
        org.jsoup.nodes.Document document31 = org.jsoup.Jsoup.parse(inputStream27, "#root", "", parser30);
        boolean boolean32 = isFirstOfType22.matches((org.jsoup.nodes.Element) document25, (org.jsoup.nodes.Element) document31);
        java.util.List<org.jsoup.nodes.Node> nodeList33 = document25.childNodesCopy();
        java.util.Collection[] collectionArray35 = new java.util.Collection[3];
        @SuppressWarnings("unchecked")
        java.util.Collection<org.jsoup.nodes.Node>[] nodeCollectionArray36 = (java.util.Collection<org.jsoup.nodes.Node>[]) collectionArray35;
        nodeCollectionArray36[0] = nodeList18;
        nodeCollectionArray36[1] = nodeList21;
        nodeCollectionArray36[2] = nodeList33;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Collection<org.jsoup.nodes.Node>[] nodeCollectionArray43 = elements4.toArray(nodeCollectionArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: null");
        } catch (java.lang.ArrayStoreException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<head></head>\n<body>\n hi!\n</body>" + "'", str5.equals("<head></head>\n<body>\n hi!\n</body>"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "#root" + "'", str26.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(collectionArray35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeCollectionArray36);
    }
}

