import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest29.test030");
        org.jsoup.select.Evaluator.IsEmpty isEmpty0 = new org.jsoup.select.Evaluator.IsEmpty();
    }
}

