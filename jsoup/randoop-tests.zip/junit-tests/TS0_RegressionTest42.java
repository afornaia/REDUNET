import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest42.test043");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = org.jsoup.helper.DataUtil.load(inputStream0, "#root", "", parser3);
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str8 = document7.tagName();
        org.jsoup.select.Elements elements10 = document7.getElementsByTag("hi");
        java.lang.String[] strArray13 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet14 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet14, strArray13);
        org.jsoup.nodes.Element element16 = document7.classNames((java.util.Set<java.lang.String>) strSet14);
        org.jsoup.nodes.Document document19 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str20 = document19.tagName();
        org.jsoup.select.Elements elements22 = document19.getElementsByTag("hi");
        java.lang.String[] strArray25 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet26 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean27 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet26, strArray25);
        org.jsoup.nodes.Element element28 = document19.classNames((java.util.Set<java.lang.String>) strSet26);
        org.jsoup.parser.Parser parser29 = null;
        org.jsoup.nodes.Document document30 = document19.parser(parser29);
        java.io.InputStream inputStream31 = null;
        org.jsoup.parser.Parser parser34 = null;
        org.jsoup.nodes.Document document35 = org.jsoup.Jsoup.parse(inputStream31, "#root", "", parser34);
        org.jsoup.select.Elements elements36 = document35.getAllElements();
        org.jsoup.nodes.Document document39 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str40 = document39.tagName();
        org.jsoup.select.Elements elements42 = document39.getElementsByTag("hi");
        java.lang.String[] strArray45 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet46 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean47 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet46, strArray45);
        org.jsoup.nodes.Element element48 = document39.classNames((java.util.Set<java.lang.String>) strSet46);
        java.io.InputStream inputStream49 = null;
        org.jsoup.parser.Parser parser52 = null;
        org.jsoup.nodes.Document document53 = org.jsoup.Jsoup.parse(inputStream49, "#root", "", parser52);
        org.jsoup.nodes.Document document56 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str57 = document56.tagName();
        org.jsoup.select.Elements elements59 = document56.getElementsByTag("hi");
        java.lang.String[] strArray62 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet63 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean64 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet63, strArray62);
        org.jsoup.nodes.Element element65 = document56.classNames((java.util.Set<java.lang.String>) strSet63);
        java.io.InputStream inputStream66 = null;
        org.jsoup.parser.Parser parser69 = null;
        org.jsoup.nodes.Document document70 = org.jsoup.Jsoup.parse(inputStream66, "#root", "", parser69);
        org.jsoup.select.Elements elements71 = document70.getAllElements();
        org.jsoup.nodes.Element element72 = document70.shallowClone();
        org.jsoup.nodes.Element[] elementArray73 = new org.jsoup.nodes.Element[] { document4, element16, document30, document35, document39, document53, element65, document70 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList74 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean75 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList74, elementArray73);
        org.jsoup.parser.ParseError[] parseErrorArray76 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList77 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean78 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList77, parseErrorArray76);
        org.jsoup.nodes.Node[] nodeArray79 = new org.jsoup.nodes.Node[] {};
        java.util.ArrayList<org.jsoup.nodes.Node> nodeList80 = new java.util.ArrayList<org.jsoup.nodes.Node>();
        boolean boolean81 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList80, nodeArray79);
        boolean boolean82 = parseErrorList77.removeAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList80);
        boolean boolean83 = elementList74.retainAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList80);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "#root" + "'", str8.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "#root" + "'", str20.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "#root" + "'", str40.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray45);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "#root" + "'", str57.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray62);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element65);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements71);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element72);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray73);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray76);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray79);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
    }
}

