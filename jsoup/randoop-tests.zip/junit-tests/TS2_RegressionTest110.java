import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest110.test111");
        org.jsoup.nodes.Attributes attributes2 = null;
        org.jsoup.nodes.Attribute attribute3 = new org.jsoup.nodes.Attribute("hi!", "", attributes2);
        java.lang.String str5 = attribute3.setValue("");
        java.lang.String str7 = attribute3.setValue(" =\"PUBLIC\"");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }
}

