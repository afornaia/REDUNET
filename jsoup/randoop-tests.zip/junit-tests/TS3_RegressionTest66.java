import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest66.test067");
        org.jsoup.select.Evaluator.IsNthChild isNthChild2 = new org.jsoup.select.Evaluator.IsNthChild((int) 'a', (-1));
        org.jsoup.nodes.Document document5 = org.jsoup.parser.Parser.parse("Content-Type", "[]");
        org.jsoup.nodes.Document.QuirksMode quirksMode6 = null;
        org.jsoup.nodes.Document document7 = document5.quirksMode(quirksMode6);
        org.jsoup.select.Elements elements8 = new org.jsoup.select.Elements();
        org.jsoup.nodes.Document document10 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements12 = document10.getElementsByTag("[]");
        java.lang.String str13 = document10.className();
        org.jsoup.nodes.Attributes attributes14 = document10.attributes();
        boolean boolean15 = elements8.add((org.jsoup.nodes.Element) document10);
        boolean boolean16 = isNthChild2.matches((org.jsoup.nodes.Element) document5, (org.jsoup.nodes.Element) document10);
        org.jsoup.nodes.Document document19 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.nodes.Document document22 = org.jsoup.Jsoup.parseBodyFragment(" ", " ");
        org.jsoup.select.Elements elements23 = document22.previousElementSiblings();
        org.jsoup.nodes.Document document26 = org.jsoup.parser.Parser.parse("Content-Type", "[]");
        org.jsoup.nodes.Document.QuirksMode quirksMode27 = null;
        org.jsoup.nodes.Document document28 = document26.quirksMode(quirksMode27);
        org.jsoup.nodes.Element element30 = document26.removeClass("hi!");
        org.jsoup.nodes.Document document32 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements34 = document32.getElementsByTag("[]");
        org.jsoup.nodes.Element element36 = document32.removeAttr("content-type");
        int int37 = document32.elementSiblingIndex();
        org.jsoup.nodes.Document document38 = document32.clone();
        org.jsoup.nodes.Document document41 = org.jsoup.Jsoup.parseBodyFragment(" ", " ");
        org.jsoup.nodes.Node[] nodeArray42 = new org.jsoup.nodes.Node[] { document19, document22, document26, document32, document41 };
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element43 = document5.insertChildren((int) 'a', nodeArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Insert position out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray42);
    }
}

