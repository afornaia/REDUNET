import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest0.test001");
        org.jsoup.nodes.Element[] elementArray1 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList2 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList2, elementArray1);
        java.util.Spliterator<org.jsoup.nodes.Element> elementSpliterator4 = elementList2.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.Elements elements5 = org.jsoup.select.Selector.select("", (java.lang.Iterable<org.jsoup.nodes.Element>) elementList2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementSpliterator4);
    }
}

