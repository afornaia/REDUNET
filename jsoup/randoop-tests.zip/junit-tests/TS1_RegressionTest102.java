import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest102.test103");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse(inputStream0, "", "[public=content-encoding]", parser3);
        org.jsoup.select.Elements elements5 = document4.parents();
        org.jsoup.select.Elements elements7 = document4.getElementsMatchingText("PUBLIC");
        org.jsoup.nodes.TextNode textNode9 = new org.jsoup.nodes.TextNode("PUBLIC");
        org.jsoup.nodes.Node node11 = textNode9.removeAttr("PUBLIC");
        boolean boolean13 = textNode9.hasAttr("hi!");
        boolean boolean14 = textNode9.isBlank();
        org.jsoup.nodes.Attributes attributes15 = textNode9.attributes();
        org.jsoup.nodes.Attributes attributes18 = attributes15.put("content-encoding", true);
        boolean boolean19 = elements7.equals((java.lang.Object) attributes18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }
}

