import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest98 {

    public static boolean debug = false;

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest98.test099");
        org.jsoup.nodes.Document.OutputSettings outputSettings0 = new org.jsoup.nodes.Document.OutputSettings();
        org.jsoup.nodes.Document.OutputSettings outputSettings2 = outputSettings0.prettyPrint(true);
        org.jsoup.nodes.Entities.EscapeMode escapeMode3 = org.jsoup.nodes.Entities.EscapeMode.xhtml;
        org.jsoup.nodes.Document.OutputSettings outputSettings4 = outputSettings2.escapeMode(escapeMode3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(outputSettings2);
        org.junit.Assert.assertTrue("'" + escapeMode3 + "' != '" + org.jsoup.nodes.Entities.EscapeMode.xhtml + "'", escapeMode3.equals(org.jsoup.nodes.Entities.EscapeMode.xhtml));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(outputSettings4);
    }
}

