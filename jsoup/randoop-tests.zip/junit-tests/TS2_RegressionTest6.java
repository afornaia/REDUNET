import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest6.test007");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.helper.Validate.wtf("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: hi!");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
    }
}

