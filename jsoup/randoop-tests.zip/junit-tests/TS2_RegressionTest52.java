import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest52.test053");
        org.jsoup.UnsupportedMimeTypeException unsupportedMimeTypeException3 = new org.jsoup.UnsupportedMimeTypeException(":first-of-type", ":first-of-type", "PUBLIC");
    }
}

