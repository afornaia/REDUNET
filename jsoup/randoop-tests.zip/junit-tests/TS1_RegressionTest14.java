import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest14.test015");
        org.jsoup.select.Elements elements1 = new org.jsoup.select.Elements((int) (short) 10);
    }
}

