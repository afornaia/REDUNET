import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest15.test016");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node3 = document2.shallowClone();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Document document9 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node10 = document9.shallowClone();
        org.jsoup.nodes.Document document13 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element14 = document13.parent();
        org.jsoup.nodes.Document document17 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str18 = document17.tagName();
        org.jsoup.nodes.Document document21 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str22 = document21.tagName();
        org.jsoup.nodes.Element[] elementArray23 = new org.jsoup.nodes.Element[] { document2, document6, document9, document13, document17, document21 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList24 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList24, elementArray23);
        org.jsoup.nodes.Document document29 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node30 = document29.shallowClone();
        // The following exception was thrown during execution in test generation
        try {
            elementList24.add(10, (org.jsoup.nodes.Element) document29);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 6");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "#root" + "'", str18.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "#root" + "'", str22.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node30);
    }
}

