import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest85.test086");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element3 = document1.prependText(":first-of-type");
        org.jsoup.nodes.Element element5 = element3.removeAttr("");
        org.jsoup.select.Elements elements8 = element5.getElementsByAttributeValueEnding("PUBLIC", ":first-of-type");
        int int9 = elements8.size();
        org.jsoup.nodes.Document document11 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element13 = document11.prependText(":first-of-type");
        org.jsoup.nodes.Element element15 = element13.removeAttr("");
        boolean boolean16 = elements8.add(element15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }
}

