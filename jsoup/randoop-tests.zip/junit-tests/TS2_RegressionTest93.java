import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest93.test094");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element3 = document1.prependText(":first-of-type");
        java.lang.String str4 = element3.ownText();
        org.jsoup.nodes.Document document7 = org.jsoup.parser.Parser.parseBodyFragment("", "");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Node node8 = element3.before((org.jsoup.nodes.Node) document7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ":first-of-type" + "'", str4.equals(":first-of-type"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
    }
}

