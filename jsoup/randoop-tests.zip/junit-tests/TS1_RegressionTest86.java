import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest86.test087");
        org.jsoup.select.Evaluator.IsFirstChild isFirstChild0 = new org.jsoup.select.Evaluator.IsFirstChild();
        org.jsoup.parser.Parser parser1 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document4 = parser1.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList5 = document4.dataNodes();
        org.jsoup.select.Elements elements8 = document4.getElementsByAttributeValueMatching("Content-Type", "hi!");
        org.jsoup.select.Evaluator.TagEndsWith tagEndsWith10 = new org.jsoup.select.Evaluator.TagEndsWith("");
        java.io.InputStream inputStream11 = null;
        org.jsoup.parser.Parser parser14 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document15 = org.jsoup.Jsoup.parse(inputStream11, "", "[public=content-encoding]", parser14);
        org.jsoup.select.Elements elements16 = document15.parents();
        java.io.InputStream inputStream17 = null;
        org.jsoup.parser.Parser parser20 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document21 = org.jsoup.Jsoup.parse(inputStream17, "", "[public=content-encoding]", parser20);
        org.jsoup.select.Elements elements22 = document21.parents();
        org.jsoup.nodes.Element element24 = document21.removeAttr("hi!");
        boolean boolean25 = tagEndsWith10.matches((org.jsoup.nodes.Element) document15, element24);
        boolean boolean26 = isFirstChild0.matches((org.jsoup.nodes.Element) document4, element24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }
}

