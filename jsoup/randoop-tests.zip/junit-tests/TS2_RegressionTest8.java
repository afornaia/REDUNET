import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest8.test009");
        org.jsoup.select.NodeFilter.FilterResult filterResult0 = org.jsoup.select.NodeFilter.FilterResult.SKIP_CHILDREN;
        org.junit.Assert.assertTrue("'" + filterResult0 + "' != '" + org.jsoup.select.NodeFilter.FilterResult.SKIP_CHILDREN + "'", filterResult0.equals(org.jsoup.select.NodeFilter.FilterResult.SKIP_CHILDREN));
    }
}

