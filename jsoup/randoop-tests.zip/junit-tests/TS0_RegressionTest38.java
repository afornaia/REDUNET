import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest38.test039");
        org.jsoup.safety.Whitelist whitelist0 = org.jsoup.safety.Whitelist.basic();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(whitelist0);
    }
}

