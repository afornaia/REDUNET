import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest117.test118");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse(inputStream0, "", "[public=content-encoding]", parser3);
        org.jsoup.select.Elements elements5 = document4.parents();
        // The following exception was thrown during execution in test generation
        try {
            org.w3c.dom.Document document6 = org.jsoup.helper.W3CDom.convert(document4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
    }
}

