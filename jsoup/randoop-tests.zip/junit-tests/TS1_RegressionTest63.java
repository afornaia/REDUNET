import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest63.test064");
        org.jsoup.select.Evaluator.IsNthChild isNthChild2 = new org.jsoup.select.Evaluator.IsNthChild((int) (short) 0, (int) (short) 0);
        org.jsoup.parser.Parser parser3 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document6 = parser3.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList7 = document6.dataNodes();
        org.jsoup.select.Elements elements10 = document6.getElementsByAttributeValueMatching("Content-Type", "hi!");
        org.jsoup.select.Elements elements11 = org.jsoup.select.Collector.collect((org.jsoup.select.Evaluator) isNthChild2, (org.jsoup.nodes.Element) document6);
        org.jsoup.nodes.TextNode textNode13 = new org.jsoup.nodes.TextNode("PUBLIC");
        org.jsoup.nodes.Node node15 = textNode13.removeAttr("PUBLIC");
        boolean boolean17 = textNode13.hasAttr("hi!");
        boolean boolean18 = textNode13.isBlank();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element19 = document6.before((org.jsoup.nodes.Node) textNode13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }
}

