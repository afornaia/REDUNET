import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest59.test060");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        org.jsoup.nodes.Element element5 = document1.addClass("[]");
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements9 = document7.getElementsByTag("[]");
        org.jsoup.nodes.Element element11 = document7.addClass("[]");
        java.lang.String str13 = element11.attr(":first-of-type");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element14 = document1.after((org.jsoup.nodes.Node) element11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
    }
}

