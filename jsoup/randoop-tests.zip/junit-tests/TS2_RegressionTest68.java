import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest68.test069");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment("", "");
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = document2.parser(parser3);
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parseBodyFragment("public", "PUBLIC");
        org.jsoup.parser.Parser parser8 = null;
        org.jsoup.nodes.Document document9 = document7.parser(parser8);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element10 = document2.after((org.jsoup.nodes.Node) document9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document9);
    }
}

