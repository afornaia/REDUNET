import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest38.test039");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        org.jsoup.nodes.Document document5 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element7 = document5.prependText(":first-of-type");
        org.jsoup.nodes.Document document10 = org.jsoup.parser.Parser.parseBodyFragment("", "");
        org.jsoup.nodes.Document document12 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str13 = document12.location();
        org.jsoup.nodes.Element element14 = document12.root();
        org.jsoup.nodes.Document document16 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element18 = document16.prependText(":first-of-type");
        java.lang.String str19 = element18.ownText();
        org.jsoup.nodes.Element[] elementArray20 = new org.jsoup.nodes.Element[] { document1, element7, document10, element14, element18 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList21 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList21, elementArray20);
        org.jsoup.nodes.Element[] elementArray23 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList24 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean25 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList24, elementArray23);
        boolean boolean27 = elementList24.contains((java.lang.Object) 100);
        java.util.ListIterator<org.jsoup.nodes.Element> elementItor28 = elementList24.listIterator();
        org.jsoup.nodes.Document document30 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str31 = document30.location();
        org.jsoup.nodes.Element element32 = document30.root();
        boolean boolean33 = elementList24.add(element32);
        boolean boolean34 = elementList21.removeAll((java.util.Collection<org.jsoup.nodes.Element>) elementList24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + ":first-of-type" + "'", str19.equals(":first-of-type"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }
}

