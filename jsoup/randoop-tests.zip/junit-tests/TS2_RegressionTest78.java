import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest78.test079");
        org.jsoup.select.Evaluator.IsFirstOfType isFirstOfType0 = new org.jsoup.select.Evaluator.IsFirstOfType();
        org.jsoup.nodes.Document document3 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element5 = document3.prependText(":first-of-type");
        org.jsoup.nodes.Element element7 = element5.removeAttr("");
        org.jsoup.select.Evaluator.Class class9 = new org.jsoup.select.Evaluator.Class("");
        boolean boolean10 = element5.is((org.jsoup.select.Evaluator) class9);
        org.jsoup.nodes.Element element11 = element5.clone();
        java.util.List<org.jsoup.nodes.Node> nodeList13 = org.jsoup.parser.Parser.parseFragment("", element11, ".");
        org.jsoup.nodes.Document document16 = org.jsoup.Jsoup.parseBodyFragment("public", "PUBLIC");
        org.jsoup.parser.Parser parser17 = null;
        org.jsoup.nodes.Document document18 = document16.parser(parser17);
        boolean boolean19 = isFirstOfType0.matches(element11, (org.jsoup.nodes.Element) document16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }
}

