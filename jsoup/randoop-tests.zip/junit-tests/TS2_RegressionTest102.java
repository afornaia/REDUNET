import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest102.test103");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("public", "PUBLIC");
        org.jsoup.nodes.Element element4 = document2.child((int) (short) 0);
        org.jsoup.nodes.Document.OutputSettings outputSettings5 = new org.jsoup.nodes.Document.OutputSettings();
        java.nio.charset.Charset charset6 = null;
        org.jsoup.nodes.Document.OutputSettings outputSettings7 = outputSettings5.charset(charset6);
        boolean boolean8 = outputSettings7.outline();
        org.jsoup.nodes.Document document9 = document2.outputSettings(outputSettings7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(outputSettings7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document9);
    }
}

