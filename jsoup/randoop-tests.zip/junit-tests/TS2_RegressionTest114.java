import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest114 {

    public static boolean debug = false;

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest114.test115");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        org.jsoup.nodes.Document document5 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str6 = document5.location();
        org.jsoup.nodes.Element element7 = document5.root();
        int int8 = document5.childNodeSize();
        org.jsoup.parser.Tag tag9 = document5.tag();
        boolean boolean10 = tag9.formatAsBlock();
        org.jsoup.nodes.Element element12 = new org.jsoup.nodes.Element(tag9, "#document");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element13 = document1.after((org.jsoup.nodes.Node) element12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tag9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }
}

