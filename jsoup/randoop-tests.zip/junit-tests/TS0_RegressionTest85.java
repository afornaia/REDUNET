import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest85.test086");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node3 = document2.shallowClone();
        org.jsoup.select.Elements elements4 = document2.children();
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node8 = document7.shallowClone();
        // The following exception was thrown during execution in test generation
        try {
            document2.replaceWith(node8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node8);
    }
}

