import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest16.test017");
        org.jsoup.nodes.Document.OutputSettings.Syntax syntax0 = org.jsoup.nodes.Document.OutputSettings.Syntax.html;
        org.junit.Assert.assertTrue("'" + syntax0 + "' != '" + org.jsoup.nodes.Document.OutputSettings.Syntax.html + "'", syntax0.equals(org.jsoup.nodes.Document.OutputSettings.Syntax.html));
    }
}

