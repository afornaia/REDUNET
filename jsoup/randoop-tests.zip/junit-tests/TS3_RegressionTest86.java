import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest86.test087");
        org.jsoup.select.Evaluator.IsNthChild isNthChild2 = new org.jsoup.select.Evaluator.IsNthChild((int) 'a', (-1));
        java.lang.String str3 = isNthChild2.toString();
        org.jsoup.nodes.Element element4 = null;
        org.jsoup.nodes.Element element5 = org.jsoup.select.Collector.findFirst((org.jsoup.select.Evaluator) isNthChild2, element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + ":nth-child(97n-1)" + "'", str3.equals(":nth-child(97n-1)"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element5);
    }
}

