import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest72.test073");
        java.util.HashMap<java.lang.String, java.lang.String> strMap0 = org.jsoup.helper.W3CDom.OutputHtml();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap0);
    }
}

