import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest117.test118");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str3 = document2.tagName();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element7 = document6.parent();
        boolean boolean9 = document6.hasAttr("Content-Encoding");
        org.jsoup.nodes.Document document12 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node13 = document12.shallowClone();
        document12.updateMetaCharsetElement(true);
        java.io.InputStream inputStream16 = null;
        org.jsoup.parser.Parser parser19 = null;
        org.jsoup.nodes.Document document20 = org.jsoup.Jsoup.parse(inputStream16, "#root", "", parser19);
        org.jsoup.select.Elements elements21 = document20.getAllElements();
        org.jsoup.nodes.Element element22 = document20.shallowClone();
        java.io.InputStream inputStream23 = null;
        org.jsoup.parser.Parser parser26 = null;
        org.jsoup.nodes.Document document27 = org.jsoup.helper.DataUtil.load(inputStream23, "#root", "", parser26);
        org.jsoup.nodes.Element element29 = document27.closest("Content-Encoding");
        org.jsoup.nodes.Document document32 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str33 = document32.tagName();
        org.jsoup.select.Elements elements35 = document32.getElementsByTag("hi");
        java.lang.String[] strArray38 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet39 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet39, strArray38);
        org.jsoup.nodes.Element element41 = document32.classNames((java.util.Set<java.lang.String>) strSet39);
        org.jsoup.parser.Parser parser42 = null;
        org.jsoup.nodes.Document document43 = document32.parser(parser42);
        org.jsoup.nodes.Element[] elementArray44 = new org.jsoup.nodes.Element[] { document2, document6, document12, document20, element29, document43 };
        org.jsoup.select.Elements elements45 = new org.jsoup.select.Elements(elementArray44);
        java.util.ListIterator<org.jsoup.nodes.Element> elementItor46 = elements45.listIterator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#root" + "'", str3.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "#root" + "'", str33.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor46);
    }
}

