import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest13.test014");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.helper.Validate.isTrue(false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must be true");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

