import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest114 {

    public static boolean debug = false;

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest114.test115");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str3 = document2.tagName();
        org.jsoup.select.Elements elements5 = document2.getElementsByTag("hi");
        java.lang.String[] strArray8 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet9 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet9, strArray8);
        org.jsoup.nodes.Element element11 = document2.classNames((java.util.Set<java.lang.String>) strSet9);
        org.jsoup.nodes.Document document14 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str15 = document14.tagName();
        org.jsoup.select.Elements elements17 = document14.getElementsByTag("hi");
        java.lang.String[] strArray20 = new java.lang.String[] { "Content-Encoding", "" };
        java.util.LinkedHashSet<java.lang.String> strSet21 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean22 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet21, strArray20);
        org.jsoup.nodes.Element element23 = document14.classNames((java.util.Set<java.lang.String>) strSet21);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Node node24 = document2.after((org.jsoup.nodes.Node) element23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#root" + "'", str3.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "#root" + "'", str15.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element23);
    }
}

