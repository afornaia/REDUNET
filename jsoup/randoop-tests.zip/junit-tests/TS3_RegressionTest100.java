import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest100.test101");
        org.jsoup.parser.ParseSettings parseSettings2 = new org.jsoup.parser.ParseSettings(true, true);
    }
}

