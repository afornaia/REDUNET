import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest88 {

    public static boolean debug = false;

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest88.test089");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        org.jsoup.nodes.Element element4 = document1.clone();
        java.lang.String str5 = document1.wholeText();
        org.jsoup.nodes.Document document6 = document1.clone();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
    }
}

