import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest4.test005");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 10, 0.0f };
        org.jsoup.select.Selector.SelectorParseException selectorParseException4 = new org.jsoup.select.Selector.SelectorParseException("", objArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray3);
    }
}

