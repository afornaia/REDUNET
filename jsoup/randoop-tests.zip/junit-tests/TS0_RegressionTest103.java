import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest103.test104");
        org.jsoup.select.NodeVisitor nodeVisitor0 = null;
        org.jsoup.select.Evaluator.IndexEquals indexEquals2 = new org.jsoup.select.Evaluator.IndexEquals((int) (short) 10);
        java.io.InputStream inputStream3 = null;
        org.jsoup.parser.Parser parser6 = null;
        org.jsoup.nodes.Document document7 = org.jsoup.helper.DataUtil.load(inputStream3, "#root", "", parser6);
        org.jsoup.nodes.Document document10 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element11 = document10.parent();
        boolean boolean12 = indexEquals2.matches((org.jsoup.nodes.Element) document7, (org.jsoup.nodes.Element) document10);
        java.util.List<org.jsoup.nodes.Node> nodeList13 = document7.childNodesCopy();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.NodeTraversor.traverse(nodeVisitor0, (org.jsoup.nodes.Node) document7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList13);
    }
}

