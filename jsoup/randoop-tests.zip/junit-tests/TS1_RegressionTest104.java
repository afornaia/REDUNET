import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest104.test105");
        boolean boolean1 = org.jsoup.internal.StringUtil.isNumeric("PUBLIC");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }
}

