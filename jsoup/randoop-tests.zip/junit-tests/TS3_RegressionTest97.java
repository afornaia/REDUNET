import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest97.test098");
        org.jsoup.nodes.TextNode textNode1 = new org.jsoup.nodes.TextNode("[]");
        int int2 = textNode1.childNodeSize();
        org.jsoup.nodes.Node node4 = textNode1.removeAttr("content-type");
        org.jsoup.select.NodeFilter nodeFilter5 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Node node6 = textNode1.filter(nodeFilter5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node4);
    }
}

