import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest54.test055");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node3 = document2.shallowClone();
        org.jsoup.select.Elements elements4 = document2.children();
        java.lang.String str5 = elements4.toString();
        org.jsoup.select.Elements elements6 = elements4.unwrap();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>" + "'", str5.equals("<html>\n <head></head>\n <body>\n  hi!\n </body>\n</html>"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements6);
    }
}

