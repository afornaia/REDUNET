import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest96.test097");
        java.io.InputStream inputStream0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.nio.ByteBuffer byteBuffer2 = org.jsoup.helper.DataUtil.readToByteBuffer(inputStream0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Stream closed");
        } catch (java.io.IOException e) {
        // Expected exception.
        }
    }
}

