import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest36.test037");
        org.jsoup.select.NodeFilter nodeFilter0 = null;
        org.jsoup.nodes.Comment comment2 = new org.jsoup.nodes.Comment("hi!");
        org.jsoup.nodes.Node node3 = comment2.clone();
        java.lang.String str4 = node3.outerHtml();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.NodeFilter.FilterResult filterResult5 = org.jsoup.select.NodeTraversor.filter(nodeFilter0, node3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "<!--hi!-->" + "'", str4.equals("<!--hi!-->"));
    }
}

