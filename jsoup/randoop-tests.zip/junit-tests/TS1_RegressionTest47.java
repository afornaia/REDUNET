import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest47.test048");
        java.lang.Throwable throwable1 = null;
        org.jsoup.SerializationException serializationException2 = new org.jsoup.SerializationException(throwable1);
        org.jsoup.SerializationException serializationException3 = new org.jsoup.SerializationException("hi!", throwable1);
    }
}

