import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest104.test105");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        int int4 = document1.childNodeSize();
        org.jsoup.parser.Tag tag5 = document1.tag();
        org.jsoup.nodes.Attributes attributes7 = new org.jsoup.nodes.Attributes();
        org.jsoup.nodes.Attributes attributes10 = attributes7.put("", "PUBLIC");
        org.jsoup.nodes.FormElement formElement11 = new org.jsoup.nodes.FormElement(tag5, " =\"PUBLIC\"", attributes7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tag5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes10);
    }
}

