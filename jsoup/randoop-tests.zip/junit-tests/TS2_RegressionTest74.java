import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest74.test075");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("public", "PUBLIC");
        java.lang.String str3 = document2.cssSelector();
        org.jsoup.nodes.Document document5 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str6 = document5.location();
        org.jsoup.nodes.Element element7 = document5.root();
        org.jsoup.select.Elements elements9 = element7.getElementsByTag("PUBLIC");
        java.lang.String[] strArray16 = new java.lang.String[] { "", ":first-of-type", "hi!", "#hi!", "public", "public" };
        java.util.LinkedHashSet<java.lang.String> strSet17 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean18 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet17, strArray16);
        org.jsoup.nodes.Element element19 = element7.classNames((java.util.Set<java.lang.String>) strSet17);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element20 = document2.before((org.jsoup.nodes.Node) element7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#root" + "'", str3.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element19);
    }
}

