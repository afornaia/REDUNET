import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest39.test040");
        org.jsoup.nodes.Element[] elementArray0 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList1 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList1, elementArray0);
        org.jsoup.select.Elements elements3 = new org.jsoup.select.Elements((java.util.Collection<org.jsoup.nodes.Element>) elementList1);
        boolean boolean5 = elements3.equals((java.lang.Object) "");
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream6 = elements3.stream();
        org.jsoup.select.Elements elements8 = elements3.next("Content-Type");
        org.jsoup.nodes.Element element10 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element11 = elements8.set((int) (short) 10, element10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementStream6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements8);
    }
}

