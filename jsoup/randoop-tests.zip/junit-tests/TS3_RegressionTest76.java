import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest76.test077");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        org.jsoup.nodes.Element element5 = document1.removeAttr("content-type");
        org.jsoup.select.Elements elements7 = document1.getElementsByIndexGreaterThan((int) ' ');
        org.jsoup.nodes.Element element9 = document1.tagName("[]");
        org.jsoup.nodes.Element element11 = document1.prependElement("content-type");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
    }
}

