import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest37.test038");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("Content-Type", "[]");
        org.jsoup.nodes.Document.QuirksMode quirksMode3 = null;
        org.jsoup.nodes.Document document4 = document2.quirksMode(quirksMode3);
        org.jsoup.nodes.Element element6 = document2.removeClass("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element6);
    }
}

