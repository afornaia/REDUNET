import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest69.test070");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str3 = document2.tagName();
        org.jsoup.select.Elements elements5 = document2.getElementsByTag("hi");
        org.jsoup.nodes.Element element7 = document2.appendElement("Content-Encoding");
        org.jsoup.nodes.Document document10 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str11 = document10.tagName();
        org.jsoup.select.Elements elements13 = document10.getElementsByTag("hi");
        org.jsoup.nodes.Element element15 = document10.appendElement("Content-Encoding");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element16 = document2.before((org.jsoup.nodes.Node) document10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#root" + "'", str3.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "#root" + "'", str11.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element15);
    }
}

