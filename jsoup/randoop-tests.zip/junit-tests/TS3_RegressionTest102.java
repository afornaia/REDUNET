import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest102.test103");
        org.jsoup.Connection.Method method0 = org.jsoup.Connection.Method.DELETE;
        org.junit.Assert.assertTrue("'" + method0 + "' != '" + org.jsoup.Connection.Method.DELETE + "'", method0.equals(org.jsoup.Connection.Method.DELETE));
    }
}

