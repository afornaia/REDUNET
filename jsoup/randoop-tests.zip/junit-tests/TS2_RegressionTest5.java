import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest5.test006");
        org.jsoup.Connection.Method method0 = org.jsoup.Connection.Method.TRACE;
        org.junit.Assert.assertTrue("'" + method0 + "' != '" + org.jsoup.Connection.Method.TRACE + "'", method0.equals(org.jsoup.Connection.Method.TRACE));
    }
}

