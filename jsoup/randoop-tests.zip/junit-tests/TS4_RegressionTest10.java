import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest10.test011");
        org.jsoup.select.NodeFilter.FilterResult filterResult0 = org.jsoup.select.NodeFilter.FilterResult.CONTINUE;
        org.junit.Assert.assertTrue("'" + filterResult0 + "' != '" + org.jsoup.select.NodeFilter.FilterResult.CONTINUE + "'", filterResult0.equals(org.jsoup.select.NodeFilter.FilterResult.CONTINUE));
    }
}

