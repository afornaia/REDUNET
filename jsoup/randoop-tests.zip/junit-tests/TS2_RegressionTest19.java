import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest19.test020");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parseBodyFragment("", "");
        org.jsoup.nodes.Element[] elementArray3 = new org.jsoup.nodes.Element[] { document2 };
        java.util.ArrayList<org.jsoup.nodes.Element> elementList4 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList4, elementArray3);
        java.util.Iterator<org.jsoup.nodes.Element> elementItor6 = elementList4.iterator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor6);
    }
}

