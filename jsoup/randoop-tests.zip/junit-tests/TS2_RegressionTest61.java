import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest61.test062");
        org.jsoup.UnsupportedMimeTypeException unsupportedMimeTypeException3 = new org.jsoup.UnsupportedMimeTypeException("", "", "hi!");
        org.jsoup.SerializationException serializationException4 = new org.jsoup.SerializationException((java.lang.Throwable) unsupportedMimeTypeException3);
        org.jsoup.UnsupportedMimeTypeException unsupportedMimeTypeException8 = new org.jsoup.UnsupportedMimeTypeException("", "", "hi!");
        org.jsoup.SerializationException serializationException9 = new org.jsoup.SerializationException((java.lang.Throwable) unsupportedMimeTypeException8);
        unsupportedMimeTypeException3.addSuppressed((java.lang.Throwable) serializationException9);
        java.lang.String str11 = unsupportedMimeTypeException3.getUrl();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "hi!" + "'", str11.equals("hi!"));
    }
}

