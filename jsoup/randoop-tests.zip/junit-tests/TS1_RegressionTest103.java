import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest103.test104");
        org.jsoup.nodes.Comment comment1 = new org.jsoup.nodes.Comment("hi!");
        java.lang.String str3 = comment1.attr("PUBLIC");
        java.lang.String str4 = comment1.nodeName();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "#comment" + "'", str4.equals("#comment"));
    }
}

