import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest114 {

    public static boolean debug = false;

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest114.test115");
        org.jsoup.nodes.TextNode textNode1 = new org.jsoup.nodes.TextNode("PUBLIC");
        org.jsoup.nodes.Node node3 = textNode1.removeAttr("PUBLIC");
        boolean boolean5 = textNode1.hasAttr("hi!");
        boolean boolean6 = textNode1.isBlank();
        org.jsoup.nodes.Attributes attributes7 = textNode1.attributes();
        org.jsoup.nodes.Attributes attributes10 = attributes7.add("", "[public=content-encoding]");
        java.util.Iterator<org.jsoup.nodes.Attribute> attributeItor11 = attributes10.iterator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributeItor11);
    }
}

