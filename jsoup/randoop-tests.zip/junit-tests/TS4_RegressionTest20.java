import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest20.test021");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("", "");
        org.jsoup.select.Elements elements3 = document2.getAllElements();
        org.jsoup.select.Elements elements5 = document2.getElementsContainingText("hi!");
        org.jsoup.select.Elements elements7 = elements5.append("hi!");
        java.lang.Class<?> wildcardClass8 = elements7.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass8);
    }
}

