import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest105.test106");
        org.jsoup.select.NodeFilter nodeFilter0 = null;
        org.jsoup.select.Elements elements1 = new org.jsoup.select.Elements();
        elements1.clear();
        org.jsoup.select.Elements elements4 = elements1.html(" ");
        java.util.List<java.lang.String> strList5 = elements1.eachText();
        org.jsoup.select.Elements elements7 = elements1.addClass("");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.NodeTraversor.filter(nodeFilter0, elements7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
    }
}

