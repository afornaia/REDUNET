import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest79.test080");
        java.util.regex.Pattern pattern0 = null;
        org.jsoup.select.Evaluator.Matches matches1 = new org.jsoup.select.Evaluator.Matches(pattern0);
    }
}

