import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest44.test045");
        org.jsoup.Connection.Method method0 = org.jsoup.Connection.Method.POST;
        org.junit.Assert.assertTrue("'" + method0 + "' != '" + org.jsoup.Connection.Method.POST + "'", method0.equals(org.jsoup.Connection.Method.POST));
    }
}

