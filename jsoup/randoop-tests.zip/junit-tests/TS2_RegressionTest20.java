import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest20.test021");
        java.lang.String str1 = org.jsoup.nodes.Entities.unescape("PUBLIC");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PUBLIC" + "'", str1.equals("PUBLIC"));
    }
}

