import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest92.test093");
        java.lang.Throwable throwable1 = null;
        org.jsoup.SerializationException serializationException2 = new org.jsoup.SerializationException("", throwable1);
        java.lang.Throwable[] throwableArray3 = serializationException2.getSuppressed();
        java.lang.Throwable[] throwableArray4 = serializationException2.getSuppressed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray4);
    }
}

