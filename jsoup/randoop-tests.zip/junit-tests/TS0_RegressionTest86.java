import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest86.test087");
        org.jsoup.select.Evaluator.IndexEquals indexEquals1 = new org.jsoup.select.Evaluator.IndexEquals((int) (short) 10);
        java.io.InputStream inputStream2 = null;
        org.jsoup.parser.Parser parser5 = null;
        org.jsoup.nodes.Document document6 = org.jsoup.helper.DataUtil.load(inputStream2, "#root", "", parser5);
        org.jsoup.nodes.Document document9 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Element element10 = document9.parent();
        boolean boolean11 = indexEquals1.matches((org.jsoup.nodes.Element) document6, (org.jsoup.nodes.Element) document9);
        java.lang.String str12 = document9.cssSelector();
        java.io.InputStream inputStream13 = null;
        org.jsoup.parser.Parser parser16 = null;
        org.jsoup.nodes.Document document17 = org.jsoup.helper.DataUtil.load(inputStream13, "#root", "", parser16);
        java.nio.charset.Charset charset18 = null;
        document17.charset(charset18);
        // The following exception was thrown during execution in test generation
        try {
            document9.replaceWith((org.jsoup.nodes.Node) document17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(element10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#root" + "'", str12.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document17);
    }
}

