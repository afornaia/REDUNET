import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest11.test012");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("", "");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = document2.absUrl("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: String must not be empty");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
    }
}

