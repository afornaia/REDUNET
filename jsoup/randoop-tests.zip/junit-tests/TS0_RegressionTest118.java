import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest118 {

    public static boolean debug = false;

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest118.test119");
        org.jsoup.select.Evaluator.IndexEquals indexEquals1 = new org.jsoup.select.Evaluator.IndexEquals((int) (byte) 0);
    }
}

