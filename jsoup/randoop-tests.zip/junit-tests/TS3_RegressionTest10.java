import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest10.test011");
        org.jsoup.parser.TokenQueue tokenQueue1 = new org.jsoup.parser.TokenQueue("");
        boolean boolean2 = tokenQueue1.matchesWhitespace();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str4 = tokenQueue1.consumeToIgnoreCase("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 1");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

