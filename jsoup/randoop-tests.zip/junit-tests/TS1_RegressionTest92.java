import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest92.test093");
        java.lang.StringBuilder stringBuilder0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.internal.StringUtil.appendNormalisedWhitespace(stringBuilder0, "Content-Type", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

