import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest109 {

    public static boolean debug = false;

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest109.test110");
        org.jsoup.SerializationException serializationException1 = new org.jsoup.SerializationException("SYSTEM");
    }
}

