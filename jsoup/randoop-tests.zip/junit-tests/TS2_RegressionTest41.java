import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest41.test042");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str2 = document1.location();
        org.jsoup.nodes.Element element3 = document1.root();
        org.jsoup.nodes.Document document5 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element7 = document5.prependText(":first-of-type");
        org.jsoup.nodes.Element element9 = element7.removeAttr("");
        org.jsoup.select.Elements elements12 = element9.getElementsByAttributeValueEnding("PUBLIC", ":first-of-type");
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element13 = document1.before((org.jsoup.nodes.Node) element9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements12);
    }
}

