import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest116.test117");
        org.jsoup.nodes.DataNode dataNode2 = org.jsoup.nodes.DataNode.createFromEncoded("content-encoding", "Content-Type");
        java.lang.String str3 = dataNode2.getWholeData();
        org.jsoup.nodes.Node node6 = dataNode2.attr("", "content-encoding");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNode2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "content-encoding" + "'", str3.equals("content-encoding"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node6);
    }
}

