import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest37.test038");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        org.jsoup.nodes.Element element3 = document1.prependText(":first-of-type");
        org.jsoup.nodes.Element element5 = element3.removeAttr("");
        org.jsoup.select.Evaluator.Class class7 = new org.jsoup.select.Evaluator.Class("");
        boolean boolean8 = element3.is((org.jsoup.select.Evaluator) class7);
        java.lang.String str9 = class7.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "." + "'", str9.equals("."));
    }
}

