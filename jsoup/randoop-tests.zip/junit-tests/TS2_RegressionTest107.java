import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest107.test108");
        org.jsoup.select.NodeVisitor nodeVisitor0 = null;
        org.jsoup.nodes.Element[] elementArray1 = new org.jsoup.nodes.Element[] {};
        org.jsoup.select.Elements elements2 = new org.jsoup.select.Elements(elementArray1);
        org.jsoup.select.Elements elements3 = elements2.remove();
        java.util.ListIterator<org.jsoup.nodes.Element> elementItor4 = elements3.listIterator();
        org.jsoup.select.Elements elements6 = elements3.eq((int) (byte) 10);
        java.util.stream.Stream<org.jsoup.nodes.Element> elementStream7 = elements6.parallelStream();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.NodeTraversor.traverse(nodeVisitor0, elements6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementItor4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementStream7);
    }
}

