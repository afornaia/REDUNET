import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest112.test113");
        org.jsoup.nodes.Element[] elementArray0 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList1 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList1, elementArray0);
        org.jsoup.select.Elements elements3 = new org.jsoup.select.Elements((java.util.Collection<org.jsoup.nodes.Element>) elementList1);
        boolean boolean5 = elements3.equals((java.lang.Object) "");
        java.util.List<org.jsoup.nodes.FormElement> formElementList6 = elements3.forms();
        org.jsoup.parser.Parser parser7 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document10 = parser7.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList11 = document10.dataNodes();
        org.jsoup.select.Elements elements14 = document10.getElementsByAttributeValueMatching("Content-Type", "hi!");
        boolean boolean15 = elements3.add((org.jsoup.nodes.Element) document10);
        java.lang.String str16 = document10.normalName();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(formElementList6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "#root" + "'", str16.equals("#root"));
    }
}

