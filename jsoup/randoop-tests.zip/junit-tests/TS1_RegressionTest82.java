import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest82.test083");
        org.jsoup.select.Evaluator.Class class1 = new org.jsoup.select.Evaluator.Class("Content-Encoding");
    }
}

