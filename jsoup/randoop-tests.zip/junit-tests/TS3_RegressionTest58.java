import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest58.test059");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        org.jsoup.nodes.Element element4 = document1.clone();
        org.jsoup.nodes.Attributes attributes5 = document1.attributes();
        boolean boolean7 = attributes5.hasDeclaredValueForKeyIgnoreCase("content-type");
        int int8 = attributes5.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }
}

