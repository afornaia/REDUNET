import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest60.test061");
        org.jsoup.parser.Tag tag0 = null;
        org.jsoup.nodes.TextNode textNode3 = new org.jsoup.nodes.TextNode("PUBLIC");
        org.jsoup.nodes.Node node5 = textNode3.removeAttr("PUBLIC");
        boolean boolean7 = textNode3.hasAttr("hi!");
        boolean boolean8 = textNode3.isBlank();
        org.jsoup.nodes.Attributes attributes9 = textNode3.attributes();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.PseudoTextElement pseudoTextElement10 = new org.jsoup.nodes.PseudoTextElement(tag0, "PUBLIC", attributes9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes9);
    }
}

