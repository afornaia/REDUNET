import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest54.test055");
        org.jsoup.nodes.Document document1 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements3 = document1.getElementsByTag("[]");
        java.lang.String str4 = elements3.text();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }
}

