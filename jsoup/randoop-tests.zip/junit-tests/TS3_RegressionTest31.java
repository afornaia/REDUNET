import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest31.test032");
        org.jsoup.nodes.Document document2 = org.jsoup.parser.Parser.parse("Content-Type", "[]");
        org.jsoup.nodes.Document.QuirksMode quirksMode3 = null;
        org.jsoup.nodes.Document document4 = document2.quirksMode(quirksMode3);
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Node node6 = document4.wrap("[]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
    }
}

