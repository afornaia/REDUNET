import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest124 {

    public static boolean debug = false;

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest124.test125");
        org.jsoup.parser.Parser parser0 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document3 = parser0.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList4 = document3.dataNodes();
        org.jsoup.select.Elements elements7 = document3.getElementsByAttributeValueMatching("Content-Type", "hi!");
        org.jsoup.nodes.Element element9 = document3.appendText("");
        java.util.regex.Pattern pattern10 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.select.Elements elements11 = element9.getElementsMatchingOwnText(pattern10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element9);
    }
}

