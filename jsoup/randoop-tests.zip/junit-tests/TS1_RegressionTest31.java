import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest31.test032");
        org.jsoup.safety.Whitelist whitelist2 = org.jsoup.safety.Whitelist.simpleText();
        java.lang.String[] strArray6 = new java.lang.String[] { "hi!" };
        org.jsoup.safety.Whitelist whitelist7 = whitelist2.addProtocols("Content-Type", "Content-Encoding", strArray6);
        java.lang.String str8 = org.jsoup.Jsoup.clean("", "Content-Encoding", whitelist2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(whitelist2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(whitelist7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }
}

