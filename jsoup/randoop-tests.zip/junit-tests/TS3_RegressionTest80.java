import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest80.test081");
        org.jsoup.parser.ParseSettings parseSettings2 = new org.jsoup.parser.ParseSettings(false, true);
        java.lang.String str4 = parseSettings2.normalizeAttribute("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }
}

