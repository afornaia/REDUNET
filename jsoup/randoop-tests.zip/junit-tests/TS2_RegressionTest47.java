import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest47.test048");
        org.jsoup.select.Evaluator.AttributeWithValueNot attributeWithValueNot2 = new org.jsoup.select.Evaluator.AttributeWithValueNot("PUBLIC", ":first-of-type");
    }
}

