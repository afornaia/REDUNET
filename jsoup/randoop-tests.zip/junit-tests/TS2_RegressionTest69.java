import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest69.test070");
        org.jsoup.nodes.Element[] elementArray0 = new org.jsoup.nodes.Element[] {};
        org.jsoup.select.Elements elements1 = new org.jsoup.select.Elements(elementArray0);
        org.jsoup.select.Elements elements2 = elements1.remove();
        java.lang.String str3 = elements2.html();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }
}

