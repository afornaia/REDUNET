import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest99.test100");
        org.jsoup.parser.TokenQueue tokenQueue1 = new org.jsoup.parser.TokenQueue("PUBLIC");
        java.lang.String str2 = tokenQueue1.consumeCssIdentifier();
        java.lang.String str3 = tokenQueue1.consumeElementSelector();
        java.lang.String str5 = tokenQueue1.chompToIgnoreCase("#document");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PUBLIC" + "'", str2.equals("PUBLIC"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }
}

