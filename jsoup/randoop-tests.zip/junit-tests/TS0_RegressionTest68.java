import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest68.test069");
        java.lang.StringBuilder stringBuilder0 = org.jsoup.internal.StringUtil.borrowBuilder();
        org.jsoup.internal.StringUtil.appendNormalisedWhitespace(stringBuilder0, "", false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringBuilder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(stringBuilder0.toString(), "");
    }
}

