import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest12.test013");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("", "");
        org.jsoup.select.Elements elements3 = document2.getAllElements();
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element5 = document2.before("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Object must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
    }
}

