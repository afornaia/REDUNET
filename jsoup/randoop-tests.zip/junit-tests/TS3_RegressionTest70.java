import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest70.test071");
        java.util.regex.Pattern pattern0 = null;
        org.jsoup.select.Evaluator.MatchesOwn matchesOwn1 = new org.jsoup.select.Evaluator.MatchesOwn(pattern0);
        org.jsoup.nodes.Document document3 = org.jsoup.Jsoup.parseBodyFragment("hi!");
        org.jsoup.select.Elements elements5 = document3.getElementsByTag("[]");
        org.jsoup.nodes.Element element6 = document3.clone();
        org.jsoup.nodes.Attributes attributes7 = document3.attributes();
        org.jsoup.nodes.Document document10 = org.jsoup.parser.Parser.parse("Content-Type", "[]");
        org.jsoup.nodes.Document.QuirksMode quirksMode11 = null;
        org.jsoup.nodes.Document document12 = document10.quirksMode(quirksMode11);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean13 = matchesOwn1.matches((org.jsoup.nodes.Element) document3, (org.jsoup.nodes.Element) document10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(attributes7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document12);
    }
}

