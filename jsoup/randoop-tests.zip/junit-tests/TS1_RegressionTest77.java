import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest77.test078");
        org.jsoup.select.Evaluator.TagEndsWith tagEndsWith1 = new org.jsoup.select.Evaluator.TagEndsWith("");
        java.io.InputStream inputStream2 = null;
        org.jsoup.parser.Parser parser5 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document6 = org.jsoup.Jsoup.parse(inputStream2, "", "[public=content-encoding]", parser5);
        org.jsoup.select.Elements elements7 = document6.parents();
        java.io.InputStream inputStream8 = null;
        org.jsoup.parser.Parser parser11 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document12 = org.jsoup.Jsoup.parse(inputStream8, "", "[public=content-encoding]", parser11);
        org.jsoup.select.Elements elements13 = document12.parents();
        org.jsoup.nodes.Element element15 = document12.removeAttr("hi!");
        boolean boolean16 = tagEndsWith1.matches((org.jsoup.nodes.Element) document6, element15);
        org.jsoup.parser.Parser parser17 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document20 = parser17.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList21 = document20.dataNodes();
        org.jsoup.parser.Parser parser22 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document25 = parser22.parseInput("PUBLIC", "hi!");
        org.jsoup.nodes.DocumentType documentType26 = document25.documentType();
        org.jsoup.select.Elements elements28 = document25.getElementsContainingText("[public=content-encoding]");
        boolean boolean29 = tagEndsWith1.matches((org.jsoup.nodes.Element) document20, (org.jsoup.nodes.Element) document25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(documentType26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }
}

