import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest66.test067");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parseBodyFragment("public", "PUBLIC");
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = document2.parser(parser3);
        java.lang.String str5 = document2.nodeName();
        boolean boolean7 = document2.hasAttr("#root");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "#document" + "'", str5.equals("#document"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

