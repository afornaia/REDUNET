import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest83.test084");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = org.jsoup.parser.Parser.htmlParser();
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse(inputStream0, "", "[public=content-encoding]", parser3);
        org.jsoup.select.Elements elements5 = document4.parents();
        java.util.List<org.jsoup.nodes.FormElement> formElementList6 = elements5.forms();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(formElementList6);
    }
}

