import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest89.test090");
        java.io.InputStream inputStream0 = null;
        org.jsoup.parser.Parser parser3 = null;
        org.jsoup.nodes.Document document4 = org.jsoup.Jsoup.parse(inputStream0, "#root", "", parser3);
        boolean boolean5 = document4.hasText();
        org.jsoup.nodes.Document.OutputSettings outputSettings6 = document4.outputSettings();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(outputSettings6);
    }
}

