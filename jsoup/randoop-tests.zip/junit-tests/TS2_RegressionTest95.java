import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest95.test096");
        org.jsoup.nodes.Document document1 = org.jsoup.nodes.Document.createShell("");
        int int2 = document1.childNodeSize();
        org.jsoup.nodes.Document.QuirksMode quirksMode3 = document1.quirksMode();
        java.lang.String str4 = document1.ownText();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + quirksMode3 + "' != '" + org.jsoup.nodes.Document.QuirksMode.noQuirks + "'", quirksMode3.equals(org.jsoup.nodes.Document.QuirksMode.noQuirks));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }
}

