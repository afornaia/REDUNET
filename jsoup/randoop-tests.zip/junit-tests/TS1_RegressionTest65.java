import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest65.test066");
        org.jsoup.select.Evaluator.MatchText matchText1 = new org.jsoup.select.Evaluator.MatchText();
        org.jsoup.parser.Parser parser2 = org.jsoup.parser.Parser.xmlParser();
        org.jsoup.nodes.Document document5 = parser2.parseInput("PUBLIC", "hi!");
        java.util.List<org.jsoup.nodes.DataNode> dataNodeList6 = document5.dataNodes();
        org.jsoup.select.Elements elements9 = document5.getElementsByAttributeValueMatching("Content-Type", "hi!");
        org.jsoup.nodes.Element element11 = document5.appendText("");
        org.jsoup.select.Elements elements12 = org.jsoup.select.Selector.select((org.jsoup.select.Evaluator) matchText1, (org.jsoup.nodes.Element) document5);
        org.jsoup.select.Elements elements13 = org.jsoup.select.Selector.select("Content-Encoding", (java.lang.Iterable<org.jsoup.nodes.Element>) elements12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parser2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(dataNodeList6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements13);
    }
}

