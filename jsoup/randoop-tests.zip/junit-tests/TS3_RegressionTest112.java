import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest112.test113");
        org.jsoup.select.Elements elements0 = new org.jsoup.select.Elements();
        elements0.clear();
        org.jsoup.select.Elements elements3 = elements0.html(" ");
        java.util.List<java.lang.String> strList4 = elements0.eachText();
        org.jsoup.select.Elements elements6 = elements0.addClass("");
        org.jsoup.select.Elements elements7 = elements6.nextAll();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strList4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements7);
    }
}

