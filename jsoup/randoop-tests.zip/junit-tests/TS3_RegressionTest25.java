import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest25.test026");
        org.jsoup.parser.ParseSettings parseSettings0 = org.jsoup.parser.ParseSettings.htmlDefault;
        java.lang.String str2 = parseSettings0.normalizeTag("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseSettings0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }
}

