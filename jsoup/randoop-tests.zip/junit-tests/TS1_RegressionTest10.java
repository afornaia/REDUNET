import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest10.test011");
        org.jsoup.nodes.Element[] elementArray0 = new org.jsoup.nodes.Element[] {};
        java.util.ArrayList<org.jsoup.nodes.Element> elementList1 = new java.util.ArrayList<org.jsoup.nodes.Element>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Element>) elementList1, elementArray0);
        org.jsoup.parser.ParseError[] parseErrorArray3 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList4 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList4, parseErrorArray3);
        int int6 = parseErrorList4.size();
        org.jsoup.parser.ParseError[] parseErrorArray7 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList8 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean9 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList8, parseErrorArray7);
        int int10 = parseErrorList8.size();
        org.jsoup.parser.ParseError[] parseErrorArray11 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList12 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean13 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList12, parseErrorArray11);
        int int14 = parseErrorList12.size();
        java.util.List[] listArray16 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.jsoup.parser.ParseError>[] parseErrorListArray17 = (java.util.List<org.jsoup.parser.ParseError>[]) listArray16;
        parseErrorListArray17[0] = parseErrorList4;
        parseErrorListArray17[1] = parseErrorList8;
        parseErrorListArray17[2] = parseErrorList12;
        java.util.List<org.jsoup.parser.ParseError>[] parseErrorListArray24 = elementList1.toArray(parseErrorListArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elementArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorListArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorListArray24);
    }
}

