import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest113.test114");
        org.jsoup.parser.ParseError[] parseErrorArray0 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList1 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList1, parseErrorArray0);
        org.jsoup.nodes.Node[] nodeArray3 = new org.jsoup.nodes.Node[] {};
        java.util.ArrayList<org.jsoup.nodes.Node> nodeList4 = new java.util.ArrayList<org.jsoup.nodes.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList4, nodeArray3);
        boolean boolean6 = parseErrorList1.removeAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList4);
        parseErrorList1.clear();
        org.jsoup.select.Evaluator.IsFirstOfType isFirstOfType8 = new org.jsoup.select.Evaluator.IsFirstOfType();
        org.jsoup.nodes.Document document11 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str12 = document11.tagName();
        java.io.InputStream inputStream13 = null;
        org.jsoup.parser.Parser parser16 = null;
        org.jsoup.nodes.Document document17 = org.jsoup.Jsoup.parse(inputStream13, "#root", "", parser16);
        boolean boolean18 = isFirstOfType8.matches((org.jsoup.nodes.Element) document11, (org.jsoup.nodes.Element) document17);
        java.util.List<org.jsoup.nodes.Node> nodeList19 = document11.childNodesCopy();
        boolean boolean20 = parseErrorList1.retainAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#root" + "'", str12.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }
}

