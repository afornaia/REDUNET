import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest36.test037");
        org.jsoup.select.Evaluator.AttributeWithValueNot attributeWithValueNot2 = new org.jsoup.select.Evaluator.AttributeWithValueNot("public", "public");
    }
}

