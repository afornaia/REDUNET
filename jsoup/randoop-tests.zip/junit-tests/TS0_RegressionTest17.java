import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest17.test018");
        org.jsoup.nodes.Document document2 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str3 = document2.tagName();
        org.jsoup.nodes.Document document7 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node8 = document7.shallowClone();
        org.jsoup.nodes.Document document11 = org.jsoup.Jsoup.parse("hi!", "");
        java.lang.String str12 = document11.tagName();
        java.io.InputStream inputStream13 = null;
        org.jsoup.parser.Parser parser16 = null;
        org.jsoup.nodes.Document document17 = org.jsoup.helper.DataUtil.load(inputStream13, "#root", "", parser16);
        org.jsoup.nodes.Document document20 = org.jsoup.Jsoup.parse("hi!", "");
        org.jsoup.nodes.Node node21 = document20.shallowClone();
        java.io.InputStream inputStream22 = null;
        org.jsoup.parser.Parser parser25 = null;
        org.jsoup.nodes.Document document26 = org.jsoup.helper.DataUtil.load(inputStream22, "#root", "", parser25);
        java.io.InputStream inputStream27 = null;
        org.jsoup.parser.Parser parser30 = null;
        org.jsoup.nodes.Document document31 = org.jsoup.helper.DataUtil.load(inputStream27, "#root", "", parser30);
        org.jsoup.nodes.Node[] nodeArray32 = new org.jsoup.nodes.Node[] { node8, document11, document17, node21, document26, document31 };
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.nodes.Element element33 = document2.insertChildren(100, nodeArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Insert position out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "#root" + "'", str3.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "#root" + "'", str12.equals("#root"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(node21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray32);
    }
}

