import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest39.test040");
        org.jsoup.parser.ParseError[] parseErrorArray0 = new org.jsoup.parser.ParseError[] {};
        java.util.ArrayList<org.jsoup.parser.ParseError> parseErrorList1 = new java.util.ArrayList<org.jsoup.parser.ParseError>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.jsoup.parser.ParseError>) parseErrorList1, parseErrorArray0);
        org.jsoup.nodes.Node[] nodeArray3 = new org.jsoup.nodes.Node[] {};
        java.util.ArrayList<org.jsoup.nodes.Node> nodeList4 = new java.util.ArrayList<org.jsoup.nodes.Node>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList4, nodeArray3);
        boolean boolean6 = parseErrorList1.removeAll((java.util.Collection<org.jsoup.nodes.Node>) nodeList4);
        org.jsoup.parser.ParseError parseError8 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.jsoup.parser.ParseError parseError9 = parseErrorList1.set((int) (byte) 100, parseError8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(parseErrorArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }
}

