import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest97.test098");
        org.jsoup.nodes.Document document2 = org.jsoup.nodes.Document.createShell("");
        java.lang.String str3 = document2.location();
        org.jsoup.nodes.Element element4 = document2.root();
        org.jsoup.select.Elements elements6 = element4.getElementsByTag("hi!");
        org.jsoup.nodes.Element element7 = element4.clearAttributes();
        java.lang.String str8 = element7.toString();
        java.util.List<org.jsoup.nodes.Node> nodeList10 = org.jsoup.parser.Parser.parseFragment(" =\"PUBLIC\"", element7, "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(document2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(elements6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(element7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "<html>\n <head></head>\n <body></body>\n</html>" + "'", str8.equals("<html>\n <head></head>\n <body></body>\n</html>"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodeList10);
    }
}

