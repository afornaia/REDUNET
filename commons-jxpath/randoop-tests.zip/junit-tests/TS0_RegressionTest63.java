import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest63.test064");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer2 = null;
        org.apache.commons.beanutils.DynaBean dynaBean3 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer4 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer(nodePointer2, dynaBean3);
        boolean boolean6 = dynaBeanPropertyPointer4.equals((java.lang.Object) (byte) -1);
        org.apache.commons.jxpath.ri.QName qName8 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer9 = new org.apache.commons.jxpath.ri.model.beans.NullPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynaBeanPropertyPointer4, qName8);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = org.apache.commons.jxpath.ri.model.NodePointer.newNodePointer(qName1, (java.lang.Object) dynaBeanPropertyPointer4, locale10);
        org.apache.commons.beanutils.DynaBean dynaBean12 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer13 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynaBeanPropertyPointer4, dynaBean12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj14 = dynaBeanPropertyPointer13.getImmediateNode();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer11);
    }
}

