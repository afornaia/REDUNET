import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest99.test100");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = treeCompiler0.notEqual((java.lang.Object) 100, (java.lang.Object) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.apache.commons.jxpath.ri.compiler.Expression");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
    }
}

