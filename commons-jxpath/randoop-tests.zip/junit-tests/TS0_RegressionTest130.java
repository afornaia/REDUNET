import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest130.test131");
        javax.servlet.jsp.PageContext pageContext0 = null;
        org.apache.commons.jxpath.servlet.PageScopeContext pageScopeContext1 = new org.apache.commons.jxpath.servlet.PageScopeContext(pageContext0);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = null;
        org.apache.commons.beanutils.DynaBean dynaBean4 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer5 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer(nodePointer3, dynaBean4);
        boolean boolean7 = dynaBeanPropertyPointer5.equals((java.lang.Object) (byte) -1);
        org.apache.commons.jxpath.ri.QName qName9 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer10 = new org.apache.commons.jxpath.ri.model.beans.NullPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynaBeanPropertyPointer5, qName9);
        // The following exception was thrown during execution in test generation
        try {
            pageScopeContext1.setAttribute("or", (java.lang.Object) nullPointer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

