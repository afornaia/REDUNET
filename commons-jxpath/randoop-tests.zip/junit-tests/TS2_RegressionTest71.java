import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest71.test072");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer2 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest3 = null;
        boolean boolean4 = dOMNodePointer2.testNode(nodeTest3);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo5 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer beanPropertyPointer6 = new org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer2, jXPathBeanInfo5);
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = beanPropertyPointer6.createPath(jXPathContext7, (java.lang.Object) 11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}

