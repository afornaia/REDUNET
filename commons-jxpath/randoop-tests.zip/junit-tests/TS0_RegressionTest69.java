import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest69.test070");
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) 1L);
        org.apache.commons.jxpath.ri.QName qName4 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = null;
        org.apache.commons.beanutils.DynaBean dynaBean6 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer7 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer(nodePointer5, dynaBean6);
        boolean boolean9 = dynaBeanPropertyPointer7.equals((java.lang.Object) (byte) -1);
        org.apache.commons.jxpath.ri.QName qName11 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer12 = new org.apache.commons.jxpath.ri.model.beans.NullPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynaBeanPropertyPointer7, qName11);
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = org.apache.commons.jxpath.ri.model.NodePointer.newNodePointer(qName4, (java.lang.Object) dynaBeanPropertyPointer7, locale13);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl15 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext1, (java.lang.Object) 'a', (org.apache.commons.jxpath.Pointer) dynaBeanPropertyPointer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContext1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer14);
    }
}

