import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest137 {

    public static boolean debug = false;

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest137.test138");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        boolean boolean6 = namespacePointer4.isNode();
        int int7 = namespacePointer4.getLength();
        org.w3c.dom.Attr attr8 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMAttributePointer dOMAttributePointer9 = new org.apache.commons.jxpath.ri.model.dom.DOMAttributePointer((org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer4, attr8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }
}

