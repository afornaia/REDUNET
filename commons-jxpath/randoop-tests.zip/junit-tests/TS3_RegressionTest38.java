import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest38.test039");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.util.Locale locale4 = jXPathContextReferenceImpl3.getLocale();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = org.apache.commons.jxpath.util.ValueUtils.expandCollection((java.lang.Object) jXPathContextReferenceImpl3, 900);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn org.apache.commons.jxpath.ri.JXPathContextReferenceImpl into a collection of size 900");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale4.toString(), "en_US");
    }
}

