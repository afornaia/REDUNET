import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest40.test041");
        org.apache.commons.jxpath.ri.parser.Token token0 = new org.apache.commons.jxpath.ri.parser.Token();
        org.apache.commons.jxpath.ri.parser.Token token1 = token0.specialToken;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = token1.image;
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(token1);
    }
}

