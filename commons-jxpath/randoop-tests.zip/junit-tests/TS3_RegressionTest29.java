import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest29.test030");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl.addNodePointerFactory((org.apache.commons.jxpath.ri.model.NodePointerFactory) strictLazyDynaBeanPointerFactory0);
    }
}

