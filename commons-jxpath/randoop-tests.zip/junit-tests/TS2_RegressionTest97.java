import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest97.test098");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName5, locale6);
        boolean boolean8 = nullPointer7.isActual();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }
}

