import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest89.test090");
        org.apache.commons.jxpath.MapDynamicPropertyHandler mapDynamicPropertyHandler0 = new org.apache.commons.jxpath.MapDynamicPropertyHandler();
        org.apache.commons.jxpath.xml.DOMParser dOMParser1 = new org.apache.commons.jxpath.xml.DOMParser();
        boolean boolean2 = org.apache.commons.jxpath.util.ValueUtils.isCollection((java.lang.Object) dOMParser1);
        boolean boolean3 = dOMParser1.isNamespaceAware();
        dOMParser1.setIgnoringComments(false);
        java.lang.Object obj7 = null;
        // The following exception was thrown during execution in test generation
        try {
            mapDynamicPropertyHandler0.setProperty((java.lang.Object) false, "", obj7);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Boolean cannot be cast to java.util.Map");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

