import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest55.test056");
        org.apache.commons.jxpath.ri.QName qName0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray1 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction2 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName0, expressionArray1);
        org.apache.commons.jxpath.ri.QName qName3 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray4 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction5 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName3, expressionArray4);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod6 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction2, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction5);
        java.lang.String str7 = coreOperationMod6.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null() mod null()" + "'", str7.equals("null() mod null()"));
    }
}

