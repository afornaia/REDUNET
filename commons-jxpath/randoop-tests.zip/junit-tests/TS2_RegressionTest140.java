import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest140 {

    public static boolean debug = false;

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest140.test141");
        int int0 = org.apache.commons.jxpath.ri.parser.XPathParserConstants.UnicodeDigit;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 25 + "'", int0 == 25);
    }
}

