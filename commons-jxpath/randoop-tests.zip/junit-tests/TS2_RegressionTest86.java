import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest86.test087");
        java.lang.Number number1 = org.apache.commons.jxpath.ri.InfoSetUtil.number((java.lang.Object) "page");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
    }
}

