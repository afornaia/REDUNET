import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest3.test004");
        org.apache.commons.jxpath.JXPathContextFactory jXPathContextFactory0 = org.apache.commons.jxpath.JXPathContextFactory.newInstance();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContextFactory0);
    }
}

