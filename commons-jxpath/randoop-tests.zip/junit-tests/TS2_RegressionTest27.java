import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest27.test028");
        org.apache.commons.jxpath.MapDynamicPropertyHandler mapDynamicPropertyHandler0 = new org.apache.commons.jxpath.MapDynamicPropertyHandler();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = mapDynamicPropertyHandler0.getProperty((java.lang.Object) ' ', "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Character cannot be cast to java.util.Map");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
    }
}

