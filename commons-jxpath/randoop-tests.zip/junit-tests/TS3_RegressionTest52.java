import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest52.test053");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj2 = treeCompiler0.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName4 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray5 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction6 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName4, expressionArray5);
        java.lang.Object obj7 = treeCompiler0.locationPath(false, (java.lang.Object[]) expressionArray5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj9 = treeCompiler0.variableReference((java.lang.Object) 17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.apache.commons.jxpath.ri.QName");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj2.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj7.toString(), "");
    }
}

