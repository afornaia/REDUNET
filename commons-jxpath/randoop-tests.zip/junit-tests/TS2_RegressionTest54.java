import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest54.test055");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName5, locale6);
        org.w3c.dom.Node node8 = null;
        java.util.Locale locale9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer10 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node8, locale9);
        java.lang.Object obj11 = dOMNodePointer10.getImmediateNode();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = null;
        org.jdom.Attribute attribute13 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer14 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer12, attribute13);
        org.apache.commons.jxpath.JXPathContext jXPathContext15 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = jDOMAttributePointer14.createPath(jXPathContext15);
        // The following exception was thrown during execution in test generation
        try {
            int int17 = nullPointer7.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer10, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMAttributePointer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer16);
    }
}

