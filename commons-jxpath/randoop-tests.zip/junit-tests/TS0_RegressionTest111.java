import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest111.test112");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext2 = new org.apache.commons.jxpath.ri.axes.NamespaceContext(evalContext0, nodeTest1);
        boolean boolean4 = namespaceContext2.setPosition(100);
        org.apache.commons.jxpath.ri.compiler.Expression expression5 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression6 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod7 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression5, expression6);
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression9 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod10 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression8, expression9);
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression12 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression11, expression12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.Expression expression17 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression18 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod19 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression17, expression18);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray20 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression5, expression9, expression11, expression14, coreOperationMod19 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr21 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray20);
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext22 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) namespaceContext2, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationOr21);
        boolean boolean23 = predicateContext22.nextNode();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.NodeSet nodeSet24 = predicateContext22.getNodeSet();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }
}

