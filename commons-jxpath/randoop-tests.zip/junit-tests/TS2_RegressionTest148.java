import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest148 {

    public static boolean debug = false;

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest148.test149");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray6 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction7 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName5, expressionArray6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = null;
        org.jdom.Attribute attribute9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer8, attribute9);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer12 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer8, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = namespacePointer12.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray14 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction15 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName13, expressionArray14);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply coreOperationMultiply16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction7, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction15);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = null;
        org.jdom.Attribute attribute18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer17, attribute18);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer21 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer17, "hi!");
        org.apache.commons.jxpath.ri.QName qName22 = namespacePointer21.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray23 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction24 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName22, expressionArray23);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = null;
        org.jdom.Attribute attribute26 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer27 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer25, attribute26);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer29 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer25, "hi!");
        org.apache.commons.jxpath.ri.QName qName30 = namespacePointer29.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray31 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction32 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName30, expressionArray31);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply coreOperationMultiply33 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction24, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction32);
        org.apache.commons.jxpath.ri.compiler.CoreOperationEqual coreOperationEqual34 = new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction15, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray31);
    }
}

