import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest104.test105");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer2 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1);
        java.lang.Object obj3 = dOMNodePointer2.getImmediateNode();
        org.w3c.dom.Node node4 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer5 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer2, node4);
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory6 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        org.apache.commons.jxpath.ri.QName qName8 = new org.apache.commons.jxpath.ri.QName("hi!");
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer11 = strictLazyDynaBeanPointerFactory6.createNodePointer(qName8, (java.lang.Object) 10.0d, locale10);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator12 = dOMNodePointer5.attributeIterator(qName8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodePointer11);
    }
}

