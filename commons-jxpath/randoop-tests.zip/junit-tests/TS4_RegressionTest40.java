import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest40.test041");
        org.apache.commons.jxpath.ri.compiler.Expression expression0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression1 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod2 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression0, expression1);
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression4 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod5 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression3, expression4);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual6 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression1, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod5);
        org.apache.commons.jxpath.ri.compiler.Expression expression7 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod9 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression7, expression8);
        org.apache.commons.jxpath.ri.compiler.Expression expression10 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod12 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression10, expression11);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression8, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest17 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual13, expression14);
        org.apache.commons.jxpath.ri.compiler.Expression expression18 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression19 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod20 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression18, expression19);
        org.apache.commons.jxpath.ri.compiler.Expression expression21 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression22 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod23 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression21, expression22);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual24 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression19, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod23);
        org.apache.commons.jxpath.ri.compiler.CoreOperationEqual coreOperationEqual25 = new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual(expression14, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod23);
        org.apache.commons.jxpath.ri.compiler.Expression expression26 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression27 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod28 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression26, expression27);
        org.apache.commons.jxpath.ri.compiler.Expression expression29 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression30 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod31 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression29, expression30);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual32 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression27, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod31);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual33 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationEqual25, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual32);
        org.apache.commons.jxpath.ri.compiler.Expression expression34 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression35 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod36 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression34, expression35);
        org.apache.commons.jxpath.ri.compiler.Expression expression37 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression38 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod39 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression37, expression38);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual40 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression35, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod39);
        org.apache.commons.jxpath.ri.compiler.CoreOperationDivide coreOperationDivide41 = new org.apache.commons.jxpath.ri.compiler.CoreOperationDivide((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual32, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod39);
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest42 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest(expression1, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual32);
    }
}

