import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest136 {

    public static boolean debug = false;

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest136.test137");
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) 1L);
        jXPathContext1.setLenient(false);
        org.apache.commons.jxpath.IdentityManager identityManager4 = null;
        jXPathContext1.setIdentityManager(identityManager4);
        jXPathContext1.setLenient(true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContext1);
    }
}

