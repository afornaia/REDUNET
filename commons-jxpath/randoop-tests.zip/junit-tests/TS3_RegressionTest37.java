import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest37.test038");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.util.Locale locale4 = jXPathContextReferenceImpl3.getLocale();
        org.apache.commons.jxpath.ExceptionHandler exceptionHandler5 = null;
        jXPathContextReferenceImpl3.setExceptionHandler(exceptionHandler5);
        // The following exception was thrown during execution in test generation
        try {
            java.util.List list8 = jXPathContextReferenceImpl3.selectNodes("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathInvalidSyntaxException; message: Invalid XPath: 'hi!'. Invalid symbol '!' - expression incomplete");
        } catch (org.apache.commons.jxpath.JXPathInvalidSyntaxException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale4.toString(), "en_US");
    }
}

