import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest54.test055");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext2 = new org.apache.commons.jxpath.ri.axes.ParentContext(evalContext0, nodeTest1);
        // The following exception was thrown during execution in test generation
        try {
            parentContext2.remove();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: JXPath iterators cannot remove nodes");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
    }
}

