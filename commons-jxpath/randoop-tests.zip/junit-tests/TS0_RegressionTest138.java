import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest138 {

    public static boolean debug = false;

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest138.test139");
        java.lang.String str0 = org.apache.commons.jxpath.servlet.Constants.JXPATH_CONTEXT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "org.apache.commons.jxpath.JXPATH_CONTEXT" + "'", str0.equals("org.apache.commons.jxpath.JXPATH_CONTEXT"));
    }
}

