import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest131 {

    public static boolean debug = false;

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest131.test132");
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler0 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj1 = null;
        java.lang.Object obj2 = treeCompiler0.variableReference(obj1);
        java.lang.Object obj4 = treeCompiler0.nodeTypeTest(70);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj2.toString(), "$null");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj4.toString(), "UNKNOWN()");
    }
}

