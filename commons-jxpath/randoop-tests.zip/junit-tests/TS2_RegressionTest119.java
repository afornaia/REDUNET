import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest119.test120");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray6 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction7 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName5, expressionArray6);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer8 = null;
        org.jdom.Attribute attribute9 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer10 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer8, attribute9);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer12 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer8, "hi!");
        org.apache.commons.jxpath.ri.QName qName13 = namespacePointer12.getName();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray14 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction15 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName13, expressionArray14);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply coreOperationMultiply16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMultiply((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction7, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction15);
        java.lang.String str17 = extensionFunction7.toString();
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray18 = extensionFunction7.getArguments();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hi!()" + "'", str17.equals("hi!()"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray18);
    }
}

