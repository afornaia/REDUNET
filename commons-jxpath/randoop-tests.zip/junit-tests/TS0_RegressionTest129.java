import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest129 {

    public static boolean debug = false;

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest129.test130");
        org.apache.commons.jxpath.JXPathException jXPathException0 = new org.apache.commons.jxpath.JXPathException();
    }
}

