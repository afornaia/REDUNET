import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest81.test082");
        org.apache.commons.jxpath.servlet.KeywordVariables keywordVariables2 = new org.apache.commons.jxpath.servlet.KeywordVariables("<<unknown namespace>>", (java.lang.Object) 0L);
    }
}

