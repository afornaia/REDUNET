import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest10.test011");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler1 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer dynamicPropertyPointer2 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer(nodePointer0, dynamicPropertyHandler1);
        boolean boolean3 = dynamicPropertyPointer2.isContainer();
        org.apache.commons.jxpath.JXPathContext jXPathContext4 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer6 = dynamicPropertyPointer2.createPath(jXPathContext4, (java.lang.Object) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

