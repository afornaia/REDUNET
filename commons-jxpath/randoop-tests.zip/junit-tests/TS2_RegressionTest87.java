import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest87.test088");
        org.w3c.dom.Node node0 = null;
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer2 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale1);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest3 = null;
        boolean boolean4 = dOMNodePointer2.testNode(nodeTest3);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo5 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer beanPropertyPointer6 = new org.apache.commons.jxpath.ri.model.beans.BeanPropertyPointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer2, jXPathBeanInfo5);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest7 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = null;
        org.jdom.Attribute attribute10 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer11 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer9, attribute10);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer13 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer9, "hi!");
        org.apache.commons.jxpath.ri.QName qName14 = namespacePointer13.getName();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator15 = dOMNodePointer2.childIterator(nodeTest7, true, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName14);
    }
}

