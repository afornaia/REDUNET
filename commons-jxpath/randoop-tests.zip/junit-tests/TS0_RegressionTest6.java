import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest6.test007");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) ' ', locale1, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespacePointer jDOMNamespacePointer6 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespacePointer(nodePointer4, "hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer7 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespacePointer jDOMNamespacePointer9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespacePointer(nodePointer7, "hi!");
        // The following exception was thrown during execution in test generation
        try {
            int int10 = jDOMNodePointer3.compareChildNodePointers((org.apache.commons.jxpath.ri.model.NodePointer) jDOMNamespacePointer6, nodePointer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

