import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest139 {

    public static boolean debug = false;

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest139.test140");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer2 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale1);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer2);
        boolean boolean4 = collectionPointer2.isAttribute();
        org.apache.commons.jxpath.JXPathContext jXPathContext5 = null;
        org.apache.commons.jxpath.Pointer pointer7 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl8 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext5, (java.lang.Object) 1, pointer7);
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler11 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj13 = treeCompiler11.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName15 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray16 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction17 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName15, expressionArray16);
        java.lang.Object obj18 = treeCompiler11.locationPath(false, (java.lang.Object[]) expressionArray16);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = collectionPointer2.createChild(jXPathContext5, qName9, (int) (byte) 0, obj18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj13.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj18.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer19);
    }
}

