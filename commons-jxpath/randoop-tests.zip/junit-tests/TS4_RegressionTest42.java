import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest42.test043");
        org.apache.commons.jxpath.ri.compiler.Expression expression0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression1 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod2 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression0, expression1);
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression4 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod5 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression3, expression4);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual6 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression1, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod5);
        org.apache.commons.jxpath.ri.compiler.Expression expression7 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod9 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression7, expression8);
        org.apache.commons.jxpath.ri.compiler.NameAttributeTest nameAttributeTest10 = new org.apache.commons.jxpath.ri.compiler.NameAttributeTest((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual6, expression7);
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression12 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression11, expression12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual17 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression12, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod16);
        org.apache.commons.jxpath.ri.compiler.CoreOperationEqual coreOperationEqual18 = new org.apache.commons.jxpath.ri.compiler.CoreOperationEqual(expression7, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod16);
        org.apache.commons.jxpath.ri.compiler.Expression expression19 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression20 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod21 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression19, expression20);
        org.apache.commons.jxpath.ri.compiler.Expression expression22 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression23 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod24 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression22, expression23);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual25 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression20, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod24);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual26 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationEqual18, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationLessThanOrEqual25);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str27 = coreOperationLessThanOrEqual25.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

