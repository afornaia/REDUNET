import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest111.test112");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext2 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext0, nodeTest1);
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext4 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext2, expression3);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = null;
        org.jdom.Attribute attribute6 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer7 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer5, attribute6);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer9 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer5, "hi!");
        org.apache.commons.jxpath.ri.QName qName10 = namespacePointer9.getName();
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray12 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression11 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationUnion coreOperationUnion13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationUnion(expressionArray12);
        org.apache.commons.jxpath.ri.compiler.Step[] stepArray15 = new org.apache.commons.jxpath.ri.compiler.Step[] {};
        org.apache.commons.jxpath.ri.compiler.LocationPath locationPath16 = new org.apache.commons.jxpath.ri.compiler.LocationPath(true, stepArray15);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = org.apache.commons.jxpath.ri.axes.SimplePathInterpreter.interpretSimpleExpressionPath((org.apache.commons.jxpath.ri.EvalContext) attributeContext2, (org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer9, expressionArray12, stepArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stepArray15);
    }
}

