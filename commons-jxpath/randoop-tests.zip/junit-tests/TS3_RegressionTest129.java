import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest129 {

    public static boolean debug = false;

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest129.test130");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.lang.Object obj4 = jXPathContextReferenceImpl3.getContextBean();
        java.util.Locale locale5 = jXPathContextReferenceImpl3.getLocale();
        java.util.Locale locale7 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer8 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale7);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator9 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8);
        org.w3c.dom.Node node10 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer11 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer8, node10);
        java.lang.String str13 = dOMNodePointer11.getNamespaceURI("org.apache.commons.jxpath.JXPathContextFactory");
        org.apache.commons.jxpath.ri.axes.RootContext rootContext14 = new org.apache.commons.jxpath.ri.axes.RootContext(jXPathContextReferenceImpl3, (org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer11);
        java.lang.String str16 = dOMNodePointer11.getNamespaceURI("org.apache.commons.jxpath.JXPathInvalidAccessException: ");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1 + "'", obj4.equals(1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale5.toString(), "en_US");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str16);
    }
}

