import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest92.test093");
        org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory beanPointerFactory0 = new org.apache.commons.jxpath.ri.model.beans.BeanPointerFactory();
        org.apache.commons.jxpath.ri.QName qName2 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer3 = null;
        org.jdom.Attribute attribute4 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer3, attribute4);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer7 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer3, "hi!");
        java.util.Locale locale8 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = beanPointerFactory0.createNodePointer(qName2, (java.lang.Object) "hi!", locale8);
        int int10 = beanPointerFactory0.getOrder();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 900 + "'", int10 == 900);
    }
}

