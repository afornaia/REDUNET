import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest108.test109");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        boolean boolean6 = namespacePointer4.isNode();
        boolean boolean7 = namespacePointer4.isCollection();
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.parser.Token token9 = new org.apache.commons.jxpath.ri.parser.Token();
        token9.kind = 20;
        org.apache.commons.jxpath.MapDynamicPropertyHandler mapDynamicPropertyHandler12 = new org.apache.commons.jxpath.MapDynamicPropertyHandler();
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer13 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer4, qName8, (java.lang.Object) 20, (org.apache.commons.jxpath.DynamicPropertyHandler) mapDynamicPropertyHandler12);
        int int14 = dynamicPointer13.getLength();
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest15 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = null;
        org.jdom.Attribute attribute18 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer19 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer17, attribute18);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer21 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer17, "hi!");
        org.apache.commons.jxpath.ri.QName qName22 = namespacePointer21.getName();
        boolean boolean23 = namespacePointer21.isNode();
        boolean boolean24 = namespacePointer21.isCollection();
        org.apache.commons.jxpath.ri.QName qName25 = null;
        org.apache.commons.jxpath.ri.parser.Token token26 = new org.apache.commons.jxpath.ri.parser.Token();
        token26.kind = 20;
        org.apache.commons.jxpath.MapDynamicPropertyHandler mapDynamicPropertyHandler29 = new org.apache.commons.jxpath.MapDynamicPropertyHandler();
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer30 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer((org.apache.commons.jxpath.ri.model.NodePointer) namespacePointer21, qName25, (java.lang.Object) 20, (org.apache.commons.jxpath.DynamicPropertyHandler) mapDynamicPropertyHandler29);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator dOMNodeIterator31 = new org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPointer13, nodeTest15, false, (org.apache.commons.jxpath.ri.model.NodePointer) dynamicPointer30);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Integer cannot be cast to org.w3c.dom.Node");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }
}

