import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest21.test022");
        org.apache.commons.jxpath.ri.compiler.Expression expression0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression1 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod2 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression0, expression1);
        org.apache.commons.jxpath.ri.QName qName4 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.compiler.Expression expression5 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression6 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod7 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression5, expression6);
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression9 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod10 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression8, expression9);
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression12 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression11, expression12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.Expression expression17 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression18 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod19 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression17, expression18);
        org.apache.commons.jxpath.ri.compiler.Expression expression20 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression21 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod22 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression20, expression21);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray23 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression8, expression12, expression14, expression17, coreOperationMod22 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr24 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray23);
        org.apache.commons.jxpath.ri.compiler.Expression expression25 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression26 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod27 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression25, expression26);
        org.apache.commons.jxpath.ri.compiler.Expression expression28 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression29 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod30 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression28, expression29);
        org.apache.commons.jxpath.ri.compiler.Expression expression31 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression32 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod33 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression31, expression32);
        org.apache.commons.jxpath.ri.compiler.Expression expression34 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression35 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod36 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression34, expression35);
        org.apache.commons.jxpath.ri.compiler.Expression expression37 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression38 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod39 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression37, expression38);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray40 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression25, expression29, expression31, expression34, coreOperationMod39 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr41 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray40);
        org.apache.commons.jxpath.ri.compiler.Expression expression42 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression43 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod44 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression42, expression43);
        org.apache.commons.jxpath.ri.compiler.Expression expression45 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression46 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod47 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression45, expression46);
        org.apache.commons.jxpath.ri.compiler.Expression expression48 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression49 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod50 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression48, expression49);
        org.apache.commons.jxpath.ri.compiler.Expression expression51 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression52 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod53 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression51, expression52);
        org.apache.commons.jxpath.ri.compiler.Expression expression54 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression55 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod56 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression54, expression55);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray57 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression42, expression46, expression48, expression51, coreOperationMod56 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr58 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray57);
        org.apache.commons.jxpath.ri.compiler.Expression expression59 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression60 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod61 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression59, expression60);
        org.apache.commons.jxpath.ri.compiler.Expression expression62 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression63 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod64 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression62, expression63);
        org.apache.commons.jxpath.ri.compiler.Expression expression65 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression66 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod67 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression65, expression66);
        org.apache.commons.jxpath.ri.compiler.Expression expression68 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression69 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod70 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression68, expression69);
        org.apache.commons.jxpath.ri.compiler.Expression expression71 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression72 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod73 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression71, expression72);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray74 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression59, expression63, expression65, expression68, coreOperationMod73 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr75 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray74);
        org.apache.commons.jxpath.ri.compiler.Expression expression76 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression77 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod78 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression76, expression77);
        org.apache.commons.jxpath.ri.compiler.Expression expression79 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression80 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod81 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression79, expression80);
        org.apache.commons.jxpath.ri.compiler.Expression expression82 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression83 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod84 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression82, expression83);
        org.apache.commons.jxpath.ri.compiler.Expression expression85 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression86 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod87 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression85, expression86);
        org.apache.commons.jxpath.ri.compiler.Expression expression88 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression89 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod90 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression88, expression89);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray91 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression76, expression80, expression82, expression85, coreOperationMod90 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr92 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray91);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray93 = new org.apache.commons.jxpath.ri.compiler.Expression[] { coreOperationMod7, coreOperationOr24, coreOperationOr41, coreOperationOr58, coreOperationOr75, coreOperationOr92 };
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction94 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName4, expressionArray93);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThan coreOperationLessThan95 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThan(expression0, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction94);
        boolean boolean96 = extensionFunction94.computeContextDependent();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray57);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray74);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray91);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray93);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
    }
}

