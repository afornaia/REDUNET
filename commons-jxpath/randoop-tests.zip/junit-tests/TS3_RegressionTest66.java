import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest66.test067");
        org.apache.commons.jxpath.servlet.ServletContextHandler servletContextHandler0 = new org.apache.commons.jxpath.servlet.ServletContextHandler();
    }
}

