import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest29.test030");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler1 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer dynamicPropertyPointer2 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer(nodePointer0, dynamicPropertyHandler1);
        org.jdom.Attribute attribute3 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPropertyPointer2, attribute3);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = jDOMAttributePointer4.getValue();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

