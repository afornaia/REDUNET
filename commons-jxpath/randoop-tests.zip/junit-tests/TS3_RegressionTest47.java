import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest47.test048");
        org.apache.commons.jxpath.ri.axes.SimplePathInterpreter simplePathInterpreter0 = new org.apache.commons.jxpath.ri.axes.SimplePathInterpreter();
    }
}

