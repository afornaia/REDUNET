import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest28.test029");
        int int0 = org.apache.commons.jxpath.ri.Compiler.NODE_TYPE_TEXT;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }
}

