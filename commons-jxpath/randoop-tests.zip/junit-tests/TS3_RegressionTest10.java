import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest10.test011");
        java.lang.Number number1 = org.apache.commons.jxpath.ri.InfoSetUtil.number((java.lang.Object) (byte) -1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + number1 + "' != '" + (byte) -1 + "'", number1.equals((byte) -1));
    }
}

