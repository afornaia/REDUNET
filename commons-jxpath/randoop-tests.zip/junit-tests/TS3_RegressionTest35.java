import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest35.test036");
        org.apache.commons.jxpath.ri.QName qName0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray1 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction2 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName0, expressionArray1);
        org.apache.commons.jxpath.ri.EvalContext evalContext3 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest5 = null;
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext6 = new org.apache.commons.jxpath.ri.axes.AncestorContext(evalContext3, false, nodeTest5);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest8 = null;
        org.apache.commons.jxpath.ri.axes.DescendantContext descendantContext9 = new org.apache.commons.jxpath.ri.axes.DescendantContext(evalContext3, true, nodeTest8);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Iterator iterator10 = extensionFunction2.iterate((org.apache.commons.jxpath.ri.EvalContext) descendantContext9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray1);
    }
}

