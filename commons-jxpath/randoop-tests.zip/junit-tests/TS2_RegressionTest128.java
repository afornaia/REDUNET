import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest128 {

    public static boolean debug = false;

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest128.test129");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        boolean boolean6 = namespacePointer4.isNode();
        boolean boolean7 = namespacePointer4.isCollection();
        boolean boolean8 = namespacePointer4.isAttribute();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }
}

