import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest121 {

    public static boolean debug = false;

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest121.test122");
        org.apache.commons.jxpath.xml.DOMParser dOMParser0 = new org.apache.commons.jxpath.xml.DOMParser();
    }
}

