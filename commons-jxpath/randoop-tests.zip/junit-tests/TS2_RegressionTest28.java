import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest28.test029");
        java.lang.Class class0 = null;
        org.apache.commons.jxpath.ClassFunctions classFunctions2 = new org.apache.commons.jxpath.ClassFunctions(class0, "hi!");
        java.lang.String str3 = org.apache.commons.jxpath.ri.InfoSetUtil.stringValue((java.lang.Object) classFunctions2);
    }
}

