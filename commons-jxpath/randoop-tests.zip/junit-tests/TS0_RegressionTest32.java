import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest32.test033");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.beanutils.DynaBean dynaBean1 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer2 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer(nodePointer0, dynaBean1);
        boolean boolean4 = dynaBeanPropertyPointer2.equals((java.lang.Object) (byte) -1);
        org.apache.commons.jxpath.JXPathContext jXPathContext5 = null;
        org.apache.commons.jxpath.ri.QName qName7 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression9 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod10 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression8, expression9);
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression12 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression11, expression12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.Expression expression17 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression18 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod19 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression17, expression18);
        org.apache.commons.jxpath.ri.compiler.Expression expression20 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression21 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod22 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression20, expression21);
        org.apache.commons.jxpath.ri.compiler.Expression expression23 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression24 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod25 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression23, expression24);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray26 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression11, expression15, expression17, expression20, coreOperationMod25 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr27 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray26);
        org.apache.commons.jxpath.ri.compiler.Expression expression28 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression29 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod30 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression28, expression29);
        org.apache.commons.jxpath.ri.compiler.Expression expression31 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression32 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod33 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression31, expression32);
        org.apache.commons.jxpath.ri.compiler.Expression expression34 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression35 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod36 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression34, expression35);
        org.apache.commons.jxpath.ri.compiler.Expression expression37 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression38 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod39 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression37, expression38);
        org.apache.commons.jxpath.ri.compiler.Expression expression40 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression41 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod42 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression40, expression41);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray43 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression28, expression32, expression34, expression37, coreOperationMod42 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr44 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray43);
        org.apache.commons.jxpath.ri.compiler.Expression expression45 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression46 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod47 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression45, expression46);
        org.apache.commons.jxpath.ri.compiler.Expression expression48 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression49 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod50 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression48, expression49);
        org.apache.commons.jxpath.ri.compiler.Expression expression51 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression52 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod53 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression51, expression52);
        org.apache.commons.jxpath.ri.compiler.Expression expression54 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression55 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod56 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression54, expression55);
        org.apache.commons.jxpath.ri.compiler.Expression expression57 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression58 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod59 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression57, expression58);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray60 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression45, expression49, expression51, expression54, coreOperationMod59 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr61 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray60);
        org.apache.commons.jxpath.ri.compiler.Expression expression62 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression63 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod64 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression62, expression63);
        org.apache.commons.jxpath.ri.compiler.Expression expression65 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression66 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod67 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression65, expression66);
        org.apache.commons.jxpath.ri.compiler.Expression expression68 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression69 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod70 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression68, expression69);
        org.apache.commons.jxpath.ri.compiler.Expression expression71 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression72 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod73 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression71, expression72);
        org.apache.commons.jxpath.ri.compiler.Expression expression74 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression75 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod76 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression74, expression75);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray77 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression62, expression66, expression68, expression71, coreOperationMod76 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr78 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray77);
        org.apache.commons.jxpath.ri.compiler.Expression expression79 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression80 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod81 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression79, expression80);
        org.apache.commons.jxpath.ri.compiler.Expression expression82 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression83 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod84 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression82, expression83);
        org.apache.commons.jxpath.ri.compiler.Expression expression85 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression86 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod87 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression85, expression86);
        org.apache.commons.jxpath.ri.compiler.Expression expression88 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression89 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod90 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression88, expression89);
        org.apache.commons.jxpath.ri.compiler.Expression expression91 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression92 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod93 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression91, expression92);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray94 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression79, expression83, expression85, expression88, coreOperationMod93 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr95 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray94);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray96 = new org.apache.commons.jxpath.ri.compiler.Expression[] { coreOperationMod10, coreOperationOr27, coreOperationOr44, coreOperationOr61, coreOperationOr78, coreOperationOr95 };
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction97 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName7, expressionArray96);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer99 = dynaBeanPropertyPointer2.createChild(jXPathContext5, qName7, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray60);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray77);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray94);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray96);
    }
}

