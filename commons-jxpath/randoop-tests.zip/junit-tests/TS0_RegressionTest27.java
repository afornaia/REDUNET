import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest27.test028");
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver0 = new org.apache.commons.jxpath.ri.NamespaceResolver();
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver1 = new org.apache.commons.jxpath.ri.NamespaceResolver(namespaceResolver0);
    }
}

