import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest120 {

    public static boolean debug = false;

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest120.test121");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext3 = new org.apache.commons.jxpath.ri.axes.AncestorContext(evalContext0, false, nodeTest2);
        ancestorContext3.reset();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj6 = org.apache.commons.jxpath.util.ValueUtils.remove((java.lang.Object) ancestorContext3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot remove org.apache.commons.jxpath.ri.axes.AncestorContext[0]");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
    }
}

