import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest116.test117");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName5, locale6);
        org.w3c.dom.Node node10 = null;
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer12 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node10, locale11);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest13 = null;
        boolean boolean14 = dOMNodePointer12.testNode(nodeTest13);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator15 = nullPointer7.createNodeIterator("1", true, (org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: PropertyIerator startWith parameter is not a child of the supplied parent");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }
}

