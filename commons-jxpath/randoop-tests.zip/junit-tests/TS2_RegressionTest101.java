import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest101.test102");
        org.apache.commons.jxpath.ri.axes.SimplePathInterpreter simplePathInterpreter0 = new org.apache.commons.jxpath.ri.axes.SimplePathInterpreter();
    }
}

