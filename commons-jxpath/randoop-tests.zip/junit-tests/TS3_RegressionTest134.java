import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest134 {

    public static boolean debug = false;

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest134.test135");
        org.apache.commons.jxpath.ri.QName qName0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray1 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction2 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName0, expressionArray1);
        org.apache.commons.jxpath.ri.QName qName3 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray4 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction5 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName3, expressionArray4);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod6 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction2, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction5);
        java.lang.String str7 = extensionFunction2.toString();
        org.apache.commons.jxpath.ri.compiler.CoreOperationNegate coreOperationNegate8 = new org.apache.commons.jxpath.ri.compiler.CoreOperationNegate((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction2);
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray10 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction11 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName9, expressionArray10);
        org.apache.commons.jxpath.ri.QName qName12 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray13 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction14 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName12, expressionArray13);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod15 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction11, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction14);
        java.lang.String str16 = extensionFunction11.toString();
        org.apache.commons.jxpath.ri.compiler.CoreOperationNegate coreOperationNegate17 = new org.apache.commons.jxpath.ri.compiler.CoreOperationNegate((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction11);
        org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual coreOperationNotEqual18 = new org.apache.commons.jxpath.ri.compiler.CoreOperationNotEqual((org.apache.commons.jxpath.ri.compiler.Expression) coreOperationNegate8, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction11);
        boolean boolean19 = extensionFunction11.computeContextDependent();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null()" + "'", str7.equals("null()"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "null()" + "'", str16.equals("null()"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }
}

