import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest46.test047");
        java.lang.Exception exception2 = null;
        org.apache.commons.jxpath.JXPathTypeConversionException jXPathTypeConversionException3 = new org.apache.commons.jxpath.JXPathTypeConversionException("hi!", exception2);
        org.apache.commons.jxpath.JXPathTypeConversionException jXPathTypeConversionException4 = new org.apache.commons.jxpath.JXPathTypeConversionException("hi!", exception2);
    }
}

