import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest104.test105");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext2 = new org.apache.commons.jxpath.ri.axes.NamespaceContext(evalContext0, nodeTest1);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator3 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) evalContext0);
        java.beans.PropertyDescriptor propertyDescriptor4 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.util.ValueUtils.setValue((java.lang.Object) evalContext0, propertyDescriptor4, 9, (java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

