import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest17.test018");
        java.net.URL uRL0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.xml.DocumentContainer documentContainer1 = new org.apache.commons.jxpath.xml.DocumentContainer(uRL0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: XML URL is null");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
    }
}

