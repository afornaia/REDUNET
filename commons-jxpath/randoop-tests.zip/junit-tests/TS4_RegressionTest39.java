import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest39.test040");
        org.apache.commons.jxpath.ri.compiler.Expression expression0 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression1 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod2 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression0, expression1);
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression4 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod5 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression3, expression4);
        org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual coreOperationLessThanOrEqual6 = new org.apache.commons.jxpath.ri.compiler.CoreOperationLessThanOrEqual(expression1, (org.apache.commons.jxpath.ri.compiler.Expression) coreOperationMod5);
        org.apache.commons.jxpath.ri.EvalContext evalContext7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Iterator iterator8 = coreOperationLessThanOrEqual6.iterate(evalContext7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

