import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest34.test035");
        javax.servlet.http.HttpSession httpSession0 = null;
        javax.servlet.ServletContext servletContext1 = null;
        org.apache.commons.jxpath.servlet.HttpSessionAndServletContext httpSessionAndServletContext2 = new org.apache.commons.jxpath.servlet.HttpSessionAndServletContext(httpSession0, servletContext1);
        javax.servlet.ServletContext servletContext3 = httpSessionAndServletContext2.getServletContext();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(servletContext3);
    }
}

