import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest43.test044");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "");
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale5, "");
        java.lang.Object obj8 = nullPointer7.getImmediateNode();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyIterator dynamicPropertyIterator9 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyIterator((org.apache.commons.jxpath.ri.model.beans.PropertyOwnerPointer) nullPointer2, "JDOM", true, (org.apache.commons.jxpath.ri.model.NodePointer) nullPointer7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: PropertyIerator startWith parameter is not a child of the supplied parent");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj8);
    }
}

