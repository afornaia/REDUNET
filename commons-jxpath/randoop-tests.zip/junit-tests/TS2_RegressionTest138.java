import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest138 {

    public static boolean debug = false;

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest138.test139");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.EvalContext evalContext1 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext3 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext1, nodeTest2);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest4 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext5 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext3, nodeTest4);
        org.apache.commons.jxpath.ri.EvalContext evalContext6 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest7 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext8 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext6, nodeTest7);
        org.apache.commons.jxpath.ri.compiler.Expression expression9 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext10 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext8, expression9);
        org.apache.commons.jxpath.ri.EvalContext evalContext11 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest12 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext13 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext11, nodeTest12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext15 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext13, expression14);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator16 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) attributeContext13);
        org.apache.commons.jxpath.ri.EvalContext evalContext17 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest18 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext19 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext17, nodeTest18);
        org.apache.commons.jxpath.ri.compiler.Expression expression20 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext21 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext19, expression20);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator22 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) attributeContext19);
        org.apache.commons.jxpath.ri.EvalContext evalContext23 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest24 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext25 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext23, nodeTest24);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest26 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext27 = new org.apache.commons.jxpath.ri.axes.AttributeContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext25, nodeTest26);
        org.apache.commons.jxpath.ri.EvalContext[] evalContextArray28 = new org.apache.commons.jxpath.ri.EvalContext[] { attributeContext5, attributeContext8, attributeContext13, attributeContext19, attributeContext27 };
        org.apache.commons.jxpath.ri.axes.UnionContext unionContext29 = new org.apache.commons.jxpath.ri.axes.UnionContext(evalContext0, evalContextArray28);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest30 = null;
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext31 = new org.apache.commons.jxpath.ri.axes.ParentContext((org.apache.commons.jxpath.ri.EvalContext) unionContext29, nodeTest30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(evalContextArray28);
    }
}

