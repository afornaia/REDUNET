import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest105.test106");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext3 = new org.apache.commons.jxpath.ri.axes.AncestorContext(evalContext0, false, nodeTest2);
        ancestorContext3.reset();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer7 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale6);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator8 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer7);
        org.w3c.dom.Node node9 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer10 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer7, node9);
        org.apache.commons.jxpath.ri.compiler.Step[] stepArray11 = new org.apache.commons.jxpath.ri.compiler.Step[] {};
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = org.apache.commons.jxpath.ri.axes.SimplePathInterpreter.interpretSimpleLocationPath((org.apache.commons.jxpath.ri.EvalContext) ancestorContext3, (org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer10, stepArray11);
        org.apache.commons.jxpath.JXPathContext jXPathContext13 = null;
        org.apache.commons.jxpath.Pointer pointer15 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl16 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext13, (java.lang.Object) 1, pointer15);
        java.lang.Object obj17 = jXPathContextReferenceImpl16.getContextBean();
        org.apache.commons.jxpath.ri.QName qName18 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer19 = nodePointer12.createAttribute((org.apache.commons.jxpath.JXPathContext) jXPathContextReferenceImpl16, qName18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stepArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + 1 + "'", obj17.equals(1));
    }
}

