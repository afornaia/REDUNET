import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest84.test085");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = null;
        org.apache.commons.jxpath.Pointer pointer3 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl4 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext1, (java.lang.Object) 1, pointer3);
        java.util.Locale locale5 = jXPathContextReferenceImpl4.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer7 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale5, "");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator8 = dOMNodePointer7.namespaceIterator();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale5.toString(), "en_US");
    }
}

