import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest134 {

    public static boolean debug = false;

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest134.test135");
        org.apache.commons.jxpath.ri.QName qName1 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.compiler.Expression expression2 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod4 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression2, expression3);
        org.apache.commons.jxpath.ri.compiler.Expression expression5 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression6 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod7 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression5, expression6);
        org.apache.commons.jxpath.ri.compiler.Expression expression8 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression9 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod10 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression8, expression9);
        org.apache.commons.jxpath.ri.compiler.Expression expression11 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression12 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod13 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression11, expression12);
        org.apache.commons.jxpath.ri.compiler.Expression expression14 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression15 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod16 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression14, expression15);
        org.apache.commons.jxpath.ri.compiler.Expression expression17 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression18 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod19 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression17, expression18);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray20 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression5, expression9, expression11, expression14, coreOperationMod19 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr21 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray20);
        org.apache.commons.jxpath.ri.compiler.Expression expression22 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression23 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod24 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression22, expression23);
        org.apache.commons.jxpath.ri.compiler.Expression expression25 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression26 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod27 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression25, expression26);
        org.apache.commons.jxpath.ri.compiler.Expression expression28 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression29 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod30 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression28, expression29);
        org.apache.commons.jxpath.ri.compiler.Expression expression31 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression32 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod33 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression31, expression32);
        org.apache.commons.jxpath.ri.compiler.Expression expression34 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression35 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod36 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression34, expression35);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray37 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression22, expression26, expression28, expression31, coreOperationMod36 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr38 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray37);
        org.apache.commons.jxpath.ri.compiler.Expression expression39 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression40 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod41 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression39, expression40);
        org.apache.commons.jxpath.ri.compiler.Expression expression42 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression43 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod44 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression42, expression43);
        org.apache.commons.jxpath.ri.compiler.Expression expression45 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression46 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod47 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression45, expression46);
        org.apache.commons.jxpath.ri.compiler.Expression expression48 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression49 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod50 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression48, expression49);
        org.apache.commons.jxpath.ri.compiler.Expression expression51 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression52 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod53 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression51, expression52);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray54 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression39, expression43, expression45, expression48, coreOperationMod53 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr55 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray54);
        org.apache.commons.jxpath.ri.compiler.Expression expression56 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression57 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod58 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression56, expression57);
        org.apache.commons.jxpath.ri.compiler.Expression expression59 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression60 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod61 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression59, expression60);
        org.apache.commons.jxpath.ri.compiler.Expression expression62 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression63 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod64 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression62, expression63);
        org.apache.commons.jxpath.ri.compiler.Expression expression65 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression66 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod67 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression65, expression66);
        org.apache.commons.jxpath.ri.compiler.Expression expression68 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression69 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod70 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression68, expression69);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray71 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression56, expression60, expression62, expression65, coreOperationMod70 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr72 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray71);
        org.apache.commons.jxpath.ri.compiler.Expression expression73 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression74 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod75 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression73, expression74);
        org.apache.commons.jxpath.ri.compiler.Expression expression76 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression77 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod78 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression76, expression77);
        org.apache.commons.jxpath.ri.compiler.Expression expression79 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression80 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod81 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression79, expression80);
        org.apache.commons.jxpath.ri.compiler.Expression expression82 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression83 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod84 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression82, expression83);
        org.apache.commons.jxpath.ri.compiler.Expression expression85 = null;
        org.apache.commons.jxpath.ri.compiler.Expression expression86 = null;
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod87 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod(expression85, expression86);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray88 = new org.apache.commons.jxpath.ri.compiler.Expression[] { expression73, expression77, expression79, expression82, coreOperationMod87 };
        org.apache.commons.jxpath.ri.compiler.CoreOperationOr coreOperationOr89 = new org.apache.commons.jxpath.ri.compiler.CoreOperationOr(expressionArray88);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray90 = new org.apache.commons.jxpath.ri.compiler.Expression[] { coreOperationMod4, coreOperationOr21, coreOperationOr38, coreOperationOr55, coreOperationOr72, coreOperationOr89 };
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction91 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName1, expressionArray90);
        boolean boolean92 = extensionFunction91.computeContextDependent();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray54);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray71);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray88);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray90);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }
}

