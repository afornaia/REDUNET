import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest94 {

    public static boolean debug = false;

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest94.test095");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.lang.Object obj4 = jXPathContextReferenceImpl3.getContextBean();
        java.util.Locale locale5 = jXPathContextReferenceImpl3.getLocale();
        org.apache.commons.jxpath.JXPathContext jXPathContext6 = jXPathContextReferenceImpl3.getParentContext();
        org.apache.commons.jxpath.ri.QName qName7 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory8 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass9 = strictLazyDynaBeanPointerFactory8.getClass();
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo10 = org.apache.commons.jxpath.JXPathIntrospector.getBeanInfo((java.lang.Class) wildcardClass9);
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler11 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj13 = treeCompiler11.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName15 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray16 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction17 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName15, expressionArray16);
        java.lang.Object obj18 = treeCompiler11.locationPath(false, (java.lang.Object[]) expressionArray16);
        java.lang.reflect.Constructor constructor19 = org.apache.commons.jxpath.util.MethodLookupUtils.lookupConstructor((java.lang.Class) wildcardClass9, (java.lang.Object[]) expressionArray16);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.Function function20 = jXPathContextReferenceImpl3.getFunction(qName7, (java.lang.Object[]) expressionArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj4 + "' != '" + 1 + "'", obj4.equals(1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale5.toString(), "en_US");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(jXPathContext6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathBeanInfo10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj13.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj18.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(constructor19);
    }
}

