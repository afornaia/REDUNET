import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest143 {

    public static boolean debug = false;

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest143.test144");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass1 = strictLazyDynaBeanPointerFactory0.getClass();
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory2 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass3 = strictLazyDynaBeanPointerFactory2.getClass();
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo4 = org.apache.commons.jxpath.JXPathIntrospector.getBeanInfo((java.lang.Class) wildcardClass3);
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler5 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj7 = treeCompiler5.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray10 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction11 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName9, expressionArray10);
        java.lang.Object obj12 = treeCompiler5.locationPath(false, (java.lang.Object[]) expressionArray10);
        java.lang.reflect.Constructor constructor13 = org.apache.commons.jxpath.util.MethodLookupUtils.lookupConstructor((java.lang.Class) wildcardClass3, (java.lang.Object[]) expressionArray10);
        org.apache.commons.jxpath.JXPathBasicBeanInfo jXPathBasicBeanInfo14 = new org.apache.commons.jxpath.JXPathBasicBeanInfo((java.lang.Class) wildcardClass1, (java.lang.Class) wildcardClass3);
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo15 = org.apache.commons.jxpath.JXPathIntrospector.getBeanInfo((java.lang.Class) wildcardClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathBeanInfo4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj7.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj12.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(constructor13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathBeanInfo15);
    }
}

