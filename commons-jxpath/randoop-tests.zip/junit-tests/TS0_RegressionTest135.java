import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest135 {

    public static boolean debug = false;

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest135.test136");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "");
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer5 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, "hi!", "hi!");
        java.lang.Object obj6 = namespacePointer5.getNodeValue();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj6 + "' != '" + "hi!" + "'", obj6.equals("hi!"));
    }
}

