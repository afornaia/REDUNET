import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest92.test093");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass1 = strictLazyDynaBeanPointerFactory0.getClass();
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo2 = org.apache.commons.jxpath.JXPathIntrospector.getBeanInfo((java.lang.Class) wildcardClass1);
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler3 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj5 = treeCompiler3.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName7 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray8 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction9 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName7, expressionArray8);
        java.lang.Object obj10 = treeCompiler3.locationPath(false, (java.lang.Object[]) expressionArray8);
        java.lang.reflect.Constructor constructor11 = org.apache.commons.jxpath.util.MethodLookupUtils.lookupConstructor((java.lang.Class) wildcardClass1, (java.lang.Object[]) expressionArray8);
        org.apache.commons.jxpath.ri.QName qName13 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray14 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction15 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName13, expressionArray14);
        org.apache.commons.jxpath.ri.QName qName16 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray17 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction18 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName16, expressionArray17);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod19 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction15, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction18);
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray20 = extensionFunction15.getArguments();
        java.lang.reflect.Method method21 = org.apache.commons.jxpath.util.MethodLookupUtils.lookupStaticMethod((java.lang.Class) wildcardClass1, "null() mod null()", (java.lang.Object[]) expressionArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathBeanInfo2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj5.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj10.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(constructor11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(method21);
    }
}

