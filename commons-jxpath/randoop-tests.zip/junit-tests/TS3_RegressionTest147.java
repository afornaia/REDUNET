import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest147 {

    public static boolean debug = false;

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest147.test148");
        org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory containerPointerFactory0 = new org.apache.commons.jxpath.ri.model.container.ContainerPointerFactory();
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer3 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale2);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer3);
        org.apache.commons.jxpath.ri.QName qName5 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer7 = containerPointerFactory0.createNodePointer((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer3, qName5, (java.lang.Object) 28);
        org.apache.commons.jxpath.JXPathContext jXPathContext8 = null;
        org.apache.commons.jxpath.Pointer pointer10 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl11 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext8, (java.lang.Object) 1, pointer10);
        org.apache.commons.jxpath.KeyManager keyManager12 = jXPathContextReferenceImpl11.getKeyManager();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = collectionPointer3.createPath((org.apache.commons.jxpath.JXPathContext) jXPathContextReferenceImpl11, (java.lang.Object) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodePointer7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(keyManager12);
    }
}

