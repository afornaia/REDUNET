import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest126 {

    public static boolean debug = false;

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest126.test127");
        java.util.Locale locale0 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer2 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale0, "");
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer5 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) nullPointer2, "hi!", "hi!");
        org.apache.commons.jxpath.ri.QName qName8 = new org.apache.commons.jxpath.ri.QName("", "");
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator9 = namespacePointer5.attributeIterator(qName8);
        java.util.Locale locale11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer13 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) ' ', locale11, "hi!");
        java.lang.Object obj14 = jDOMNodePointer13.getValue();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = jDOMNodePointer13.getImmediateValuePointer();
        org.apache.commons.jxpath.servlet.HttpSessionHandler httpSessionHandler16 = new org.apache.commons.jxpath.servlet.HttpSessionHandler();
        java.util.Locale locale17 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer dynamicPointer18 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPointer(qName8, (java.lang.Object) nodePointer15, (org.apache.commons.jxpath.DynamicPropertyHandler) httpSessionHandler16, locale17);
        org.apache.commons.jxpath.JXPathContext jXPathContext20 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) 1L);
        // The following exception was thrown during execution in test generation
        try {
            int int21 = nodePointer15.compareTo((java.lang.Object) jXPathContext20);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.apache.commons.jxpath.ri.JXPathContextReferenceImpl cannot be cast to org.apache.commons.jxpath.ri.model.NodePointer");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodeIterator9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContext20);
    }
}

