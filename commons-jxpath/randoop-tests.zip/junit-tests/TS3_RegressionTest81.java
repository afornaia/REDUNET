import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest81.test082");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        org.apache.commons.jxpath.ri.QName qName5 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray6 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction7 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName5, expressionArray6);
        // The following exception was thrown during execution in test generation
        try {
            jXPathContextReferenceImpl3.removePath("hi!", (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Exception trying to remove xpath hi!; java.lang.NullPointerException");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray6);
    }
}

