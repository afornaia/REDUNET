import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest77.test078");
        org.apache.commons.jxpath.ri.parser.ParseException parseException2 = new org.apache.commons.jxpath.ri.parser.ParseException("http://www.w3.org/XML/1998/namespace");
        org.apache.commons.jxpath.JXPathTypeConversionException jXPathTypeConversionException3 = new org.apache.commons.jxpath.JXPathTypeConversionException("application", (java.lang.Exception) parseException2);
        java.lang.String str4 = parseException2.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.jxpath.ri.parser.ParseException: http://www.w3.org/XML/1998/namespace" + "'", str4.equals("org.apache.commons.jxpath.ri.parser.ParseException: http://www.w3.org/XML/1998/namespace"));
    }
}

