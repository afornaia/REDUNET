import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest28.test029");
        java.io.Reader reader0 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream3 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader0, 63, (int) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.parser.XPathParserTokenManager xPathParserTokenManager5 = new org.apache.commons.jxpath.ri.parser.XPathParserTokenManager(simpleCharStream3, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.ri.parser.TokenMgrError; message: Error: Ignoring invalid lexical state : 97. State unchanged.");
        } catch (org.apache.commons.jxpath.ri.parser.TokenMgrError e) {
        // Expected exception.
        }
    }
}

