import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest124 {

    public static boolean debug = false;

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest124.test125");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.JXPathContext jXPathContext3 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer4 = jDOMAttributePointer2.createPath(jXPathContext3);
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer6 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer(nodePointer4, (java.lang.Object) 23);
        org.apache.commons.jxpath.ri.parser.ParseException parseException9 = new org.apache.commons.jxpath.ri.parser.ParseException("http://www.w3.org/XML/1998/namespace");
        int[] intArray16 = new int[] { '4', (short) -1, 100, 21, (short) 10, (short) 1 };
        int[][] intArray17 = new int[][] { intArray16 };
        parseException9.expectedTokenSequences = intArray17;
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException19 = new org.apache.commons.jxpath.JXPathInvalidAccessException("page", (java.lang.Throwable) parseException9);
        boolean boolean20 = collectionPointer6.equals((java.lang.Object) "page");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }
}

