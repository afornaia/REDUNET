import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest128 {

    public static boolean debug = false;

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest128.test129");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.util.Locale locale4 = jXPathContextReferenceImpl3.getLocale();
        org.apache.commons.jxpath.ExceptionHandler exceptionHandler5 = null;
        jXPathContextReferenceImpl3.setExceptionHandler(exceptionHandler5);
        org.apache.commons.jxpath.BasicVariables basicVariables7 = new org.apache.commons.jxpath.BasicVariables();
        jXPathContextReferenceImpl3.setVariables((org.apache.commons.jxpath.Variables) basicVariables7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale4.toString(), "en_US");
    }
}

