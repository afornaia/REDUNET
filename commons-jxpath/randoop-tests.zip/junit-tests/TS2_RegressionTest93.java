import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest93.test094");
        java.lang.String str0 = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.XMLNS_NAMESPACE_URI;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "http://www.w3.org/2000/xmlns/" + "'", str0.equals("http://www.w3.org/2000/xmlns/"));
    }
}

