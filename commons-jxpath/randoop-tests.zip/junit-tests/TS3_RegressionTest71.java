import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest71.test072");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        org.apache.commons.jxpath.ri.QName qName5 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray6 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction7 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName5, expressionArray6);
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray9 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction10 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName8, expressionArray9);
        org.apache.commons.jxpath.ri.compiler.CoreOperationMod coreOperationMod11 = new org.apache.commons.jxpath.ri.compiler.CoreOperationMod((org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction7, (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction10);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Iterator iterator12 = jXPathContextReferenceImpl3.iteratePointers("org.apache.commons.jxpath.JXPathInvalidAccessException: ", (org.apache.commons.jxpath.ri.compiler.Expression) extensionFunction10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray9);
    }
}

