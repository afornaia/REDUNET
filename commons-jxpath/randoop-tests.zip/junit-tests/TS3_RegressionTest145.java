import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest145 {

    public static boolean debug = false;

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest145.test146");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest2 = null;
        org.apache.commons.jxpath.ri.axes.AncestorContext ancestorContext3 = new org.apache.commons.jxpath.ri.axes.AncestorContext(evalContext0, false, nodeTest2);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest5 = null;
        org.apache.commons.jxpath.ri.axes.DescendantContext descendantContext6 = new org.apache.commons.jxpath.ri.axes.DescendantContext(evalContext0, true, nodeTest5);
        org.apache.commons.jxpath.NodeSet nodeSet7 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext8 = new org.apache.commons.jxpath.ri.axes.NodeSetContext(evalContext0, nodeSet7);
        org.apache.commons.jxpath.NodeSet nodeSet9 = nodeSetContext8.getNodeSet();
        boolean boolean11 = nodeSetContext8.setPosition(0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodeSet9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }
}

