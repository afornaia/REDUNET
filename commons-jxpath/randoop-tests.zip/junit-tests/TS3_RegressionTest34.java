import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest34.test035");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass1 = strictLazyDynaBeanPointerFactory0.getClass();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler2 = org.apache.commons.jxpath.util.ValueUtils.getDynamicPropertyHandler((java.lang.Class) wildcardClass1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot allocate dynamic property handler of class org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory; org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory cannot be cast to org.apache.commons.jxpath.DynamicPropertyHandler");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
    }
}

