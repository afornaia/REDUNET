import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest128 {

    public static boolean debug = false;

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest128.test129");
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) 1L);
        java.text.DecimalFormatSymbols decimalFormatSymbols3 = jXPathContext1.getDecimalFormatSymbols("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContext1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(decimalFormatSymbols3);
    }
}

