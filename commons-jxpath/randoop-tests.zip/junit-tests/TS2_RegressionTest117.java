import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest117.test118");
        org.apache.commons.jxpath.ri.compiler.Step[] stepArray2 = new org.apache.commons.jxpath.ri.compiler.Step[] {};
        org.apache.commons.jxpath.ri.compiler.LocationPath locationPath3 = new org.apache.commons.jxpath.ri.compiler.LocationPath(true, stepArray2);
        org.apache.commons.jxpath.ri.JXPathCompiledExpression jXPathCompiledExpression4 = new org.apache.commons.jxpath.ri.JXPathCompiledExpression("org.apache.commons.jxpath.ri.parser.ParseException: http://www.w3.org/XML/1998/namespace", (org.apache.commons.jxpath.ri.compiler.Expression) locationPath3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stepArray2);
    }
}

