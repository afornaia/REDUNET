import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest93.test094");
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl0 = null;
        java.util.Locale locale2 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer4 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) ' ', locale2, "hi!");
        java.lang.Object obj5 = jDOMNodePointer4.getValue();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.axes.RootContext rootContext6 = new org.apache.commons.jxpath.ri.axes.RootContext(jXPathContextReferenceImpl0, (org.apache.commons.jxpath.ri.model.NodePointer) jDOMNodePointer4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj5);
    }
}

