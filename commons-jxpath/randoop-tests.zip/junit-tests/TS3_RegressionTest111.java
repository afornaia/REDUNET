import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest111.test112");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer2 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale1);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer2);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = collectionPointer2.namespacePointer("hi!");
        java.lang.Throwable throwable7 = null;
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException8 = new org.apache.commons.jxpath.JXPathInvalidAccessException("", throwable7);
        java.util.Locale locale10 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer11 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale10);
        org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator jDOMNamespaceIterator12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNamespaceIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer11);
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer14 = collectionPointer11.namespacePointer("hi!");
        collectionPointer2.handle(throwable7, nodePointer14);
        org.w3c.dom.Node node16 = null;
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer17 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(nodePointer14, node16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodePointer5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodePointer14);
    }
}

