import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest140 {

    public static boolean debug = false;

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest140.test141");
        java.io.Reader reader0 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream3 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader0, 63, (int) (byte) 1);
        java.io.Reader reader4 = null;
        simpleCharStream3.ReInit(reader4, (int) '4', 29, (int) (byte) 10);
        simpleCharStream3.bufpos = (short) 100;
    }
}

