import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest101.test102");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = null;
        org.apache.commons.jxpath.Pointer pointer3 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl4 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext1, (java.lang.Object) 1, pointer3);
        java.util.Locale locale5 = jXPathContextReferenceImpl4.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer7 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale5, "");
        org.apache.commons.jxpath.JXPathContext jXPathContext8 = null;
        org.apache.commons.jxpath.ri.QName qName9 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory11 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass12 = strictLazyDynaBeanPointerFactory11.getClass();
        org.apache.commons.jxpath.JXPathIntrospector.registerAtomicClass((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.apache.commons.jxpath.util.TypeUtils.wrapPrimitive((java.lang.Class) wildcardClass12);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer15 = dOMNodePointer7.createChild(jXPathContext8, qName9, 54, (java.lang.Object) wildcardClass12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale5.toString(), "en_US");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(class14);
    }
}

