import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest139 {

    public static boolean debug = false;

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest139.test140");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer5 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer((org.apache.commons.jxpath.ri.model.NodePointer) jDOMAttributePointer2, "page", "hi!");
        java.lang.Object obj6 = jDOMAttributePointer2.getRootNode();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj6);
    }
}

