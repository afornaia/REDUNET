import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest61.test062");
        org.apache.commons.jxpath.JXPathContext jXPathContext0 = null;
        org.apache.commons.jxpath.Pointer pointer2 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl3 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext0, (java.lang.Object) 1, pointer2);
        java.util.Locale locale4 = jXPathContextReferenceImpl3.getLocale();
        org.apache.commons.jxpath.ri.compiler.Constant constant7 = new org.apache.commons.jxpath.ri.compiler.Constant((java.lang.Number) 23);
        // The following exception was thrown during execution in test generation
        try {
            jXPathContextReferenceImpl3.setValue("null()", (org.apache.commons.jxpath.ri.compiler.Expression) constant7, (java.lang.Object) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Exception trying to set value with xpath null(); Cannot set value for xpath: null()");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale4.toString(), "en_US");
    }
}

