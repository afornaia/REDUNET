import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest106 {

    public static boolean debug = false;

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest106.test107");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        java.lang.Class<?> wildcardClass1 = strictLazyDynaBeanPointerFactory0.getClass();
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo2 = org.apache.commons.jxpath.JXPathIntrospector.getBeanInfo((java.lang.Class) wildcardClass1);
        org.apache.commons.jxpath.ri.compiler.TreeCompiler treeCompiler3 = new org.apache.commons.jxpath.ri.compiler.TreeCompiler();
        java.lang.Object obj5 = treeCompiler3.nodeTypeTest((int) '#');
        org.apache.commons.jxpath.ri.QName qName7 = null;
        org.apache.commons.jxpath.ri.compiler.Expression[] expressionArray8 = new org.apache.commons.jxpath.ri.compiler.Expression[] {};
        org.apache.commons.jxpath.ri.compiler.ExtensionFunction extensionFunction9 = new org.apache.commons.jxpath.ri.compiler.ExtensionFunction(qName7, expressionArray8);
        java.lang.Object obj10 = treeCompiler3.locationPath(false, (java.lang.Object[]) expressionArray8);
        java.lang.reflect.Constructor constructor11 = org.apache.commons.jxpath.util.MethodLookupUtils.lookupConstructor((java.lang.Class) wildcardClass1, (java.lang.Object[]) expressionArray8);
        org.apache.commons.jxpath.functions.ConstructorFunction constructorFunction12 = new org.apache.commons.jxpath.functions.ConstructorFunction(constructor11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathBeanInfo2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj5.toString(), "UNKNOWN()");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(expressionArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(obj10.toString(), "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(constructor11);
    }
}

