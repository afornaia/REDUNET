import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest95.test096");
        org.w3c.dom.Node node0 = null;
        org.apache.commons.jxpath.JXPathContext jXPathContext1 = null;
        org.apache.commons.jxpath.Pointer pointer3 = null;
        org.apache.commons.jxpath.ri.JXPathContextReferenceImpl jXPathContextReferenceImpl4 = new org.apache.commons.jxpath.ri.JXPathContextReferenceImpl(jXPathContext1, (java.lang.Object) 1, pointer3);
        java.util.Locale locale5 = jXPathContextReferenceImpl4.getLocale();
        org.apache.commons.jxpath.ri.model.dom.DOMNodePointer dOMNodePointer7 = new org.apache.commons.jxpath.ri.model.dom.DOMNodePointer(node0, locale5, "");
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer9 = new org.apache.commons.jxpath.ri.model.beans.NullPointer((org.apache.commons.jxpath.ri.model.NodePointer) dOMNodePointer7, qName8);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest10 = null;
        java.util.Locale locale13 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer14 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale13);
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver15 = new org.apache.commons.jxpath.ri.NamespaceResolver();
        collectionPointer14.setNamespaceResolver(namespaceResolver15);
        java.lang.Object obj17 = collectionPointer14.getImmediateNode();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator18 = dOMNodePointer7.childIterator(nodeTest10, false, (org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer14);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.w3c.dom.Node");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(locale5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(locale5.toString(), "en_US");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + (short) 1 + "'", obj17.equals((short) 1));
    }
}

