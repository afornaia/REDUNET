import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest80.test081");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.beans.CollectionPointer collectionPointer2 = new org.apache.commons.jxpath.ri.model.beans.CollectionPointer((java.lang.Object) (short) 1, locale1);
        org.apache.commons.jxpath.ri.NamespaceResolver namespaceResolver3 = new org.apache.commons.jxpath.ri.NamespaceResolver();
        collectionPointer2.setNamespaceResolver(namespaceResolver3);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest5 = null;
        org.apache.commons.jxpath.Variables variables7 = null;
        org.apache.commons.jxpath.ri.QName qName8 = null;
        org.apache.commons.jxpath.ri.model.VariablePointer variablePointer9 = new org.apache.commons.jxpath.ri.model.VariablePointer(variables7, qName8);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator dOMNodeIterator10 = new org.apache.commons.jxpath.ri.model.dom.DOMNodeIterator((org.apache.commons.jxpath.ri.model.NodePointer) collectionPointer2, nodeTest5, false, (org.apache.commons.jxpath.ri.model.NodePointer) variablePointer9);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Short cannot be cast to org.w3c.dom.Node");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
    }
}

