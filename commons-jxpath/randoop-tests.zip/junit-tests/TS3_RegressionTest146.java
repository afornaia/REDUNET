import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest146 {

    public static boolean debug = false;

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest146.test147");
        java.io.Reader reader0 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream3 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader0, 200, 890);
        // The following exception was thrown during execution in test generation
        try {
            int int4 = simpleCharStream3.getColumn();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
    }
}

