import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest12.test013");
        java.lang.String str0 = org.apache.commons.jxpath.ri.model.dom.DOMNodePointer.XML_NAMESPACE_URI;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "http://www.w3.org/XML/1998/namespace" + "'", str0.equals("http://www.w3.org/XML/1998/namespace"));
    }
}

