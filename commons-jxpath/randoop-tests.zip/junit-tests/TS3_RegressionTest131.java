import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest131 {

    public static boolean debug = false;

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest131.test132");
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory0 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        int int1 = strictLazyDynaBeanPointerFactory0.getOrder();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 699 + "'", int1 == 699);
    }
}

