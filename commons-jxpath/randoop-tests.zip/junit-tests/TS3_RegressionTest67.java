import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest67.test068");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class class1 = org.apache.commons.jxpath.util.ClassLoaderUtil.getClass("org.apache.commons.jxpath.JXPathInvalidAccessException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassNotFoundException; message: org.apache.commons.jxpath.JXPathInvalidAccessException: ");
        } catch (java.lang.ClassNotFoundException e) {
        // Expected exception.
        }
    }
}

