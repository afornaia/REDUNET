import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest5.test006");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler1 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer dynamicPropertyPointer2 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer(nodePointer0, dynamicPropertyHandler1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String[] strArray3 = dynamicPropertyPointer2.getPropertyNames();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

