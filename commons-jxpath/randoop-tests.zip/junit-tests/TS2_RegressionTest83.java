import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest83.test084");
        java.net.URL uRL0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.xml.DocumentContainer documentContainer2 = new org.apache.commons.jxpath.xml.DocumentContainer(uRL0, "http://www.w3.org/XML/1998/namespace");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: XML URL is null");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
    }
}

