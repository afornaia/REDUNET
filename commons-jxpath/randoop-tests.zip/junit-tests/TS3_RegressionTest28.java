import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest28.test029");
        java.lang.String str0 = org.apache.commons.jxpath.servlet.Constants.APPLICATION_SCOPE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "application" + "'", str0.equals("application"));
    }
}

