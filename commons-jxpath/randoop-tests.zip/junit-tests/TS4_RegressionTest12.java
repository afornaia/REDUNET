import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest12.test013");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer1 = null;
        org.apache.commons.jxpath.DynamicPropertyHandler dynamicPropertyHandler2 = null;
        org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer dynamicPropertyPointer3 = new org.apache.commons.jxpath.ri.model.dynamic.DynamicPropertyPointer(nodePointer1, dynamicPropertyHandler2);
        org.jdom.Attribute attribute4 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer5 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer((org.apache.commons.jxpath.ri.model.NodePointer) dynamicPropertyPointer3, attribute4);
        org.apache.commons.jxpath.ri.compiler.Step step6 = null;
        org.apache.commons.jxpath.ri.compiler.Step[] stepArray7 = new org.apache.commons.jxpath.ri.compiler.Step[] { step6 };
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer9 = org.apache.commons.jxpath.ri.axes.SimplePathInterpreter.createNullPointer(evalContext0, (org.apache.commons.jxpath.ri.model.NodePointer) dynamicPropertyPointer3, stepArray7, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stepArray7);
    }
}

