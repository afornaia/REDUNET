import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest12.test013");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = org.apache.commons.jxpath.util.ValueUtils.expandCollection((java.lang.Object) 1.0d, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot turn java.lang.Double into a collection of size 10");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
    }
}

