import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest90.test091");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext2 = new org.apache.commons.jxpath.ri.axes.NamespaceContext(evalContext0, nodeTest1);
        boolean boolean4 = namespaceContext2.setPosition(100);
        boolean boolean5 = namespaceContext2.nextNode();
        org.apache.commons.jxpath.NodeSet nodeSet6 = null;
        org.apache.commons.jxpath.ri.axes.NodeSetContext nodeSetContext7 = new org.apache.commons.jxpath.ri.axes.NodeSetContext((org.apache.commons.jxpath.ri.EvalContext) namespaceContext2, nodeSet6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

