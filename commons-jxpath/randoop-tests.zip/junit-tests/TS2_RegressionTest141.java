import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest141 {

    public static boolean debug = false;

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest141.test142");
        java.io.Reader reader0 = null;
        org.apache.commons.jxpath.ri.parser.SimpleCharStream simpleCharStream4 = new org.apache.commons.jxpath.ri.parser.SimpleCharStream(reader0, 0, (-1), (int) (byte) 1);
        java.io.InputStream inputStream5 = null;
        // The following exception was thrown during execution in test generation
        try {
            simpleCharStream4.ReInit(inputStream5, 35, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

