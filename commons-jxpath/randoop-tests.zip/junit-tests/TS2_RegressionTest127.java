import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest127 {

    public static boolean debug = false;

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest127.test128");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.AttributeContext attributeContext2 = new org.apache.commons.jxpath.ri.axes.AttributeContext(evalContext0, nodeTest1);
        org.apache.commons.jxpath.ri.compiler.Expression expression3 = null;
        org.apache.commons.jxpath.ri.axes.PredicateContext predicateContext4 = new org.apache.commons.jxpath.ri.axes.PredicateContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext2, expression3);
        org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator valueIterator5 = new org.apache.commons.jxpath.ri.compiler.Expression.ValueIterator((java.util.Iterator) attributeContext2);
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest6 = null;
        org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext precedingOrFollowingContext8 = new org.apache.commons.jxpath.ri.axes.PrecedingOrFollowingContext((org.apache.commons.jxpath.ri.EvalContext) attributeContext2, nodeTest6, false);
    }
}

