import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest59.test060");
        java.lang.String str0 = org.apache.commons.jxpath.JXPathContextFactory.FACTORY_NAME_PROPERTY;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "org.apache.commons.jxpath.JXPathContextFactory" + "'", str0.equals("org.apache.commons.jxpath.JXPathContextFactory"));
    }
}

