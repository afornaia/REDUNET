import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest45 {

    public static boolean debug = false;

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest45.test046");
        org.apache.commons.jxpath.servlet.HttpSessionHandler httpSessionHandler0 = new org.apache.commons.jxpath.servlet.HttpSessionHandler();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = httpSessionHandler0.getProperty((java.lang.Object) "hi!", "JDOM");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.apache.commons.jxpath.servlet.HttpSessionAndServletContext");
        } catch (java.lang.ClassCastException e) {
        // Expected exception.
        }
    }
}

