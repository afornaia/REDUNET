import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest83.test084");
        org.apache.commons.jxpath.JXPathTypeConversionException jXPathTypeConversionException1 = new org.apache.commons.jxpath.JXPathTypeConversionException("");
        java.lang.Throwable throwable2 = jXPathTypeConversionException1.getException();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(throwable2);
    }
}

