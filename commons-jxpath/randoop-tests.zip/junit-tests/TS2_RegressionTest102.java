import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest102.test103");
        org.apache.commons.jxpath.ri.parser.ParseException parseException2 = new org.apache.commons.jxpath.ri.parser.ParseException("http://www.w3.org/XML/1998/namespace");
        int[] intArray9 = new int[] { '4', (short) -1, 100, 21, (short) 10, (short) 1 };
        int[][] intArray10 = new int[][] { intArray9 };
        parseException2.expectedTokenSequences = intArray10;
        org.apache.commons.jxpath.JXPathInvalidAccessException jXPathInvalidAccessException12 = new org.apache.commons.jxpath.JXPathInvalidAccessException("page", (java.lang.Throwable) parseException2);
        org.apache.commons.jxpath.ri.parser.Token token13 = parseException2.currentToken;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(token13);
    }
}

