import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest56.test057");
        org.apache.commons.jxpath.ri.QName qName0 = null;
        org.apache.commons.jxpath.JXPathBeanInfo jXPathBeanInfo2 = null;
        java.util.Locale locale3 = null;
        org.apache.commons.jxpath.ri.model.beans.BeanPointer beanPointer4 = new org.apache.commons.jxpath.ri.model.beans.BeanPointer(qName0, (java.lang.Object) (byte) 1, jXPathBeanInfo2, locale3);
        org.apache.commons.jxpath.ri.model.NodeIterator nodeIterator5 = beanPointer4.namespaceIterator();
        org.apache.commons.jxpath.JXPathContext jXPathContext6 = null;
        org.apache.commons.jxpath.ri.QName qName7 = null;
        java.lang.Object obj9 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = beanPointer4.createChild(jXPathContext6, qName7, 3, obj9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an object for path 1/null[4], operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodeIterator5);
    }
}

