import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest74.test075");
        org.apache.commons.jxpath.ri.parser.ParseException parseException2 = new org.apache.commons.jxpath.ri.parser.ParseException("http://www.w3.org/XML/1998/namespace");
        org.apache.commons.jxpath.JXPathTypeConversionException jXPathTypeConversionException3 = new org.apache.commons.jxpath.JXPathTypeConversionException("application", (java.lang.Exception) parseException2);
        org.apache.commons.jxpath.JXPathException jXPathException4 = new org.apache.commons.jxpath.JXPathException((java.lang.Throwable) jXPathTypeConversionException3);
    }
}

