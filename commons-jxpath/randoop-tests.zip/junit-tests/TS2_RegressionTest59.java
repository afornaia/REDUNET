import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest59.test060");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer0 = null;
        org.jdom.Attribute attribute1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer2 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer0, attribute1);
        org.apache.commons.jxpath.ri.model.dom.NamespacePointer namespacePointer4 = new org.apache.commons.jxpath.ri.model.dom.NamespacePointer(nodePointer0, "hi!");
        org.apache.commons.jxpath.ri.QName qName5 = namespacePointer4.getName();
        java.util.Locale locale6 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(qName5, locale6);
        org.apache.commons.jxpath.JXPathContext jXPathContext8 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory strictLazyDynaBeanPointerFactory9 = new org.apache.commons.jxpath.ri.model.dynabeans.StrictLazyDynaBeanPointerFactory();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = null;
        org.jdom.Attribute attribute11 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer jDOMAttributePointer12 = new org.apache.commons.jxpath.ri.model.jdom.JDOMAttributePointer(nodePointer10, attribute11);
        org.apache.commons.jxpath.ri.QName qName14 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer16 = strictLazyDynaBeanPointerFactory9.createNodePointer(nodePointer10, qName14, (java.lang.Object) (byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer17 = nullPointer7.createAttribute(jXPathContext8, qName14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Cannot create an attribute for path null()/@hi!, operation is not allowed for this type of node");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(qName5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(nodePointer16);
    }
}

