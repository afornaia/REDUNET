import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest55.test056");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.ParentContext parentContext2 = new org.apache.commons.jxpath.ri.axes.ParentContext(evalContext0, nodeTest1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.axes.InitialContext initialContext3 = new org.apache.commons.jxpath.ri.axes.InitialContext(evalContext0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

