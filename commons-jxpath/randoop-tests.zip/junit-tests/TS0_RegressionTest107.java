import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest107.test108");
        java.util.Locale locale1 = null;
        org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer jDOMNodePointer3 = new org.apache.commons.jxpath.ri.model.jdom.JDOMNodePointer((java.lang.Object) ' ', locale1, "hi!");
        java.lang.Object obj4 = jDOMNodePointer3.getValue();
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer5 = jDOMNodePointer3.getImmediateValuePointer();
        org.apache.commons.jxpath.JXPathContext jXPathContext7 = org.apache.commons.jxpath.JXPathContext.newContext((java.lang.Object) 1L);
        jXPathContext7.setLenient(false);
        org.apache.commons.jxpath.ri.QName qName11 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer12 = null;
        org.apache.commons.beanutils.DynaBean dynaBean13 = null;
        org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer dynaBeanPropertyPointer14 = new org.apache.commons.jxpath.ri.model.dynabeans.DynaBeanPropertyPointer(nodePointer12, dynaBean13);
        boolean boolean16 = dynaBeanPropertyPointer14.equals((java.lang.Object) (byte) -1);
        org.apache.commons.jxpath.ri.QName qName18 = new org.apache.commons.jxpath.ri.QName("hi!");
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer19 = new org.apache.commons.jxpath.ri.model.beans.NullPointer((org.apache.commons.jxpath.ri.model.NodePointer) dynaBeanPropertyPointer14, qName18);
        java.util.Locale locale20 = null;
        org.apache.commons.jxpath.ri.model.NodePointer nodePointer21 = org.apache.commons.jxpath.ri.model.NodePointer.newNodePointer(qName11, (java.lang.Object) dynaBeanPropertyPointer14, locale20);
        javax.servlet.jsp.PageContext pageContext23 = null;
        org.apache.commons.jxpath.servlet.PageScopeContext pageScopeContext24 = new org.apache.commons.jxpath.servlet.PageScopeContext(pageContext23);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer25 = jDOMNodePointer3.createChild(jXPathContext7, qName11, (int) (short) 1, (java.lang.Object) pageScopeContext24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.jxpath.JXPathException; message: Factory is not set on the JXPathContext - cannot create path: id('hi!')");
        } catch (org.apache.commons.jxpath.JXPathException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jXPathContext7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(nodePointer21);
    }
}

