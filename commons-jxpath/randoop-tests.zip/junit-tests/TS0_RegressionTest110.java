import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest110.test111");
        org.apache.commons.jxpath.ri.EvalContext evalContext0 = null;
        org.apache.commons.jxpath.ri.compiler.NodeTest nodeTest1 = null;
        org.apache.commons.jxpath.ri.axes.NamespaceContext namespaceContext2 = new org.apache.commons.jxpath.ri.axes.NamespaceContext(evalContext0, nodeTest1);
        boolean boolean4 = namespaceContext2.setPosition(100);
        java.util.Locale locale5 = null;
        org.apache.commons.jxpath.ri.model.beans.NullPointer nullPointer7 = new org.apache.commons.jxpath.ri.model.beans.NullPointer(locale5, "");
        org.apache.commons.jxpath.ri.compiler.Step[] stepArray8 = new org.apache.commons.jxpath.ri.compiler.Step[] {};
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.jxpath.ri.model.NodePointer nodePointer10 = org.apache.commons.jxpath.ri.axes.SimplePathInterpreter.createNullPointer((org.apache.commons.jxpath.ri.EvalContext) namespaceContext2, (org.apache.commons.jxpath.ri.model.NodePointer) nullPointer7, stepArray8, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stepArray8);
    }
}

