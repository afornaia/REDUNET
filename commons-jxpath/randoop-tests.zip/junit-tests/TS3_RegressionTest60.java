import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest60.test061");
        org.apache.commons.jxpath.util.KeyManagerUtils keyManagerUtils0 = new org.apache.commons.jxpath.util.KeyManagerUtils();
    }
}

