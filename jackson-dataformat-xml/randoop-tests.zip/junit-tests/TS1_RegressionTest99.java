import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest99.test100");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version2 = jacksonXmlAnnotationIntrospector1.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = builder0.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider4 = builder3.filterProvider();
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature5 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        boolean boolean7 = feature5.enabledIn((int) (byte) 10);
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature8 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        boolean boolean10 = feature8.enabledIn((int) (byte) 10);
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] featureArray11 = new com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] { feature5, feature8 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = builder3.disable(featureArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(filterProvider4);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + feature8 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature8.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
    }
}

