import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest69.test70");
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator0 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping1 = null;
        com.fasterxml.jackson.annotation.JsonTypeInfo.As as2 = null;
        com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder defaultingXmlTypeResolverBuilder3 = new com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder(polymorphicTypeValidator0, defaultTyping1, as2);
        com.fasterxml.jackson.databind.DatabindContext databindContext4 = null;
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator5 = defaultingXmlTypeResolverBuilder3.subTypeValidator(databindContext4);
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider6 = null;
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray8 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList9 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList9, namedTypeArray8);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = defaultingXmlTypeResolverBuilder3.buildTypeSerializer(serializerProvider6, javaType7, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(polymorphicTypeValidator5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }
}

