import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest101.test102");
        com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter defaultXmlPrettyPrinter0 = new com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter();
        javax.xml.stream.XMLInputFactory xMLInputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory1);
        int int3 = xmlFactory2.getStreamReadFeatures();
        boolean boolean4 = xmlFactory2.canParseAsync();
        com.fasterxml.jackson.core.Version version5 = xmlFactory2.version();
        java.io.DataOutput dataOutput6 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = xmlFactory2.createGenerator(dataOutput6);
        defaultXmlPrettyPrinter0.beforeObjectEntries(jsonGenerator7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 9 + "'", int3 == 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator7);
    }
}

