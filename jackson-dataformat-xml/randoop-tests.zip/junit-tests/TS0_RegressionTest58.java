import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest58.test59");
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector0 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation1 = null;
        boolean boolean2 = annotationIntrospector0.isAnnotationBundle(annotation1);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector3 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair4 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector0, annotationIntrospector3);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper5 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader7 = xmlMapper5.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig8 = xmlMapper5.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedMember annotatedMember9 = null;
        java.lang.Boolean boolean10 = pair4.hasRequiredMarker((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig8, annotatedMember9);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper11 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader13 = xmlMapper11.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig14 = xmlMapper11.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated15 = null;
        com.fasterxml.jackson.annotation.JsonSetter.Value value16 = pair4.findSetterInfo((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig14, annotated15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(value16);
    }
}

