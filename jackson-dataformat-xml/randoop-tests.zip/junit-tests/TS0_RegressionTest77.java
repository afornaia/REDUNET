import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest77.test78");
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector0 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation1 = null;
        boolean boolean2 = annotationIntrospector0.isAnnotationBundle(annotation1);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector3 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair4 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector0, annotationIntrospector3);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector5 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation6 = null;
        boolean boolean7 = annotationIntrospector5.isAnnotationBundle(annotation6);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector8 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair9 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector5, annotationIntrospector8);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper10 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader12 = xmlMapper10.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig13 = xmlMapper10.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated14 = null;
        java.util.List<com.fasterxml.jackson.databind.PropertyName> propertyNameList15 = pair9.findPropertyAliases((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig13, annotated14);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector16 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation17 = null;
        boolean boolean18 = annotationIntrospector16.isAnnotationBundle(annotation17);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector19 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair20 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector16, annotationIntrospector19);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper21 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader23 = xmlMapper21.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig24 = xmlMapper21.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField25 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName26 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName27 = pair20.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig24, annotatedField25, propertyName26);
        com.fasterxml.jackson.databind.introspect.Annotated annotated28 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName29 = pair9.findNameForSerialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig24, annotated28);
        com.fasterxml.jackson.databind.introspect.Annotated annotated30 = null;
        java.util.List<com.fasterxml.jackson.databind.PropertyName> propertyNameList31 = pair4.findPropertyAliases((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig24, annotated30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyNameList15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyNameList31);
    }
}

