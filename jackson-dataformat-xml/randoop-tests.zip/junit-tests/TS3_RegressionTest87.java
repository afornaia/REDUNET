import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest87.test088");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        int int2 = xmlFactory1.getFormatReadFeatures();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory3 = xmlFactory1.copy();
        xmlFactory3.setXMLTextElementName("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory3);
    }
}

