import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest49.test50");
        java.util.List<com.fasterxml.jackson.databind.Module> moduleList0 = com.fasterxml.jackson.databind.cfg.MapperBuilder.findModules();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleList0);
    }
}

