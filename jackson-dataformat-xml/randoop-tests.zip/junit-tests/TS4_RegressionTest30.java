import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest30.test31");
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext3 = com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext.createRootContext((int) '#', (int) (short) -1);
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext6 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext(3, xmlReadContext3, 0, (int) (short) 1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlReadContext3);
    }
}

