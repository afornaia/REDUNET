import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest81.test82");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder1 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean2 = builder1.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray3 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder1.disable(streamWriteFeatureArray3);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature5 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder1.configure(feature5, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper8 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder1);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig9 = xmlMapper8.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass10 = null;
        java.lang.Boolean boolean11 = xmlJaxbAnnotationIntrospector0.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig9, annotatedClass10);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean13 = builder12.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray14 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = builder12.disable(streamWriteFeatureArray14);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature16 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder18 = builder12.configure(feature16, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper19 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder12);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig20 = xmlMapper19.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField21 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName22 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName23 = xmlJaxbAnnotationIntrospector0.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig20, annotatedField21, propertyName22);
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector24 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder25 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean26 = builder25.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray27 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder28 = builder25.disable(streamWriteFeatureArray27);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature29 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder31 = builder25.configure(feature29, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper32 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder25);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig33 = xmlMapper32.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass34 = null;
        java.lang.Boolean boolean35 = xmlJaxbAnnotationIntrospector24.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig33, annotatedClass34);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder36 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean37 = builder36.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray38 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder39 = builder36.disable(streamWriteFeatureArray38);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature40 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder42 = builder36.configure(feature40, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper43 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder36);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig44 = xmlMapper43.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField45 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName46 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName47 = xmlJaxbAnnotationIntrospector24.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig44, annotatedField45, propertyName46);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector48 = com.fasterxml.jackson.databind.introspect.AnnotationIntrospectorPair.create((com.fasterxml.jackson.databind.AnnotationIntrospector) xmlJaxbAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) xmlJaxbAnnotationIntrospector24);
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector49 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder50 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean51 = builder50.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray52 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder53 = builder50.disable(streamWriteFeatureArray52);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature54 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder56 = builder50.configure(feature54, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper57 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder50);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig58 = xmlMapper57.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass59 = null;
        java.lang.Boolean boolean60 = xmlJaxbAnnotationIntrospector49.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig58, annotatedClass59);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder61 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean62 = builder61.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray63 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder64 = builder61.disable(streamWriteFeatureArray63);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature65 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder67 = builder61.configure(feature65, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper68 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder61);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig69 = xmlMapper68.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField70 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName71 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName72 = xmlJaxbAnnotationIntrospector49.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig69, annotatedField70, propertyName71);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder73 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean74 = builder73.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray75 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder76 = builder73.disable(streamWriteFeatureArray75);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature77 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder79 = builder73.configure(feature77, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper80 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder73);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig81 = xmlMapper80.serializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated82 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName83 = xmlJaxbAnnotationIntrospector49.findNameForDeserialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig81, annotated82);
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField84 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName85 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName86 = annotationIntrospector48.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig81, annotatedField84, propertyName85);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder15);
        org.junit.Assert.assertTrue("'" + feature16 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature16.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder28);
        org.junit.Assert.assertTrue("'" + feature29 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature29.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder39);
        org.junit.Assert.assertTrue("'" + feature40 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature40.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray52);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder53);
        org.junit.Assert.assertTrue("'" + feature54 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature54.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder56);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean60);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder61);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray63);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder64);
        org.junit.Assert.assertTrue("'" + feature65 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature65.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder67);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName72);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder73);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray75);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder76);
        org.junit.Assert.assertTrue("'" + feature77 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature77.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder79);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig81);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName83);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName86);
    }
}

