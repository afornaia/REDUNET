import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest71.test72");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader2 = xmlMapper0.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig3 = xmlMapper0.deserializationConfig();
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes4 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter5 = xmlMapper0.writer(contextAttributes4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter5);
    }
}

