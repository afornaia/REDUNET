import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest23.test024");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        int int2 = xmlFactory1.getStreamReadFeatures();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory3 = xmlFactory1.copy();
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext4 = null;
        javax.xml.stream.XMLStreamReader xMLStreamReader5 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser fromXmlParser6 = xmlFactory1.createParser(objectReadContext4, xMLStreamReader5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory3);
    }
}

