import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest105.test106");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory6 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder3.serializerFactory(serializerFactory6);
        javax.xml.stream.XMLInputFactory xMLInputFactory8 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory9 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory8);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder10 = xmlFactory9.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory9);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder13 = builder11.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides14 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler15 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory16 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector17 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver18 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup19 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider20 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig21 = builder13.buildSerializationConfig(configOverrides14, mixInHandler15, typeFactory16, classIntrospector17, subtypeResolver18, rootNameLookup19, filterProvider20);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder22 = builder3.mixInOverrides((com.fasterxml.jackson.databind.introspect.MixInResolver) serializationConfig21);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature23 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder25 = builder3.configure(feature23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder22);
    }
}

