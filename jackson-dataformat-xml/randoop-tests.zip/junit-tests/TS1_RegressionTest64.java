import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest64 {

    public static boolean debug = false;

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest64.test065");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = xmlFactory0.snapshot();
        xmlFactory0.setXMLTextElementName("hi!");
        java.lang.String str4 = xmlFactory0.getXMLTextElementName();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }
}

