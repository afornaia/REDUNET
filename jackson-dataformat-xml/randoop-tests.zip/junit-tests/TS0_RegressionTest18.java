import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest18.test19");
        com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializerModifier xmlBeanSerializerModifier0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializerModifier();
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig1 = null;
        com.fasterxml.jackson.databind.BeanDescription beanDescription2 = null;
        com.fasterxml.jackson.databind.ser.BeanPropertyWriter[] beanPropertyWriterArray3 = new com.fasterxml.jackson.databind.ser.BeanPropertyWriter[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.ser.BeanPropertyWriter> beanPropertyWriterList4 = new java.util.ArrayList<com.fasterxml.jackson.databind.ser.BeanPropertyWriter>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.ser.BeanPropertyWriter>) beanPropertyWriterList4, beanPropertyWriterArray3);
        java.util.List<com.fasterxml.jackson.databind.ser.BeanPropertyWriter> beanPropertyWriterList6 = xmlBeanSerializerModifier0.orderProperties(serializationConfig1, beanDescription2, (java.util.List<com.fasterxml.jackson.databind.ser.BeanPropertyWriter>) beanPropertyWriterList4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(beanPropertyWriterArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(beanPropertyWriterList6);
    }
}

