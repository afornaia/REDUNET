import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest97.test098");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper1 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider2 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter3 = xmlMapper1.writer(filterProvider2);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = xmlMapper1.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray5 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder6 = builder4.addModules(moduleArray5);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides7 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler8 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory9 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector10 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver11 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup12 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider13 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig14 = builder6.buildSerializationConfig(configOverrides7, mixInHandler8, typeFactory9, classIntrospector10, subtypeResolver11, rootNameLookup12, filterProvider13);
        com.fasterxml.jackson.databind.introspect.Annotated annotated15 = null;
        com.fasterxml.jackson.annotation.JsonFormat.Value value16 = xmlJaxbAnnotationIntrospector0.findFormat((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig14, annotated15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(value16);
    }
}

