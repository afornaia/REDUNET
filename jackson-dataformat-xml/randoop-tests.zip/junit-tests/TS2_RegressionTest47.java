import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest47.test048");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        byte[] byteArray1 = new byte[] {};
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser2 = xmlMapper0.createParser(byteArray1);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Unexpected EOF in prolog\n at [row,col {unknown-source}]: [1,0]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
    }
}

