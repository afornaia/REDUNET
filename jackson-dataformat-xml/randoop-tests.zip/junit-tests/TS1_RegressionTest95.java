import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest95 {

    public static boolean debug = false;

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest95.test096");
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlTypeResolverBuilder xmlTypeResolverBuilder1 = new com.fasterxml.jackson.dataformat.xml.XmlTypeResolverBuilder(value0);
        java.lang.String str2 = xmlTypeResolverBuilder1.getTypeProperty();
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeIdResolver typeIdResolver4 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder5 = xmlTypeResolverBuilder1.init(value3, typeIdResolver4);
        java.lang.Class<?> wildcardClass6 = stdTypeResolverBuilder5.getDefaultImpl();
        java.lang.String str7 = stdTypeResolverBuilder5.getTypeProperty();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str7);
    }
}

