import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest86.test087");
        com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier xmlBeanDeserializerModifier1 = new com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier("");
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig2 = null;
        com.fasterxml.jackson.databind.JavaType javaType3 = null;
        com.fasterxml.jackson.databind.KeyDeserializer keyDeserializer4 = null;
        com.fasterxml.jackson.databind.KeyDeserializer keyDeserializer5 = xmlBeanDeserializerModifier1.modifyKeyDeserializer(deserializationConfig2, javaType3, keyDeserializer4);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig6 = null;
        com.fasterxml.jackson.databind.type.MapLikeType mapLikeType7 = null;
        com.fasterxml.jackson.databind.BeanDescription beanDescription8 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer9 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer10 = xmlBeanDeserializerModifier1.modifyMapLikeDeserializer(deserializationConfig6, mapLikeType7, beanDescription8, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.String>) xmlStringDeserializer9);
        com.fasterxml.jackson.core.JsonParser jsonParser11 = null;
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext12 = null;
        com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer13 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = xmlStringDeserializer9.deserializeWithType(jsonParser11, deserializationContext12, typeDeserializer13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(keyDeserializer5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer10);
    }
}

