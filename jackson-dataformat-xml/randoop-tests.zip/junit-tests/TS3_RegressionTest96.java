import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest96.test097");
        com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts xmlSerializationContexts0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts();
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer1 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        java.lang.Class<?> wildcardClass2 = xmlStringDeserializer1.handledType();
        javax.xml.stream.XMLInputFactory xMLInputFactory3 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory4 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory3);
        com.fasterxml.jackson.core.FormatSchema formatSchema5 = null;
        boolean boolean6 = xmlFactory4.canUseSchema(formatSchema5);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory7 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts8 = xmlSerializationContexts0.forMapper((java.lang.Object) xmlStringDeserializer1, (com.fasterxml.jackson.core.TokenStreamFactory) xmlFactory4, serializerFactory7);
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator9 = xmlFactory4.getInputDecorator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(inputDecorator9);
    }
}

