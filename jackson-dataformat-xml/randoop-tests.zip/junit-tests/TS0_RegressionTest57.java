import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest57 {

    public static boolean debug = false;

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest57.test58");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory3 = xmlFactory2.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory2);
        java.io.DataOutput dataOutput5 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding6 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator7 = xmlFactory2.createGenerator(dataOutput5, jsonEncoding6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory3);
    }
}

