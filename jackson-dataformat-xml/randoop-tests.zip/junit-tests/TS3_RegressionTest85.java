import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest85.test086");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector3 = jacksonXmlAnnotationIntrospector1.setConstructorPropertiesImpliesCreator(false);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector5 = jacksonAnnotationIntrospector3.setConstructorPropertiesImpliesCreator(true);
        javax.xml.stream.XMLInputFactory xMLInputFactory6 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory7 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory6);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder8 = xmlFactory7.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory7);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = builder9.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory12 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder13 = builder9.serializerFactory(serializerFactory12);
        javax.xml.stream.XMLInputFactory xMLInputFactory14 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory15 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory14);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder16 = xmlFactory15.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder17 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory15);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder19 = builder17.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides20 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler21 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory22 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector23 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver24 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup25 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider26 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig27 = builder19.buildSerializationConfig(configOverrides20, mixInHandler21, typeFactory22, classIntrospector23, subtypeResolver24, rootNameLookup25, filterProvider26);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder28 = builder9.mixInOverrides((com.fasterxml.jackson.databind.introspect.MixInResolver) serializationConfig27);
        com.fasterxml.jackson.databind.introspect.Annotated annotated29 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj30 = jacksonAnnotationIntrospector5.findKeyDeserializer((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig27, annotated29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder28);
    }
}

