import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest80.test081");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = xmlFactory0.snapshot();
        xmlFactory0.setXMLTextElementName("hi!");
        java.net.URL uRL4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser5 = xmlFactory0.createParser(uRL4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
    }
}

