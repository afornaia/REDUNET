import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest88 {

    public static boolean debug = false;

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest88.test089");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version1 = jacksonXmlAnnotationIntrospector0.version();
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector3 = jacksonXmlAnnotationIntrospector0.setConstructorPropertiesImpliesCreator(false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper4 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = xmlMapper4.writer(filterProvider5);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = xmlMapper4.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray8 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = builder7.addModules(moduleArray8);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides10 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler11 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory12 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector13 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver14 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup15 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider16 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig17 = builder9.buildSerializationConfig(configOverrides10, mixInHandler11, typeFactory12, classIntrospector13, subtypeResolver14, rootNameLookup15, filterProvider16);
        com.fasterxml.jackson.databind.introspect.AnnotatedMethod annotatedMethod18 = null;
        com.fasterxml.jackson.databind.introspect.AnnotatedMethod annotatedMethod19 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.introspect.AnnotatedMethod annotatedMethod20 = jacksonAnnotationIntrospector3.resolveSetterConflict((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig17, annotatedMethod18, annotatedMethod19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig17);
    }
}

