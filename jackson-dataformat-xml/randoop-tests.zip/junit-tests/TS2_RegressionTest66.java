import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest66.test067");
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator0 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping1 = null;
        com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder defaultingXmlTypeResolverBuilder3 = new com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder(polymorphicTypeValidator0, defaultTyping1, "");
        boolean boolean4 = defaultingXmlTypeResolverBuilder3.isTypeIdVisible();
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder5 = com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder.noTypeInfoBuilder();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider6 = null;
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray8 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList9 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean10 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList9, namedTypeArray8);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer11 = stdTypeResolverBuilder5.buildTypeSerializer(serializerProvider6, javaType7, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList9);
        java.lang.String str12 = stdTypeResolverBuilder5.getTypeProperty();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper13 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider14 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter15 = xmlMapper13.writer(filterProvider14);
        java.util.Collection<com.fasterxml.jackson.databind.Module> moduleCollection16 = xmlMapper13.getRegisteredModules();
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext17 = xmlMapper13._deserializationContext();
        com.fasterxml.jackson.databind.JavaType javaType18 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder19 = com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder.noTypeInfoBuilder();
        com.fasterxml.jackson.databind.SerializerProvider serializerProvider20 = null;
        com.fasterxml.jackson.databind.JavaType javaType21 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray22 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList23 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList23, namedTypeArray22);
        com.fasterxml.jackson.databind.jsontype.TypeSerializer typeSerializer25 = stdTypeResolverBuilder19.buildTypeSerializer(serializerProvider20, javaType21, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList23);
        com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer26 = stdTypeResolverBuilder5.buildTypeDeserializer((com.fasterxml.jackson.databind.DeserializationContext) defaultDeserializationContext17, javaType18, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList23);
        com.fasterxml.jackson.databind.JavaType javaType27 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray28 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList29 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean30 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList29, namedTypeArray28);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer31 = defaultingXmlTypeResolverBuilder3.buildTypeDeserializer((com.fasterxml.jackson.databind.DeserializationContext) defaultDeserializationContext17, javaType27, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(typeSerializer11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleCollection16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(defaultDeserializationContext17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(typeSerializer25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(typeDeserializer26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }
}

