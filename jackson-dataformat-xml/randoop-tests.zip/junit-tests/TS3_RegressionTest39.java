import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest39.test040");
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator0 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping1 = null;
        com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder defaultingXmlTypeResolverBuilder3 = new com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder(polymorphicTypeValidator0, defaultTyping1, "hi!");
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext4 = null;
        com.fasterxml.jackson.databind.JavaType javaType5 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray6 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList7 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean8 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList7, namedTypeArray6);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer9 = defaultingXmlTypeResolverBuilder3.buildTypeDeserializer(deserializationContext4, javaType5, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }
}

