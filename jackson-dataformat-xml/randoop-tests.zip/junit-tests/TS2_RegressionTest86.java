import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest86.test087");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider1 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter2 = xmlMapper0.writer(filterProvider1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = xmlMapper0.rebuild();
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.activateDefaultTyping(polymorphicTypeValidator4);
        com.fasterxml.jackson.databind.SerializationFeature[] serializationFeatureArray6 = new com.fasterxml.jackson.databind.SerializationFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder3.disable(serializationFeatureArray6);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter8 = builder3.defaultPrettyPrinter();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationFeatureArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(prettyPrinter8);
    }
}

