import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest73.test74");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader2 = xmlMapper0.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.ObjectWriter objectWriter3 = xmlMapper0.writer();
        com.fasterxml.jackson.databind.InjectableValues injectableValues4 = xmlMapper0.getInjectableValues();
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 100, (byte) 100 };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser11 = xmlMapper0.createParser(byteArray8, 100, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(injectableValues4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
    }
}

