import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest63.test64");
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector0 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation1 = null;
        boolean boolean2 = annotationIntrospector0.isAnnotationBundle(annotation1);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector3 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair4 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector0, annotationIntrospector3);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector5 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation6 = null;
        boolean boolean7 = annotationIntrospector5.isAnnotationBundle(annotation6);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector8 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair9 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector5, annotationIntrospector8);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper10 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader12 = xmlMapper10.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig13 = xmlMapper10.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated14 = null;
        java.util.List<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList15 = pair9.findSubtypes((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig13, annotated14);
        com.fasterxml.jackson.databind.introspect.Annotated annotated16 = null;
        java.lang.Object obj17 = pair4.findTypeResolverBuilder((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig13, annotated16);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector18 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation19 = null;
        boolean boolean20 = annotationIntrospector18.isAnnotationBundle(annotation19);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector21 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair22 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector18, annotationIntrospector21);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector23 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation24 = null;
        boolean boolean25 = annotationIntrospector23.isAnnotationBundle(annotation24);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector26 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair27 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector23, annotationIntrospector26);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper28 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader30 = xmlMapper28.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig31 = xmlMapper28.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated32 = null;
        java.util.List<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList33 = pair27.findSubtypes((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig31, annotated32);
        com.fasterxml.jackson.databind.introspect.Annotated annotated34 = null;
        java.lang.Object obj35 = pair22.findTypeResolverBuilder((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig31, annotated34);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector36 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation37 = null;
        boolean boolean38 = annotationIntrospector36.isAnnotationBundle(annotation37);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector39 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair40 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector36, annotationIntrospector39);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper41 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader43 = xmlMapper41.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig44 = xmlMapper41.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField45 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName46 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName47 = pair40.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotatedField45, propertyName46);
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass48 = null;
        java.lang.Class<?> wildcardClass49 = pair22.findPOJOBuilder((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotatedClass48);
        com.fasterxml.jackson.databind.introspect.Annotated annotated50 = null;
        java.lang.Boolean boolean51 = pair4.hasAsValue((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotated50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(namedTypeList15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig31);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(namedTypeList33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardClass49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean51);
    }
}

