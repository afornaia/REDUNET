import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest112.test113");
        com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector jaxbAnnotationIntrospector0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper jaxbWrapper1 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper(jaxbAnnotationIntrospector0);
        jaxbWrapper1.setDefaultUseWrapper(true);
        com.fasterxml.jackson.databind.introspect.Annotated annotated4 = null;
        java.lang.Boolean boolean5 = jaxbWrapper1.isOutputAsCData(annotated4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean5);
    }
}

