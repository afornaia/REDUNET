import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest64 {

    public static boolean debug = false;

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest64.test065");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        java.lang.Class<com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature> featureClass2 = xmlFactory1.getFormatReadFeatureType();
        int int3 = xmlFactory1.getStreamWriteFeatures();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureClass2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 7 + "'", int3 == 7);
    }
}

