import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest89.test090");
        com.fasterxml.jackson.databind.deser.BeanDeserializerBase beanDeserializerBase0 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext2 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext5 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) (byte) 100, xmlReadContext2, 7, 7);
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        xmlReadContext5.setNamesToWrap((java.util.Set<java.lang.String>) strSet10);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.deser.WrapperHandlingDeserializer wrapperHandlingDeserializer13 = new com.fasterxml.jackson.dataformat.xml.deser.WrapperHandlingDeserializer(beanDeserializerBase0, (java.util.Set<java.lang.String>) strSet10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }
}

