import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest54.test55");
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer0 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer1 = xmlStringDeserializer0.getDelegatee();
        com.fasterxml.jackson.core.JsonParser jsonParser2 = null;
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = xmlStringDeserializer0.deserialize(jsonParser2, deserializationContext3, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardJsonDeserializer1);
    }
}

