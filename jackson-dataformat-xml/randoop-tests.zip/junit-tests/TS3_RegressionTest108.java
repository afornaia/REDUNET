import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest108.test109");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory1);
        com.fasterxml.jackson.databind.deser.DeserializerFactory deserializerFactory4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.deserializerFactory(deserializerFactory4);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter6 = builder5.defaultPrettyPrinter();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = builder5.defaultMergeable((java.lang.Boolean) true);
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator9 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping10 = null;
        com.fasterxml.jackson.annotation.JsonTypeInfo.As as11 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = builder8.activateDefaultTyping(polymorphicTypeValidator9, defaultTyping10, as11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(prettyPrinter6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
    }
}

