import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest37.test38");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean1 = builder0.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray2 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = builder0.disable(streamWriteFeatureArray2);
        com.fasterxml.jackson.core.StreamReadFeature streamReadFeature4 = null;
        com.fasterxml.jackson.core.StreamReadFeature[] streamReadFeatureArray5 = new com.fasterxml.jackson.core.StreamReadFeature[] { streamReadFeature4 };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder6 = builder3.enable(streamReadFeatureArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamReadFeatureArray5);
    }
}

