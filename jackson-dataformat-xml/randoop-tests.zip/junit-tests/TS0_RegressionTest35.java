import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest35.test36");
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector0 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation1 = null;
        boolean boolean2 = annotationIntrospector0.isAnnotationBundle(annotation1);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector3 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation4 = null;
        boolean boolean5 = annotationIntrospector3.isAnnotationBundle(annotation4);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector6 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation7 = null;
        boolean boolean8 = annotationIntrospector6.isAnnotationBundle(annotation7);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector9 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair10 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector6, annotationIntrospector9);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector11 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector12 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation13 = null;
        boolean boolean14 = annotationIntrospector12.isAnnotationBundle(annotation13);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector15 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair16 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector12, annotationIntrospector15);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector17 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation18 = null;
        boolean boolean19 = annotationIntrospector17.isAnnotationBundle(annotation18);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector20 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair21 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector17, annotationIntrospector20);
        com.fasterxml.jackson.databind.AnnotationIntrospector[] annotationIntrospectorArray22 = new com.fasterxml.jackson.databind.AnnotationIntrospector[] { annotationIntrospector3, annotationIntrospector9, annotationIntrospector11, annotationIntrospector12, annotationIntrospector17 };
        java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorList23 = new java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector>();
        boolean boolean24 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList23, annotationIntrospectorArray22);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection25 = annotationIntrospector0.allIntrospectors((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection25);
    }
}

