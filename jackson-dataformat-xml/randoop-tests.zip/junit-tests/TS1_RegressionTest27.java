import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest27.test028");
        com.fasterxml.jackson.dataformat.xml.util.XmlInfo xmlInfo4 = new com.fasterxml.jackson.dataformat.xml.util.XmlInfo((java.lang.Boolean) false, "hi!", (java.lang.Boolean) false, (java.lang.Boolean) false);
        java.lang.String str5 = xmlInfo4.getNamespace();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }
}

