import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest94 {

    public static boolean debug = false;

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest94.test095");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider1 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter2 = xmlMapper0.writer(filterProvider1);
        java.util.Collection<com.fasterxml.jackson.databind.Module> moduleCollection3 = xmlMapper0.getRegisteredModules();
        com.fasterxml.jackson.databind.deser.DefaultDeserializationContext defaultDeserializationContext4 = xmlMapper0._deserializationContext();
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes5 = null;
        com.fasterxml.jackson.databind.ObjectReader objectReader6 = xmlMapper0.reader(contextAttributes5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleCollection3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(defaultDeserializationContext4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader6);
    }
}

