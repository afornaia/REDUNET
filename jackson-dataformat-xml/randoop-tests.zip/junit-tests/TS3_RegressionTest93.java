import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest93.test094");
        com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts xmlSerializationContexts0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector2 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector4 = jacksonXmlAnnotationIntrospector2.setConstructorPropertiesImpliesCreator(false);
        javax.xml.stream.XMLInputFactory xMLInputFactory5 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory6 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory5);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder7 = xmlFactory6.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory8 = xmlFactory6.copy();
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory9 = null;
        com.fasterxml.jackson.databind.ser.SerializerCache serializerCache10 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts11 = xmlSerializationContexts0.forMapper((java.lang.Object) false, (com.fasterxml.jackson.core.TokenStreamFactory) xmlFactory6, serializerFactory9, serializerCache10);
        javax.xml.stream.XMLInputFactory xMLInputFactory12 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory13 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory12);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder14 = xmlFactory13.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory13);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder17 = builder15.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides18 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler19 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory20 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector21 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver22 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup23 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider24 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig25 = builder17.buildSerializationConfig(configOverrides18, mixInHandler19, typeFactory20, classIntrospector21, subtypeResolver22, rootNameLookup23, filterProvider24);
        com.fasterxml.jackson.databind.cfg.GeneratorSettings generatorSettings26 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.ser.DefaultSerializerProvider defaultSerializerProvider27 = xmlSerializationContexts0.createContext(serializationConfig25, generatorSettings26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig25);
    }
}

