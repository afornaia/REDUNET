import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest75.test076");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector3 = jacksonXmlAnnotationIntrospector1.setConstructorPropertiesImpliesCreator(false);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector5 = jacksonAnnotationIntrospector3.setConstructorPropertiesImpliesCreator(true);
        javax.xml.stream.XMLInputFactory xMLInputFactory6 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory7 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory6);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder8 = xmlFactory7.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory7);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = builder9.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides12 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler13 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory14 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector15 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver16 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup17 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider18 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig19 = builder11.buildSerializationConfig(configOverrides12, mixInHandler13, typeFactory14, classIntrospector15, subtypeResolver16, rootNameLookup17, filterProvider18);
        com.fasterxml.jackson.databind.introspect.Annotated annotated20 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.annotation.JsonTypeInfo.Value value21 = jacksonAnnotationIntrospector3.findPolymorphicTypeInfo((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig19, annotated20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig19);
    }
}

