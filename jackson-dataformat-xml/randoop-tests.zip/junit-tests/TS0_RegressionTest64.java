import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest64 {

    public static boolean debug = false;

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest64.test65");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        boolean boolean3 = xmlFactory2.canParseAsync();
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder4 = xmlFactory2.rebuild();
        com.fasterxml.jackson.core.StreamWriteFeature streamWriteFeature5 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder7 = xmlFactoryBuilder4.configure(streamWriteFeature5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder4);
    }
}

