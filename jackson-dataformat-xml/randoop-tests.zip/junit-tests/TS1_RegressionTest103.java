import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest103.test104");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder2 = builder0.activateDefaultTyping(polymorphicTypeValidator1);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory3 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder0.serializerFactory(serializerFactory3);
        com.fasterxml.jackson.databind.cfg.BaseSettings baseSettings5 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder6 = builder0.baseSettings(baseSettings5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder6);
    }
}

