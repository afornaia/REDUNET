import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest90.test091");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        boolean boolean1 = xmlFactory0.canHandleBinaryNatively();
        int int2 = xmlFactory0.getStreamReadFeatures();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }
}

