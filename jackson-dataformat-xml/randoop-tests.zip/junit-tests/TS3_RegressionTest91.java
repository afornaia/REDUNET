import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest91 {

    public static boolean debug = false;

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest91.test092");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.core.io.InputDecorator inputDecorator3 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder4 = xmlFactoryBuilder2.inputDecorator(inputDecorator3);
        javax.xml.stream.XMLInputFactory xMLInputFactory5 = xmlFactoryBuilder4.inputFactory();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLInputFactory5);
    }
}

