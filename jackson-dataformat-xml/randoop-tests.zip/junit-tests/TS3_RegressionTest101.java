import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest101.test102");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector3 = jacksonXmlAnnotationIntrospector1.setConstructorPropertiesImpliesCreator(false);
        javax.xml.stream.XMLInputFactory xMLInputFactory4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory5 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory4);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder6 = xmlFactory5.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory5);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = builder7.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory10 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = builder7.serializerFactory(serializerFactory10);
        javax.xml.stream.XMLInputFactory xMLInputFactory12 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory13 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory12);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder14 = xmlFactory13.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory13);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder17 = builder15.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides18 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler19 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory20 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector21 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver22 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup23 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider24 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig25 = builder17.buildSerializationConfig(configOverrides18, mixInHandler19, typeFactory20, classIntrospector21, subtypeResolver22, rootNameLookup23, filterProvider24);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder26 = builder7.mixInOverrides((com.fasterxml.jackson.databind.introspect.MixInResolver) serializationConfig25);
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass27 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder.Value value28 = jacksonXmlAnnotationIntrospector1.findPOJOBuilderConfig((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig25, annotatedClass27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder26);
    }
}

