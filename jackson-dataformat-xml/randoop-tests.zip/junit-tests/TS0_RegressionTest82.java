import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest82.test83");
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer0 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext1 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty2 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer3 = xmlStringDeserializer0.createContextual(deserializationContext1, beanProperty2);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext4 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty5 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer6 = xmlStringDeserializer0.createContextual(deserializationContext4, beanProperty5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer6);
    }
}

