import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest34.test35");
        com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier xmlBeanDeserializerModifier1 = new com.fasterxml.jackson.dataformat.xml.deser.XmlBeanDeserializerModifier("hi!");
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig2 = null;
        com.fasterxml.jackson.databind.type.CollectionType collectionType3 = null;
        com.fasterxml.jackson.databind.BeanDescription beanDescription4 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer5 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer6 = xmlBeanDeserializerModifier1.modifyCollectionDeserializer(deserializationConfig2, collectionType3, beanDescription4, (com.fasterxml.jackson.databind.JsonDeserializer<java.lang.String>) xmlStringDeserializer5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer6);
    }
}

