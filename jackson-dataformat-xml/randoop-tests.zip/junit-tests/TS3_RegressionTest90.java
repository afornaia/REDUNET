import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest90.test091");
        java.lang.String str0 = com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializerBase.KEY_XML_INFO;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "xmlInfo" + "'", str0.equals("xmlInfo"));
    }
}

