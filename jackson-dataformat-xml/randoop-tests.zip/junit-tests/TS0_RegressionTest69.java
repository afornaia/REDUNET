import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest69.test70");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory3 = xmlFactory2.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory2);
        int int5 = xmlFactory2.getFormatWriteFeatures();
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext6 = null;
        char[] charArray13 = new char[] { ' ', '4', '#', '4', 'a', '4' };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser14 = xmlFactory2.createParser(objectReadContext6, charArray13);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Unexpected character '4' (code 52) in prolog; expected '<'\n at [row,col {unknown-source}]: [1,2]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray13);
    }
}

