import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest65.test66");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory3 = xmlFactory2.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory2);
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature5 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature6 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature7 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature8 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] featureArray9 = new com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] { feature5, feature6, feature7, feature8 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder10 = builder4.disable(featureArray9);
        com.fasterxml.jackson.databind.SerializationFeature[] serializationFeatureArray11 = new com.fasterxml.jackson.databind.SerializationFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = builder10.disable(serializationFeatureArray11);
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector13 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder14 = builder10.classIntrospector(classIntrospector13);
        java.util.function.UnaryOperator<com.fasterxml.jackson.databind.introspect.VisibilityChecker> visibilityCheckerUnaryOperator15 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder16 = builder14.changeDefaultVisibility(visibilityCheckerUnaryOperator15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory3);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature6 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature6.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature7.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature8 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature8.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationFeatureArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder14);
    }
}

