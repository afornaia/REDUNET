import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest73.test074");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory1);
        com.fasterxml.jackson.databind.deser.DeserializerFactory deserializerFactory4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.deserializerFactory(deserializerFactory4);
        com.fasterxml.jackson.core.PrettyPrinter prettyPrinter6 = builder5.defaultPrettyPrinter();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = builder5.defaultMergeable((java.lang.Boolean) true);
        com.fasterxml.jackson.databind.DeserializationFeature deserializationFeature9 = null;
        com.fasterxml.jackson.databind.DeserializationFeature[] deserializationFeatureArray10 = new com.fasterxml.jackson.databind.DeserializationFeature[] { deserializationFeature9 };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = builder5.enable(deserializationFeatureArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(prettyPrinter6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationFeatureArray10);
    }
}

