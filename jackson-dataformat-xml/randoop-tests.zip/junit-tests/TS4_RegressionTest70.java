import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest70.test71");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean1 = builder0.defaultUseWrapper();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper2 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder0);
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory3 = xmlMapper2.getTypeFactory();
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes4 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter5 = xmlMapper2.writer(contextAttributes4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(typeFactory3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter5);
    }
}

