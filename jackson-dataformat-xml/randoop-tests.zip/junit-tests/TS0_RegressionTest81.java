import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest81.test82");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory3 = xmlFactory2.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory2);
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature5 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature6 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature7 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature8 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] featureArray9 = new com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] { feature5, feature6, feature7, feature8 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder10 = builder4.disable(featureArray9);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature11 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        boolean boolean13 = feature11.enabledIn((int) (short) 1);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature14 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        boolean boolean16 = feature14.enabledIn((int) (short) 1);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature17 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        boolean boolean19 = feature17.enabledIn((int) (short) 1);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] featureArray20 = new com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] { feature11, feature14, feature17 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder21 = builder10.enable(featureArray20);
        com.fasterxml.jackson.databind.SerializationFeature[] serializationFeatureArray22 = new com.fasterxml.jackson.databind.SerializationFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder23 = builder10.disable(serializationFeatureArray22);
        com.fasterxml.jackson.core.StreamReadFeature[] streamReadFeatureArray24 = new com.fasterxml.jackson.core.StreamReadFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder25 = builder10.disable(streamReadFeatureArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory3);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature6 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature6.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature7 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature7.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature8 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature8.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder10);
        org.junit.Assert.assertTrue("'" + feature11 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature11.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature14.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + feature17 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature17.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationFeatureArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamReadFeatureArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder25);
    }
}

