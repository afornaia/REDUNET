import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest66.test067");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = xmlFactory0.snapshot();
        java.io.DataOutput dataOutput2 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator3 = tokenStreamFactory1.createGenerator(dataOutput2);
        com.fasterxml.jackson.core.FormatSchema formatSchema4 = null;
        boolean boolean5 = jsonGenerator3.canUseSchema(formatSchema4);
        java.lang.String[] strArray9 = new java.lang.String[] { "hi!", "xmlInfo", "" };
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator3.writeArray(strArray9, 55296, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: invalid argument(s) (offset=55296, length=0) for input array of 3 element");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
    }
}

