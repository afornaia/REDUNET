import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest87.test088");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair2 = com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair.instance((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection3 = pair2.allIntrospectors();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector4 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version5 = jacksonXmlAnnotationIntrospector4.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector6 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version7 = jacksonXmlAnnotationIntrospector6.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector8 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version9 = jacksonXmlAnnotationIntrospector8.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector11 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.AnnotationIntrospector[] annotationIntrospectorArray12 = new com.fasterxml.jackson.databind.AnnotationIntrospector[] { jacksonXmlAnnotationIntrospector6, jacksonXmlAnnotationIntrospector8, jacksonXmlAnnotationIntrospector11 };
        java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorList13 = new java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList13, annotationIntrospectorArray12);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection15 = jacksonXmlAnnotationIntrospector4.allIntrospectors((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList13);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection16 = pair2.allIntrospectors(annotationIntrospectorCollection15);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection17 = pair2.allIntrospectors();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper18 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider19 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter20 = xmlMapper18.writer(filterProvider19);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder21 = xmlMapper18.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray22 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder23 = builder21.addModules(moduleArray22);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides24 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler25 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory26 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector27 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver28 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup29 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider30 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig31 = builder23.buildSerializationConfig(configOverrides24, mixInHandler25, typeFactory26, classIntrospector27, subtypeResolver28, rootNameLookup29, filterProvider30);
        com.fasterxml.jackson.databind.introspect.Annotated annotated32 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean33 = pair2.findMergeInfo((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig31, annotated32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(pair2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig31);
    }
}

