import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest61.test62");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        java.lang.String str2 = xmlFactory1.getXMLTextElementName();
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext3 = null;
        java.io.InputStream inputStream4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser5 = xmlFactory1.createParser(objectReadContext3, inputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null InputStream is not a valid argument");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str2);
    }
}

