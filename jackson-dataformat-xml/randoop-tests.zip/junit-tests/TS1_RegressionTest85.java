import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest85.test086");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        int int1 = xmlFactory0.getStreamReadFeatures();
        java.io.InputStream inputStream2 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser3 = xmlFactory0.createParser(inputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null InputStream is not a valid argument");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }
}

