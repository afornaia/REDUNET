import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest58.test59");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder2 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean3 = builder2.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray4 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder2.disable(streamWriteFeatureArray4);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature6 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = builder2.configure(feature6, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper9 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder2);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig10 = xmlMapper9.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass11 = null;
        java.lang.Boolean boolean12 = xmlJaxbAnnotationIntrospector1.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig10, annotatedClass11);
        com.fasterxml.jackson.databind.introspect.Annotated annotated13 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean14 = xmlJaxbAnnotationIntrospector0.findSerializationSortAlphabetically((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig10, annotated13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        org.junit.Assert.assertTrue("'" + feature6 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature6.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean12);
    }
}

