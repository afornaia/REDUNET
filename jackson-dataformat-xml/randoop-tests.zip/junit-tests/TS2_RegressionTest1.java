import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest1.test002");
        com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializerBase xmlBeanSerializerBase0 = null;
        com.fasterxml.jackson.databind.ser.impl.ObjectIdWriter objectIdWriter1 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializer xmlBeanSerializer3 = new com.fasterxml.jackson.dataformat.xml.ser.XmlBeanSerializer(xmlBeanSerializerBase0, objectIdWriter1, (java.lang.Object) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

