import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest26.test027");
        com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter defaultXmlPrettyPrinter0 = new com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter();
        org.codehaus.stax2.XMLStreamWriter2 xMLStreamWriter2_1 = null;
        // The following exception was thrown during execution in test generation
        try {
            defaultXmlPrettyPrinter0.writeLeafElement(xMLStreamWriter2_1, "XML", "XML", (long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

