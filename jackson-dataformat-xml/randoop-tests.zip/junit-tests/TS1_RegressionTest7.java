import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest7.test008");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory1 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory2 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory1);
        com.fasterxml.jackson.core.ObjectReadContext objectReadContext3 = null;
        java.io.DataInput dataInput4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser5 = xmlFactory2.createParser(objectReadContext3, dataInput4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Operation not supported for this format (XML)");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
    }
}

