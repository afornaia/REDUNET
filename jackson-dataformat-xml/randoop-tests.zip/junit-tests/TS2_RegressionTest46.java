import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest46.test047");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator1 = null;
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector2 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version3 = jacksonXmlAnnotationIntrospector2.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector4 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version5 = jacksonXmlAnnotationIntrospector4.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector6 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version7 = jacksonXmlAnnotationIntrospector6.version();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector9 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.AnnotationIntrospector[] annotationIntrospectorArray10 = new com.fasterxml.jackson.databind.AnnotationIntrospector[] { jacksonXmlAnnotationIntrospector4, jacksonXmlAnnotationIntrospector6, jacksonXmlAnnotationIntrospector9 };
        java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorList11 = new java.util.ArrayList<com.fasterxml.jackson.databind.AnnotationIntrospector>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList11, annotationIntrospectorArray10);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection13 = jacksonXmlAnnotationIntrospector2.allIntrospectors((java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector>) annotationIntrospectorList11);
        // The following exception was thrown during execution in test generation
        try {
            xmlMapper0.writeValue(jsonGenerator1, (java.lang.Object) jacksonXmlAnnotationIntrospector2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: argument \"g\" is null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection13);
    }
}

