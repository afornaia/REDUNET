import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest14.test015");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(false);
        com.fasterxml.jackson.databind.introspect.AnnotatedMember annotatedMember2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil.findNamespaceAnnotation((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1, annotatedMember2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

