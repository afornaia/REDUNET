import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest67.test068");
        com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts xmlSerializationContexts0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector2 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector jacksonAnnotationIntrospector4 = jacksonXmlAnnotationIntrospector2.setConstructorPropertiesImpliesCreator(false);
        javax.xml.stream.XMLInputFactory xMLInputFactory5 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory6 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory5);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder7 = xmlFactory6.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory8 = xmlFactory6.copy();
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory9 = null;
        com.fasterxml.jackson.databind.ser.SerializerCache serializerCache10 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts11 = xmlSerializationContexts0.forMapper((java.lang.Object) false, (com.fasterxml.jackson.core.TokenStreamFactory) xmlFactory6, serializerFactory9, serializerCache10);
        java.io.InputStream inputStream12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser13 = xmlFactory6.createParser(inputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null InputStream is not a valid argument");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jacksonAnnotationIntrospector4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts11);
    }
}

