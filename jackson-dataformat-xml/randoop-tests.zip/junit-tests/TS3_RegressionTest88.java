import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest88 {

    public static boolean debug = false;

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest88.test089");
        com.fasterxml.jackson.dataformat.xml.PackageVersion packageVersion0 = new com.fasterxml.jackson.dataformat.xml.PackageVersion();
        com.fasterxml.jackson.core.Version version1 = packageVersion0.version();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version1);
    }
}

