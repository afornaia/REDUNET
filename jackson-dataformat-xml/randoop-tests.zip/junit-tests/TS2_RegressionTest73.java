import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest73.test074");
        com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts xmlSerializationContexts0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts();
        com.fasterxml.jackson.dataformat.xml.PackageVersion packageVersion1 = new com.fasterxml.jackson.dataformat.xml.PackageVersion();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory2 = null;
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory3 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts4 = xmlSerializationContexts0.forMapper((java.lang.Object) packageVersion1, tokenStreamFactory2, serializerFactory3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts4);
    }
}

