import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest38.test039");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = xmlFactory0.snapshot();
        java.io.DataOutput dataOutput2 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator3 = tokenStreamFactory1.createGenerator(dataOutput2);
        int[] intArray10 = new int[] { 1, (byte) 10, 55296, 10, 'a', '#' };
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator3.writeArray(intArray10, 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: invalid argument(s) (offset=0, length=100) for input array of 6 element");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(intArray10);
    }
}

