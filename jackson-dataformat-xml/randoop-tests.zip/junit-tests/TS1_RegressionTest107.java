import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest107.test108");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        jacksonXmlAnnotationIntrospector0.setDefaultUseWrapper(false);
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector3 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector5 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version6 = jacksonXmlAnnotationIntrospector5.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder4.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector5);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector8 = com.fasterxml.jackson.databind.AnnotationIntrospector.pair((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector3, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector5);
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair9 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector5);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder10 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector11 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version12 = jacksonXmlAnnotationIntrospector11.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder13 = builder10.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector11);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides14 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler15 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory16 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector17 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver18 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup19 = null;
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig20 = builder10.buildDeserializationConfig(configOverrides14, mixInHandler15, typeFactory16, classIntrospector17, subtypeResolver18, rootNameLookup19);
        com.fasterxml.jackson.databind.introspect.Annotated annotated21 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Integer int22 = jacksonXmlAnnotationIntrospector0.findPropertyIndex((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig20, annotated21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig20);
    }
}

