import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest63.test64");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        java.lang.String str2 = xmlFactory1.getXMLTextElementName();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory4 = xmlFactory1.withNameForTextElement("XML");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory4);
    }
}

