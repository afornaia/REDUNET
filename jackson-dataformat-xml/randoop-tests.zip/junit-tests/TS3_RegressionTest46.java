import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest46.test047");
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator0 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping1 = null;
        com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder defaultingXmlTypeResolverBuilder3 = new com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder(polymorphicTypeValidator0, defaultTyping1, "hi!");
        com.fasterxml.jackson.databind.jsontype.impl.DefaultTypeResolverBuilder defaultTypeResolverBuilder5 = defaultingXmlTypeResolverBuilder3.typeIdVisibility(true);
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext6 = null;
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder8 = com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder.noTypeInfoBuilder();
        java.lang.String str9 = stdTypeResolverBuilder8.getTypeProperty();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext10 = null;
        com.fasterxml.jackson.databind.JavaType javaType11 = null;
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray12 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType> namedTypeList13 = new java.util.ArrayList<com.fasterxml.jackson.databind.jsontype.NamedType>();
        boolean boolean14 = java.util.Collections.addAll((java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList13, namedTypeArray12);
        com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer15 = stdTypeResolverBuilder8.buildTypeDeserializer(deserializationContext10, javaType11, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList13);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.jsontype.TypeDeserializer typeDeserializer16 = defaultingXmlTypeResolverBuilder3.buildTypeDeserializer(deserializationContext6, javaType7, (java.util.Collection<com.fasterxml.jackson.databind.jsontype.NamedType>) namedTypeList13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(defaultTypeResolverBuilder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(typeDeserializer15);
    }
}

