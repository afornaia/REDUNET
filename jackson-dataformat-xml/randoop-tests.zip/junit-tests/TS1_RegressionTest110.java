import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest110.test111");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder2 = builder0.nameForTextElement("");
        com.fasterxml.jackson.databind.jsontype.NamedType[] namedTypeArray3 = new com.fasterxml.jackson.databind.jsontype.NamedType[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder0.registerSubtypes(namedTypeArray3);
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector5 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        jacksonXmlAnnotationIntrospector5.setDefaultUseWrapper(false);
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector8 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector10 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version11 = jacksonXmlAnnotationIntrospector10.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = builder9.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector10);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector13 = com.fasterxml.jackson.databind.AnnotationIntrospector.pair((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector8, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector10);
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair14 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector5, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector10);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = builder4.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(namedTypeArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder15);
    }
}

