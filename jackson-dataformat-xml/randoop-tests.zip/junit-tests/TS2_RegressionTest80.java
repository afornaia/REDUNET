import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest80.test081");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider1 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter2 = xmlMapper0.writer(filterProvider1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = xmlMapper0.rebuild();
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator4 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.activateDefaultTyping(polymorphicTypeValidator4);
        com.fasterxml.jackson.databind.InjectableValues injectableValues6 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder3.injectableValues(injectableValues6);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper8 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider9 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter10 = xmlMapper8.writer(filterProvider9);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = xmlMapper8.rebuild();
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature12 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature13 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature14 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION;
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature15 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION;
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature16 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION;
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] featureArray17 = new com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] { feature12, feature13, feature14, feature15, feature16 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder18 = builder11.enable(featureArray17);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder19 = builder3.disable(featureArray17);
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler20 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder21 = builder19.mixInHandler(mixInHandler20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        org.junit.Assert.assertTrue("'" + feature12 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature12.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        org.junit.Assert.assertTrue("'" + feature13 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature13.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        org.junit.Assert.assertTrue("'" + feature14 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION + "'", feature14.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION));
        org.junit.Assert.assertTrue("'" + feature15 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION + "'", feature15.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION));
        org.junit.Assert.assertTrue("'" + feature16 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION + "'", feature16.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_XML_DECLARATION));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder21);
    }
}

