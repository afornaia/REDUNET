import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest97.test098");
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer0 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.JavaType javaType1 = xmlStringDeserializer0.getValueType();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(javaType1);
    }
}

