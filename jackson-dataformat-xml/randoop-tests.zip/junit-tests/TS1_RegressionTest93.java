import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest93.test094");
        com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts xmlSerializationContexts0 = new com.fasterxml.jackson.dataformat.xml.ser.XmlSerializationContexts();
        javax.xml.stream.XMLInputFactory xMLInputFactory2 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory3 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory4 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory2, xMLOutputFactory3);
        com.fasterxml.jackson.core.FormatSchema formatSchema5 = null;
        boolean boolean6 = xmlFactory4.canUseSchema(formatSchema5);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory7 = null;
        com.fasterxml.jackson.databind.ser.SerializerCache serializerCache8 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts9 = xmlSerializationContexts0.forMapper((java.lang.Object) 100, (com.fasterxml.jackson.core.TokenStreamFactory) xmlFactory4, serializerFactory7, serializerCache8);
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory11 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        boolean boolean12 = xmlFactory11.canHandleBinaryNatively();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory13 = xmlFactory11.copy();
        boolean boolean14 = xmlFactory13.requiresPropertyOrdering();
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory15 = null;
        com.fasterxml.jackson.databind.cfg.SerializationContexts serializationContexts16 = xmlSerializationContexts0.forMapper((java.lang.Object) '#', (com.fasterxml.jackson.core.TokenStreamFactory) xmlFactory13, serializerFactory15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactory13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationContexts16);
    }
}

