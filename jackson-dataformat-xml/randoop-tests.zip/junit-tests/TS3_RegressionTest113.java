import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest113.test114");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        int int3 = xmlFactory1.getFormatWriteFeatures();
        java.io.InputStream inputStream4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser5 = xmlFactory1.createParser(inputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null InputStream is not a valid argument");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }
}

