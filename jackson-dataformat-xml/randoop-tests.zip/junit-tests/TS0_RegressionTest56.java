import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest56.test57");
        com.fasterxml.jackson.dataformat.xml.XmlModule xmlModule0 = new com.fasterxml.jackson.dataformat.xml.XmlModule();
        java.lang.Object obj1 = xmlModule0.getRegistrationId();
        java.lang.String str2 = xmlModule0.getModuleName();
        com.fasterxml.jackson.databind.Module.SetupContext setupContext3 = null;
        // The following exception was thrown during execution in test generation
        try {
            xmlModule0.setupModule(setupContext3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj1 + "' != '" + "com.fasterxml.jackson.dataformat.xml.XmlModule" + "'", obj1.equals("com.fasterxml.jackson.dataformat.xml.XmlModule"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "com.fasterxml.jackson.dataformat.xml.XmlModule" + "'", str2.equals("com.fasterxml.jackson.dataformat.xml.XmlModule"));
    }
}

