import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest107 {

    public static boolean debug = false;

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest107.test108");
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext2 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext5 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) (byte) 100, xmlReadContext2, 7, 7);
        java.lang.String[] strArray9 = new java.lang.String[] { "", "hi!", "hi!" };
        java.util.LinkedHashSet<java.lang.String> strSet10 = new java.util.LinkedHashSet<java.lang.String>();
        boolean boolean11 = java.util.Collections.addAll((java.util.Collection<java.lang.String>) strSet10, strArray9);
        xmlReadContext5.setNamesToWrap((java.util.Set<java.lang.String>) strSet10);
        com.fasterxml.jackson.core.JsonPointer jsonPointer13 = xmlReadContext5.pathAsPointer();
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext16 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext(6, xmlReadContext5, (int) (short) 1, 0);
        com.fasterxml.jackson.core.JsonPointer jsonPointer17 = xmlReadContext16.pathAsPointer();
        xmlReadContext16.setCurrentName("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonPointer17);
    }
}

