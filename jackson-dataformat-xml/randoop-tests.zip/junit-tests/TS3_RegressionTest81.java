import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest81.test082");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        javax.xml.stream.XMLInputFactory xMLInputFactory2 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory3 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory2);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder4 = xmlFactory3.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory3);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder5.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides8 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler9 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory10 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector11 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver12 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup13 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider14 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig15 = builder7.buildSerializationConfig(configOverrides8, mixInHandler9, typeFactory10, classIntrospector11, subtypeResolver12, rootNameLookup13, filterProvider14);
        com.fasterxml.jackson.databind.introspect.Annotated annotated16 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean17 = jacksonXmlAnnotationIntrospector1.hasAnySetter((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig15, annotated16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig15);
    }
}

