import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest41.test042");
        com.fasterxml.jackson.core.ObjectWriteContext objectWriteContext0 = null;
        com.fasterxml.jackson.core.io.IOContext iOContext1 = null;
        javax.xml.stream.XMLStreamWriter xMLStreamWriter4 = null;
        com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter defaultXmlPrettyPrinter5 = new com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter();
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = null;
        defaultXmlPrettyPrinter5.writeObjectEntrySeparator(jsonGenerator6);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator toXmlGenerator8 = new com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator(objectWriteContext0, iOContext1, (int) 'a', (int) (short) 10, xMLStreamWriter4, (com.fasterxml.jackson.dataformat.xml.XmlPrettyPrinter) defaultXmlPrettyPrinter5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

