import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest77 {

    public static boolean debug = false;

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest77.test078");
        com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter defaultXmlPrettyPrinter0 = new com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter();
        defaultXmlPrettyPrinter0.spacesInObjectEntries(true);
        org.codehaus.stax2.XMLStreamWriter2 xMLStreamWriter2_3 = null;
        byte[] byteArray12 = new byte[] { (byte) 0, (byte) -1, (byte) 100, (byte) -1, (byte) 10, (byte) 1 };
        // The following exception was thrown during execution in test generation
        try {
            defaultXmlPrettyPrinter0.writeLeafElement(xMLStreamWriter2_3, "", "xmlInfo", byteArray12, (int) ' ', 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
    }
}

