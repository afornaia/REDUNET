import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest38.test039");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader1 = xmlMapper0.reader();
        char[] charArray8 = new char[] { ' ', '#', 'a', '4', '#', 'a' };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonParser jsonParser11 = xmlMapper0.createParser(charArray8, (int) (byte) 0, 100);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Unexpected character '#' (code 35) in prolog; expected '<'\n at [row,col {unknown-source}]: [1,2]");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray8);
    }
}

