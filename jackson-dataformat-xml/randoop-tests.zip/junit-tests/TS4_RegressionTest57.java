import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest57 {

    public static boolean debug = false;

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest57.test58");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean1 = builder0.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray2 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = builder0.disable(streamWriteFeatureArray2);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature4 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder6 = builder0.configure(feature4, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper7 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder0);
        java.lang.String str9 = xmlMapper7.writeValueAsString((java.lang.Object) 0L);
        com.fasterxml.jackson.databind.cfg.ContextAttributes contextAttributes10 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter11 = xmlMapper7.writer(contextAttributes10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        org.junit.Assert.assertTrue("'" + feature4 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature4.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "<Long>0</Long>" + "'", str9.equals("<Long>0</Long>"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter11);
    }
}

