import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest50.test51");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.core.FormatSchema formatSchema1 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter2 = xmlMapper0.writer(formatSchema1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter2);
    }
}

