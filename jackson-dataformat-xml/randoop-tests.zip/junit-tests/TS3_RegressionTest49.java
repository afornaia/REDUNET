import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest49.test050");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory1);
        java.util.function.UnaryOperator<com.fasterxml.jackson.databind.introspect.VisibilityChecker> visibilityCheckerUnaryOperator4 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.changeDefaultVisibility(visibilityCheckerUnaryOperator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
    }
}

