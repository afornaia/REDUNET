import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest104.test105");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder2 = xmlFactory1.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = builder3.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides6 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler7 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory8 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector9 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver10 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup11 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider12 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig13 = builder5.buildSerializationConfig(configOverrides6, mixInHandler7, typeFactory8, classIntrospector9, subtypeResolver10, rootNameLookup11, filterProvider12);
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator14 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping15 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder16 = builder5.activateDefaultTyping(polymorphicTypeValidator14, defaultTyping15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder16);
    }
}

