import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest40.test41");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder1 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean2 = builder1.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray3 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder1.disable(streamWriteFeatureArray3);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature5 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder1.configure(feature5, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper8 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder1);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig9 = xmlMapper8.serializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated10 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.annotation.JsonCreator.Mode mode11 = jacksonXmlAnnotationIntrospector0.findCreatorAnnotation((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig9, annotated10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig9);
    }
}

