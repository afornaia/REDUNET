import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest69.test070");
        com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector jaxbAnnotationIntrospector0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper jaxbWrapper1 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper(jaxbAnnotationIntrospector0);
        com.fasterxml.jackson.databind.introspect.Annotated annotated2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean3 = jaxbWrapper1.isOutputAsText(annotated2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

