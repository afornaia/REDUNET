import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest20.test21");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean1 = builder0.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray2 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = builder0.disable(streamWriteFeatureArray2);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory4 = builder3.serializerFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean6 = builder5.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray7 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = builder5.disable(streamWriteFeatureArray7);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature9 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder11 = builder5.configure(feature9, false);
        boolean boolean13 = feature9.enabledIn((int) (byte) 10);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] featureArray14 = new com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature[] { feature9 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = builder3.enable(featureArray14);
        com.fasterxml.jackson.databind.MapperFeature mapperFeature16 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean17 = builder15.isEnabled(mapperFeature16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializerFactory4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder8);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature9.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder15);
    }
}

