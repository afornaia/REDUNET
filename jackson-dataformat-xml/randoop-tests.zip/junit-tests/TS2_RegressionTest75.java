import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest75.test076");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair2 = com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair.instance((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper3 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider4 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter5 = xmlMapper3.writer(filterProvider4);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder6 = xmlMapper3.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray7 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = builder6.addModules(moduleArray7);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides9 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler10 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory11 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector12 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver13 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup14 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider15 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig16 = builder8.buildSerializationConfig(configOverrides9, mixInHandler10, typeFactory11, classIntrospector12, subtypeResolver13, rootNameLookup14, filterProvider15);
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass17 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Class<?> wildcardClass18 = jacksonXmlAnnotationIntrospector0.findPOJOBuilder((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig16, annotatedClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(pair2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig16);
    }
}

