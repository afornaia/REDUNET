import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest78.test79");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.annotation.JsonInclude.Include include1 = null;
        com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector jaxbAnnotationIntrospector2 = xmlJaxbAnnotationIntrospector0.setNonNillableInclusion(include1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jaxbAnnotationIntrospector2);
    }
}

