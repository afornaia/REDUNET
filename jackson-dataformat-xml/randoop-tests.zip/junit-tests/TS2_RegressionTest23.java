import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest23.test024");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair2 = com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair.instance((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        com.fasterxml.jackson.databind.introspect.AnnotatedMember annotatedMember3 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean4 = com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil.findIsCDataAnnotation((com.fasterxml.jackson.databind.AnnotationIntrospector) pair2, annotatedMember3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(pair2);
    }
}

