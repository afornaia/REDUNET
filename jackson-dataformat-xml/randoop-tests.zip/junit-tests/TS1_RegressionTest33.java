import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest33.test034");
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlTypeResolverBuilder xmlTypeResolverBuilder1 = new com.fasterxml.jackson.dataformat.xml.XmlTypeResolverBuilder(value0);
        java.lang.String str2 = xmlTypeResolverBuilder1.getTypeProperty();
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value3 = null;
        com.fasterxml.jackson.databind.jsontype.TypeIdResolver typeIdResolver4 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder5 = xmlTypeResolverBuilder1.init(value3, typeIdResolver4);
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value6 = null;
        com.fasterxml.jackson.databind.jsontype.TypeIdResolver typeIdResolver7 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder8 = xmlTypeResolverBuilder1.init(value6, typeIdResolver7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder8);
    }
}

