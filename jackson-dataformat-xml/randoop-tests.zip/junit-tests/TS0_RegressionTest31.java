import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest31.test32");
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer0 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext1 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty2 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer3 = xmlStringDeserializer0.createContextual(deserializationContext1, beanProperty2);
        com.fasterxml.jackson.databind.util.AccessPattern accessPattern4 = wildcardJsonDeserializer3.getEmptyAccessPattern();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer3);
        org.junit.Assert.assertTrue("'" + accessPattern4 + "' != '" + com.fasterxml.jackson.databind.util.AccessPattern.CONSTANT + "'", accessPattern4.equals(com.fasterxml.jackson.databind.util.AccessPattern.CONSTANT));
    }
}

