import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest36.test037");
        com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector jaxbAnnotationIntrospector0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper jaxbWrapper1 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.JaxbWrapper(jaxbAnnotationIntrospector0);
        jaxbWrapper1.setDefaultUseWrapper(false);
    }
}

