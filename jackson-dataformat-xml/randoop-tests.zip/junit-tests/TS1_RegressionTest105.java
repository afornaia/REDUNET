import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest105.test106");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder1 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector2 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version3 = jacksonXmlAnnotationIntrospector2.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder1.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector2);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides5 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler6 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory7 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector8 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver9 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup10 = null;
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig11 = builder1.buildDeserializationConfig(configOverrides5, mixInHandler6, typeFactory7, classIntrospector8, subtypeResolver9, rootNameLookup10);
        com.fasterxml.jackson.databind.introspect.Annotated annotated12 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.annotation.JsonProperty.Access access13 = jacksonXmlAnnotationIntrospector0.findPropertyAccess((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig11, annotated12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig11);
    }
}

