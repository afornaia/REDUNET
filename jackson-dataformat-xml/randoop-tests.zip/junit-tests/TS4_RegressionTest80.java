import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest80.test81");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector2 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector3 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean5 = builder4.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray6 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder4.disable(streamWriteFeatureArray6);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature8 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder10 = builder4.configure(feature8, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper11 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder4);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig12 = xmlMapper11.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass13 = null;
        java.lang.Boolean boolean14 = xmlJaxbAnnotationIntrospector3.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig12, annotatedClass13);
        com.fasterxml.jackson.databind.introspect.Annotated annotated15 = null;
        java.lang.Object obj16 = xmlJaxbAnnotationIntrospector2.findContentSerializer((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig12, annotated15);
        com.fasterxml.jackson.databind.introspect.Annotated annotated17 = null;
        java.lang.Object obj18 = xmlJaxbAnnotationIntrospector1.findNullSerializer((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig12, annotated17);
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass19 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean20 = jacksonXmlAnnotationIntrospector0.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig12, annotatedClass19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        org.junit.Assert.assertTrue("'" + feature8 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature8.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj18);
    }
}

