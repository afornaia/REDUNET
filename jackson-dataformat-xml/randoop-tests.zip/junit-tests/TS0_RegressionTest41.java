import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest41.test42");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader2 = xmlMapper0.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.SerializationFeature serializationFeature3 = null;
        javax.xml.stream.XMLInputFactory xMLInputFactory4 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory5 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory6 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory4, xMLOutputFactory5);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory7 = xmlFactory6.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder8 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory6);
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature9 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature10 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature11 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature feature12 = com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL;
        com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] featureArray13 = new com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature[] { feature9, feature10, feature11, feature12 };
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder14 = builder8.disable(featureArray13);
        com.fasterxml.jackson.databind.SerializationFeature[] serializationFeatureArray15 = new com.fasterxml.jackson.databind.SerializationFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder16 = builder14.disable(serializationFeatureArray15);
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.ObjectWriter objectWriter17 = xmlMapper0.writer(serializationFeature3, serializationFeatureArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory7);
        org.junit.Assert.assertTrue("'" + feature9 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature9.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature10 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature10.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature11 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature11.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        org.junit.Assert.assertTrue("'" + feature12 + "' != '" + com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL + "'", feature12.equals(com.fasterxml.jackson.dataformat.xml.deser.FromXmlParser.Feature.EMPTY_ELEMENT_AS_NULL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(featureArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationFeatureArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder16);
    }
}

