import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest92 {

    public static boolean debug = false;

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest92.test093");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 1, (byte) -1, (byte) -1, (byte) 1, (byte) 100 };
        com.fasterxml.jackson.databind.JavaType javaType8 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair9 = xmlMapper0.readValue(byteArray7, javaType8);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Invalid UTF-8 start byte 0xff (at char #1, byte #-1)");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
    }
}

