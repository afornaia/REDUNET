import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest91 {

    public static boolean debug = false;

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest91.test092");
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext2 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext5 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) (byte) 1, xmlReadContext2, (int) (short) 1, (int) (short) 0);
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext8 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) (byte) 100, xmlReadContext5, 1, 100);
        int int9 = xmlReadContext8.getEntryCount();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }
}

