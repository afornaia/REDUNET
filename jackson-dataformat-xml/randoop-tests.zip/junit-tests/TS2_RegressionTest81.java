import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest81.test082");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version1 = xmlJaxbAnnotationIntrospector0.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper2 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider3 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter4 = xmlMapper2.writer(filterProvider3);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = xmlMapper2.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray6 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder5.addModules(moduleArray6);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides8 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler9 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory10 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector11 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver12 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup13 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider14 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig15 = builder7.buildSerializationConfig(configOverrides8, mixInHandler9, typeFactory10, classIntrospector11, subtypeResolver12, rootNameLookup13, filterProvider14);
        com.fasterxml.jackson.databind.introspect.Annotated annotated16 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.annotation.JsonInclude.Value value17 = xmlJaxbAnnotationIntrospector0.findPropertyInclusion((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig15, annotated16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig15);
    }
}

