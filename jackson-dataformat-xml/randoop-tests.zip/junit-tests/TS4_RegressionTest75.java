import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest75.test76");
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder1 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean2 = builder1.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray3 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder4 = builder1.disable(streamWriteFeatureArray3);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature5 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder1.configure(feature5, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper8 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder1);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig9 = xmlMapper8.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass10 = null;
        java.lang.Boolean boolean11 = xmlJaxbAnnotationIntrospector0.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig9, annotatedClass10);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder12 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean13 = builder12.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray14 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = builder12.disable(streamWriteFeatureArray14);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature16 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder18 = builder12.configure(feature16, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper19 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder12);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig20 = xmlMapper19.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField21 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName22 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName23 = xmlJaxbAnnotationIntrospector0.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig20, annotatedField21, propertyName22);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder24 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean25 = builder24.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray26 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder27 = builder24.disable(streamWriteFeatureArray26);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature28 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder30 = builder24.configure(feature28, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper31 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder24);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig32 = xmlMapper31.serializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated33 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName34 = xmlJaxbAnnotationIntrospector0.findNameForDeserialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig32, annotated33);
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector35 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector36 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector xmlJaxbAnnotationIntrospector37 = new com.fasterxml.jackson.dataformat.xml.jaxb.XmlJaxbAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder38 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean39 = builder38.defaultUseWrapper();
        com.fasterxml.jackson.core.StreamWriteFeature[] streamWriteFeatureArray40 = new com.fasterxml.jackson.core.StreamWriteFeature[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder41 = builder38.disable(streamWriteFeatureArray40);
        com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature feature42 = com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder44 = builder38.configure(feature42, false);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper45 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder38);
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig46 = xmlMapper45.serializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedClass annotatedClass47 = null;
        java.lang.Boolean boolean48 = xmlJaxbAnnotationIntrospector37.isIgnorableType((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig46, annotatedClass47);
        com.fasterxml.jackson.databind.introspect.Annotated annotated49 = null;
        java.lang.Object obj50 = xmlJaxbAnnotationIntrospector36.findContentSerializer((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig46, annotated49);
        com.fasterxml.jackson.databind.introspect.Annotated annotated51 = null;
        java.lang.Object obj52 = xmlJaxbAnnotationIntrospector35.findNullSerializer((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig46, annotated51);
        com.fasterxml.jackson.databind.introspect.Annotated annotated53 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.annotation.JsonInclude.Value value54 = xmlJaxbAnnotationIntrospector0.findPropertyInclusion((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig46, annotated53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder4);
        org.junit.Assert.assertTrue("'" + feature5 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature5.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder15);
        org.junit.Assert.assertTrue("'" + feature16 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature16.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder27);
        org.junit.Assert.assertTrue("'" + feature28 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature28.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(streamWriteFeatureArray40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder41);
        org.junit.Assert.assertTrue("'" + feature42 + "' != '" + com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL + "'", feature42.equals(com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator.Feature.WRITE_NULLS_AS_XSI_NIL));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig46);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj52);
    }
}

