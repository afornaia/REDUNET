import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest84.test85");
        com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer xmlStringDeserializer0 = new com.fasterxml.jackson.dataformat.xml.deser.XmlStringDeserializer();
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer1 = xmlStringDeserializer0.getDelegatee();
        com.fasterxml.jackson.databind.DeserializationContext deserializationContext2 = null;
        com.fasterxml.jackson.databind.BeanProperty beanProperty3 = null;
        com.fasterxml.jackson.databind.JsonDeserializer<?> wildcardJsonDeserializer4 = xmlStringDeserializer0.createContextual(deserializationContext2, beanProperty3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(wildcardJsonDeserializer1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardJsonDeserializer4);
    }
}

