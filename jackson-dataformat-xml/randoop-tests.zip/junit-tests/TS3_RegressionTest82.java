import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest82.test083");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector(true);
        javax.xml.stream.XMLInputFactory xMLInputFactory2 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory3 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory2);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder4 = xmlFactory3.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder5 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory3);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = builder5.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.ser.SerializerFactory serializerFactory8 = null;
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = builder5.serializerFactory(serializerFactory8);
        javax.xml.stream.XMLInputFactory xMLInputFactory10 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory11 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory10);
        com.fasterxml.jackson.dataformat.xml.XmlFactoryBuilder xmlFactoryBuilder12 = xmlFactory11.rebuild();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder13 = new com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder(xmlFactory11);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder15 = builder13.defaultLeniency((java.lang.Boolean) false);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides16 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler17 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory18 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector19 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver20 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup21 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider22 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig23 = builder15.buildSerializationConfig(configOverrides16, mixInHandler17, typeFactory18, classIntrospector19, subtypeResolver20, rootNameLookup21, filterProvider22);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder24 = builder5.mixInOverrides((com.fasterxml.jackson.databind.introspect.MixInResolver) serializationConfig23);
        com.fasterxml.jackson.databind.introspect.AnnotatedMember annotatedMember25 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Boolean boolean26 = jacksonXmlAnnotationIntrospector1.hasRequiredMarker((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig23, annotatedMember25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlFactoryBuilder12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder24);
    }
}

