import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest112.test113");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.core.Version version2 = jacksonXmlAnnotationIntrospector1.version();
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder3 = builder0.annotationIntrospector((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper4 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder3);
        com.fasterxml.jackson.core.Version version5 = xmlMapper4.version();
        com.fasterxml.jackson.databind.node.ArrayNode arrayNode6 = xmlMapper4.createArrayNode();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(arrayNode6);
    }
}

