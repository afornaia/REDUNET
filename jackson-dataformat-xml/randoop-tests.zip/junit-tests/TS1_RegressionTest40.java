import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest40.test041");
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory0 = new com.fasterxml.jackson.dataformat.xml.XmlFactory();
        com.fasterxml.jackson.core.TokenStreamFactory tokenStreamFactory1 = xmlFactory0.snapshot();
        java.io.DataOutput dataOutput2 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator3 = tokenStreamFactory1.createGenerator(dataOutput2);
        jsonGenerator3.writeOmittedField("xmlInfo");
        // The following exception was thrown during execution in test generation
        try {
            jsonGenerator3.writeNumberField("", (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonGenerationException; message: Can not write a field name, expecting a value");
        } catch (com.fasterxml.jackson.core.JsonGenerationException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(tokenStreamFactory1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator3);
    }
}

