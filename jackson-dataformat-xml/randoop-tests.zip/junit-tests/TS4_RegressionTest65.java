import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest65.test66");
        com.fasterxml.jackson.databind.jsontype.PolymorphicTypeValidator polymorphicTypeValidator0 = null;
        com.fasterxml.jackson.databind.DefaultTyping defaultTyping1 = null;
        com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder defaultingXmlTypeResolverBuilder3 = new com.fasterxml.jackson.dataformat.xml.DefaultingXmlTypeResolverBuilder(polymorphicTypeValidator0, defaultTyping1, "XML");
        com.fasterxml.jackson.annotation.JsonTypeInfo.Value value4 = null;
        com.fasterxml.jackson.databind.jsontype.TypeIdResolver typeIdResolver5 = null;
        com.fasterxml.jackson.databind.jsontype.impl.StdTypeResolverBuilder stdTypeResolverBuilder6 = defaultingXmlTypeResolverBuilder3.init(value4, typeIdResolver5);
        com.fasterxml.jackson.databind.JavaType javaType7 = null;
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean8 = defaultingXmlTypeResolverBuilder3.useForType(javaType7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stdTypeResolverBuilder6);
    }
}

