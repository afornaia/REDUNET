import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest104.test105");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory1 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0);
        int int2 = xmlFactory1.getStreamReadFeatures();
        boolean boolean3 = xmlFactory1.canParseAsync();
        com.fasterxml.jackson.core.Version version4 = xmlFactory1.version();
        java.io.DataOutput dataOutput5 = null;
        com.fasterxml.jackson.core.JsonGenerator jsonGenerator6 = xmlFactory1.createGenerator(dataOutput5);
        int int7 = jsonGenerator6.getHighestNonEscapedChar();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(jsonGenerator6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }
}

