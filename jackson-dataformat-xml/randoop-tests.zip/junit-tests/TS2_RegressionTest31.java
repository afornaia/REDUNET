import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest31.test032");
        com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil annotationUtil0 = new com.fasterxml.jackson.dataformat.xml.util.AnnotationUtil();
    }
}

