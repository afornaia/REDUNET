import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest55.test056");
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext2 = null;
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext5 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) (byte) 1, xmlReadContext2, (int) (short) 1, (int) (short) 0);
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext6 = xmlReadContext5.getParent();
        com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext xmlReadContext9 = new com.fasterxml.jackson.dataformat.xml.deser.XmlReadContext((int) '#', xmlReadContext6, (int) '4', 0);
        // The following exception was thrown during execution in test generation
        try {
            int int10 = xmlReadContext6.getEntryCount();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(xmlReadContext6);
    }
}

