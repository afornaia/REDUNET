import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest13.test014");
        com.fasterxml.jackson.dataformat.xml.util.XmlInfo xmlInfo4 = new com.fasterxml.jackson.dataformat.xml.util.XmlInfo((java.lang.Boolean) false, "hi!", (java.lang.Boolean) false, (java.lang.Boolean) false);
        boolean boolean5 = xmlInfo4.isCData();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

