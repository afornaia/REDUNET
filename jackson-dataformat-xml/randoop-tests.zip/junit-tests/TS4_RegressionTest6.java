import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest6.test07");
        com.fasterxml.jackson.databind.deser.BeanDeserializerBase beanDeserializerBase0 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.dataformat.xml.deser.XmlTextDeserializer xmlTextDeserializer2 = new com.fasterxml.jackson.dataformat.xml.deser.XmlTextDeserializer(beanDeserializerBase0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

