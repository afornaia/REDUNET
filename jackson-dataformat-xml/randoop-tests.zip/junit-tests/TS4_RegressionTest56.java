import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest56.test57");
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.builder();
        boolean boolean1 = builder0.defaultUseWrapper();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper2 = new com.fasterxml.jackson.dataformat.xml.XmlMapper(builder0);
        byte[] byteArray6 = new byte[] { (byte) 100, (byte) 100, (byte) -1 };
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.databind.JsonNode jsonNode7 = xmlMapper2.readTree(byteArray6);
            org.junit.Assert.fail("Expected exception of type com.fasterxml.jackson.core.JsonParseException; message: Invalid UTF-8 start byte 0xff (at char #3, byte #-1)");
        } catch (com.fasterxml.jackson.core.JsonParseException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
    }
}

