import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest91 {

    public static boolean debug = false;

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest91.test092");
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector0 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector jacksonXmlAnnotationIntrospector1 = new com.fasterxml.jackson.dataformat.xml.JacksonXmlAnnotationIntrospector();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair2 = com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair.instance((com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector0, (com.fasterxml.jackson.databind.AnnotationIntrospector) jacksonXmlAnnotationIntrospector1);
        java.util.Collection<com.fasterxml.jackson.databind.AnnotationIntrospector> annotationIntrospectorCollection3 = pair2.allIntrospectors();
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper4 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider5 = null;
        com.fasterxml.jackson.databind.ObjectWriter objectWriter6 = xmlMapper4.writer(filterProvider5);
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder7 = xmlMapper4.rebuild();
        com.fasterxml.jackson.databind.Module[] moduleArray8 = new com.fasterxml.jackson.databind.Module[] {};
        com.fasterxml.jackson.dataformat.xml.XmlMapper.Builder builder9 = builder7.addModules(moduleArray8);
        com.fasterxml.jackson.databind.cfg.ConfigOverrides configOverrides10 = null;
        com.fasterxml.jackson.databind.introspect.MixInHandler mixInHandler11 = null;
        com.fasterxml.jackson.databind.type.TypeFactory typeFactory12 = null;
        com.fasterxml.jackson.databind.introspect.ClassIntrospector classIntrospector13 = null;
        com.fasterxml.jackson.databind.jsontype.SubtypeResolver subtypeResolver14 = null;
        com.fasterxml.jackson.databind.util.RootNameLookup rootNameLookup15 = null;
        com.fasterxml.jackson.databind.ser.FilterProvider filterProvider16 = null;
        com.fasterxml.jackson.databind.SerializationConfig serializationConfig17 = builder9.buildSerializationConfig(configOverrides10, mixInHandler11, typeFactory12, classIntrospector13, subtypeResolver14, rootNameLookup15, filterProvider16);
        com.fasterxml.jackson.databind.introspect.AnnotatedMember annotatedMember18 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj19 = pair2.findDeserializationContentConverter((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.SerializationConfig>) serializationConfig17, annotatedMember18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(pair2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospectorCollection3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(moduleArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializationConfig17);
    }
}

