import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest80.test81");
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector0 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation1 = null;
        boolean boolean2 = annotationIntrospector0.isAnnotationBundle(annotation1);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector3 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair4 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector0, annotationIntrospector3);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper5 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader7 = xmlMapper5.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig8 = xmlMapper5.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated9 = null;
        java.util.List<com.fasterxml.jackson.databind.PropertyName> propertyNameList10 = pair4.findPropertyAliases((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig8, annotated9);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector11 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation12 = null;
        boolean boolean13 = annotationIntrospector11.isAnnotationBundle(annotation12);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector14 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair15 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector11, annotationIntrospector14);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper16 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader18 = xmlMapper16.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig19 = xmlMapper16.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField20 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName21 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName22 = pair15.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig19, annotatedField20, propertyName21);
        com.fasterxml.jackson.databind.introspect.Annotated annotated23 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName24 = pair4.findNameForSerialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig19, annotated23);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector25 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation26 = null;
        boolean boolean27 = annotationIntrospector25.isAnnotationBundle(annotation26);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector28 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair29 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector25, annotationIntrospector28);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper30 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader32 = xmlMapper30.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig33 = xmlMapper30.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.Annotated annotated34 = null;
        java.util.List<com.fasterxml.jackson.databind.PropertyName> propertyNameList35 = pair29.findPropertyAliases((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig33, annotated34);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector36 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        java.lang.annotation.Annotation annotation37 = null;
        boolean boolean38 = annotationIntrospector36.isAnnotationBundle(annotation37);
        com.fasterxml.jackson.databind.AnnotationIntrospector annotationIntrospector39 = com.fasterxml.jackson.databind.AnnotationIntrospector.nopInstance();
        com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair pair40 = new com.fasterxml.jackson.dataformat.xml.XmlAnnotationIntrospector.Pair(annotationIntrospector36, annotationIntrospector39);
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper41 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader43 = xmlMapper41.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.DeserializationConfig deserializationConfig44 = xmlMapper41.deserializationConfig();
        com.fasterxml.jackson.databind.introspect.AnnotatedField annotatedField45 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName46 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName47 = pair40.findRenameByField((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotatedField45, propertyName46);
        com.fasterxml.jackson.databind.introspect.Annotated annotated48 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName49 = pair29.findNameForSerialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotated48);
        com.fasterxml.jackson.databind.introspect.Annotated annotated50 = null;
        com.fasterxml.jackson.databind.PropertyName propertyName51 = pair4.findNameForDeserialization((com.fasterxml.jackson.databind.cfg.MapperConfig<com.fasterxml.jackson.databind.DeserializationConfig>) deserializationConfig44, annotated50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyNameList10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyNameList35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(annotationIntrospector39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper41);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(deserializationConfig44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName47);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName49);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(propertyName51);
    }
}

