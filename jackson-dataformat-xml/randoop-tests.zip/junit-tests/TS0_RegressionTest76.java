import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest76.test77");
        javax.xml.stream.XMLInputFactory xMLInputFactory0 = null;
        javax.xml.stream.XMLInputFactory xMLInputFactory1 = null;
        javax.xml.stream.XMLOutputFactory xMLOutputFactory2 = null;
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory3 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory1, xMLOutputFactory2);
        javax.xml.stream.XMLOutputFactory xMLOutputFactory4 = xmlFactory3.getXMLOutputFactory();
        com.fasterxml.jackson.dataformat.xml.XmlFactory xmlFactory5 = new com.fasterxml.jackson.dataformat.xml.XmlFactory(xMLInputFactory0, xMLOutputFactory4);
        java.io.File file6 = null;
        com.fasterxml.jackson.core.JsonEncoding jsonEncoding7 = null;
        // The following exception was thrown during execution in test generation
        try {
            com.fasterxml.jackson.core.JsonGenerator jsonGenerator8 = xmlFactory5.createGenerator(file6, jsonEncoding7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xMLOutputFactory4);
    }
}

