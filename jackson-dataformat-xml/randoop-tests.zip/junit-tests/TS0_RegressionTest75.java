import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest75.test76");
        com.fasterxml.jackson.dataformat.xml.XmlMapper xmlMapper0 = com.fasterxml.jackson.dataformat.xml.XmlMapper.shared();
        com.fasterxml.jackson.databind.ObjectReader objectReader2 = xmlMapper0.readerForUpdating((java.lang.Object) (short) -1);
        com.fasterxml.jackson.databind.ObjectWriter objectWriter3 = xmlMapper0.writer();
        com.fasterxml.jackson.core.Version version4 = xmlMapper0.version();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(xmlMapper0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectReader2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objectWriter3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(version4);
    }
}

