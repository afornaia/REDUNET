import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest84.test085");
        // The following exception was thrown during execution in test generation
        try {
            java.io.InputStream inputStream1 = org.apache.commons.codec.Resources.getInputStream("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unable to resolve required resource: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

