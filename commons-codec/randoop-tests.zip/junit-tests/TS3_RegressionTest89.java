import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest89 {

    public static boolean debug = false;

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest89.test090");
        byte[] byteArray1 = org.apache.commons.codec.digest.DigestUtils.sha1("SHA-224");
        java.lang.String str2 = org.apache.commons.codec.digest.UnixCrypt.crypt(byteArray1);
        org.apache.commons.codec.net.PercentCodec percentCodec3 = new org.apache.commons.codec.net.PercentCodec();
        byte[] byteArray5 = org.apache.commons.codec.digest.DigestUtils.sha1("SHA-224");
        java.lang.String str6 = org.apache.commons.codec.digest.UnixCrypt.crypt(byteArray5);
        byte[] byteArray7 = percentCodec3.encode(byteArray5);
        java.lang.String str8 = org.apache.commons.codec.digest.HmacUtils.hmacSha512Hex(byteArray1, byteArray7);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = org.apache.commons.codec.digest.Md5Crypt.md5Crypt(byteArray1, "$apr1$YPRGL5eF$fikELsk0E.aQVvksdnTzS1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: $apr1$YPRGL5eF$fikELsk0E.aQVvksdnTzS1");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9s89UFzqxiYvQ" + "'", str2.equals("9s89UFzqxiYvQ"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "B2b/c/RFcy/5Y" + "'", str6.equals("B2b/c/RFcy/5Y"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "fe818f6c3248b346e5cb74c35601b005963c80a610d8bdccc74bdcec93807784b8aa50805db6a146b82b47a2c7f9c75f5fbd447c930036581c77fcc896792a26" + "'", str8.equals("fe818f6c3248b346e5cb74c35601b005963c80a610d8bdccc74bdcec93807784b8aa50805db6a146b82b47a2c7f9c75f5fbd447c930036581c77fcc896792a26"));
    }
}
