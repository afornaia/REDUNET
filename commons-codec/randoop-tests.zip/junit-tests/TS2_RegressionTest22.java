import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest22.test023");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream1 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0);
        byte[] byteArray5 = org.apache.commons.codec.digest.DigestUtils.sha1("");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.binary.Base64OutputStream base64OutputStream6 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false, (-1), byteArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: lineSeparator must not contain base64 characters: [�9��^kK\r2U��`���	]");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

