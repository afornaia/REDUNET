import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest68.test069");
        org.apache.commons.codec.EncoderException encoderException1 = new org.apache.commons.codec.EncoderException();
        org.apache.commons.codec.EncoderException encoderException2 = new org.apache.commons.codec.EncoderException("", (java.lang.Throwable) encoderException1);
        org.apache.commons.codec.DecoderException decoderException3 = new org.apache.commons.codec.DecoderException((java.lang.Throwable) encoderException1);
    }
}

