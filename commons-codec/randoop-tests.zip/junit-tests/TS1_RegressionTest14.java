import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest14.test015");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        java.lang.String str10 = org.apache.commons.codec.binary.StringUtils.newStringUsAscii(byteArray6);
        java.lang.String str11 = org.apache.commons.codec.digest.Sha2Crypt.sha256Crypt(byteArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str13 = org.apache.commons.codec.binary.StringUtils.newString(byteArray6, "\uFFFDdd\uFFFDd\uFFFD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: �dd�d�: java.io.UnsupportedEncodingException: �dd�d�");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\uFFFDdd\uFFFDd\uFFFD" + "'", str10.equals("\uFFFDdd\uFFFDd\uFFFD"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "$5$abuM2dVi$6xcfSjgRCIzfRmd2vCYH4/MunhAOI/fOjWXK11RRWE5" + "'", str11.equals("$5$abuM2dVi$6xcfSjgRCIzfRmd2vCYH4/MunhAOI/fOjWXK11RRWE5"));
    }
}
