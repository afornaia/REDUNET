import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest139 {

    public static boolean debug = false;

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest139.test140");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray10 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray5, byteArray9);
        byte[] byteArray16 = new byte[] { (byte) 0, (byte) 10, (byte) 0, (byte) -1 };
        org.apache.commons.codec.binary.Base32 base32_17 = new org.apache.commons.codec.binary.Base32((int) (byte) -1, byteArray16);
        java.lang.String str18 = org.apache.commons.codec.digest.HmacUtils.hmacSha256Hex(byteArray9, byteArray16);
        // The following exception was thrown during execution in test generation
        try {
            int int22 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray16, (int) '4', 64, 104729);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "d135bbd572bbfcbb5ccc3cf6006fecf6875dbdd93cb7b63e5e5bdac6416e758c" + "'", str18.equals("d135bbd572bbfcbb5ccc3cf6006fecf6875dbdd93cb7b63e5e5bdac6416e758c"));
    }
}

