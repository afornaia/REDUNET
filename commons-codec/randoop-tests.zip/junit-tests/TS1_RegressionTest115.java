import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest115 {

    public static boolean debug = false;

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest115.test116");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        boolean boolean10 = org.apache.commons.codec.binary.Base64.isBase64(byteArray6);
        java.lang.String str11 = org.apache.commons.codec.binary.StringUtils.newStringUtf16Le(byteArray6);
        byte[] byteArray18 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int21 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray18, (int) (short) 1, 1);
        java.lang.String str22 = org.apache.commons.codec.digest.HmacUtils.hmacSha384Hex(byteArray6, byteArray18);
        java.lang.String str23 = org.apache.commons.codec.binary.BinaryCodec.toAsciiString(byteArray6);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray24 = org.apache.commons.codec.digest.DigestUtils.sha512_224(byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA-512/224 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "\u64FF\uFF64\uFF64" + "'", str11.equals("\u64FF\uFF64\uFF64"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-759276303) + "'", int21 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10fc5b2c03401f0f6e49f7e27ded23698ea3c97d5cd6b75ac3b916f536ffbb2c4a23fe7fc7dd4326196d3b944bde41ff" + "'", str22.equals("10fc5b2c03401f0f6e49f7e27ded23698ea3c97d5cd6b75ac3b916f536ffbb2c4a23fe7fc7dd4326196d3b944bde41ff"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "111111110110010011111111011001000110010011111111" + "'", str23.equals("111111110110010011111111011001000110010011111111"));
    }
}

