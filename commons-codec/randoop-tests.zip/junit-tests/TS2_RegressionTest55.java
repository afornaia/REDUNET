import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest55.test056");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray6, byteArray10);
        org.apache.commons.codec.binary.Base32 base32_13 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray10, true);
        java.lang.String str14 = org.apache.commons.codec.digest.DigestUtils.md2Hex(byteArray10);
        byte[] byteArray21 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray25 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray26 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray21, byteArray25);
        org.apache.commons.codec.binary.Base32 base32_28 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray25, true);
        byte[] byteArray29 = org.apache.commons.codec.digest.HmacUtils.hmacSha256(byteArray10, byteArray25);
        java.io.InputStream inputStream30 = null;
        byte[] byteArray33 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream34 = new org.apache.commons.codec.binary.Base32InputStream(inputStream30, false, (int) (byte) -1, byteArray33);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray35 = org.apache.commons.codec.digest.HmacUtils.hmacSha384(byteArray25, inputStream30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "48fccf591114be6a396e26d783105c21" + "'", str14.equals("48fccf591114be6a396e26d783105c21"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray26);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray29);
    }
}

