import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest75 {

    public static boolean debug = false;

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest75.test076");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray10 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray5, byteArray9);
        byte[] byteArray11 = org.apache.commons.codec.digest.DigestUtils.sha1(byteArray5);
        java.io.InputStream inputStream12 = null;
        byte[] byteArray15 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream16 = new org.apache.commons.codec.binary.Base32InputStream(inputStream12, false, (int) (byte) -1, byteArray15);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = org.apache.commons.codec.digest.HmacUtils.hmacMd5Hex(byteArray11, inputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

