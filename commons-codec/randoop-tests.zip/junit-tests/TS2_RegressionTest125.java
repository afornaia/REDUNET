import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest125.test126");
        org.apache.commons.codec.language.Soundex soundex2 = new org.apache.commons.codec.language.Soundex("8d32cf11af0f9646fb25c4fd362287a08a65f34bd378703c306cb4d2c8f54a1a", false);
        soundex2.setMaxLength((int) (short) 100);
    }
}

