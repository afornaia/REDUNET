import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest48.test049");
        char[] charArray4 = new char[] { ' ', 'a', '#', '4' };
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray5 = org.apache.commons.codec.binary.Hex.decodeHex(charArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.DecoderException; message: Illegal hexadecimal character   at index 0");
        } catch (org.apache.commons.codec.DecoderException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray4);
    }
}

