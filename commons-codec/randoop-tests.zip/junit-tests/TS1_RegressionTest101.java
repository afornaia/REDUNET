import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest101 {

    public static boolean debug = false;

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest101.test102");
        org.apache.commons.codec.binary.Base32 base32_1 = new org.apache.commons.codec.binary.Base32((byte) 0);
        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int11 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray8, (int) (short) 1, 1);
        boolean boolean12 = org.apache.commons.codec.binary.Base64.isBase64(byteArray8);
        java.lang.String str13 = org.apache.commons.codec.binary.StringUtils.newStringUtf16Le(byteArray8);
        java.lang.String str14 = base32_1.encodeAsString(byteArray8);
        base32_1.setStrictDecoding(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-759276303) + "'", int11 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "\u64FF\uFF64\uFF64" + "'", str13.equals("\u64FF\uFF64\uFF64"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "75SGJ73E74\u0000\u0000\u0000\u0000\u0000\u0000" + "'", str14.equals("75SGJ73E74\u0000\u0000\u0000\u0000\u0000\u0000"));
    }
}

