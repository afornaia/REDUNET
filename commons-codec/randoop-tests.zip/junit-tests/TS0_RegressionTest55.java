import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest55.test056");
        org.apache.commons.codec.language.Nysiis nysiis0 = new org.apache.commons.codec.language.Nysiis();
        org.apache.commons.codec.binary.Base32 base32_2 = new org.apache.commons.codec.binary.Base32((byte) 1);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj3 = nysiis0.encode((java.lang.Object) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Nysiis encode is not of type java.lang.String");
        } catch (org.apache.commons.codec.EncoderException e) {
        // Expected exception.
        }
    }
}

