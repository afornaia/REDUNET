import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest87.test088");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        byte[] byteArray10 = org.apache.commons.codec.digest.DigestUtils.sha384(byteArray6);
        byte[] byteArray11 = org.apache.commons.codec.binary.Base64.encodeBase64(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

