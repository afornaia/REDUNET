import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest12.test013");
        org.apache.commons.codec.language.bm.Languages.LanguageSet languageSet1 = null;
        org.apache.commons.codec.language.bm.Rule.Phoneme phoneme2 = new org.apache.commons.codec.language.bm.Rule.Phoneme((java.lang.CharSequence) "SHA3-384", languageSet1);
        org.apache.commons.codec.language.bm.Languages.LanguageSet languageSet3 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.language.bm.Rule.Phoneme phoneme4 = phoneme2.mergeWithLanguage(languageSet3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

