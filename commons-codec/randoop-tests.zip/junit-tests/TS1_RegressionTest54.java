import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest54.test055");
        javax.crypto.Mac mac0 = null;
        // The following exception was thrown during execution in test generation
        try {
            javax.crypto.Mac mac2 = org.apache.commons.codec.digest.HmacUtils.updateHmac(mac0, "$5$t8nPJuyM$eWNtSdnfZW/l/QJUpZOjN0zdlRS2WzkB/7lVhLC1vr1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

