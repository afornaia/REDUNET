import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest61.test062");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.language.bm.Languages languages1 = org.apache.commons.codec.language.bm.Languages.getInstance("$6$Y6saQxRM$7ilnFRqMyO3N4Ut7Kv5cPn0VQIFT4kIX4b24CyEBdsKEGbMW7kj4g4BZqEy2dq96hX8d1BaV7sHH4t.rgVw08.");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unable to resolve required resource: $6$Y6saQxRM$7ilnFRqMyO3N4Ut7Kv5cPn0VQIFT4kIX4b24CyEBdsKEGbMW7kj4g4BZqEy2dq96hX8d1BaV7sHH4t.rgVw08.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

