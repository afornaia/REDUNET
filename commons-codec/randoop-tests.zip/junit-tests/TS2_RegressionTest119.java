import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest119 {

    public static boolean debug = false;

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest119.test120");
        // The following exception was thrown during execution in test generation
        try {
            java.security.MessageDigest messageDigest0 = org.apache.commons.codec.digest.DigestUtils.getSha3_256Digest();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA3-256 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

