import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest86.test087");
        java.lang.String str2 = org.apache.commons.codec.digest.HmacUtils.hmacMd5Hex("SHA3-256", "F9E20DB6D388A9F86A3374779247C5460A1A5574");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2b50ff9e57b789eb25d288102e0f258e" + "'", str2.equals("2b50ff9e57b789eb25d288102e0f258e"));
    }
}

