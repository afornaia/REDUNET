import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest34.test035");
        java.security.MessageDigest messageDigest0 = org.apache.commons.codec.digest.DigestUtils.getMd2Digest();
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int10 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray7, (int) (short) 1, 1);
        byte[] byteArray11 = org.apache.commons.codec.digest.DigestUtils.sha384(byteArray7);
        java.security.MessageDigest messageDigest12 = org.apache.commons.codec.digest.DigestUtils.updateDigest(messageDigest0, byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(messageDigest0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(messageDigest0.toString(), "MD2 Message Digest from SUN, <in progress>\n");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-759276303) + "'", int10 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(messageDigest12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertEquals(messageDigest12.toString(), "MD2 Message Digest from SUN, <in progress>\n");
    }
}

