import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest66.test067");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) 1 };
        javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.getHmacSha512(byteArray6);
        byte[] byteArray9 = org.apache.commons.codec.digest.DigestUtils.sha("48fccf591114be6a396e26d783105c21");
        byte[] byteArray15 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray19 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray20 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray15, byteArray19);
        byte[] byteArray21 = org.apache.commons.codec.digest.DigestUtils.sha1(byteArray15);
        byte[] byteArray22 = org.apache.commons.codec.digest.HmacUtils.hmacSha384(byteArray9, byteArray21);
        javax.crypto.Mac mac23 = org.apache.commons.codec.digest.HmacUtils.updateHmac(mac7, byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac23);
    }
}

