import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest104 {

    public static boolean debug = false;

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest104.test105");
        char[] charArray3 = new char[] { '4', ' ', '4' };
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex4 = new org.apache.commons.codec.language.RefinedSoundex(charArray3);
        byte[] byteArray5 = org.apache.commons.codec.binary.BinaryCodec.fromAscii(charArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

