import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest23.test024");
        org.apache.commons.codec.digest.HmacAlgorithms hmacAlgorithms0 = org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384;
        byte[] byteArray1 = new byte[] {};
        int int4 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray1, (int) (short) 0, (int) '4');
        // The following exception was thrown during execution in test generation
        try {
            javax.crypto.Mac mac5 = org.apache.commons.codec.digest.HmacUtils.getInitializedMac(hmacAlgorithms0, byteArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + hmacAlgorithms0 + "' != '" + org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384 + "'", hmacAlgorithms0.equals(org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33005907 + "'", int4 == 33005907);
    }
}

