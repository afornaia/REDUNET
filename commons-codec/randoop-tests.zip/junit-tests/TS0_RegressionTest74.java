import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest74.test075");
        byte[] byteArray1 = org.apache.commons.codec.binary.StringUtils.getBytesUtf16("");
        java.lang.String str3 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray1, "HmacMD5");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "$apr1$HmacMD5$m/zsTqxWyVUfZ5YwkmvJC/" + "'", str3.equals("$apr1$HmacMD5$m/zsTqxWyVUfZ5YwkmvJC/"));
    }
}

