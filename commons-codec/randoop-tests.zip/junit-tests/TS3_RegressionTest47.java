import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest47.test048");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_SIMPLIFIED;
        int int1 = soundex0.getMaxLength();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(soundex0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }
}

