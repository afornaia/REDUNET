import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest40.test041");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        org.apache.commons.codec.net.PercentCodec percentCodec5 = new org.apache.commons.codec.net.PercentCodec(byteArray0, true);
        // The following exception was thrown during execution in test generation
        try {
            long long8 = org.apache.commons.codec.digest.MurmurHash3.hash64(byteArray0, 33005907, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 33005907");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
    }
}

