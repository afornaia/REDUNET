import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest109 {

    public static boolean debug = false;

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest109.test110");
        byte[] byteArray2 = org.apache.commons.codec.digest.HmacUtils.hmacMd5("Af8KAQ==", "85d36a077aabad064007523ed544988fa061e1859edad15e4a0646efab7f8a541897ecf5c10188fae159f91937f9b4cd73c99eb5464d8f847812db0bfb1edada");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray2);
    }
}

