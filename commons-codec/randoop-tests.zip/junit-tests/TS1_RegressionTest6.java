import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest6.test007");
        byte[] byteArray3 = new byte[] { (byte) 10, (byte) 100, (byte) 0 };
        java.io.InputStream inputStream4 = null;
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray5 = org.apache.commons.codec.digest.HmacUtils.hmacMd5(byteArray3, inputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray3);
    }
}

