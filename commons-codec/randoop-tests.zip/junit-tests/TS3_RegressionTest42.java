import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest42.test043");
        byte[] byteArray1 = org.apache.commons.codec.digest.DigestUtils.sha1("SHA-224");
        java.lang.String str2 = org.apache.commons.codec.digest.UnixCrypt.crypt(byteArray1);
        java.util.Random random4 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str5 = org.apache.commons.codec.digest.Sha2Crypt.sha256Crypt(byteArray1, "DyFhoOVd0OQSc", random4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: DyFhoOVd0OQSc");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Zv0sIyRfd3us6" + "'", str2.equals("Zv0sIyRfd3us6"));
    }
}
