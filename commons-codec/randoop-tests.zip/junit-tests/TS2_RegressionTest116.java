import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest116.test117");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray6, byteArray10);
        org.apache.commons.codec.binary.Base32 base32_13 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray10, true);
        java.util.BitSet bitSet14 = null;
        byte[] byteArray19 = new byte[] { (byte) 100, (byte) 1, (byte) 100, (byte) 10 };
        byte[] byteArray20 = org.apache.commons.codec.net.QuotedPrintableCodec.encodeQuotedPrintable(bitSet14, byteArray19);
        java.lang.String str21 = org.apache.commons.codec.digest.DigestUtils.md2Hex(byteArray19);
        java.lang.String str22 = base32_13.encodeToString(byteArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ab4c3a65ffce8dc620e89a1b53dac436" + "'", str21.equals("ab4c3a65ffce8dc620e89a1b53dac436"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "CG0M82G=" + "'", str22.equals("CG0M82G="));
    }
}

