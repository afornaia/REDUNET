import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest52.test053");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        java.lang.String str10 = org.apache.commons.codec.binary.StringUtils.newStringUsAscii(byteArray6);
        java.io.InputStream inputStream11 = null;
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacMd5(byteArray6, inputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\uFFFDdd\uFFFDd\uFFFD" + "'", str10.equals("\uFFFDdd\uFFFDd\uFFFD"));
    }
}

