import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest100.test101");
        byte[] byteArray2 = org.apache.commons.codec.digest.HmacUtils.hmacSha1("SHA3-256", "48fccf591114be6a396e26d783105c21");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray2);
    }
}

