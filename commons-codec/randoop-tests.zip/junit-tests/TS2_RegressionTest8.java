import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest8.test009");
        int int2 = org.apache.commons.codec.digest.MurmurHash3.hash32((long) (short) 1, (long) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1786221660) + "'", int2 == (-1786221660));
    }
}

