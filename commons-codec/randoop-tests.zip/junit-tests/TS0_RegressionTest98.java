import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest98 {

    public static boolean debug = false;

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest98.test099");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray11 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray5, byteArray10);
        java.lang.String str13 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray10);
        java.lang.String str14 = org.apache.commons.codec.binary.StringUtils.newStringIso8859_1(byteArray10);
        long[] longArray15 = org.apache.commons.codec.digest.MurmurHash3.hash128x64(byteArray10);
        java.io.InputStream inputStream16 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream17 = new org.apache.commons.codec.binary.Base32InputStream(inputStream16);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str18 = org.apache.commons.codec.digest.HmacUtils.hmacMd5Hex(byteArray10, (java.io.InputStream) base32InputStream17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str13.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\u0001\u00FF\n\u0001" + "'", str14.equals("\u0001\u00FF\n\u0001"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray15);
    }
}

