import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest52.test053");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream1 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0);
        org.apache.commons.codec.binary.BaseNCodec baseNCodec2 = null;
        org.apache.commons.codec.binary.BaseNCodecOutputStream baseNCodecOutputStream4 = new org.apache.commons.codec.binary.BaseNCodecOutputStream((java.io.OutputStream) base32OutputStream1, baseNCodec2, false);
        byte[] byteArray13 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray17 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray18 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray13, byteArray17);
        org.apache.commons.codec.binary.Base32 base32_20 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray17, true);
        java.lang.String str21 = org.apache.commons.codec.digest.DigestUtils.md2Hex(byteArray17);
        byte[] byteArray28 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray32 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray33 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray28, byteArray32);
        org.apache.commons.codec.binary.Base32 base32_35 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray32, true);
        byte[] byteArray36 = org.apache.commons.codec.digest.HmacUtils.hmacSha256(byteArray17, byteArray32);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.binary.Base64OutputStream base64OutputStream37 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base32OutputStream1, false, (int) 'a', byteArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: lineSeparator must not contain base64 characters: [:����ӳ>L�L�I�D���Q���$��wf]");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "48fccf591114be6a396e26d783105c21" + "'", str21.equals("48fccf591114be6a396e26d783105c21"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray36);
    }
}

