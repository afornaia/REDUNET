import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest73.test074");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult2 = doubleMetaphone0.new DoubleMetaphoneResult(100);
        doubleMetaphoneResult2.append("\u00C3\u00C1G\u00D8\u00C3\u00DC", "$5$mATmnbyC$wb4IcWAAo/vnKvN5c/5agFj3CyaJ09PjsSY8C2bkpx.");
    }
}

