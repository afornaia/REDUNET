import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest33.test034");
        long long0 = org.apache.commons.codec.digest.MurmurHash3.NULL_HASHCODE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 2862933555777941757L + "'", long0 == 2862933555777941757L);
    }
}

