import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest141 {

    public static boolean debug = false;

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest141.test142");
        org.apache.commons.codec.net.QCodec qCodec0 = new org.apache.commons.codec.net.QCodec();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = qCodec0.encode("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
            org.junit.Assert.fail("Expected exception of type java.nio.charset.UnsupportedCharsetException; message: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
        } catch (java.nio.charset.UnsupportedCharsetException e) {
        // Expected exception.
        }
    }
}

