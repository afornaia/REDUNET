import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest60.test061");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray10 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray5, byteArray9);
        javax.crypto.Mac mac11 = org.apache.commons.codec.digest.HmacUtils.getHmacSha512(byteArray10);
        java.lang.String str13 = org.apache.commons.codec.binary.Hex.encodeHexString(byteArray10, false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "F9E20DB6D388A9F86A3374779247C5460A1A5574" + "'", str13.equals("F9E20DB6D388A9F86A3374779247C5460A1A5574"));
    }
}

