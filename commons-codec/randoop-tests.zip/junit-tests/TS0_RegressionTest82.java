import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest82 {

    public static boolean debug = false;

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest82.test083");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray11 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray5, byteArray10);
        java.lang.String str13 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray10);
        java.lang.String str14 = org.apache.commons.codec.binary.StringUtils.newStringIso8859_1(byteArray10);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.net.PercentCodec percentCodec16 = new org.apache.commons.codec.net.PercentCodec(byteArray10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: bitIndex < 0: -1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str13.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\u0001\u00FF\n\u0001" + "'", str14.equals("\u0001\u00FF\n\u0001"));
    }
}

