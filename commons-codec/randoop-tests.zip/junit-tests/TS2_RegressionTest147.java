import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest147 {

    public static boolean debug = false;

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest147.test148");
        java.io.InputStream inputStream0 = null;
        byte[] byteArray3 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream4 = new org.apache.commons.codec.binary.Base32InputStream(inputStream0, false, (int) (byte) -1, byteArray3);
        boolean boolean5 = base32InputStream4.markSupported();
        byte[] byteArray6 = null;
        // The following exception was thrown during execution in test generation
        try {
            int int7 = base32InputStream4.read(byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }
}

