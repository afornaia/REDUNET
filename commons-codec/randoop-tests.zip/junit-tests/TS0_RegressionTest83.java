import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest83.test084");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream1 = new org.apache.commons.codec.binary.Base32InputStream(inputStream0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = org.apache.commons.codec.digest.DigestUtils.sha3_224Hex((java.io.InputStream) base32InputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA3-224 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

