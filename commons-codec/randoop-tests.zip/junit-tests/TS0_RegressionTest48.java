import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest48.test049");
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray1 = org.apache.commons.codec.binary.Hex.decodeHex("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.DecoderException; message: Odd number of characters.");
        } catch (org.apache.commons.codec.DecoderException e) {
        // Expected exception.
        }
    }
}

