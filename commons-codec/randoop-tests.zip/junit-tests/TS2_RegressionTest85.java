import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest85 {

    public static boolean debug = false;

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest85.test086");
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray2 = org.apache.commons.codec.binary.StringUtils.getBytesUnchecked("$5$s2WPdWZI$fFk14XxZUA1.hEV3lPqzST3RPBUX3KgHfHGtALtaDk9", "$5$s2WPdWZI$fFk14XxZUA1.hEV3lPqzST3RPBUX3KgHfHGtALtaDk9");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: $5$s2WPdWZI$fFk14XxZUA1.hEV3lPqzST3RPBUX3KgHfHGtALtaDk9: java.io.UnsupportedEncodingException: $5$s2WPdWZI$fFk14XxZUA1.hEV3lPqzST3RPBUX3KgHfHGtALtaDk9");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
    }
}

