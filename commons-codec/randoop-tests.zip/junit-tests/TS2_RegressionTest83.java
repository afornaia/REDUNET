import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest83.test084");
        byte[] byteArray1 = null;
        // The following exception was thrown during execution in test generation
        try {
            javax.crypto.Mac mac2 = org.apache.commons.codec.digest.HmacUtils.getInitializedMac("any", byteArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

