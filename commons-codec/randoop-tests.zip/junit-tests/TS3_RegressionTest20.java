import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest20.test021");
        long long1 = org.apache.commons.codec.digest.MurmurHash3.hash64(10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1246764444718532769L + "'", long1 == 1246764444718532769L);
    }
}

