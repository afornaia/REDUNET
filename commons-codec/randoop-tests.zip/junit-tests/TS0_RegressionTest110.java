import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest110 {

    public static boolean debug = false;

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest110.test111");
        java.io.InputStream inputStream0 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream1 = new org.apache.commons.codec.binary.Base32InputStream(inputStream0);
        boolean boolean2 = base32InputStream1.markSupported();
        // The following exception was thrown during execution in test generation
        try {
            int int3 = base32InputStream1.read();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

