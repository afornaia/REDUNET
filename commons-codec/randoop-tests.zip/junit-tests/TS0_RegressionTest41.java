import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest41.test042");
        // The following exception was thrown during execution in test generation
        try {
            java.security.MessageDigest messageDigest1 = org.apache.commons.codec.digest.DigestUtils.getDigest("$apr1$go1oGj2j$neSj/z2aRRMITHEBXD7R/0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: $apr1$go1oGj2j$neSj/z2aRRMITHEBXD7R/0 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

