import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest69.test070");
        org.apache.commons.codec.binary.Base32 base32_1 = new org.apache.commons.codec.binary.Base32((byte) 1);
        boolean boolean2 = base32_1.isStrictDecoding();
        boolean boolean4 = base32_1.isInAlphabet("");
        byte[] byteArray9 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray10 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray9);
        byte[] byteArray11 = base32_1.decode(byteArray10);
        java.io.InputStream inputStream12 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream13 = new org.apache.commons.codec.binary.Base32InputStream(inputStream12);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str14 = org.apache.commons.codec.digest.HmacUtils.hmacSha384Hex(byteArray11, (java.io.InputStream) base32InputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

