import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest58.test059");
        java.lang.String str1 = org.apache.commons.codec.digest.UnixCrypt.crypt("\u0001\u00FF\n\u0001");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str1 + "' != '" + "fmuIwpYo9UPpI" + "'", str1.equals("fmuIwpYo9UPpI"));
    }
}
