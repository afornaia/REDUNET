import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest99 {

    public static boolean debug = false;

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest99.test100");
        byte[] byteArray1 = org.apache.commons.codec.digest.DigestUtils.sha("48fccf591114be6a396e26d783105c21");
        java.lang.String str2 = org.apache.commons.codec.digest.Sha2Crypt.sha256Crypt(byteArray1);
        java.lang.String str3 = org.apache.commons.codec.binary.Hex.encodeHexString(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str2 + "' != '" + "$5$X84vLcVP$KZGCIWov9kqTVi0tQu3oAxpU/8Q.6cijqYD4nlpk5r4" + "'", str2.equals("$5$X84vLcVP$KZGCIWov9kqTVi0tQu3oAxpU/8Q.6cijqYD4nlpk5r4"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0000000000000000000000000000000000000000" + "'", str3.equals("0000000000000000000000000000000000000000"));
    }
}
