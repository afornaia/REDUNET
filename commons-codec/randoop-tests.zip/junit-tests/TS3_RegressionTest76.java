import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest76.test077");
        org.apache.commons.codec.language.Nysiis nysiis1 = new org.apache.commons.codec.language.Nysiis(false);
        java.lang.String str3 = nysiis1.nysiis("$6$1PQDJw2e$ecX9fWo9YAWtn13i/OTcLsF2b4IwFWDkxFDF7z7pmE2m73hTUmwneiOnQNrblwJ7yKqZOfmKjHWFMgLGH9rkd/");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PGDJWACXFWAYATNATCLSFBAFWDCXFDFSPNANTANWNANGNRBLWJYCGSAFNCJWFNGLGRCD" + "'", str3.equals("PGDJWACXFWAYATNATCLSFBAFWDCXFDFSPNANTANWNANGNRBLWJYCGSAFNCJWFNGLGRCD"));
    }
}

