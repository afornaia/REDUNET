import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest103 {

    public static boolean debug = false;

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest103.test104");
        org.apache.commons.codec.language.Soundex soundex0 = org.apache.commons.codec.language.Soundex.US_ENGLISH_GENEALOGY;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = soundex0.soundex("\u64FF\uFF64\uFF64");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The character is not mapped: 擿 (index=25790)");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(soundex0);
    }
}

