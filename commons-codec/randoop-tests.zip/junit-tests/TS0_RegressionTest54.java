import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest54.test055");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.digest.HmacUtils hmacUtils2 = new org.apache.commons.codec.digest.HmacUtils("6ffb812766edee043f1e893b221b3216", "2jmj7l5rSw0yVb_vlWAYkK_YBwk");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: Algorithm 6ffb812766edee043f1e893b221b3216 not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

