import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest124 {

    public static boolean debug = false;

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest124.test125");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray6, byteArray10);
        org.apache.commons.codec.binary.Base32 base32_13 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray10, true);
        byte[] byteArray17 = new byte[] { (byte) 1, (byte) 10, (byte) -1 };
        byte[] byteArray19 = org.apache.commons.codec.binary.Base64.decodeBase64("hi!");
        java.lang.String str20 = org.apache.commons.codec.digest.HmacUtils.hmacSha256Hex(byteArray17, byteArray19);
        byte[] byteArray21 = org.apache.commons.codec.binary.BinaryCodec.toAsciiBytes(byteArray19);
        byte[] byteArray24 = base32_13.encode(byteArray21, (-1786221660), (int) (byte) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a" + "'", str20.equals("17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray24);
    }
}

