import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest24.test025");
        byte[] byteArray1 = org.apache.commons.codec.digest.DigestUtils.md5("6ffb812766edee043f1e893b221b3216");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
    }
}

