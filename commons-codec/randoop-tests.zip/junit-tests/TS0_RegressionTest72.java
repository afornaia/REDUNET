import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest72 {

    public static boolean debug = false;

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest72.test073");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray11 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray5, byteArray10);
        java.lang.String str13 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray10);
        byte[] byteArray14 = org.apache.commons.codec.digest.DigestUtils.md2(byteArray10);
        java.util.Random random16 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str17 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray14, "", random16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: ");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str13.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray14);
    }
}

