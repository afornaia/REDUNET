import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest87 {

    public static boolean debug = false;

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest87.test088");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray6 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray5);
        org.apache.commons.codec.binary.Base64 base64_7 = new org.apache.commons.codec.binary.Base64((int) (short) 10, byteArray5);
        boolean boolean8 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray5);
        byte[] byteArray9 = org.apache.commons.codec.net.QuotedPrintableCodec.decodeQuotedPrintable(byteArray5);
        java.util.Random random11 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray9, "hi!", random11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: hi!");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
    }
}

