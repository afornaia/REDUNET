import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest80.test081");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream2 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0, true);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1 };
        base32OutputStream2.write(byteArray5);
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) 10, (byte) -1 };
        org.apache.commons.codec.binary.Base32 base32_13 = new org.apache.commons.codec.binary.Base32((int) ' ', byteArray11, true);
        org.apache.commons.codec.binary.BaseNCodecOutputStream baseNCodecOutputStream15 = new org.apache.commons.codec.binary.BaseNCodecOutputStream((java.io.OutputStream) base32OutputStream2, (org.apache.commons.codec.binary.BaseNCodec) base32_13, false);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj17 = base32_13.encode((java.lang.Object) (-79826993));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base-N encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

