import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest39.test040");
        org.apache.commons.codec.language.ColognePhonetic colognePhonetic0 = new org.apache.commons.codec.language.ColognePhonetic();
        java.lang.String str2 = colognePhonetic0.colognePhonetic("SHA-384");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8" + "'", str2.equals("8"));
    }
}

