import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest59.test060");
        org.apache.commons.codec.DecoderException decoderException0 = new org.apache.commons.codec.DecoderException();
        java.lang.String str1 = decoderException0.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.codec.DecoderException" + "'", str1.equals("org.apache.commons.codec.DecoderException"));
    }
}

