import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest21.test022");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        byte[] byteArray4 = new byte[] {};
        int int7 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray4, (int) (short) 0, (int) '4');
        java.lang.String str8 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray4);
        java.lang.String str9 = org.apache.commons.codec.binary.StringUtils.newStringUtf16(byteArray4);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str10 = org.apache.commons.codec.digest.HmacUtils.hmacMd5Hex(byteArray0, byteArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 33005907 + "'", int7 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "$apr1$AAgUEj8z$bQZXAXmLbK5FRzhy.eq63/" + "'", str8.equals("$apr1$AAgUEj8z$bQZXAXmLbK5FRzhy.eq63/"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }
}
