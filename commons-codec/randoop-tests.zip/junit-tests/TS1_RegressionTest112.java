import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest112.test113");
        org.apache.commons.codec.net.PercentCodec percentCodec0 = new org.apache.commons.codec.net.PercentCodec();
        byte[] byteArray3 = org.apache.commons.codec.digest.HmacUtils.hmacSha1("\uFFFDdd\uFFFDd\uFFFD", "hi!");
        java.lang.String str4 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray3);
        byte[] byteArray5 = percentCodec0.decode(byteArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray3);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$6$w6Su2epm$iKlFNn27uWdXdJahjhsS5nUcuqJEC9gc/q4.EIkHn5H/RmeknZcQfD/7fS7c8m4h9VG6r32NUhShIx9HpBJX1." + "'", str4.equals("$6$w6Su2epm$iKlFNn27uWdXdJahjhsS5nUcuqJEC9gc/q4.EIkHn5H/RmeknZcQfD/7fS7c8m4h9VG6r32NUhShIx9HpBJX1."));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}
