import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest59 {

    public static boolean debug = false;

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest59.test060");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) 1 };
        javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.getHmacSha512(byteArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str9 = org.apache.commons.codec.binary.StringUtils.newString(byteArray6, "any");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: any: java.io.UnsupportedEncodingException: any");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac7);
    }
}

