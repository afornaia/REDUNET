import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest62 {

    public static boolean debug = false;

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest62.test063");
        org.apache.commons.codec.language.Nysiis nysiis0 = new org.apache.commons.codec.language.Nysiis();
        java.lang.String str2 = nysiis0.encode(".\u0094\u00E3\u0097\u00E1G4 \u0013!\u00F8\f#\u00E3\u0015'\u00DC\u00F3\u00C7*");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "\u00C3\u00C1G\u00D8\u00C3\u00DC" + "'", str2.equals("\u00C3\u00C1G\u00D8\u00C3\u00DC"));
    }
}

