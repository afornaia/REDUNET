import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest24.test025");
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int10 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray7, (int) (short) 1, 1);
        java.lang.String str11 = org.apache.commons.codec.binary.StringUtils.newStringUsAscii(byteArray7);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.binary.Base32 base32_14 = new org.apache.commons.codec.binary.Base32((int) (short) 100, byteArray7, true, (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: lineSeparator must not contain Base32 characters: [�dd�d�]");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-759276303) + "'", int10 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "\uFFFDdd\uFFFDd\uFFFD" + "'", str11.equals("\uFFFDdd\uFFFDd\uFFFD"));
    }
}

