import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest84 {

    public static boolean debug = false;

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest84.test085");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray5 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray4);
        java.lang.String str6 = org.apache.commons.codec.binary.BinaryCodec.toAsciiString(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "00000001000010101111111100000001" + "'", str6.equals("00000001000010101111111100000001"));
    }
}

