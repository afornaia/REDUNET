import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest130 {

    public static boolean debug = false;

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest130.test131");
        org.apache.commons.codec.language.bm.NameType nameType0 = org.apache.commons.codec.language.bm.NameType.SEPHARDIC;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine3 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, false);
        org.apache.commons.codec.language.bm.NameType nameType4 = phoneticEngine3.getNameType();
        org.apache.commons.codec.language.bm.Lang lang5 = phoneticEngine3.getLang();
        java.lang.String str7 = lang5.guessLanguage("ab4c3a65ffce8dc620e89a1b53dac436");
        org.junit.Assert.assertTrue("'" + nameType0 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType0.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        org.junit.Assert.assertTrue("'" + nameType4 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType4.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(lang5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "any" + "'", str7.equals("any"));
    }
}

