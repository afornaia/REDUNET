import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest64 {

    public static boolean debug = false;

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest64.test065");
        org.apache.commons.codec.language.DaitchMokotoffSoundex daitchMokotoffSoundex0 = new org.apache.commons.codec.language.DaitchMokotoffSoundex();
        java.lang.String str2 = daitchMokotoffSoundex0.soundex("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "500000" + "'", str2.equals("500000"));
    }
}

