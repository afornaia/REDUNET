import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest97.test098");
        java.lang.String str1 = org.apache.commons.codec.digest.DigestUtils.md2Hex("org.apache.commons.codec.DecoderException");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "c4cd527c7e08b2c4c48699af764a4457" + "'", str1.equals("c4cd527c7e08b2c4c48699af764a4457"));
    }
}

