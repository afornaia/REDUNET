import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest100 {

    public static boolean debug = false;

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest100.test101");
        org.apache.commons.codec.net.QuotedPrintableCodec quotedPrintableCodec0 = new org.apache.commons.codec.net.QuotedPrintableCodec();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = quotedPrintableCodec0.decode((java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.DecoderException; message: Objects of type java.lang.Boolean cannot be quoted-printable decoded");
        } catch (org.apache.commons.codec.DecoderException e) {
        // Expected exception.
        }
    }
}

