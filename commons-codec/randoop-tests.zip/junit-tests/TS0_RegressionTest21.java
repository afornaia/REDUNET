import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest21.test022");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream2 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream4 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false);
        byte[] byteArray10 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray15 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray16 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray15);
        byte[] byteArray17 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray10, byteArray15);
        java.lang.String str18 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray15);
        java.lang.String str19 = org.apache.commons.codec.binary.StringUtils.newStringIso8859_1(byteArray15);
        // The following exception was thrown during execution in test generation
        try {
            base64OutputStream4.write(byteArray15, 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str18.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "\u0001\u00FF\n\u0001" + "'", str19.equals("\u0001\u00FF\n\u0001"));
    }
}

