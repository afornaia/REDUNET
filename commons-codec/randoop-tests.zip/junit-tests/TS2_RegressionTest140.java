import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest140 {

    public static boolean debug = false;

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest140.test141");
        byte[] byteArray1 = org.apache.commons.codec.digest.DigestUtils.sha384("8d32cf11af0f9646fb25c4fd362287a08a65f34bd378703c306cb4d2c8f54a1a");
        // The following exception was thrown during execution in test generation
        try {
            long long4 = org.apache.commons.codec.digest.MurmurHash2.hash64(byteArray1, 64, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 48");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
    }
}

