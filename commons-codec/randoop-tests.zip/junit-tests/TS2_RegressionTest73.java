import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest73 {

    public static boolean debug = false;

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest73.test074");
        java.lang.String str2 = org.apache.commons.codec.digest.HmacUtils.hmacSha256Hex("000000", "");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8d32cf11af0f9646fb25c4fd362287a08a65f34bd378703c306cb4d2c8f54a1a" + "'", str2.equals("8d32cf11af0f9646fb25c4fd362287a08a65f34bd378703c306cb4d2c8f54a1a"));
    }
}

