import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest48.test049");
        org.apache.commons.codec.language.bm.NameType nameType0 = null;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine4 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, true, (int) 'a');
        org.apache.commons.codec.language.bm.RuleType ruleType5 = phoneticEngine4.getRuleType();
        org.apache.commons.codec.language.bm.Lang lang6 = phoneticEngine4.getLang();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(ruleType5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(lang6);
    }
}

