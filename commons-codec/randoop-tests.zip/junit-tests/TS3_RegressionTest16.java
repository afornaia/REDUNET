import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest16.test017");
        java.lang.String str0 = org.apache.commons.codec.language.RefinedSoundex.US_ENGLISH_MAPPING_STRING;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "01360240043788015936020505" + "'", str0.equals("01360240043788015936020505"));
    }
}

