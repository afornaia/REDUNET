import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest96.test097");
        org.apache.commons.codec.net.PercentCodec percentCodec0 = new org.apache.commons.codec.net.PercentCodec();
        java.util.BitSet bitSet1 = null;
        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int11 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray8, (int) (short) 1, 1);
        byte[] byteArray12 = org.apache.commons.codec.net.QuotedPrintableCodec.encodeQuotedPrintable(bitSet1, byteArray8);
        byte[] byteArray13 = org.apache.commons.codec.binary.Base64.encodeBase64Chunked(byteArray12);
        byte[] byteArray14 = percentCodec0.encode(byteArray12);
        org.apache.commons.codec.net.PercentCodec percentCodec16 = new org.apache.commons.codec.net.PercentCodec(byteArray12, false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-759276303) + "'", int11 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray14);
    }
}

