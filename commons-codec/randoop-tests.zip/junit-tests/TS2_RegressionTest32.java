import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest32.test033");
        java.lang.String str1 = org.apache.commons.codec.digest.DigestUtils.sha256Hex("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" + "'", str1.equals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"));
    }
}

