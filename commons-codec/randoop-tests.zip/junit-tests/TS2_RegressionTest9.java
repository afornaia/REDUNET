import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest9.test010");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray10 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray5, byteArray9);
        java.lang.String str11 = org.apache.commons.codec.digest.Md5Crypt.md5Crypt(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "$1$hdx2yRJF$RGZEfVAZ2JCPczsCM3bVi1" + "'", str11.equals("$1$hdx2yRJF$RGZEfVAZ2JCPczsCM3bVi1"));
    }
}
