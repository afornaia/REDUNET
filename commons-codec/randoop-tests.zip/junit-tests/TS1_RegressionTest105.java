import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest105 {

    public static boolean debug = false;

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest105.test106");
        org.apache.commons.codec.net.QuotedPrintableCodec quotedPrintableCodec1 = new org.apache.commons.codec.net.QuotedPrintableCodec(true);
        java.lang.Object obj2 = null;
        java.lang.Object obj3 = quotedPrintableCodec1.decode(obj2);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int13 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray10, (int) (short) 1, 1);
        java.lang.String str14 = org.apache.commons.codec.binary.StringUtils.newStringUsAscii(byteArray10);
        java.lang.String str15 = org.apache.commons.codec.digest.Sha2Crypt.sha256Crypt(byteArray10);
        java.lang.Object obj16 = quotedPrintableCodec1.decode((java.lang.Object) byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-759276303) + "'", int13 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "\uFFFDdd\uFFFDd\uFFFD" + "'", str14.equals("\uFFFDdd\uFFFDd\uFFFD"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str15 + "' != '" + "$5$GRuWQg.w$sXSvP.JiXQmYSlxZl/VbH.qoVNyN6derO/I4M4LvvY0" + "'", str15.equals("$5$GRuWQg.w$sXSvP.JiXQmYSlxZl/VbH.qoVNyN6derO/I4M4LvvY0"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(obj16);
    }
}
