import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest5.test006");
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = org.apache.commons.codec.digest.Crypt.crypt("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: ");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

