import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest53.test054");
        java.util.Comparator<org.apache.commons.codec.language.bm.Rule.Phoneme> phonemeComparator0 = org.apache.commons.codec.language.bm.Rule.Phoneme.COMPARATOR;
        java.util.Comparator<org.apache.commons.codec.language.bm.Rule.Phoneme> phonemeComparator1 = org.apache.commons.codec.language.bm.Rule.Phoneme.COMPARATOR;
        java.util.Comparator<org.apache.commons.codec.language.bm.Rule.Phoneme> phonemeComparator2 = phonemeComparator0.thenComparing(phonemeComparator1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(phonemeComparator0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(phonemeComparator1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(phonemeComparator2);
    }
}

