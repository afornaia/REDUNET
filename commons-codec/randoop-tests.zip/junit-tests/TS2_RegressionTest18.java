import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest18.test019");
        org.apache.commons.codec.language.bm.NameType nameType0 = org.apache.commons.codec.language.bm.NameType.SEPHARDIC;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.List<org.apache.commons.codec.language.bm.Rule> ruleList3 = org.apache.commons.codec.language.bm.Rule.getInstance(nameType0, ruleType1, "$1$hdx2yRJF$RGZEfVAZ2JCPczsCM3bVi1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + nameType0 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType0.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
    }
}

