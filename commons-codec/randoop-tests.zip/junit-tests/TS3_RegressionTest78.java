import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest78 {

    public static boolean debug = false;

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest78.test079");
        java.nio.charset.Charset charset0 = org.apache.commons.codec.binary.Hex.DEFAULT_CHARSET;
        org.apache.commons.codec.binary.Hex hex1 = new org.apache.commons.codec.binary.Hex(charset0);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.codec.DecoderException decoderException3 = new org.apache.commons.codec.DecoderException(throwable2);
        org.apache.commons.codec.DecoderException decoderException4 = new org.apache.commons.codec.DecoderException(throwable2);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj5 = hex1.encode((java.lang.Object) decoderException4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: org.apache.commons.codec.DecoderException cannot be cast to [B");
        } catch (org.apache.commons.codec.EncoderException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charset0);
    }
}

