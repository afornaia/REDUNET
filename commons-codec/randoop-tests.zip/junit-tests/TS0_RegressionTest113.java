import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest113 {

    public static boolean debug = false;

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest113.test114");
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray11 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray12 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray11);
        byte[] byteArray13 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray6, byteArray11);
        java.lang.String str14 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray11);
        org.apache.commons.codec.digest.HmacUtils hmacUtils15 = new org.apache.commons.codec.digest.HmacUtils("HmacMD5", byteArray11);
        java.nio.ByteBuffer byteBuffer16 = null;
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray17 = hmacUtils15.hmac(byteBuffer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Buffer must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str14.equals("6ffb812766edee043f1e893b221b3216"));
    }
}

