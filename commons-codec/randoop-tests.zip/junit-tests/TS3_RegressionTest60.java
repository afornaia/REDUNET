import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest60 {

    public static boolean debug = false;

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest60.test061");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        java.lang.String str4 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray0);
        java.lang.String str5 = org.apache.commons.codec.binary.StringUtils.newStringUtf16(byteArray0);
        boolean boolean6 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray0);
        java.lang.String str7 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray0);
        // The following exception was thrown during execution in test generation
        try {
            long long10 = org.apache.commons.codec.digest.MurmurHash2.hash64(byteArray0, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$apr1$WabYs.bn$k0/ttQtTFJipDwD5ROWRz." + "'", str4.equals("$apr1$WabYs.bn$k0/ttQtTFJipDwD5ROWRz."));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str7 + "' != '" + "$6$0HuP.a/y$Emk1/.yIV8t1Wj7jLkY8u56xCaRdSFVT0GXwIxAqN7Yq3qmfjnhZar4fuVT7QJfMxvZ8yZLIq.Cp.kP74TD711" + "'", str7.equals("$6$0HuP.a/y$Emk1/.yIV8t1Wj7jLkY8u56xCaRdSFVT0GXwIxAqN7Yq3qmfjnhZar4fuVT7QJfMxvZ8yZLIq.Cp.kP74TD711"));
    }
}
