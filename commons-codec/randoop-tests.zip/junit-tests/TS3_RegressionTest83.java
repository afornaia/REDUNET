import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest83 {

    public static boolean debug = false;

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest83.test084");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 10, (byte) 10, (byte) 1, (byte) -1 };
        java.util.Random random7 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray5, "fe818f6c3248b346e5cb74c35601b005963c80a610d8bdccc74bdcec93807784b8aa50805db6a146b82b47a2c7f9c75f5fbd447c930036581c77fcc896792a26", random7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid salt value: fe818f6c3248b346e5cb74c35601b005963c80a610d8bdccc74bdcec93807784b8aa50805db6a146b82b47a2c7f9c75f5fbd447c930036581c77fcc896792a26");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

