import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest129 {

    public static boolean debug = false;

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest129.test130");
        org.apache.commons.codec.language.bm.Languages.LanguageSet languageSet1 = null;
        org.apache.commons.codec.language.bm.Rule.Phoneme phoneme2 = new org.apache.commons.codec.language.bm.Rule.Phoneme((java.lang.CharSequence) "", languageSet1);
        org.apache.commons.codec.language.bm.Languages.LanguageSet languageSet4 = null;
        org.apache.commons.codec.language.bm.Rule.Phoneme phoneme5 = new org.apache.commons.codec.language.bm.Rule.Phoneme((java.lang.CharSequence) "", languageSet4);
        org.apache.commons.codec.language.bm.Rule.Phoneme phoneme6 = new org.apache.commons.codec.language.bm.Rule.Phoneme(phoneme2, phoneme5);
    }
}

