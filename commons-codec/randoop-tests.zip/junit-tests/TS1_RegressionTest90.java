import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest90 {

    public static boolean debug = false;

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest90.test091");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        java.lang.String str10 = org.apache.commons.codec.binary.StringUtils.newStringUsAscii(byteArray6);
        java.lang.String str11 = org.apache.commons.codec.digest.Sha2Crypt.sha256Crypt(byteArray6);
        byte[] byteArray13 = org.apache.commons.codec.digest.DigestUtils.sha1("");
        java.lang.String str14 = org.apache.commons.codec.digest.HmacUtils.hmacSha1Hex(byteArray6, byteArray13);
        byte[] byteArray15 = org.apache.commons.codec.binary.Base64.encodeBase64URLSafe(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "\uFFFDdd\uFFFDd\uFFFD" + "'", str10.equals("\uFFFDdd\uFFFDd\uFFFD"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "$5$tKSMegrn$Qy8MV8KY7S8LvrahWVOgvWXIrv85jFD2fK92lZuhXOB" + "'", str11.equals("$5$tKSMegrn$Qy8MV8KY7S8LvrahWVOgvWXIrv85jFD2fK92lZuhXOB"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5664354c856d9ac436d1240b475c91dc86d41826" + "'", str14.equals("5664354c856d9ac436d1240b475c91dc86d41826"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray15);
    }
}
