import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest50.test051");
        org.apache.commons.codec.digest.HmacAlgorithms hmacAlgorithms0 = org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384;
        org.apache.commons.codec.digest.HmacUtils hmacUtils2 = new org.apache.commons.codec.digest.HmacUtils(hmacAlgorithms0, "$6$CJwagVkR$LFxz.A5vDPU1Bsm3dlguOVlgCdqoca0LmOBM2R4K1RAyx4pNPU4u87.Y.of2SIgqa3kxumBhbcqAaAkcxiNY40");
        org.junit.Assert.assertTrue("'" + hmacAlgorithms0 + "' != '" + org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384 + "'", hmacAlgorithms0.equals(org.apache.commons.codec.digest.HmacAlgorithms.HMAC_SHA_384));
    }
}

