import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest128 {

    public static boolean debug = false;

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest128.test129");
        org.apache.commons.codec.net.BCodec bCodec0 = new org.apache.commons.codec.net.BCodec();
        java.nio.charset.Charset charset1 = bCodec0.getCharset();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charset1);
    }
}

