import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest27.test028");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) 1 };
        javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.getHmacSha512(byteArray6);
        // The following exception was thrown during execution in test generation
        try {
            int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac7);
    }
}

