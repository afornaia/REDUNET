import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest118 {

    public static boolean debug = false;

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest118.test119");
        org.apache.commons.codec.language.Nysiis nysiis1 = new org.apache.commons.codec.language.Nysiis(true);
        byte[] byteArray8 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray13 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray8, byteArray12);
        org.apache.commons.codec.binary.Base32 base32_15 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray12, true);
        java.lang.String str16 = org.apache.commons.codec.digest.DigestUtils.md2Hex(byteArray12);
        java.lang.Object obj17 = nysiis1.encode((java.lang.Object) str16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "48fccf591114be6a396e26d783105c21" + "'", str16.equals("48fccf591114be6a396e26d783105c21"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + "FCFBAD" + "'", obj17.equals("FCFBAD"));
    }
}

