import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest62 {

    public static boolean debug = false;

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest62.test063");
        org.apache.commons.codec.net.BCodec bCodec0 = new org.apache.commons.codec.net.BCodec();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str2 = bCodec0.decode("MD5");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.DecoderException; message: RFC 1522 violation: malformed encoded content");
        } catch (org.apache.commons.codec.DecoderException e) {
        // Expected exception.
        }
    }
}

