import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest74.test075");
        byte[] byteArray1 = org.apache.commons.codec.binary.StringUtils.getBytesUsAscii("$5$t8nPJuyM$eWNtSdnfZW/l/QJUpZOjN0zdlRS2WzkB/7lVhLC1vr1");
        java.util.Random random2 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray1, random2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
    }
}

