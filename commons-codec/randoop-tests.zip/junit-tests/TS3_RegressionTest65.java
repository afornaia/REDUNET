import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest65.test066");
        org.apache.commons.codec.net.URLCodec uRLCodec1 = new org.apache.commons.codec.net.URLCodec("hi!");
        org.apache.commons.codec.net.PercentCodec percentCodec2 = new org.apache.commons.codec.net.PercentCodec();
        byte[] byteArray4 = org.apache.commons.codec.digest.DigestUtils.sha1("SHA-224");
        java.lang.String str5 = org.apache.commons.codec.digest.UnixCrypt.crypt(byteArray4);
        byte[] byteArray6 = percentCodec2.encode(byteArray4);
        byte[] byteArray7 = uRLCodec1.encode(byteArray6);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str8 = org.apache.commons.codec.digest.DigestUtils.sha3_224Hex(byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA3-224 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str5 + "' != '" + "wmcU2ETee7T3Q" + "'", str5.equals("wmcU2ETee7T3Q"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
    }
}
