import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest71 {

    public static boolean debug = false;

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest71.test072");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 10, (byte) 0, (byte) -1 };
        org.apache.commons.codec.binary.Base32 base32_6 = new org.apache.commons.codec.binary.Base32((int) (byte) -1, byteArray5);
        org.apache.commons.codec.net.QCodec qCodec7 = new org.apache.commons.codec.net.QCodec();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj8 = base32_6.encode((java.lang.Object) qCodec7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.EncoderException; message: Parameter supplied to Base-N encode is not a byte[]");
        } catch (org.apache.commons.codec.EncoderException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

