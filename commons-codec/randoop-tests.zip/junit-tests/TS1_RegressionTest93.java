import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest93 {

    public static boolean debug = false;

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest93.test094");
        org.apache.commons.codec.binary.Base32 base32_1 = new org.apache.commons.codec.binary.Base32((byte) 0);
        byte[] byteArray4 = org.apache.commons.codec.digest.HmacUtils.hmacSha1("X", "org.apache.commons.codec.DecoderException");
        java.lang.String str5 = base32_1.encodeAsString(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "34B6444CDKLTE3UVPQXFWPL22Y5G37FE" + "'", str5.equals("34B6444CDKLTE3UVPQXFWPL22Y5G37FE"));
    }
}

