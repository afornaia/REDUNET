import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest117 {

    public static boolean debug = false;

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest117.test118");
        java.util.BitSet bitSet0 = null;
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 10, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.codec.binary.Base64.decodeBase64("hi!");
        java.lang.String str7 = org.apache.commons.codec.digest.HmacUtils.hmacSha256Hex(byteArray4, byteArray6);
        byte[] byteArray8 = org.apache.commons.codec.net.URLCodec.encodeUrl(bitSet0, byteArray4);
        java.lang.String str10 = org.apache.commons.codec.binary.Hex.encodeHexString(byteArray8, true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a" + "'", str7.equals("17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "253031253041254646" + "'", str10.equals("253031253041254646"));
    }
}

