import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest74.test075");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        char[] charArray4 = org.apache.commons.codec.binary.BinaryCodec.toAsciiChars(byteArray0);
        org.apache.commons.codec.language.RefinedSoundex refinedSoundex5 = new org.apache.commons.codec.language.RefinedSoundex(charArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray4);
    }
}

