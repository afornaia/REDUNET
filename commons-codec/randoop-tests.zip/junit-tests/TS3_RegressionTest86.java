import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest86 {

    public static boolean debug = false;

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest86.test087");
        byte[] byteArray1 = new byte[] {};
        int int4 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray1, (int) (short) 0, (int) '4');
        char[] charArray5 = org.apache.commons.codec.binary.BinaryCodec.toAsciiChars(byteArray1);
        byte[] byteArray6 = org.apache.commons.codec.digest.DigestUtils.md5(byteArray1);
        // The following exception was thrown during execution in test generation
        try {
            javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.getInitializedMac("$6$LkIhBB43$F4po2PDgCInhN6oxw34dym4tK32G4HdyrwbjY7cL0dunuUNf.qQOG0LrOm47SEdioTM9.W8V3uPzsn3qgE6rw0", byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: Algorithm $6$LkIhBB43$F4po2PDgCInhN6oxw34dym4tK32G4HdyrwbjY7cL0dunuUNf.qQOG0LrOm47SEdioTM9.W8V3uPzsn3qgE6rw0 not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 33005907 + "'", int4 == 33005907);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
    }
}

