import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest28.test029");
        java.security.MessageDigest messageDigest0 = null;
        java.nio.file.Path path1 = null;
        java.nio.file.OpenOption[] openOptionArray2 = new java.nio.file.OpenOption[] {};
        // The following exception was thrown during execution in test generation
        try {
            java.security.MessageDigest messageDigest3 = org.apache.commons.codec.digest.DigestUtils.updateDigest(messageDigest0, path1, openOptionArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(openOptionArray2);
    }
}

