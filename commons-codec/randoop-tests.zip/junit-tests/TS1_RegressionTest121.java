import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest121 {

    public static boolean debug = false;

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest121.test122");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int9 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray6, (int) (short) 1, 1);
        boolean boolean10 = org.apache.commons.codec.binary.Base64.isBase64(byteArray6);
        java.lang.String str11 = org.apache.commons.codec.binary.StringUtils.newStringUtf16Le(byteArray6);
        javax.crypto.Mac mac12 = org.apache.commons.codec.digest.HmacUtils.getHmacMd5(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-759276303) + "'", int9 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "\u64FF\uFF64\uFF64" + "'", str11.equals("\u64FF\uFF64\uFF64"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac12);
    }
}

