import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest61 {

    public static boolean debug = false;

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest61.test062");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream2 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0, true);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1 };
        base32OutputStream2.write(byteArray5);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str7 = org.apache.commons.codec.digest.DigestUtils.sha3_384Hex(byteArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA3-384 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
    }
}

