import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest25.test026");
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray5 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray4);
        byte[] byteArray7 = org.apache.commons.codec.binary.StringUtils.getBytesUtf16("");
        java.lang.String str8 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray7);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray9 = org.apache.commons.codec.digest.HmacUtils.hmacSha256(byteArray5, byteArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d41d8cd98f00b204e9800998ecf8427e" + "'", str8.equals("d41d8cd98f00b204e9800998ecf8427e"));
    }
}

