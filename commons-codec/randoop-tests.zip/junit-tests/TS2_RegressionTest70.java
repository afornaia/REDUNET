import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest70 {

    public static boolean debug = false;

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest70.test071");
        org.apache.commons.codec.language.Nysiis nysiis1 = new org.apache.commons.codec.language.Nysiis(true);
        org.apache.commons.codec.StringEncoderComparator stringEncoderComparator2 = new org.apache.commons.codec.StringEncoderComparator((org.apache.commons.codec.StringEncoder) nysiis1);
    }
}

