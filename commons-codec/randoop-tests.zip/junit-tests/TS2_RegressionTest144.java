import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest144 {

    public static boolean debug = false;

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest144.test145");
        java.util.BitSet bitSet0 = null;
        byte[] byteArray4 = new byte[] { (byte) 1, (byte) 10, (byte) -1 };
        byte[] byteArray6 = org.apache.commons.codec.binary.Base64.decodeBase64("hi!");
        java.lang.String str7 = org.apache.commons.codec.digest.HmacUtils.hmacSha256Hex(byteArray4, byteArray6);
        byte[] byteArray8 = org.apache.commons.codec.net.URLCodec.encodeUrl(bitSet0, byteArray4);
        byte[] byteArray9 = org.apache.commons.codec.binary.BinaryCodec.fromAscii(byteArray4);
        long long12 = org.apache.commons.codec.digest.MurmurHash2.hash64(byteArray9, 0, (int) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a" + "'", str7.equals("17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3128609297689437303L) + "'", long12 == (-3128609297689437303L));
    }
}

