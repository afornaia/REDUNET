import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest56.test057");
        byte[] byteArray2 = org.apache.commons.codec.digest.HmacUtils.hmacSha1("\uFFFDdd\uFFFDd\uFFFD", "hi!");
        long[] longArray3 = org.apache.commons.codec.digest.MurmurHash3.hash128(byteArray2);
        java.lang.String str4 = org.apache.commons.codec.binary.StringUtils.newStringIso8859_1(byteArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + ".\u0094\u00E3\u0097\u00E1G4 \u0013!\u00F8\f#\u00E3\u0015'\u00DC\u00F3\u00C7*" + "'", str4.equals(".\u0094\u00E3\u0097\u00E1G4 \u0013!\u00F8\f#\u00E3\u0015'\u00DC\u00F3\u00C7*"));
    }
}

