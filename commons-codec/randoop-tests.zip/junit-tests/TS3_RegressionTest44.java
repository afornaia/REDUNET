import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest44.test045");
        int int1 = org.apache.commons.codec.digest.MurmurHash2.hash32("7gMAVw6x7UTZ6");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-79826993) + "'", int1 == (-79826993));
    }
}

