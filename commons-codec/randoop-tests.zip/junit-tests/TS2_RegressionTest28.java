import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest28.test029");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.net.BCodec bCodec1 = new org.apache.commons.codec.net.BCodec("hi!");
            org.junit.Assert.fail("Expected exception of type java.nio.charset.IllegalCharsetNameException; message: hi!");
        } catch (java.nio.charset.IllegalCharsetNameException e) {
        // Expected exception.
        }
    }
}

