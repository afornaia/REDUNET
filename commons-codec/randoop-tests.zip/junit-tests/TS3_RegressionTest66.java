import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest66 {

    public static boolean debug = false;

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest66.test067");
        java.lang.String str0 = org.apache.commons.codec.CharEncoding.UTF_8;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "UTF-8" + "'", str0.equals("UTF-8"));
    }
}

