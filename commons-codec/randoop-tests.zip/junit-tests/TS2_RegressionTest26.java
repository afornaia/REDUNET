import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest26.test027");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray9 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray10 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray5, byteArray9);
        // The following exception was thrown during execution in test generation
        try {
            int int14 = org.apache.commons.codec.digest.MurmurHash3.hash32x86(byteArray9, (int) 'a', (int) ' ', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
    }
}

