import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest124 {

    public static boolean debug = false;

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest124.test125");
        java.lang.String str1 = org.apache.commons.codec.digest.Crypt.crypt("$5$mATmnbyC$wb4IcWAAo/vnKvN5c/5agFj3CyaJ09PjsSY8C2bkpx.");
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str1 + "' != '" + "$6$05wPQkhb$opHhS/TW5U0abeDLwozL.tR0Y4x9LnBlqGqMkRAE/qAANOtRv5hcHiHUsoXpJTpAeWOPVWDprYpqcgicT3Gij/" + "'", str1.equals("$6$05wPQkhb$opHhS/TW5U0abeDLwozL.tR0Y4x9LnBlqGqMkRAE/qAANOtRv5hcHiHUsoXpJTpAeWOPVWDprYpqcgicT3Gij/"));
    }
}
