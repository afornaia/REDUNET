import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest126 {

    public static boolean debug = false;

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest126.test127");
        org.apache.commons.codec.language.bm.NameType nameType0 = org.apache.commons.codec.language.bm.NameType.SEPHARDIC;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine3 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, false);
        org.apache.commons.codec.language.bm.NameType nameType4 = phoneticEngine3.getNameType();
        org.apache.commons.codec.language.bm.Lang lang5 = phoneticEngine3.getLang();
        boolean boolean6 = phoneticEngine3.isConcat();
        org.junit.Assert.assertTrue("'" + nameType0 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType0.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        org.junit.Assert.assertTrue("'" + nameType4 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType4.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(lang5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }
}

