import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest125 {

    public static boolean debug = false;

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest125.test126");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.digest.HmacUtils hmacUtils2 = new org.apache.commons.codec.digest.HmacUtils("SHA3-384", "$6$K5kkONVg$3UbSH0F3j.BnPCla/yLyey5Aqw6rfJ7ccMTuVLhha/3yJt0Z14ymLgKjLnmV3knrIu8Egr1TfLsZMcaYoz/RN/");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: Algorithm SHA3-384 not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

