import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest68 {

    public static boolean debug = false;

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest68.test069");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray6 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray5);
        org.apache.commons.codec.binary.Base64 base64_7 = new org.apache.commons.codec.binary.Base64((int) (short) 10, byteArray5);
        boolean boolean8 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray5);
        java.lang.String str9 = org.apache.commons.codec.binary.StringUtils.newStringUtf8(byteArray5);
        java.io.InputStream inputStream10 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream11 = new org.apache.commons.codec.binary.Base32InputStream(inputStream10);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str12 = org.apache.commons.codec.digest.HmacUtils.hmacSha384Hex(byteArray5, (java.io.InputStream) base32InputStream11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "\u0001\uFFFD\n\u0001" + "'", str9.equals("\u0001\uFFFD\n\u0001"));
    }
}

