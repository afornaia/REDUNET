import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest116 {

    public static boolean debug = false;

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest116.test117");
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray10 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray11 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray10);
        byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray5, byteArray10);
        java.lang.String str13 = org.apache.commons.codec.binary.Base64.encodeBase64String(byteArray10);
        java.io.InputStream inputStream14 = null;
        org.apache.commons.codec.binary.Base32InputStream base32InputStream15 = new org.apache.commons.codec.binary.Base32InputStream(inputStream14);
        boolean boolean16 = base32InputStream15.markSupported();
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray17 = org.apache.commons.codec.digest.HmacUtils.hmacSha256(byteArray10, (java.io.InputStream) base32InputStream15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Af8KAQ==" + "'", str13.equals("Af8KAQ=="));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }
}

