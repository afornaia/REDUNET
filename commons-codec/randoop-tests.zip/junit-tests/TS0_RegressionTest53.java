import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest53.test054");
        org.apache.commons.codec.language.bm.NameType nameType0 = null;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine4 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, false, (-1));
        org.apache.commons.codec.language.bm.Lang lang5 = phoneticEngine4.getLang();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(lang5);
    }
}

