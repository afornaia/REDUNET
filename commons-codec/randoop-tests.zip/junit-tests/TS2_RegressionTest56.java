import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest56.test057");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray6, byteArray10);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.codec.digest.HmacUtils hmacUtils12 = new org.apache.commons.codec.digest.HmacUtils("17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a", byteArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: Algorithm 17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
    }
}

