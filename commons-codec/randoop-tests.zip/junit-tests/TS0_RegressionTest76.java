import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest76 {

    public static boolean debug = false;

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest76.test077");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream2 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream4 = new org.apache.commons.codec.binary.Base64OutputStream(outputStream0, false);
        byte[] byteArray8 = org.apache.commons.codec.binary.StringUtils.getBytesUtf16Be("SHA3-384");
        long[] longArray12 = org.apache.commons.codec.digest.MurmurHash3.hash128x64(byteArray8, (int) (byte) 0, 10, (int) (byte) 100);
        java.lang.String str13 = org.apache.commons.codec.digest.Md5Crypt.md5Crypt(byteArray8);
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream14 = new org.apache.commons.codec.binary.Base32OutputStream((java.io.OutputStream) base64OutputStream4, false, (-1), byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray12);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str13 + "' != '" + "$1$J6OWqKjJ$J2r1bqWI9w/fIfXgf60Er0" + "'", str13.equals("$1$J6OWqKjJ$J2r1bqWI9w/fIfXgf60Er0"));
    }
}
