import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest81 {

    public static boolean debug = false;

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest81.test082");
        // The following exception was thrown during execution in test generation
        try {
            java.security.MessageDigest messageDigest0 = org.apache.commons.codec.digest.DigestUtils.getSha3_512Digest();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: java.security.NoSuchAlgorithmException: SHA3-512 MessageDigest not available");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

