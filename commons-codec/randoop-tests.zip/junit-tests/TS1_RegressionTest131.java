import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest131 {

    public static boolean debug = false;

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest131.test132");
        org.apache.commons.codec.language.DoubleMetaphone doubleMetaphone0 = new org.apache.commons.codec.language.DoubleMetaphone();
        org.apache.commons.codec.language.DoubleMetaphone.DoubleMetaphoneResult doubleMetaphoneResult2 = doubleMetaphone0.new DoubleMetaphoneResult((int) (byte) 10);
        java.lang.String str4 = doubleMetaphone0.doubleMetaphone("SHA3-384");
        org.apache.commons.codec.StringEncoderComparator stringEncoderComparator5 = new org.apache.commons.codec.StringEncoderComparator((org.apache.commons.codec.StringEncoder) doubleMetaphone0);
        byte[] byteArray8 = org.apache.commons.codec.digest.HmacUtils.hmacSha1("\uFFFDdd\uFFFDd\uFFFD", "hi!");
        long[] longArray9 = org.apache.commons.codec.digest.MurmurHash3.hash128(byteArray8);
        java.lang.String str10 = org.apache.commons.codec.digest.DigestUtils.shaHex(byteArray8);
        int int12 = stringEncoderComparator5.compare((java.lang.Object) str10, (java.lang.Object) "01360240043788015936020505");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "X" + "'", str4.equals("X"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8956c9dc4abfee987a9c25ce9e466f839a947b93" + "'", str10.equals("8956c9dc4abfee987a9c25ce9e466f839a947b93"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }
}

