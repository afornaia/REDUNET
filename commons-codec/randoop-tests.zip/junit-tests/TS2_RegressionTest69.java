import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest69 {

    public static boolean debug = false;

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest69.test070");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream1 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0);
        org.apache.commons.codec.binary.BaseNCodec baseNCodec2 = null;
        org.apache.commons.codec.binary.BaseNCodecOutputStream baseNCodecOutputStream4 = new org.apache.commons.codec.binary.BaseNCodecOutputStream((java.io.OutputStream) base32OutputStream1, baseNCodec2, false);
        org.apache.commons.codec.binary.Base64OutputStream base64OutputStream5 = new org.apache.commons.codec.binary.Base64OutputStream((java.io.OutputStream) base32OutputStream1);
    }
}

