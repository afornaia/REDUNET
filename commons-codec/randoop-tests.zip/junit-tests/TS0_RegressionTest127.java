import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest127 {

    public static boolean debug = false;

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest127.test128");
        org.apache.commons.codec.language.Soundex soundex1 = new org.apache.commons.codec.language.Soundex("$apr1$go1oGj2j$neSj/z2aRRMITHEBXD7R/0");
        int int4 = soundex1.difference("SHA-512/224", "$1$J6OWqKjJ$J2r1bqWI9w/fIfXgf60Er0");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }
}

