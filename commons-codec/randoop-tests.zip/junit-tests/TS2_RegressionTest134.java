import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest134 {

    public static boolean debug = false;

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest134.test135");
        org.apache.commons.codec.language.bm.NameType nameType0 = org.apache.commons.codec.language.bm.NameType.SEPHARDIC;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine3 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, false);
        org.apache.commons.codec.language.bm.Languages languages4 = org.apache.commons.codec.language.bm.Languages.getInstance(nameType0);
        org.junit.Assert.assertTrue("'" + nameType0 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType0.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(languages4);
    }
}

