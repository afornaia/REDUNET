import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest37.test038");
        org.apache.commons.codec.language.bm.Rule.Phoneme[] phonemeArray0 = new org.apache.commons.codec.language.bm.Rule.Phoneme[] {};
        java.util.ArrayList<org.apache.commons.codec.language.bm.Rule.Phoneme> phonemeList1 = new java.util.ArrayList<org.apache.commons.codec.language.bm.Rule.Phoneme>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.codec.language.bm.Rule.Phoneme>) phonemeList1, phonemeArray0);
        org.apache.commons.codec.language.bm.Rule.PhonemeList phonemeList3 = new org.apache.commons.codec.language.bm.Rule.PhonemeList((java.util.List<org.apache.commons.codec.language.bm.Rule.Phoneme>) phonemeList1);
        java.lang.Iterable<org.apache.commons.codec.language.bm.Rule.Phoneme> phonemeIterable4 = phonemeList3.getPhonemes();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(phonemeArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(phonemeIterable4);
    }
}

