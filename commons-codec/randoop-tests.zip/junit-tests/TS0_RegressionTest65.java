import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest65.test066");
        org.apache.commons.codec.DecoderException decoderException1 = new org.apache.commons.codec.DecoderException("SHA3-512");
    }
}

