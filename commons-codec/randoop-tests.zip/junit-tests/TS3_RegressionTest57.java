import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest57 {

    public static boolean debug = false;

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest57.test058");
        java.io.OutputStream outputStream0 = null;
        org.apache.commons.codec.binary.Base32OutputStream base32OutputStream2 = new org.apache.commons.codec.binary.Base32OutputStream(outputStream0, true);
        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 1 };
        base32OutputStream2.write(byteArray5);
        byte[] byteArray7 = new byte[] {};
        int int10 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray7, (int) (short) 0, (int) '4');
        java.lang.String str11 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray7);
        // The following exception was thrown during execution in test generation
        try {
            base32OutputStream2.write(byteArray7, (int) (short) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: null");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 33005907 + "'", int10 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str11 + "' != '" + "$apr1$CheSudpF$QbyDt/rmmV4cyXgqbimWc0" + "'", str11.equals("$apr1$CheSudpF$QbyDt/rmmV4cyXgqbimWc0"));
    }
}
