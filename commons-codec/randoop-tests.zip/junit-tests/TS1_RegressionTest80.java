import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest80 {

    public static boolean debug = false;

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest80.test081");
        org.apache.commons.codec.digest.XXHash32 xXHash32_1 = new org.apache.commons.codec.digest.XXHash32(100);
        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100, (byte) 100, (byte) -1, (byte) 100, (byte) -1 };
        int int11 = org.apache.commons.codec.digest.MurmurHash2.hash32(byteArray8, (int) (short) 1, 1);
        byte[] byteArray12 = org.apache.commons.codec.digest.DigestUtils.sha384(byteArray8);
        java.lang.String str13 = org.apache.commons.codec.digest.DigestUtils.sha384Hex(byteArray12);
        // The following exception was thrown during execution in test generation
        try {
            xXHash32_1.update(byteArray12, (int) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-759276303) + "'", int11 == (-759276303));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "e155c86955251709847b19723565e7a560617a92a08fb1b98c3a7eafda86490f6c8321a1bf889028878e208e12b3c390" + "'", str13.equals("e155c86955251709847b19723565e7a560617a92a08fb1b98c3a7eafda86490f6c8321a1bf889028878e208e12b3c390"));
    }
}

