import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest102.test103");
        org.apache.commons.codec.digest.HmacAlgorithms hmacAlgorithms0 = org.apache.commons.codec.digest.HmacAlgorithms.HMAC_MD5;
        org.junit.Assert.assertTrue("'" + hmacAlgorithms0 + "' != '" + org.apache.commons.codec.digest.HmacAlgorithms.HMAC_MD5 + "'", hmacAlgorithms0.equals(org.apache.commons.codec.digest.HmacAlgorithms.HMAC_MD5));
    }
}

