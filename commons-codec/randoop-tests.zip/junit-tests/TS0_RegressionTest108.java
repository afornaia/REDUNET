import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest108.test109");
        org.apache.commons.codec.digest.XXHash32 xXHash32_1 = new org.apache.commons.codec.digest.XXHash32((int) ' ');
    }
}

