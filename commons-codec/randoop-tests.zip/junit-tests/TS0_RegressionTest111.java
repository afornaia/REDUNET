import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest111 {

    public static boolean debug = false;

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest111.test112");
        byte[] byteArray1 = org.apache.commons.codec.binary.StringUtils.getBytesUtf16Be("SHA3-384");
        long[] longArray5 = org.apache.commons.codec.digest.MurmurHash3.hash128x64(byteArray1, (int) (byte) 0, 10, (int) (byte) 100);
        java.lang.String str6 = org.apache.commons.codec.digest.Md5Crypt.md5Crypt(byteArray1);
        java.lang.String str7 = org.apache.commons.codec.digest.DigestUtils.sha512Hex(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(longArray5);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str6 + "' != '" + "$1$l9SOpfF4$XeuUo8wVBPTzpkbawVVR30" + "'", str6.equals("$1$l9SOpfF4$XeuUo8wVBPTzpkbawVVR30"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0b6cbac838dfe7f47ea1bd0df00ec282fdf45510c92161072ccfb84035390c4da743d9c3b954eaa1b0f86fc9861b23cc6c8667ab232c11c686432ebb5c8c3f27" + "'", str7.equals("0b6cbac838dfe7f47ea1bd0df00ec282fdf45510c92161072ccfb84035390c4da743d9c3b954eaa1b0f86fc9861b23cc6c8667ab232c11c686432ebb5c8c3f27"));
    }
}
