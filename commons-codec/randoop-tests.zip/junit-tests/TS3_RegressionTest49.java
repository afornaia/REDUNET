import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest49.test050");
        org.apache.commons.codec.StringEncoder stringEncoder0 = null;
        org.apache.commons.codec.StringEncoderComparator stringEncoderComparator1 = new org.apache.commons.codec.StringEncoderComparator(stringEncoder0);
        byte[] byteArray3 = org.apache.commons.codec.digest.DigestUtils.sha1("SHA-224");
        java.lang.String str4 = org.apache.commons.codec.digest.UnixCrypt.crypt(byteArray3);
        java.nio.charset.Charset charset5 = org.apache.commons.codec.Charsets.UTF_8;
        // The following exception was thrown during execution in test generation
        try {
            int int6 = stringEncoderComparator1.compare((java.lang.Object) str4, (java.lang.Object) charset5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray3);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "doijX8vhxH3nA" + "'", str4.equals("doijX8vhxH3nA"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charset5);
    }
}
