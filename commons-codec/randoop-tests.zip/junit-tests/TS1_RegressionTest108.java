import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest108 {

    public static boolean debug = false;

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest108.test109");
        java.nio.ByteBuffer byteBuffer1 = org.apache.commons.codec.binary.StringUtils.getByteBufferUtf8(".\u0094\u00E3\u0097\u00E1G4 \u0013!\u00F8\f#\u00E3\u0015'\u00DC\u00F3\u00C7*");
        java.lang.String str2 = org.apache.commons.codec.binary.Hex.encodeHexString(byteBuffer1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteBuffer1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2ec294c3a3c297c3a14734201321c3b80c23c3a31527c39cc3b3c3872a" + "'", str2.equals("2ec294c3a3c297c3a14734201321c3b80c23c3a31527c39cc3b3c3872a"));
    }
}

