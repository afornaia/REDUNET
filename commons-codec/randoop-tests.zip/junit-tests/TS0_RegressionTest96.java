import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest96 {

    public static boolean debug = false;

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest96.test097");
        java.lang.String str1 = org.apache.commons.codec.digest.DigestUtils.sha512Hex("fmuIwpYo9UPpI");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "85d36a077aabad064007523ed544988fa061e1859edad15e4a0646efab7f8a541897ecf5c10188fae159f91937f9b4cd73c99eb5464d8f847812db0bfb1edada" + "'", str1.equals("85d36a077aabad064007523ed544988fa061e1859edad15e4a0646efab7f8a541897ecf5c10188fae159f91937f9b4cd73c99eb5464d8f847812db0bfb1edada"));
    }
}

