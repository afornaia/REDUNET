import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest8.test009");
        org.apache.commons.codec.language.bm.NameType nameType0 = null;
        org.apache.commons.codec.language.bm.Languages languages1 = org.apache.commons.codec.language.bm.Languages.getInstance(nameType0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(languages1);
    }
}

