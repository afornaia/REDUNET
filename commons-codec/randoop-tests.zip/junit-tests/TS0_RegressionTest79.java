import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest79 {

    public static boolean debug = false;

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest79.test080");
        org.apache.commons.codec.digest.Crypt crypt0 = new org.apache.commons.codec.digest.Crypt();
    }
}

