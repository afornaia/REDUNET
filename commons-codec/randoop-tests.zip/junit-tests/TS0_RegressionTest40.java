import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest40.test041");
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray1 = org.apache.commons.codec.binary.Hex.decodeHex("SHA3-384[null]");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.codec.DecoderException; message: Illegal hexadecimal character S at index 0");
        } catch (org.apache.commons.codec.DecoderException e) {
        // Expected exception.
        }
    }
}

