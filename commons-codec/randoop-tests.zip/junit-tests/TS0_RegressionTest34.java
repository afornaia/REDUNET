import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest34.test035");
        byte[] byteArray5 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray6 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray5);
        org.apache.commons.codec.binary.Base64 base64_7 = new org.apache.commons.codec.binary.Base64((int) (short) 10, byteArray5);
        byte[] byteArray13 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray18 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray19 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray18);
        byte[] byteArray20 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray13, byteArray18);
        java.lang.String str21 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray18);
        byte[] byteArray22 = org.apache.commons.codec.digest.DigestUtils.md2(byteArray18);
        byte[] byteArray23 = base64_7.encode(byteArray22);
        byte[] byteArray24 = org.apache.commons.codec.digest.DigestUtils.sha(byteArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray19);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str21.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray24);
    }
}

