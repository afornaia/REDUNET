import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest50.test051");
        org.apache.commons.codec.binary.Base32 base32_1 = new org.apache.commons.codec.binary.Base32((byte) 1);
        boolean boolean2 = base32_1.isStrictDecoding();
        boolean boolean4 = base32_1.isInAlphabet("");
        byte[] byteArray9 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray10 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray9);
        byte[] byteArray11 = base32_1.decode(byteArray10);
        byte[] byteArray18 = new byte[] { (byte) 0, (byte) 1, (byte) 1, (byte) 100, (byte) 1 };
        byte[] byteArray23 = new byte[] { (byte) 1, (byte) -1, (byte) 10, (byte) 1 };
        byte[] byteArray24 = org.apache.commons.codec.binary.Base64.decodeBase64(byteArray23);
        byte[] byteArray25 = org.apache.commons.codec.digest.HmacUtils.hmacSha512(byteArray18, byteArray23);
        java.lang.String str26 = org.apache.commons.codec.digest.DigestUtils.md5Hex(byteArray23);
        org.apache.commons.codec.digest.HmacUtils hmacUtils27 = new org.apache.commons.codec.digest.HmacUtils("HmacMD5", byteArray23);
        byte[] byteArray28 = base32_1.encode(byteArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "6ffb812766edee043f1e893b221b3216" + "'", str26.equals("6ffb812766edee043f1e893b221b3216"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray28);
    }
}

