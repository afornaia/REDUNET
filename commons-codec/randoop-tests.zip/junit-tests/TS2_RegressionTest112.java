import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest112 {

    public static boolean debug = false;

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest112.test113");
        byte[] byteArray6 = new byte[] { (byte) -1, (byte) 0, (byte) 10, (byte) 1, (byte) 100, (byte) 1 };
        javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.getHmacSha512(byteArray6);
        byte[] byteArray8 = org.apache.commons.codec.digest.DigestUtils.sha256(byteArray6);
        java.lang.String str9 = org.apache.commons.codec.digest.DigestUtils.sha256Hex(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mac7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "470f996ba1f9249fc405cc23505b57394762e2c17b61f69472107365ee52fba9" + "'", str9.equals("470f996ba1f9249fc405cc23505b57394762e2c17b61f69472107365ee52fba9"));
    }
}

