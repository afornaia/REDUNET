import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest97 {

    public static boolean debug = false;

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest97.test098");
        org.apache.commons.codec.language.bm.NameType nameType0 = org.apache.commons.codec.language.bm.NameType.SEPHARDIC;
        org.apache.commons.codec.language.bm.RuleType ruleType1 = null;
        org.apache.commons.codec.language.bm.PhoneticEngine phoneticEngine3 = new org.apache.commons.codec.language.bm.PhoneticEngine(nameType0, ruleType1, false);
        org.apache.commons.codec.language.bm.RuleType ruleType4 = org.apache.commons.codec.language.bm.RuleType.EXACT;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map<java.lang.String, java.util.List<org.apache.commons.codec.language.bm.Rule>> strMap6 = org.apache.commons.codec.language.bm.Rule.getInstanceMap(nameType0, ruleType4, "SHA3-384");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No rules found for sep, exact, SHA3-384.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + nameType0 + "' != '" + org.apache.commons.codec.language.bm.NameType.SEPHARDIC + "'", nameType0.equals(org.apache.commons.codec.language.bm.NameType.SEPHARDIC));
        org.junit.Assert.assertTrue("'" + ruleType4 + "' != '" + org.apache.commons.codec.language.bm.RuleType.EXACT + "'", ruleType4.equals(org.apache.commons.codec.language.bm.RuleType.EXACT));
    }
}

