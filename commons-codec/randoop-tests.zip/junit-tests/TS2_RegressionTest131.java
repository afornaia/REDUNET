import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest131 {

    public static boolean debug = false;

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest131.test132");
        org.apache.commons.codec.language.bm.RuleType ruleType0 = org.apache.commons.codec.language.bm.RuleType.RULES;
        org.junit.Assert.assertTrue("'" + ruleType0 + "' != '" + org.apache.commons.codec.language.bm.RuleType.RULES + "'", ruleType0.equals(org.apache.commons.codec.language.bm.RuleType.RULES));
    }
}

