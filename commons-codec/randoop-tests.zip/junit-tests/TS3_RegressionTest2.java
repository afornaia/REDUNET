import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest2.test003");
        javax.crypto.Mac mac0 = null;
        byte[] byteArray6 = new byte[] { (byte) 0, (byte) 0, (byte) 1, (byte) 0, (byte) 100 };
        // The following exception was thrown during execution in test generation
        try {
            javax.crypto.Mac mac7 = org.apache.commons.codec.digest.HmacUtils.updateHmac(mac0, byteArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
    }
}

