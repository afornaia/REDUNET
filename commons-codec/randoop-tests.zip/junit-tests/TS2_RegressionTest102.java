import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest102 {

    public static boolean debug = false;

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest102.test103");
        byte[] byteArray6 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray11 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray6, byteArray10);
        org.apache.commons.codec.binary.Base32 base32_13 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray10, true);
        byte[] byteArray20 = new byte[] { (byte) 1, (byte) 100, (byte) 0, (byte) 10, (byte) 0 };
        byte[] byteArray24 = new byte[] { (byte) -1, (byte) 10, (byte) 100 };
        byte[] byteArray25 = org.apache.commons.codec.digest.HmacUtils.hmacSha1(byteArray20, byteArray24);
        org.apache.commons.codec.binary.Base32 base32_27 = new org.apache.commons.codec.binary.Base32((int) (short) -1, byteArray24, true);
        java.lang.String str28 = org.apache.commons.codec.digest.DigestUtils.sha1Hex(byteArray24);
        java.lang.String str29 = base32_13.encodeToString(byteArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray25);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "e727960a63d19331bfa80e194620fb43a52c3612" + "'", str28.equals("e727960a63d19331bfa80e194620fb43a52c3612"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "VS568===" + "'", str29.equals("VS568==="));
    }
}

