import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest63.test064");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        java.lang.String str4 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray0);
        java.lang.String str5 = org.apache.commons.codec.binary.StringUtils.newStringUtf16(byteArray0);
        boolean boolean6 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray0);
        java.lang.String str7 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray0);
        java.lang.String str8 = org.apache.commons.codec.digest.Sha2Crypt.sha512Crypt(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$apr1$YPRGL5eF$fikELsk0E.aQVvksdnTzS1" + "'", str4.equals("$apr1$YPRGL5eF$fikELsk0E.aQVvksdnTzS1"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str7 + "' != '" + "$6$LkIhBB43$F4po2PDgCInhN6oxw34dym4tK32G4HdyrwbjY7cL0dunuUNf.qQOG0LrOm47SEdioTM9.W8V3uPzsn3qgE6rw0" + "'", str7.equals("$6$LkIhBB43$F4po2PDgCInhN6oxw34dym4tK32G4HdyrwbjY7cL0dunuUNf.qQOG0LrOm47SEdioTM9.W8V3uPzsn3qgE6rw0"));
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str8 + "' != '" + "$6$1PQDJw2e$ecX9fWo9YAWtn13i/OTcLsF2b4IwFWDkxFDF7z7pmE2m73hTUmwneiOnQNrblwJ7yKqZOfmKjHWFMgLGH9rkd/" + "'", str8.equals("$6$1PQDJw2e$ecX9fWo9YAWtn13i/OTcLsF2b4IwFWDkxFDF7z7pmE2m73hTUmwneiOnQNrblwJ7yKqZOfmKjHWFMgLGH9rkd/"));
    }
}
