import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest67.test068");
        org.apache.commons.codec.net.QCodec qCodec0 = new org.apache.commons.codec.net.QCodec();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str3 = qCodec0.encode("17460a065833c815e8bde9fbc4909a3945daae1d8afa222457bb02511638634a", "F9E20DB6D388A9F86A3374779247C5460A1A5574");
            org.junit.Assert.fail("Expected exception of type java.nio.charset.UnsupportedCharsetException; message: F9E20DB6D388A9F86A3374779247C5460A1A5574");
        } catch (java.nio.charset.UnsupportedCharsetException e) {
        // Expected exception.
        }
    }
}

