import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest29.test030");
        byte[] byteArray0 = new byte[] {};
        int int3 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray0, (int) (short) 0, (int) '4');
        java.lang.String str4 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray0);
        byte[] byteArray5 = new byte[] {};
        int int8 = org.apache.commons.codec.digest.MurmurHash3.hash32(byteArray5, (int) (short) 0, (int) '4');
        java.lang.String str9 = org.apache.commons.codec.digest.Md5Crypt.apr1Crypt(byteArray5);
        java.lang.String str10 = org.apache.commons.codec.binary.StringUtils.newStringUtf16(byteArray5);
        boolean boolean11 = org.apache.commons.codec.binary.Base64.isArrayByteBase64(byteArray5);
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray12 = org.apache.commons.codec.digest.HmacUtils.hmacSha256(byteArray0, byteArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty key");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 33005907 + "'", int3 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str4 + "' != '" + "$apr1$l1O7iOhu$RNpwjX0LxwrO7FtSnljp2/" + "'", str4.equals("$apr1$l1O7iOhu$RNpwjX0LxwrO7FtSnljp2/"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(byteArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 33005907 + "'", int8 == 33005907);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + str9 + "' != '" + "$apr1$g6YbXz/r$V6iKaW952gRa1QFdWQlQ21" + "'", str9.equals("$apr1$g6YbXz/r$V6iKaW952gRa1QFdWQlQ21"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }
}
