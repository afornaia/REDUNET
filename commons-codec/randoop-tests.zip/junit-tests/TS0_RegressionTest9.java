import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest9.test010");
        // The following exception was thrown during execution in test generation
        try {
            byte[] byteArray2 = org.apache.commons.codec.binary.StringUtils.getBytesUnchecked("", "SHA3-384");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: SHA3-384: java.io.UnsupportedEncodingException: SHA3-384");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
    }
}

