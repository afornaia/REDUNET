import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest53.test54");
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape0 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter1 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape0);
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape2 = bitSetBloomFilter1.getShape();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(shape2);
    }
}

