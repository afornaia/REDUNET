import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest38.test39");
        java.util.Comparator<org.apache.commons.collections4.bloomfilter.BitSetBloomFilter> bitSetBloomFilterComparator0 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<org.apache.commons.collections4.bloomfilter.BitSetBloomFilter> bitSetBloomFilterComparatorChain1 = new org.apache.commons.collections4.comparators.ComparatorChain<org.apache.commons.collections4.bloomfilter.BitSetBloomFilter>(bitSetBloomFilterComparator0);
        int int2 = bitSetBloomFilterComparatorChain1.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }
}

