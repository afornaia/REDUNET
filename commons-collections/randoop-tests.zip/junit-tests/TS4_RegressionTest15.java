import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest15.test16");
        java.util.Comparator<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparator0 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparatorChain2 = new org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>(comparableMapSpliteratorComparator0, false);
        java.util.Comparator<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparator4 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparatorChain6 = new org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>(comparableMapSpliteratorComparator4, false);
        // The following exception was thrown during execution in test generation
        try {
            comparableMapSpliteratorComparatorChain2.setComparator(31, comparableMapSpliteratorComparator4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 31, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
    }
}

