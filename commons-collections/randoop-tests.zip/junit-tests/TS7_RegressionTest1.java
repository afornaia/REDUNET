import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest1.test02");
        java.util.concurrent.TimeUnit timeUnit1 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetCollectionConstantTimeToLiveExpirationPolicy2 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>(100L, timeUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: timeUnit");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

