import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest42.test43");
        org.apache.commons.collections4.bag.HashBag<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>[]> objConstantTimeToLiveExpirationPolicyArrayCollection0 = new org.apache.commons.collections4.bag.HashBag<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>[]>();
        boolean boolean1 = objConstantTimeToLiveExpirationPolicyArrayCollection0.isEmpty();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

