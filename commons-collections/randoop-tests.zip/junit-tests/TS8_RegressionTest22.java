import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest22.test23");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.collections4.FunctorException functorException2 = new org.apache.commons.collections4.FunctorException("hi!", throwable1);
        java.lang.Throwable[] throwableArray3 = functorException2.getSuppressed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray3);
    }
}

