import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest7.test08");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet19 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray32 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet19, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList33 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList33, serializableArray32);
        boolean boolean35 = serializableSet0.containsAll((java.util.Collection<java.io.Serializable>) serializableList33);
        java.util.ListIterator<java.lang.Cloneable> cloneableItor36 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((java.lang.Cloneable) serializableList33);
        java.util.ArrayList<java.util.ListIterator<java.lang.Cloneable>> cloneableItorList37 = new java.util.ArrayList<java.util.ListIterator<java.lang.Cloneable>>();
        boolean boolean38 = cloneableItorList37.add(cloneableItor36);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet39 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet58 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray71 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet58, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList72 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList72, serializableArray71);
        boolean boolean74 = serializableSet39.containsAll((java.util.Collection<java.io.Serializable>) serializableList72);
        java.util.ListIterator<java.lang.Cloneable> cloneableItor75 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((java.lang.Cloneable) serializableList72);
        java.util.ArrayList<java.util.ListIterator<java.lang.Cloneable>> cloneableItorList76 = new java.util.ArrayList<java.util.ListIterator<java.lang.Cloneable>>();
        boolean boolean77 = cloneableItorList76.add(cloneableItor75);
        org.apache.commons.collections4.sequence.SequencesComparator<java.util.ListIterator<java.lang.Cloneable>> cloneableItorSequencesComparator78 = new org.apache.commons.collections4.sequence.SequencesComparator<java.util.ListIterator<java.lang.Cloneable>>((java.util.List<java.util.ListIterator<java.lang.Cloneable>>) cloneableItorList37, (java.util.List<java.util.ListIterator<java.lang.Cloneable>>) cloneableItorList76);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(cloneableItor36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray71);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(cloneableItor75);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
    }
}

