import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest24.test25");
        org.apache.commons.collections4.iterators.IteratorChain<java.util.Comparator<java.lang.Boolean>> booleanComparatorItor0 = new org.apache.commons.collections4.iterators.IteratorChain<java.util.Comparator<java.lang.Boolean>>();
    }
}

