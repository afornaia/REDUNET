import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest22.test23");
        org.apache.commons.collections4.Transformer<? super org.apache.commons.collections4.bloomfilter.BitSetBloomFilter, ? extends org.apache.commons.collections4.bloomfilter.BitSetBloomFilter> wildcardTransformer0 = null;
        org.apache.commons.collections4.Transformer[] transformerArray2 = new org.apache.commons.collections4.Transformer[1];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Transformer<? super org.apache.commons.collections4.bloomfilter.BitSetBloomFilter, ? extends org.apache.commons.collections4.bloomfilter.BitSetBloomFilter>[] wildcardTransformerArray3 = (org.apache.commons.collections4.Transformer<? super org.apache.commons.collections4.bloomfilter.BitSetBloomFilter, ? extends org.apache.commons.collections4.bloomfilter.BitSetBloomFilter>[]) transformerArray2;
        wildcardTransformerArray3[0] = wildcardTransformer0;
        org.apache.commons.collections4.functors.ChainedTransformer<org.apache.commons.collections4.bloomfilter.BitSetBloomFilter> bitSetBloomFilterChainedTransformer6 = new org.apache.commons.collections4.functors.ChainedTransformer<org.apache.commons.collections4.bloomfilter.BitSetBloomFilter>(wildcardTransformerArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(transformerArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardTransformerArray3);
    }
}

