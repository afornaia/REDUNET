import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest9.test10");
        org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness signedness0 = org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED;
        org.junit.Assert.assertTrue("'" + signedness0 + "' != '" + org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED + "'", signedness0.equals(org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED));
    }
}

