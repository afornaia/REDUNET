import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest1.test02");
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor0 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.Factory<java.util.Iterator<java.io.Serializable>> serializableItorFactory1 = org.apache.commons.collections4.FactoryUtils.prototypeFactory((java.util.Iterator<java.io.Serializable>) serializableItor0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The prototype must be cloneable via a public clone method");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

