import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest43.test44");
        org.apache.commons.collections4.bloomfilter.hasher.function.ObjectsHashIterative objectsHashIterative0 = new org.apache.commons.collections4.bloomfilter.hasher.function.ObjectsHashIterative();
    }
}

