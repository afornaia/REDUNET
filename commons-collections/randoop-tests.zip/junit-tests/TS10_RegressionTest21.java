import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest21.test22");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = null;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = null;
        org.apache.commons.collections4.map.ReferenceIdentityMap<java.io.Serializable, java.util.Hashtable<java.lang.Object, java.lang.Object>> serializableMap5 = new org.apache.commons.collections4.map.ReferenceIdentityMap<java.io.Serializable, java.util.Hashtable<java.lang.Object, java.lang.Object>>(referenceStrength0, referenceStrength1, (int) (byte) 1, (float) 'a', false);
    }
}

