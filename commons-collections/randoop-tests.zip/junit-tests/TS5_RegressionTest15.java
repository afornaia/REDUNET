import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest15.test16");
        org.apache.commons.collections4.Closure closure0 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure0);
    }
}

