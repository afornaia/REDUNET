import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest38.test39");
        java.util.Map<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerMap0 = null;
        java.util.Map[] mapArray2 = new java.util.Map[1];
        @SuppressWarnings("unchecked")
        java.util.Map<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>[] stringKeyAnalyzerMapArray3 = (java.util.Map<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>[]) mapArray2;
        stringKeyAnalyzerMapArray3[0] = stringKeyAnalyzerMap0;
        org.apache.commons.collections4.map.CompositeMap.MapMutator<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerMapMutator6 = null;
        org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerMap7 = new org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>(stringKeyAnalyzerMapArray3, stringKeyAnalyzerMapMutator6);
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList9 = stringKeyAnalyzerMap7.remove((java.lang.Object) 0.0d);
        java.util.Collection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> referenceStrengthListCollection10 = stringKeyAnalyzerMap7.values();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringKeyAnalyzerMapArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(referenceStrengthList9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListCollection10);
    }
}

