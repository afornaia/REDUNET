import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest11.test12");
        org.apache.commons.collections4.OrderedIterator<java.util.AbstractMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>> strMultiValuedMapMapItor0 = null;
        org.apache.commons.collections4.Transformer<org.apache.commons.collections4.Transformer<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion, java.lang.String>, org.apache.commons.collections4.OrderedIterator<java.util.AbstractMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>> criterionTransformerTransformer1 = org.apache.commons.collections4.TransformerUtils.constantTransformer(strMultiValuedMapMapItor0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(criterionTransformerTransformer1);
    }
}

