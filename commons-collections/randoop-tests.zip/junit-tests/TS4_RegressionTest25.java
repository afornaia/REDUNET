import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest25.test26");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.collections4.FunctorException functorException1 = new org.apache.commons.collections4.FunctorException(throwable0);
        java.lang.Throwable[] throwableArray2 = functorException1.getSuppressed();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(throwableArray2);
    }
}

