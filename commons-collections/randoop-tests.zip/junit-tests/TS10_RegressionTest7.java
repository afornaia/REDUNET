import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest7.test08");
        org.apache.commons.collections4.map.LinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>> strComparableItorMap2 = new org.apache.commons.collections4.map.LinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>((int) '#', (float) (short) 100);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>> strComparableItor3 = strComparableItorMap2.lastKey();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: Map is empty");
        } catch (java.util.NoSuchElementException e) {
        // Expected exception.
        }
    }
}

