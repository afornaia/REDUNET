import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest38.test39");
        org.apache.commons.collections4.Predicate predicate0 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate1 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate2 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate3 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate4 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate5 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate[] predicateArray7 = new org.apache.commons.collections4.Predicate[6];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.util.RandomAccess>[] wildcardPredicateArray8 = (org.apache.commons.collections4.Predicate<? super java.util.RandomAccess>[]) predicateArray7;
        wildcardPredicateArray8[0] = predicate0;
        wildcardPredicateArray8[1] = predicate1;
        wildcardPredicateArray8[2] = predicate2;
        wildcardPredicateArray8[3] = predicate3;
        wildcardPredicateArray8[4] = predicate4;
        wildcardPredicateArray8[5] = predicate5;
        org.apache.commons.collections4.Predicate<java.util.RandomAccess> randomAccessPredicate21 = org.apache.commons.collections4.PredicateUtils.allPredicate(wildcardPredicateArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(randomAccessPredicate21);
    }
}

