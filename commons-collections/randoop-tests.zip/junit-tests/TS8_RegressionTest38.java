import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest38.test39");
        org.apache.commons.collections4.FunctorException functorException1 = new org.apache.commons.collections4.FunctorException("hi!");
    }
}

