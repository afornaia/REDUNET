import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest49.test50");
        org.apache.commons.collections4.functors.ComparatorPredicate.Criterion criterion0 = org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER;
        org.junit.Assert.assertTrue("'" + criterion0 + "' != '" + org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER + "'", criterion0.equals(org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER));
    }
}

