import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest41.test42");
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap1 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet2 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean4 = serializableSet2.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement5 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry6 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet2, annotatedElement5);
        boolean boolean7 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet2);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet8 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean10 = serializableSet8.add((java.io.Serializable) 1.0f);
        java.util.List<java.io.Serializable> serializableList11 = org.apache.commons.collections4.ListUtils.removeAll((java.util.Collection<java.io.Serializable>) serializableSet2, (java.util.Collection<java.io.Serializable>) serializableSet8);
        boolean boolean12 = serializableMap1.equals((java.lang.Object) serializableList11);
        org.apache.commons.collections4.Predicate predicate13 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate14 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate15 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate16 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate17 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate18 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate[] predicateArray20 = new org.apache.commons.collections4.Predicate[6];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.util.Set<java.io.Serializable>>[] wildcardPredicateArray21 = (org.apache.commons.collections4.Predicate<? super java.util.Set<java.io.Serializable>>[]) predicateArray20;
        wildcardPredicateArray21[0] = predicate13;
        wildcardPredicateArray21[1] = predicate14;
        wildcardPredicateArray21[2] = predicate15;
        wildcardPredicateArray21[3] = predicate16;
        wildcardPredicateArray21[4] = predicate17;
        wildcardPredicateArray21[5] = predicate18;
        org.apache.commons.collections4.functors.NonePredicate<java.util.Set<java.io.Serializable>> serializableSetNonePredicate34 = new org.apache.commons.collections4.functors.NonePredicate<java.util.Set<java.io.Serializable>>(wildcardPredicateArray21);
        java.util.Map<java.io.Serializable, java.lang.Object> serializableMap35 = org.apache.commons.collections4.MapUtils.putAll((java.util.Map<java.io.Serializable, java.lang.Object>) serializableMap1, (java.lang.Object[]) wildcardPredicateArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableList11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate15);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableMap35);
    }
}

