import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest29.test30");
        java.util.SortedMap sortedMap0 = org.apache.commons.collections4.MapUtils.EMPTY_SORTED_MAP;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sortedMap0);
    }
}

