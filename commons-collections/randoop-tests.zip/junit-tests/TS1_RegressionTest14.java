import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest14.test15");
        org.apache.commons.collections4.SortedBag<org.apache.commons.collections4.FunctorException> functorExceptionCollection0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.bag.CollectionSortedBag<org.apache.commons.collections4.FunctorException> functorExceptionCollection1 = new org.apache.commons.collections4.bag.CollectionSortedBag<org.apache.commons.collections4.FunctorException>(functorExceptionCollection0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: collection");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

