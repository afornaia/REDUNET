import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest36.test37");
        org.apache.commons.collections4.list.TreeList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>> strComparableMultiValuedMapList0 = new org.apache.commons.collections4.list.TreeList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>();
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap2 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray4 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray5 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray4;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate6 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray4);
        boolean boolean7 = strComparableArrayListValuedHashMap2.containsValue((java.lang.Object) predicateArray4);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap8 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap2);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap10 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray12 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray13 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray12;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate14 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray12);
        boolean boolean15 = strComparableArrayListValuedHashMap10.containsValue((java.lang.Object) predicateArray12);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap16 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap10);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet17 = strComparableArrayListValuedHashMap16.keySet();
        java.util.ArrayList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>> strComparableMultiValuedMapList18 = new java.util.ArrayList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>();
        boolean boolean19 = strComparableMultiValuedMapList18.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap8);
        boolean boolean20 = strComparableMultiValuedMapList18.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap16);
        java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>> strComparableMultiValuedMapList21 = org.apache.commons.collections4.ListUtils.subtract((java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>) strComparableMultiValuedMapList0, (java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>) strComparableMultiValuedMapList18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableSet17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableMultiValuedMapList21);
    }
}

