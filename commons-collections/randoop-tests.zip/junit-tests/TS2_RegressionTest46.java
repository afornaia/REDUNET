import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest46.test47");
        org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Iterable<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType> strComparableIterableDefaultKeyValue0 = new org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Iterable<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>();
        org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Iterable<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType> strComparableIterableDefaultKeyValue1 = new org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Iterable<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>((org.apache.commons.collections4.KeyValue<java.lang.Iterable<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>) strComparableIterableDefaultKeyValue0);
    }
}

