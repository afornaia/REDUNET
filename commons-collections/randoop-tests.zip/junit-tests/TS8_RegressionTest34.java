import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest34.test35");
        org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.sequence.EditCommand<org.apache.commons.collections4.Transformer<java.util.Collection<java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.Comparable<java.lang.String>>>>> collectionTransformerEditCommandReverseComparator0 = new org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.sequence.EditCommand<org.apache.commons.collections4.Transformer<java.util.Collection<java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.Comparable<java.lang.String>>>>>();
    }
}

