import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest34.test35");
        org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence> strComparableMap2 = new org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>((java.lang.Comparable<java.lang.String>) "hi!", (java.lang.CharSequence) "hi!");
        java.lang.Float float5 = org.apache.commons.collections4.MapUtils.getFloat((java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap2, "hi!", (java.lang.Float) 10.0f);
        boolean boolean6 = org.apache.commons.collections4.MapUtils.isEmpty((java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap2);
        java.lang.Comparable<java.lang.String> strComparable7 = strComparableMap2.getKey();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 10.0f + "'", float5.equals(10.0f));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + strComparable7 + "' != '" + "hi!" + "'", strComparable7.equals("hi!"));
    }
}

