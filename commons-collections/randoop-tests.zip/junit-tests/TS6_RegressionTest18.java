import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest18.test19");
        java.util.Collection<java.lang.Object> objCollection0 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Collection<java.util.List<java.lang.Object>> objListCollection1 = org.apache.commons.collections4.CollectionUtils.permutations(objCollection0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: collection");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

