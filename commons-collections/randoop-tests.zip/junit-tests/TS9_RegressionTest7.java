import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest7.test08");
        java.util.Set<java.lang.String> strSet0 = org.apache.commons.collections4.SetUtils.emptySet();
        java.util.Collection<java.util.List<java.lang.String>> strListCollection1 = org.apache.commons.collections4.CollectionUtils.permutations((java.util.Collection<java.lang.String>) strSet0);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.ArrayIterator<org.apache.commons.collections4.Bag<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>> builderCollectionItor4 = new org.apache.commons.collections4.iterators.ArrayIterator<org.apache.commons.collections4.Bag<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>((java.lang.Object) strListCollection1, (int) '#', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strSet0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strListCollection1);
    }
}

