import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest7.test08");
        java.util.Map<java.lang.CharSequence, java.lang.Object> charSequenceMap0 = null;
        java.lang.Object obj3 = org.apache.commons.collections4.MapUtils.getObject(charSequenceMap0, (java.lang.CharSequence) "MD5", (java.lang.Object) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + (byte) 10 + "'", obj3.equals((byte) 10));
    }
}

