import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest58.test59");
        org.apache.commons.collections4.trie.PatriciaTrie<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>> propertyFormatEnumMap0 = new org.apache.commons.collections4.trie.PatriciaTrie<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>>();
        java.util.SortedMap<java.lang.String, java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>> strMap2 = propertyFormatEnumMap0.tailMap("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMap2);
    }
}

