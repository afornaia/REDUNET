import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest12.test13");
        java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>> charSequenceMultiValuedMapItor0 = null;
        org.apache.commons.collections4.iterators.SingletonIterator<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>> charSequenceMultiValuedMapItorItor2 = new org.apache.commons.collections4.iterators.SingletonIterator<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>(charSequenceMultiValuedMapItor0, false);
        boolean boolean3 = charSequenceMultiValuedMapItorItor2.hasNext();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

