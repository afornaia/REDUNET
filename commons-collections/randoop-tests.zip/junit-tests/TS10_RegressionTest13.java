import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest13.test14");
        java.util.Collection<java.lang.CharSequence> charSequenceCollection0 = null;
        java.lang.CharSequence[] charSequenceArray3 = new java.lang.CharSequence[] { "", "hi!" };
        java.util.ArrayList<java.lang.CharSequence> charSequenceList4 = new java.util.ArrayList<java.lang.CharSequence>();
        boolean boolean5 = java.util.Collections.addAll((java.util.Collection<java.lang.CharSequence>) charSequenceList4, charSequenceArray3);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap7 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        org.apache.commons.collections4.MultiSet<java.lang.CharSequence> charSequenceCollection8 = charSequenceArrayListValuedHashMap7.keys();
        int int9 = org.apache.commons.collections4.IterableUtils.size((java.lang.Iterable<java.lang.CharSequence>) charSequenceCollection8);
        boolean boolean10 = org.apache.commons.collections4.CollectionUtils.containsAll((java.util.Collection<java.lang.CharSequence>) charSequenceList4, (java.util.Collection<java.lang.CharSequence>) charSequenceCollection8);
        java.util.Spliterator<java.lang.CharSequence> charSequenceSpliterator11 = charSequenceCollection8.spliterator();
        // The following exception was thrown during execution in test generation
        try {
            java.util.List<java.lang.CharSequence> charSequenceList12 = org.apache.commons.collections4.ListUtils.retainAll(charSequenceCollection0, (java.util.Collection<java.lang.CharSequence>) charSequenceCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceCollection8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceSpliterator11);
    }
}

