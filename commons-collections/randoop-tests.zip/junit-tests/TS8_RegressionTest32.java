import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest32.test33");
        org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.sequence.DeleteCommand<org.apache.commons.collections4.Transformer<java.util.Collection<java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.Comparable<java.lang.String>>>>> collectionTransformerDeleteCommandSet0 = new org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.sequence.DeleteCommand<org.apache.commons.collections4.Transformer<java.util.Collection<java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.Comparable<java.lang.String>>>>>();
    }
}

