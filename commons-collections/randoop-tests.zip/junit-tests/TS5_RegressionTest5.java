import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest5.test06");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.set.AbstractSerializableSetDecorator<java.io.Serializable>, org.apache.commons.collections4.set.CompositeSet<java.util.RandomAccess>> serializableSetMap1 = new org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.set.AbstractSerializableSetDecorator<java.io.Serializable>, org.apache.commons.collections4.set.CompositeSet<java.util.RandomAccess>>(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: LRUMap max size must be greater than 0");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

