import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest18.test19");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet1 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet20 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray33 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet20, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList34 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean35 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList34, serializableArray33);
        boolean boolean36 = serializableSet1.containsAll((java.util.Collection<java.io.Serializable>) serializableList34);
        java.util.ListIterator<java.lang.Cloneable> cloneableItor37 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((java.lang.Cloneable) serializableList34);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet39 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean41 = serializableSet39.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement42 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry43 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet39, annotatedElement42);
        boolean boolean44 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet39);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet45 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean47 = serializableSet45.add((java.io.Serializable) 1.0f);
        java.util.List<java.io.Serializable> serializableList48 = org.apache.commons.collections4.ListUtils.removeAll((java.util.Collection<java.io.Serializable>) serializableSet39, (java.util.Collection<java.io.Serializable>) serializableSet45);
        boolean boolean49 = serializableList34.addAll((int) (byte) 10, (java.util.Collection<java.io.Serializable>) serializableList48);
        java.io.Serializable[] serializableArray50 = new java.io.Serializable[] { serializableList34 };
        boolean boolean51 = org.apache.commons.collections4.CollectionUtils.addAll((java.util.Collection<java.io.Serializable>) serializableSet0, serializableArray50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(cloneableItor37);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableList48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }
}

