import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest5.test06");
        java.util.Map<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, java.lang.String> listCollectionItorMap0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.EntrySetMapIterator<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, java.lang.String> listCollectionItorItor1 = new org.apache.commons.collections4.iterators.EntrySetMapIterator<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, java.lang.String>(listCollectionItorMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

