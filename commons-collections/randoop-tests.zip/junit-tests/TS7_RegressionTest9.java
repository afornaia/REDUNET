import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest9.test10");
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyMapList1 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>((int) (short) -1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyMapList3 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>((int) (short) -1);
        java.util.List[] listArray5 = new java.util.List[2];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>[] wildcardMultiKeyMapListArray6 = (java.util.List<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>[]) listArray5;
        wildcardMultiKeyMapListArray6[0] = wildcardMultiKeyMapList1;
        wildcardMultiKeyMapListArray6[1] = wildcardMultiKeyMapList3;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.ObjectArrayIterator<java.util.List<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> wildcardMultiKeyMapListItor13 = new org.apache.commons.collections4.iterators.ObjectArrayIterator<java.util.List<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>>(wildcardMultiKeyMapListArray6, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: End index must not be greater than the array length");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyMapListArray6);
    }
}

