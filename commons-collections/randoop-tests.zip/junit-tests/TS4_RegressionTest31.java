import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest31.test32");
        org.apache.commons.collections4.MultiSet multiSet0 = org.apache.commons.collections4.MultiSetUtils.EMPTY_MULTISET;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multiSet0);
    }
}

