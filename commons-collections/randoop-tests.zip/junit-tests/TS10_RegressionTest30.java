import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest30.test31");
        org.apache.commons.collections4.map.LinkedMap<java.lang.CharSequence, java.util.Enumeration<java.lang.String[]>> charSequenceMap0 = new org.apache.commons.collections4.map.LinkedMap<java.lang.CharSequence, java.util.Enumeration<java.lang.String[]>>();
    }
}

