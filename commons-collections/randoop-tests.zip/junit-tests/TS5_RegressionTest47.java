import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest47.test48");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet19 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray32 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet19, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList33 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList33, serializableArray32);
        boolean boolean35 = serializableSet0.containsAll((java.util.Collection<java.io.Serializable>) serializableList33);
        serializableList33.ensureCapacity((int) '#');
        java.lang.String str38 = serializableList33.toString();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet39 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet58 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray71 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet58, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList72 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean73 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList72, serializableArray71);
        boolean boolean74 = serializableSet39.containsAll((java.util.Collection<java.io.Serializable>) serializableList72);
        serializableList72.ensureCapacity((int) '#');
        int int78 = serializableList72.lastIndexOf((java.lang.Object) 100L);
        int int79 = serializableList33.lastIndexOf((java.lang.Object) serializableList72);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "[0, 10, 0, -1, 10.0, 1.0, -1, 10, -1.0, 100, 100.0, -1, 1.0, 0.0, 0.0, 10, 100, 100, [], 100, 0.0, -1, hi!, 0.0, 100, 10, 4, hi!, -1, true, -1]" + "'", str38.equals("[0, 10, 0, -1, 10.0, 1.0, -1, 10, -1.0, 100, 100.0, -1, 1.0, 0.0, 0.0, 10, 100, 100, [], 100, 0.0, -1, hi!, 0.0, 100, 10, 4, hi!, -1, true, -1]"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray71);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 9 + "'", int78 == 9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
    }
}

