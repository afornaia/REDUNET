import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest4.test05");
        java.lang.CharSequence[] charSequenceArray2 = new java.lang.CharSequence[] { "hi!", "" };
        java.util.ArrayList<java.lang.CharSequence> charSequenceList3 = new java.util.ArrayList<java.lang.CharSequence>();
        boolean boolean4 = java.util.Collections.addAll((java.util.Collection<java.lang.CharSequence>) charSequenceList3, charSequenceArray2);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap7 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        org.apache.commons.collections4.MultiSet<java.lang.CharSequence> charSequenceCollection8 = charSequenceArrayListValuedHashMap7.keys();
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean9 = charSequenceList3.addAll((int) '#', (java.util.Collection<java.lang.CharSequence>) charSequenceCollection8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceCollection8);
    }
}

