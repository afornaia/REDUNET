import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest1.test02");
        java.util.Comparator[] comparatorArray1 = new java.util.Comparator[0];
        @SuppressWarnings("unchecked")
        java.util.Comparator<java.lang.Object[]>[] objArrayComparatorArray2 = (java.util.Comparator<java.lang.Object[]>[]) comparatorArray1;
        java.util.Comparator<java.lang.Object[]> objArrayComparator3 = org.apache.commons.collections4.ComparatorUtils.chainedComparator((java.util.Comparator<java.lang.Object[]>[]) comparatorArray1);
        java.util.Comparator<java.util.AbstractCollection<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapCollectionComparator4 = org.apache.commons.collections4.ComparatorUtils.chainedComparator((java.util.Comparator<java.util.AbstractCollection<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>[]) comparatorArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(comparatorArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArrayComparatorArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArrayComparator3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(comparableMapCollectionComparator4);
    }
}

