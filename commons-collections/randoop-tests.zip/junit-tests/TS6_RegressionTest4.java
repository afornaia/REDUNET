import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest4.test05");
        org.apache.commons.collections4.Closure closure0 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        org.apache.commons.collections4.Closure closure1 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        org.apache.commons.collections4.Closure closure2 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        org.apache.commons.collections4.Closure closure3 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        org.apache.commons.collections4.Closure closure4 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        org.apache.commons.collections4.Closure[] closureArray6 = new org.apache.commons.collections4.Closure[5];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Closure<? super java.util.List<java.lang.Object>>[] wildcardClosureArray7 = (org.apache.commons.collections4.Closure<? super java.util.List<java.lang.Object>>[]) closureArray6;
        wildcardClosureArray7[0] = closure0;
        wildcardClosureArray7[1] = closure1;
        wildcardClosureArray7[2] = closure2;
        wildcardClosureArray7[3] = closure3;
        wildcardClosureArray7[4] = closure4;
        org.apache.commons.collections4.Closure<java.util.List<java.lang.Object>> objListClosure18 = org.apache.commons.collections4.ClosureUtils.chainedClosure(wildcardClosureArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closureArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClosureArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objListClosure18);
    }
}

