import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest34.test35");
        java.util.ArrayList<java.util.Comparator<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>>> mapConstantTimeToLiveExpirationPolicyComparatorList0 = new java.util.ArrayList<java.util.Comparator<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>>>();
        java.util.BitSet bitSet1 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>> objMapConstantTimeToLiveExpirationPolicyComparatorChain2 = new org.apache.commons.collections4.comparators.ComparatorChain<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>>((java.util.List<java.util.Comparator<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>>>) mapConstantTimeToLiveExpirationPolicyComparatorList0, bitSet1);
    }
}

