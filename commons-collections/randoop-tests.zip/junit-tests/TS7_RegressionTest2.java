import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest2.test03");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.ResettableIterator<java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> wildcardMultiKeyIterableGetIterableItor2 = org.apache.commons.collections4.IteratorUtils.arrayIterator((java.lang.Object) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

