import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest15.test16");
        org.apache.commons.collections4.Closure closure0 = org.apache.commons.collections4.functors.NOPClosure.INSTANCE;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.ArrayListIterator<java.util.Iterator<java.lang.Iterable<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>>> stringKeyAnalyzerIterableItorItor3 = new org.apache.commons.collections4.iterators.ArrayListIterator<java.util.Iterator<java.lang.Iterable<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>>>((java.lang.Object) closure0, (int) '4', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure0);
    }
}

