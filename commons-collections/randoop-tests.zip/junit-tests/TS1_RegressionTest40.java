import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest40.test41");
        org.apache.commons.collections4.properties.SortedProperties sortedProperties0 = new org.apache.commons.collections4.properties.SortedProperties();
        java.lang.String str1 = sortedProperties0.toString();
        java.util.Set<java.util.Map.Entry<java.lang.Object, java.lang.Object>> objEntrySet2 = sortedProperties0.entrySet();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{}" + "'", str1.equals("{}"));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objEntrySet2);
    }
}

