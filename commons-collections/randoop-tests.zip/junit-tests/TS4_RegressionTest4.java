import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest4.test05");
        java.util.Map<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> abstractBloomFilterMap0 = null;
        java.util.Map<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> abstractBloomFilterMap1 = null;
        org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> abstractBloomFilterMap2 = new org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>(abstractBloomFilterMap0, abstractBloomFilterMap1);
    }
}

