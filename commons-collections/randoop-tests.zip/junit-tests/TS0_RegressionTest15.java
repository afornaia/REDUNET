import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest15.test16");
        org.apache.commons.collections4.iterators.TransformIterator<org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>, org.apache.commons.collections4.multimap.AbstractListValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>> strMultiKeyItor0 = new org.apache.commons.collections4.iterators.TransformIterator<org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>, org.apache.commons.collections4.multimap.AbstractListValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>();
    }
}

