import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest17.test18");
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap1 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        float float3 = org.apache.commons.collections4.MapUtils.getFloatValue((java.util.Map<java.io.Serializable, java.lang.Object>) serializableMap1, (java.io.Serializable) (short) 100);
        boolean boolean4 = serializableMap1.isEmpty();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}

