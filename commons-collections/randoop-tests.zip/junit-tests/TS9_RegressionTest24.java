import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest24.test25");
        org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.map.CaseInsensitiveMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>, java.lang.Iterable<java.lang.String>> strMultiValuedMapMapMap0 = new org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.map.CaseInsensitiveMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>, java.lang.Iterable<java.lang.String>>();
        strMultiValuedMapMapMap0.clear();
    }
}

