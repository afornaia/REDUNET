import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest14.test15");
        java.util.concurrent.TimeUnit timeUnit1 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.functors.ChainedTransformer<java.util.Collection<java.lang.CharSequence>>, java.util.AbstractMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>> charSequenceCollectionChainedTransformerConstantTimeToLiveExpirationPolicy2 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.functors.ChainedTransformer<java.util.Collection<java.lang.CharSequence>>, java.util.AbstractMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>>(0L, timeUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: timeUnit");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

