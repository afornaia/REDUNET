import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest11.test12");
        org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>> charSequenceMapCollection0 = org.apache.commons.collections4.MultiSetUtils.emptyMultiSet();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMapCollection0);
    }
}

