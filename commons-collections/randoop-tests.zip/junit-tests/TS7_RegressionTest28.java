import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest28.test29");
        org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion, java.lang.Object> criterionMap0 = new org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion, java.lang.Object>();
        org.apache.commons.collections4.map.MultiValueMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyMap1 = org.apache.commons.collections4.MapUtils.multiValueMap((java.util.Map<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>) criterionMap0);
        org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object> wildcardMultiKeyItor2 = criterionMap0.mapIterator();
        org.apache.commons.collections4.Equator<java.lang.Cloneable> cloneableEquator3 = null;
        org.apache.commons.collections4.functors.EqualPredicate<java.lang.Cloneable> cloneableEqualPredicate4 = new org.apache.commons.collections4.functors.EqualPredicate<java.lang.Cloneable>((java.lang.Cloneable) criterionMap0, cloneableEquator3);
        org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion, java.lang.Object> criterionMap5 = new org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion, java.lang.Object>();
        org.apache.commons.collections4.map.MultiValueMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyMap6 = org.apache.commons.collections4.MapUtils.multiValueMap((java.util.Map<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>) criterionMap5);
        org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetCollection7 = org.apache.commons.collections4.MultiSetUtils.emptyMultiSet();
        java.util.List<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetList8 = org.apache.commons.collections4.IterableUtils.toList((java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection7);
        org.apache.commons.collections4.Factory<org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> wildcardMultiKeyIterableGetCollectionFactory9 = org.apache.commons.collections4.FactoryUtils.prototypeFactory(wildcardMultiKeyIterableGetCollection7);
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object> wildcardMultiKeyMap10 = org.apache.commons.collections4.MapUtils.lazyMap((java.util.Map<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>) criterionMap5, wildcardMultiKeyIterableGetCollectionFactory9);
        boolean boolean11 = cloneableEqualPredicate4.evaluate((java.lang.Cloneable) criterionMap5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyMap1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyItor2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyMap6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetCollection7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetList8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetCollectionFactory9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyMap10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }
}

