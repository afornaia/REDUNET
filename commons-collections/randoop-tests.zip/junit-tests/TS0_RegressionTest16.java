import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest16.test17");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.ArrayListIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.String>> charSequenceMapItor1 = new org.apache.commons.collections4.iterators.ArrayListIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.String>>((java.lang.Object) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument is not an array");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

