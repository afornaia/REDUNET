import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest30.test31");
        java.util.ListIterator<org.apache.commons.collections4.KeyValue<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableKeyValueItor0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.AbstractListIteratorDecorator<org.apache.commons.collections4.KeyValue<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableKeyValueItor1 = new org.apache.commons.collections4.iterators.AbstractListIteratorDecorator<org.apache.commons.collections4.KeyValue<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>(strComparableKeyValueItor0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: iterator");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

