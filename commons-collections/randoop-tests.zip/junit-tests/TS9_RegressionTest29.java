import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest29.test30");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD;
        org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.collection.AbstractCollectionDecorator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, java.lang.Iterable<java.lang.String>> builderPredicateDecoratorCollectionMap4 = new org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.collection.AbstractCollectionDecorator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, java.lang.Iterable<java.lang.String>>(referenceStrength0, referenceStrength1, (int) (byte) 10, (float) (byte) 1);
        org.apache.commons.collections4.map.DefaultedMap<java.lang.Enum<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, org.apache.commons.collections4.map.AbstractReferenceMap<org.apache.commons.collections4.collection.AbstractCollectionDecorator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, java.lang.Iterable<java.lang.String>>> criterionEnumMap5 = new org.apache.commons.collections4.map.DefaultedMap<java.lang.Enum<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, org.apache.commons.collections4.map.AbstractReferenceMap<org.apache.commons.collections4.collection.AbstractCollectionDecorator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, java.lang.Iterable<java.lang.String>>>((org.apache.commons.collections4.map.AbstractReferenceMap<org.apache.commons.collections4.collection.AbstractCollectionDecorator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, java.lang.Iterable<java.lang.String>>) builderPredicateDecoratorCollectionMap4);
        org.junit.Assert.assertTrue("'" + referenceStrength0 + "' != '" + org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD + "'", referenceStrength0.equals(org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD));
        org.junit.Assert.assertTrue("'" + referenceStrength1 + "' != '" + org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD + "'", referenceStrength1.equals(org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.HARD));
    }
}

