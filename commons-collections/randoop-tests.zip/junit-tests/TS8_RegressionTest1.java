import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest1.test02");
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat propertyFormat0 = org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.PROPERTIES;
        org.junit.Assert.assertTrue("'" + propertyFormat0 + "' != '" + org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.PROPERTIES + "'", propertyFormat0.equals(org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.PROPERTIES));
    }
}

