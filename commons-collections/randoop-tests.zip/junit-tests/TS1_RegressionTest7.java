import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest7 {

    public static boolean debug = false;

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest7.test08");
        org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>, org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>[] queueKeyValueMapArray0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>, org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> queueKeyValueMapMultiKey2 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.MultiKeyMap<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>, org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>>(queueKeyValueMapArray0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: keys");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

