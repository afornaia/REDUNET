import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest20.test21");
        java.util.concurrent.TimeUnit timeUnit1 = null;
        java.util.Map<java.lang.Cloneable, org.apache.commons.collections4.sequence.KeepCommand<org.apache.commons.collections4.OrderedIterator<java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>> cloneableMap2 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap<java.lang.Cloneable, org.apache.commons.collections4.sequence.KeepCommand<org.apache.commons.collections4.OrderedIterator<java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>> cloneableMap3 = new org.apache.commons.collections4.map.PassiveExpiringMap<java.lang.Cloneable, org.apache.commons.collections4.sequence.KeepCommand<org.apache.commons.collections4.OrderedIterator<java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>>((long) (short) -1, timeUnit1, cloneableMap2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: timeUnit");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

