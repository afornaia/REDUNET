import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest30.test31");
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList0 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj3 = objList0.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList4 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj7 = objList4.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList8 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList0, (java.util.List<java.lang.Object>) objList4);
        java.util.ListIterator<java.lang.Object> objItor10 = objList4.listIterator((int) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objItor10);
    }
}

