import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest28.test29");
        java.util.Set<org.apache.commons.collections4.MapIterator> mapIteratorSet0 = org.apache.commons.collections4.SetUtils.emptySet();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapIteratorSet0);
    }
}

