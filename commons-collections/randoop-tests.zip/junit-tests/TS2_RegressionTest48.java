import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest48.test49");
        org.apache.commons.collections4.ResettableListIterator resettableListIterator0 = org.apache.commons.collections4.iterators.EmptyListIterator.RESETTABLE_INSTANCE;
        org.apache.commons.collections4.sequence.DeleteCommand<org.apache.commons.collections4.ResettableIterator> resettableIteratorDeleteCommand1 = new org.apache.commons.collections4.sequence.DeleteCommand<org.apache.commons.collections4.ResettableIterator>((org.apache.commons.collections4.ResettableIterator) resettableListIterator0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(resettableListIterator0);
    }
}

