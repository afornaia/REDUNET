import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest9.test10");
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.IterableMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableMapEditScript0 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.IterableMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>();
    }
}

