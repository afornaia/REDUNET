import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest29.test30");
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript0 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript1 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript2 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript3 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript4 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript5 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript[] editScriptArray7 = new org.apache.commons.collections4.sequence.EditScript[6];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[] charSequencePutEditScriptArray8 = (org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[]) editScriptArray7;
        charSequencePutEditScriptArray8[0] = charSequencePutEditScript0;
        charSequencePutEditScriptArray8[1] = charSequencePutEditScript1;
        charSequencePutEditScriptArray8[2] = charSequencePutEditScript2;
        charSequencePutEditScriptArray8[3] = charSequencePutEditScript3;
        charSequencePutEditScriptArray8[4] = charSequencePutEditScript4;
        charSequencePutEditScriptArray8[5] = charSequencePutEditScript5;
        org.apache.commons.collections4.iterators.SingletonIterator<org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[]> putEditScriptArrayItor21 = new org.apache.commons.collections4.iterators.SingletonIterator<org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[]>(charSequencePutEditScriptArray8);
        putEditScriptArrayItor21.reset();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(editScriptArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequencePutEditScriptArray8);
    }
}

