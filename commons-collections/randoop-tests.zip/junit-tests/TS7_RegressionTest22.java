import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest22.test23");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.resolve((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

