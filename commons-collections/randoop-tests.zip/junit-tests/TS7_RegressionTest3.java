import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest3.test04");
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyMapList1 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>((int) (short) -1);
    }
}

