import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest40.test41");
        org.apache.commons.collections4.map.PassiveExpiringMap.ExpirationPolicy<java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>, java.util.RandomAccess> comparableMultiValuedMapListExpirationPolicy0 = null;
        java.util.Map<java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>, java.util.RandomAccess> comparableMultiValuedMapListMap1 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap<java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>, java.util.RandomAccess> comparableMultiValuedMapListMap2 = new org.apache.commons.collections4.map.PassiveExpiringMap<java.util.List<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>, java.util.RandomAccess>(comparableMultiValuedMapListExpirationPolicy0, comparableMultiValuedMapListMap1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: map");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

