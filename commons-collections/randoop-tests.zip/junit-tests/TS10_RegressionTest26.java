import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest26.test27");
        org.apache.commons.collections4.map.ReferenceMap<java.util.Dictionary<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.map.AbstractLinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>> objDictionaryMap0 = new org.apache.commons.collections4.map.ReferenceMap<java.util.Dictionary<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.map.AbstractLinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>>();
        boolean boolean1 = objDictionaryMap0.isEmpty();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }
}

