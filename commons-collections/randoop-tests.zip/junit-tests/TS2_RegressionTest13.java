import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest13.test14");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.functors.PredicateDecorator<java.lang.Comparable<java.lang.String>>, java.lang.String> strComparablePredicateDecoratorMap4 = new org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.functors.PredicateDecorator<java.lang.Comparable<java.lang.String>>, java.lang.String>((-1), 4, (float) 'a', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: LRUMap max size must be greater than 0");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

