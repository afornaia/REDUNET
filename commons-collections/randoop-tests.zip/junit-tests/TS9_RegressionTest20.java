import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest20.test21");
        org.apache.commons.collections4.Transformer<java.util.AbstractSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.comparators.FixedOrderComparator<org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder>> multiValuedMapIterableGetSetTransformer0 = org.apache.commons.collections4.TransformerUtils.exceptionTransformer();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(multiValuedMapIterableGetSetTransformer0);
    }
}

