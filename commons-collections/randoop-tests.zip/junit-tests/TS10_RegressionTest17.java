import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest17.test18");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>> strComparableItor1 = new org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>>((java.lang.Comparable<java.lang.String>[]) strArray0);
        int int2 = strComparableItor1.getStartIndex();
        java.lang.String[] strArray3 = new java.lang.String[] {};
        org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>> strComparableItor4 = new org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>>((java.lang.Comparable<java.lang.String>[]) strArray3);
        int int5 = strComparableItor4.getStartIndex();
        java.util.ArrayList<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>> strComparableItorList6 = new java.util.ArrayList<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>>();
        boolean boolean7 = strComparableItorList6.add((org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>) strComparableItor1);
        boolean boolean8 = strComparableItorList6.add((org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>) strComparableItor4);
        java.lang.String[] strArray9 = new java.lang.String[] {};
        org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>> strComparableItor10 = new org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>>((java.lang.Comparable<java.lang.String>[]) strArray9);
        java.lang.String[] strArray11 = new java.lang.String[] {};
        org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>> strComparableItor12 = new org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>>((java.lang.Comparable<java.lang.String>[]) strArray11);
        int int13 = strComparableItor12.getStartIndex();
        java.util.ArrayList<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>> strComparableItorList14 = new java.util.ArrayList<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>>();
        boolean boolean15 = strComparableItorList14.add((org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>) strComparableItor10);
        boolean boolean16 = strComparableItorList14.add((org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>) strComparableItor12);
        org.apache.commons.collections4.collection.CompositeCollection<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>> strComparableItorCollection17 = new org.apache.commons.collections4.collection.CompositeCollection<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>>((java.util.Collection<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>>) strComparableItorList6, (java.util.Collection<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>>) strComparableItorList14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }
}

