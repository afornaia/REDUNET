import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest14.test15");
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap1 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        java.lang.Object obj3 = serializableMap1.remove((java.lang.Object) 1.0f);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Map.Entry<java.io.Serializable, java.lang.Object> serializableEntry5 = org.apache.commons.collections4.CollectionUtils.get((java.util.Map<java.io.Serializable, java.lang.Object>) serializableMap1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index cannot be negative: -1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
    }
}

