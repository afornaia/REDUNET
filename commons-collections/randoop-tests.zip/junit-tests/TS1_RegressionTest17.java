import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest17.test18");
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap0 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap2 = referenceStrengthListMap0.remove((java.lang.Object) (short) 10);
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer> stringKeyAnalyzerQueue4 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>((int) (byte) 1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList6 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList8 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList10 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        java.util.List[] listArray12 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[] referenceStrengthListArray13 = (java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]) listArray12;
        referenceStrengthListArray13[0] = referenceStrengthList6;
        referenceStrengthListArray13[1] = referenceStrengthList8;
        referenceStrengthListArray13[2] = referenceStrengthList10;
        boolean boolean20 = org.apache.commons.collections4.CollectionUtils.containsAny((java.util.Collection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>) stringKeyAnalyzerQueue4, referenceStrengthListArray13);
        boolean boolean21 = referenceStrengthListMap0.equals((java.lang.Object) boolean20);
        org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior unknownObjectBehavior22 = org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER;
        boolean boolean23 = referenceStrengthListMap0.containsValue((java.lang.Object) unknownObjectBehavior22);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(stringKeyAnalyzerQueueMap2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + unknownObjectBehavior22 + "' != '" + org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER + "'", unknownObjectBehavior22.equals(org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }
}

