import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest55 {

    public static boolean debug = false;

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest55.test56");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet19 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray32 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet19, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList33 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList33, serializableArray32);
        boolean boolean35 = serializableSet0.containsAll((java.util.Collection<java.io.Serializable>) serializableList33);
        java.util.ListIterator<java.lang.Cloneable> cloneableItor36 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((java.lang.Cloneable) serializableList33);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet37 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet56 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray69 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet56, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList70 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean71 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList70, serializableArray69);
        boolean boolean72 = serializableSet37.containsAll((java.util.Collection<java.io.Serializable>) serializableList70);
        serializableList70.ensureCapacity((int) '#');
        java.util.RandomAccess[] randomAccessArray75 = new java.util.RandomAccess[] { serializableList33, serializableList70 };
        java.util.LinkedHashSet<java.util.RandomAccess> randomAccessSet76 = new java.util.LinkedHashSet<java.util.RandomAccess>();
        boolean boolean77 = java.util.Collections.addAll((java.util.Collection<java.util.RandomAccess>) randomAccessSet76, randomAccessArray75);
        org.apache.commons.collections4.set.CompositeSet<java.util.RandomAccess> randomAccessSet78 = new org.apache.commons.collections4.set.CompositeSet<java.util.RandomAccess>((java.util.Set<java.util.RandomAccess>) randomAccessSet76);
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap80 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet81 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean83 = serializableSet81.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement84 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry85 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet81, annotatedElement84);
        boolean boolean86 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet81);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet87 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean89 = serializableSet87.add((java.io.Serializable) 1.0f);
        java.util.List<java.io.Serializable> serializableList90 = org.apache.commons.collections4.ListUtils.removeAll((java.util.Collection<java.io.Serializable>) serializableSet81, (java.util.Collection<java.io.Serializable>) serializableSet87);
        boolean boolean91 = serializableMap80.equals((java.lang.Object) serializableList90);
        boolean boolean92 = randomAccessSet78.containsAll((java.util.Collection<java.io.Serializable>) serializableList90);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(cloneableItor36);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray69);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(randomAccessArray75);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableList90);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }
}

