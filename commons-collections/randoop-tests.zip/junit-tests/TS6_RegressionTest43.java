import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest43.test44");
        org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap0 = new org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape1 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter2 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape1);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor3 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        boolean boolean4 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.io.Serializable>) serializableItor3);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor5 = abstractBloomFilterMap0.put((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) bitSetBloomFilter2, serializableItor3);
        org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap6 = new org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape7 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter8 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape7);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor9 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        boolean boolean10 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.io.Serializable>) serializableItor9);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor11 = abstractBloomFilterMap6.put((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) bitSetBloomFilter8, serializableItor9);
        // The following exception was thrown during execution in test generation
        try {
            int int12 = bitSetBloomFilter2.andCardinality((org.apache.commons.collections4.bloomfilter.BloomFilter) bitSetBloomFilter8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableItor5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableItor11);
    }
}

