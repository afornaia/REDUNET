import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest49.test50");
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList0 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj3 = objList0.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList4 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj7 = objList4.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList8 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList0, (java.util.List<java.lang.Object>) objList4);
        org.apache.commons.collections4.functors.ConstantFactory<java.lang.Iterable<java.lang.Object>> objIterableConstantFactory9 = new org.apache.commons.collections4.functors.ConstantFactory<java.lang.Iterable<java.lang.Object>>((java.lang.Iterable<java.lang.Object>) objList8);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList10 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj13 = objList10.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList14 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj17 = objList14.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList18 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList10, (java.util.List<java.lang.Object>) objList14);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList20 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj23 = objList20.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList24 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj27 = objList24.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList28 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList20, (java.util.List<java.lang.Object>) objList24);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList29 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object[] objArray30 = objList29.toArray();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape33 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter34 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape33);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList36 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj39 = objList36.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList40 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj43 = objList40.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList44 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList36, (java.util.List<java.lang.Object>) objList40);
        org.apache.commons.collections4.comparators.ComparableComparator comparableComparator50 = org.apache.commons.collections4.comparators.ComparableComparator.INSTANCE;
        org.apache.commons.collections4.comparators.BooleanComparator booleanComparator52 = org.apache.commons.collections4.comparators.BooleanComparator.booleanComparator(false);
        java.lang.Object[] objArray53 = new java.lang.Object[] { (short) 1, objList20, objList29, true, (-1L), shape33, (byte) 1, objList36, 100L, (byte) 100, (byte) 1, (byte) 1, (short) 0, comparableComparator50, false };
        java.util.ArrayList<java.lang.Object> objList54 = new java.util.ArrayList<java.lang.Object>();
        boolean boolean55 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) objList54, objArray53);
        boolean boolean56 = objList14.removeAll((java.util.Collection<java.lang.Object>) objList54);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor57 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        boolean boolean58 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.io.Serializable>) serializableItor57);
        boolean boolean59 = org.apache.commons.collections4.CollectionUtils.addAll((java.util.Collection<java.lang.Object>) objList14, (java.util.Iterator<java.io.Serializable>) serializableItor57);
        java.util.List<java.lang.Object> objList60 = org.apache.commons.collections4.ListUtils.retainAll((java.util.Collection<java.lang.Object>) objList8, (java.util.Collection<java.lang.Object>) objList14);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj23);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj27);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList28);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray30);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList44);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(comparableComparator50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(booleanComparator52);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList60);
    }
}

