import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest30.test31");
        org.apache.commons.collections4.iterators.TransformIterator<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.util.Set<java.io.Serializable>> serializableCollectionItor0 = new org.apache.commons.collections4.iterators.TransformIterator<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.util.Set<java.io.Serializable>>();
    }
}

