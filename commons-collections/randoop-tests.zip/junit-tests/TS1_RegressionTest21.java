import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest21.test22");
        org.apache.commons.collections4.SortedBag<org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> wildcardMultiKeyMapCollection0 = org.apache.commons.collections4.BagUtils.emptySortedBag();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyMapCollection0);
    }
}

