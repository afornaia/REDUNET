import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest32.test33");
        java.util.Map<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap0 = null;
        java.util.Map<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap1 = org.apache.commons.collections4.MapUtils.emptyIfNull(stringKeyAnalyzerQueueMap0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringKeyAnalyzerQueueMap1);
    }
}

