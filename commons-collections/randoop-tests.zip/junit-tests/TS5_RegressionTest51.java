import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest51.test52");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean2 = serializableSet0.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement3 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry4 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet0, annotatedElement3);
        boolean boolean5 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet0);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet6 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet25 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray38 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet25, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList39 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean40 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList39, serializableArray38);
        boolean boolean41 = serializableSet6.containsAll((java.util.Collection<java.io.Serializable>) serializableList39);
        java.util.ListIterator<java.lang.Cloneable> cloneableItor42 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((java.lang.Cloneable) serializableList39);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet44 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean46 = serializableSet44.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement47 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry48 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet44, annotatedElement47);
        boolean boolean49 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet44);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet50 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean52 = serializableSet50.add((java.io.Serializable) 1.0f);
        java.util.List<java.io.Serializable> serializableList53 = org.apache.commons.collections4.ListUtils.removeAll((java.util.Collection<java.io.Serializable>) serializableSet44, (java.util.Collection<java.io.Serializable>) serializableSet50);
        boolean boolean54 = serializableList39.addAll((int) (byte) 10, (java.util.Collection<java.io.Serializable>) serializableList53);
        serializableList39.ensureCapacity((int) '#');
        boolean boolean57 = org.apache.commons.collections4.CollectionUtils.isSubCollection((java.util.Collection<java.io.Serializable>) serializableSet0, (java.util.Collection<java.io.Serializable>) serializableList39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray38);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(cloneableItor42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableList53);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }
}

