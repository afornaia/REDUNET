import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest18.test19");
        java.util.Comparator<java.util.Enumeration<java.lang.String[]>> strArrayEnumerationComparator0 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<java.util.Enumeration<java.lang.String[]>> strArrayEnumerationComparatorChain1 = new org.apache.commons.collections4.comparators.ComparatorChain<java.util.Enumeration<java.lang.String[]>>(strArrayEnumerationComparator0);
    }
}

