import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest6.test07");
        org.apache.commons.collections4.Bag bag0 = org.apache.commons.collections4.BagUtils.EMPTY_SORTED_BAG;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(bag0);
    }
}

