import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest23.test24");
        org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetCollection0 = org.apache.commons.collections4.MultiSetUtils.emptyMultiSet();
        java.util.List<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetList1 = org.apache.commons.collections4.IterableUtils.toList((java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection0);
        java.util.Collection<java.util.List<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> wildcardMultiKeyIterableGetListCollection2 = org.apache.commons.collections4.CollectionUtils.permutations((java.util.Collection<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetIterable4 = org.apache.commons.collections4.IterableUtils.boundedIterable((java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection0, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MaxSize parameter must not be negative.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetList1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetListCollection2);
    }
}

