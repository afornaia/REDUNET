import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest50 {

    public static boolean debug = false;

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest50.test51");
        org.apache.commons.collections4.Predicate predicate0 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate1 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate2 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate[] predicateArray4 = new org.apache.commons.collections4.Predicate[3];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>[] wildcardPredicateArray5 = (org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>[]) predicateArray4;
        wildcardPredicateArray5[0] = predicate0;
        wildcardPredicateArray5[1] = predicate1;
        wildcardPredicateArray5[2] = predicate2;
        org.apache.commons.collections4.Predicate<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion> criterionPredicate12 = org.apache.commons.collections4.functors.NonePredicate.nonePredicate(wildcardPredicateArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(criterionPredicate12);
    }
}

