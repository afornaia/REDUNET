import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest13.test14");
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat propertyFormat0 = org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML;
        org.junit.Assert.assertTrue("'" + propertyFormat0 + "' != '" + org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML + "'", propertyFormat0.equals(org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML));
    }
}

