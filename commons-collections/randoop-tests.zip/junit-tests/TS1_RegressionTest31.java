import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest31.test32");
        java.util.Iterator<? extends org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> wildcardItor0 = null;
        java.util.Iterator[] iteratorArray2 = new java.util.Iterator[1];
        @SuppressWarnings("unchecked")
        java.util.Iterator<? extends org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>>[] wildcardItorArray3 = (java.util.Iterator<? extends org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>>[]) iteratorArray2;
        wildcardItorArray3[0] = wildcardItor0;
        // The following exception was thrown during execution in test generation
        try {
            java.util.Iterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> listMapItorItor6 = org.apache.commons.collections4.IteratorUtils.chainedIterator(wildcardItorArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: iterator");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iteratorArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardItorArray3);
    }
}

