import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest40.test41");
        org.apache.commons.collections4.list.GrowthList<org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>> iterableGetSetAbstractMultiValuedMapList0 = new org.apache.commons.collections4.list.GrowthList<org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>>();
    }
}

