import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest35.test36");
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList0 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj3 = objList0.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType processType4 = org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE;
        int int5 = objList0.indexOf((java.lang.Object) processType4);
        org.apache.commons.collections4.Transformer<org.apache.commons.collections4.properties.AbstractPropertiesFactory<org.apache.commons.collections4.properties.SortedProperties>, java.lang.Enum<org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>> sortedPropertiesAbstractPropertiesFactoryTransformer6 = org.apache.commons.collections4.TransformerUtils.constantTransformer((java.lang.Enum<org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>) processType4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + processType4 + "' != '" + org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE + "'", processType4.equals(org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sortedPropertiesAbstractPropertiesFactoryTransformer6);
    }
}

