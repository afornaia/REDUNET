import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest47.test48");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap1 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray3 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray4 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray3;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate5 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray3);
        boolean boolean6 = strComparableArrayListValuedHashMap1.containsValue((java.lang.Object) predicateArray3);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap7 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap1);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableArrayListValuedHashMap7.keySet();
        int int9 = org.apache.commons.collections4.CollectionUtils.size((java.lang.Object) strComparableSet8);
        org.apache.commons.collections4.Predicate<java.lang.Comparable<java.lang.String>> strComparablePredicate10 = null;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Iterable<java.lang.Comparable<java.lang.String>> strComparableIterable11 = org.apache.commons.collections4.IterableUtils.filteredIterable((java.lang.Iterable<java.lang.Comparable<java.lang.String>>) strComparableSet8, strComparablePredicate10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: predicate");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableSet8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }
}

