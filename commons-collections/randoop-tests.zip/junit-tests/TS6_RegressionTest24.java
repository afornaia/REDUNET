import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest24.test25");
        org.apache.commons.collections4.Closure<java.lang.Object[]> objArrayClosure0 = org.apache.commons.collections4.ClosureUtils.nopClosure();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArrayClosure0);
    }
}

