import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest33.test34");
        org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>> serializableGetReverseComparator0 = new org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>();
        java.util.Comparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>> serializableGetComparator1 = org.apache.commons.collections4.ComparatorUtils.nullLowComparator((java.util.Comparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>) serializableGetReverseComparator0);
        boolean boolean3 = serializableGetReverseComparator0.equals((java.lang.Object) '#');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableGetComparator1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}

