import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest32.test33");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean2 = serializableSet0.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement3 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry4 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet0, annotatedElement3);
        org.apache.commons.collections4.functors.EqualPredicate<java.util.Map.Entry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>> serializableCollectionEntryEqualPredicate5 = new org.apache.commons.collections4.functors.EqualPredicate<java.util.Map.Entry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>((java.util.Map.Entry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>) serializableCollectionUnmodifiableMapEntry4);
        boolean boolean7 = serializableCollectionUnmodifiableMapEntry4.equals((java.lang.Object) 4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

