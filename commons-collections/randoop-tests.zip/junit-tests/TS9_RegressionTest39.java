import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest39.test40");
        org.apache.commons.collections4.bloomfilter.BloomFilter bloomFilter0 = null;
        org.apache.commons.collections4.bloomfilter.BloomFilter bloomFilter1 = null;
        // The following exception was thrown during execution in test generation
        try {
            double double2 = org.apache.commons.collections4.bloomfilter.SetOperations.cosineSimilarity(bloomFilter0, bloomFilter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

