import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest42.test43");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap1 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap3 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray5 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray6 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray5;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate7 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray5);
        boolean boolean8 = strComparableArrayListValuedHashMap3.containsValue((java.lang.Object) predicateArray5);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap9 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap3);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet10 = strComparableArrayListValuedHashMap9.keySet();
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap12 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap14 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray16 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray17 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray16;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate18 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray16);
        boolean boolean19 = strComparableArrayListValuedHashMap14.containsValue((java.lang.Object) predicateArray16);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap20 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap14);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet21 = strComparableArrayListValuedHashMap20.keySet();
        java.util.ArrayList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>> strComparableMultiValuedMapList22 = new java.util.ArrayList<org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>>();
        boolean boolean23 = strComparableMultiValuedMapList22.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap1);
        boolean boolean24 = strComparableMultiValuedMapList22.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap9);
        boolean boolean25 = strComparableMultiValuedMapList22.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap12);
        boolean boolean26 = strComparableMultiValuedMapList22.add((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap20);
        boolean boolean28 = strComparableMultiValuedMapList22.remove((java.lang.Object) 16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableSet10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableSet21);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }
}

