import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest53 {

    public static boolean debug = false;

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest53.test54");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet0 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet19 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        java.io.Serializable[] serializableArray32 = new java.io.Serializable[] { 0L, 10L, (short) 0, (short) -1, 10.0f, 1.0d, (short) -1, 10L, (-1.0f), 100L, 100.0d, (byte) -1, 1.0f, 0.0d, 0.0f, 10, (byte) 100, (byte) 100, serializableSet19, (short) 100, 0.0d, (-1), "hi!", 0.0f, (byte) 100, (short) 10, '4', "hi!", (short) -1, true, (-1) };
        java.util.ArrayList<java.io.Serializable> serializableList33 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean34 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList33, serializableArray32);
        boolean boolean35 = serializableSet0.containsAll((java.util.Collection<java.io.Serializable>) serializableList33);
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat propertyFormat36 = org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML;
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat propertyFormat37 = org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML;
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat propertyFormat38 = org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML;
        org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat[] propertyFormatArray39 = new org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat[] { propertyFormat36, propertyFormat37, propertyFormat38 };
        java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>[] propertyFormatEnumArray40 = serializableSet0.toArray((java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>[]) propertyFormatArray39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray32);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + propertyFormat36 + "' != '" + org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML + "'", propertyFormat36.equals(org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML));
        org.junit.Assert.assertTrue("'" + propertyFormat37 + "' != '" + org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML + "'", propertyFormat37.equals(org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML));
        org.junit.Assert.assertTrue("'" + propertyFormat38 + "' != '" + org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML + "'", propertyFormat38.equals(org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat.XML));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(propertyFormatArray39);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(propertyFormatEnumArray40);
    }
}

