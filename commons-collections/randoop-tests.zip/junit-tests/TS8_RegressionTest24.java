import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest24.test25");
        org.apache.commons.collections4.Predicate<org.apache.commons.collections4.functors.AllPredicate<org.apache.commons.collections4.MapIterator>> mapIteratorAllPredicatePredicate0 = org.apache.commons.collections4.PredicateUtils.nullPredicate();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapIteratorAllPredicatePredicate0);
    }
}

