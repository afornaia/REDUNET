import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest48.test49");
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap1 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet2 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean4 = serializableSet2.add((java.io.Serializable) 1.0f);
        java.lang.reflect.AnnotatedElement annotatedElement5 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement> serializableCollectionUnmodifiableMapEntry6 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>((org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>) serializableSet2, annotatedElement5);
        boolean boolean7 = org.apache.commons.collections4.IterableUtils.isEmpty((java.lang.Iterable<java.io.Serializable>) serializableSet2);
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable> serializableSet8 = new org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>();
        boolean boolean10 = serializableSet8.add((java.io.Serializable) 1.0f);
        java.util.List<java.io.Serializable> serializableList11 = org.apache.commons.collections4.ListUtils.removeAll((java.util.Collection<java.io.Serializable>) serializableSet2, (java.util.Collection<java.io.Serializable>) serializableSet8);
        boolean boolean12 = serializableMap1.equals((java.lang.Object) serializableList11);
        boolean boolean13 = org.apache.commons.collections4.MapUtils.isEmpty((java.util.Map<java.io.Serializable, java.lang.Object>) serializableMap1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableList11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }
}

