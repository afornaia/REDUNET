import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest33.test34");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap1 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((-1));
        org.apache.commons.collections4.Predicate[] predicateArray3 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray4 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray3;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate5 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray3);
        boolean boolean6 = strComparableArrayListValuedHashMap1.containsValue((java.lang.Object) predicateArray3);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>> strComparableArrayListValuedHashMap7 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>((org.apache.commons.collections4.MultiValuedMap<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>>) strComparableArrayListValuedHashMap1);
        java.util.Set<java.lang.Comparable<java.lang.String>> strComparableSet8 = strComparableArrayListValuedHashMap7.keySet();
        org.apache.commons.collections4.Predicate[] predicateArray10 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[] wildcardPredicateArray11 = (org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray10;
        org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>> strComparableNonePredicate12 = new org.apache.commons.collections4.functors.NonePredicate<java.lang.Comparable<java.lang.String>>((org.apache.commons.collections4.Predicate<? super java.lang.Comparable<java.lang.String>>[]) predicateArray10);
        boolean boolean13 = org.apache.commons.collections4.CollectionUtils.filterInverse((java.lang.Iterable<java.lang.Comparable<java.lang.String>>) strComparableSet8, (org.apache.commons.collections4.Predicate<java.lang.Comparable<java.lang.String>>) strComparableNonePredicate12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableSet8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }
}

