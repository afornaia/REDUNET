import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest42.test43");
        org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>> charSequenceMapItorItor0 = new org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>();
        org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>> charSequenceMapItorItor1 = new org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>();
        java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>> mapItorItorSet2 = new java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>();
        boolean boolean3 = mapItorItorSet2.add(charSequenceMapItorItor0);
        boolean boolean4 = mapItorItorSet2.add(charSequenceMapItorItor1);
        org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>> mapItorItorSet5 = new org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>((java.util.Set<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>) mapItorItorSet2);
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape6 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter7 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape6);
        org.apache.commons.collections4.keyvalue.DefaultMapEntry<java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>, org.apache.commons.collections4.bloomfilter.BloomFilter> itorItorSetDefaultMapEntry8 = new org.apache.commons.collections4.keyvalue.DefaultMapEntry<java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>, org.apache.commons.collections4.bloomfilter.BloomFilter>(mapItorItorSet2, (org.apache.commons.collections4.bloomfilter.BloomFilter) bitSetBloomFilter7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }
}

