import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest26.test27");
        org.apache.commons.collections4.sequence.EditScript<java.util.AbstractSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>> multiValuedMapIterableGetSetEditScript0 = new org.apache.commons.collections4.sequence.EditScript<java.util.AbstractSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>>();
    }
}

