import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest35.test36");
        java.util.Map<java.lang.CharSequence, java.lang.Object> charSequenceMap0 = null;
        java.util.Map[] mapArray2 = new java.util.Map[1];
        @SuppressWarnings("unchecked")
        java.util.Map<java.lang.CharSequence, java.lang.Object>[] charSequenceMapArray3 = (java.util.Map<java.lang.CharSequence, java.lang.Object>[]) mapArray2;
        charSequenceMapArray3[0] = charSequenceMap0;
        org.apache.commons.collections4.map.CompositeMap.MapMutator<java.lang.CharSequence, java.lang.Object> charSequenceMapMutator6 = null;
        org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object> charSequenceMap7 = new org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object>(charSequenceMapArray3, charSequenceMapMutator6);
        boolean boolean8 = charSequenceMap7.isEmpty();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMapArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }
}

