import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest44.test45");
        java.util.Comparator<org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness> signednessComparator0 = org.apache.commons.collections4.ComparatorUtils.naturalComparator();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(signednessComparator0);
    }
}

