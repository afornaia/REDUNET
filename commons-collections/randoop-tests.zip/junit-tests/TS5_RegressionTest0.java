import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest0.test01");
        java.io.Serializable[] serializableArray29 = new java.io.Serializable[] { (byte) 0, 0, (short) 0, ' ', 100.0d, (-1.0d), 0.0d, (byte) 1, '#', 1L, (-1), (-1L), false, 0, (byte) 10, (short) 0, (-1.0f), "hi!", 100.0f, "", (short) 10, '4', (byte) -1, 10, (-1.0d), (byte) 0, (-1L), (short) 1, (-1.0d) };
        java.util.ArrayList<java.io.Serializable> serializableList30 = new java.util.ArrayList<java.io.Serializable>();
        boolean boolean31 = java.util.Collections.addAll((java.util.Collection<java.io.Serializable>) serializableList30, serializableArray29);
        // The following exception was thrown during execution in test generation
        try {
            java.util.Collection<java.io.Serializable> serializableCollection34 = org.apache.commons.collections4.CollectionUtils.removeRange((java.util.Collection<java.io.Serializable>) serializableList30, 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The end index can't be less than the start index.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableArray29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }
}

