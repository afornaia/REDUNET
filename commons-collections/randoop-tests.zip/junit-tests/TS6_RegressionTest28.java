import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest28.test29");
        org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap0 = new org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape1 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter2 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape1);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor3 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        boolean boolean4 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.io.Serializable>) serializableItor3);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor5 = abstractBloomFilterMap0.put((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) bitSetBloomFilter2, serializableItor3);
        org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap6 = new org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape7 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter8 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape7);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor9 = new org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>();
        boolean boolean10 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.io.Serializable>) serializableItor9);
        org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable> serializableItor11 = abstractBloomFilterMap6.put((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) bitSetBloomFilter8, serializableItor9);
        java.util.ArrayList<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>> abstractBloomFilterMapList12 = new java.util.ArrayList<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>>();
        boolean boolean13 = abstractBloomFilterMapList12.add(abstractBloomFilterMap0);
        boolean boolean14 = abstractBloomFilterMapList12.add(abstractBloomFilterMap6);
        org.apache.commons.collections4.iterators.ReverseListIterator<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>> abstractBloomFilterMapItor15 = new org.apache.commons.collections4.iterators.ReverseListIterator<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>>((java.util.List<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>>) abstractBloomFilterMapList12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableItor5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(serializableItor11);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }
}

