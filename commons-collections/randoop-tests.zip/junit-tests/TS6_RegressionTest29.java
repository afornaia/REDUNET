import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest29.test30");
        org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap0 = new org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>();
        org.apache.commons.collections4.OrderedMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> abstractBloomFilterMap1 = org.apache.commons.collections4.MapUtils.orderedMap((java.util.Map<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>) abstractBloomFilterMap0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(abstractBloomFilterMap1);
    }
}

