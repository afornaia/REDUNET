import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest41.test42");
        org.apache.commons.collections4.map.CaseInsensitiveMap<org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>, org.apache.commons.collections4.sequence.CommandVisitor<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> strComparableMapMap1 = new org.apache.commons.collections4.map.CaseInsensitiveMap<org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>, org.apache.commons.collections4.sequence.CommandVisitor<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>(5);
        org.apache.commons.collections4.map.CaseInsensitiveMap<org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>, org.apache.commons.collections4.sequence.CommandVisitor<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> strComparableMapMap2 = strComparableMapMap1.clone();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableMapMap2);
    }
}

