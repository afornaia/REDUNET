import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest9 {

    public static boolean debug = false;

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest9.test10");
        org.apache.commons.collections4.Closure<? super org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>> wildcardClosure0 = null;
        org.apache.commons.collections4.Closure[] closureArray2 = new org.apache.commons.collections4.Closure[1];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Closure<? super org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>[] wildcardClosureArray3 = (org.apache.commons.collections4.Closure<? super org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>[]) closureArray2;
        wildcardClosureArray3[0] = wildcardClosure0;
        org.apache.commons.collections4.functors.ChainedClosure<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>> serializableCollectionKeyValueChainedClosure6 = new org.apache.commons.collections4.functors.ChainedClosure<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>(wildcardClosureArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClosureArray3);
    }
}

