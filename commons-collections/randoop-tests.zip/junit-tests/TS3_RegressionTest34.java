import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest34.test35");
        org.apache.commons.collections4.comparators.BooleanComparator booleanComparator1 = new org.apache.commons.collections4.comparators.BooleanComparator(true);
        boolean boolean2 = booleanComparator1.sortsTrueFirst();
        java.lang.Class<?> wildcardClass3 = booleanComparator1.getClass();
        org.apache.commons.collections4.iterators.SingletonListIterator<java.lang.reflect.GenericDeclaration> genericDeclarationItor4 = new org.apache.commons.collections4.iterators.SingletonListIterator<java.lang.reflect.GenericDeclaration>((java.lang.reflect.GenericDeclaration) wildcardClass3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}

