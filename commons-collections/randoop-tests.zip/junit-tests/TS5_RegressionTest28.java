import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest28.test29");
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.iterators.EnumerationIterator<org.apache.commons.collections4.keyvalue.AbstractKeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>, java.util.AbstractCollection<java.io.Serializable>> collectionAbstractKeyValueItorConstantTimeToLiveExpirationPolicy1 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<org.apache.commons.collections4.iterators.EnumerationIterator<org.apache.commons.collections4.keyvalue.AbstractKeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>, java.util.AbstractCollection<java.io.Serializable>>((long) (byte) 1);
    }
}

