import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest47.test48");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = null;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = null;
        org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>, java.lang.reflect.GenericDeclaration> itorItorSetMap3 = new org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>, java.lang.reflect.GenericDeclaration>(referenceStrength0, referenceStrength1, true);
        itorItorSetMap3.clear();
        java.lang.reflect.GenericDeclaration genericDeclaration6 = itorItorSetMap3.remove((java.lang.Object) 16);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(genericDeclaration6);
    }
}

