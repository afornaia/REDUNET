import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest1.test02");
        java.lang.Iterable<org.apache.commons.collections4.multimap.AbstractMultiValuedMap<java.lang.CharSequence, java.lang.String>> charSequenceAbstractMultiValuedMapIterable0 = org.apache.commons.collections4.IterableUtils.emptyIterable();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceAbstractMultiValuedMapIterable0);
    }
}

