import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest54.test55");
        org.apache.commons.collections4.functors.ComparatorPredicate.Criterion criterion0 = org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER;
        org.junit.Assert.assertTrue("'" + criterion0 + "' != '" + org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER + "'", criterion0.equals(org.apache.commons.collections4.functors.ComparatorPredicate.Criterion.GREATER));
    }
}

