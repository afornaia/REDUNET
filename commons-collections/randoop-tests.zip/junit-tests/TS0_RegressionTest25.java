import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest25.test26");
        org.apache.commons.collections4.Predicate predicate0 = org.apache.commons.collections4.functors.ExceptionPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate1 = org.apache.commons.collections4.functors.ExceptionPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate2 = org.apache.commons.collections4.functors.ExceptionPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate3 = org.apache.commons.collections4.functors.ExceptionPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate[] predicateArray5 = new org.apache.commons.collections4.Predicate[4];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.String>[] wildcardPredicateArray6 = (org.apache.commons.collections4.Predicate<? super java.lang.String>[]) predicateArray5;
        wildcardPredicateArray6[0] = predicate0;
        wildcardPredicateArray6[1] = predicate1;
        wildcardPredicateArray6[2] = predicate2;
        wildcardPredicateArray6[3] = predicate3;
        org.apache.commons.collections4.functors.AllPredicate<java.lang.String> strAllPredicate15 = new org.apache.commons.collections4.functors.AllPredicate<java.lang.String>(wildcardPredicateArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray6);
    }
}

