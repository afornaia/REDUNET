import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest40.test41");
        java.lang.String str0 = org.apache.commons.collections4.bloomfilter.hasher.function.ObjectsHashIterative.NAME;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "Objects32" + "'", str0.equals("Objects32"));
    }
}

