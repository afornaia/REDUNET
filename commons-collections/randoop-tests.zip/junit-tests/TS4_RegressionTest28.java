import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest28 {

    public static boolean debug = false;

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest28.test29");
        org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior unknownObjectBehavior0 = org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.EXCEPTION;
        org.junit.Assert.assertTrue("'" + unknownObjectBehavior0 + "' != '" + org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.EXCEPTION + "'", unknownObjectBehavior0.equals(org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.EXCEPTION));
    }
}

