import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest18.test19");
        org.apache.commons.collections4.map.PassiveExpiringMap.ExpirationPolicy<org.apache.commons.collections4.Predicate<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.keyvalue.DefaultKeyValue<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> queueKeyValuePredicateExpirationPolicy0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.Predicate<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.keyvalue.DefaultKeyValue<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> queueKeyValuePredicateMap1 = new org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.Predicate<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.keyvalue.DefaultKeyValue<org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>>(queueKeyValuePredicateExpirationPolicy0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: expiringPolicy");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

