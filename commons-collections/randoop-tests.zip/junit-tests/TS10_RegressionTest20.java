import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest20.test21");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap1 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>> charSequenceMultiValuedMapItor2 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>) charSequenceArrayListValuedHashMap1);
        java.util.ArrayList<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>> charSequenceMultiValuedMapItorList3 = new java.util.ArrayList<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>();
        boolean boolean4 = charSequenceMultiValuedMapItorList3.add(charSequenceMultiValuedMapItor2);
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap6 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>> charSequenceMultiValuedMapItor7 = org.apache.commons.collections4.IteratorUtils.singletonListIterator((org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>) charSequenceArrayListValuedHashMap6);
        java.util.ArrayList<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>> charSequenceMultiValuedMapItorList8 = new java.util.ArrayList<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>();
        boolean boolean9 = charSequenceMultiValuedMapItorList8.add(charSequenceMultiValuedMapItor7);
        org.apache.commons.collections4.collection.CompositeCollection<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>> charSequenceMultiValuedMapItorCollection10 = new org.apache.commons.collections4.collection.CompositeCollection<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>((java.util.Collection<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>) charSequenceMultiValuedMapItorList3, (java.util.Collection<java.util.ListIterator<org.apache.commons.collections4.MultiValuedMap<java.lang.CharSequence, java.lang.String>>>) charSequenceMultiValuedMapItorList8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMultiValuedMapItor2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMultiValuedMapItor7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }
}

