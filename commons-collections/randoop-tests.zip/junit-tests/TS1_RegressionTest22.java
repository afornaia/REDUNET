import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest22.test23");
        java.lang.Class<?> wildcardClass1 = null;
        java.lang.Class[] classArray3 = new java.lang.Class[1];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray4 = (java.lang.Class<?>[]) classArray3;
        wildcardClassArray4[0] = wildcardClass1;
        org.apache.commons.collections4.Predicate[] predicateArray8 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>[] wildcardPredicateArray9 = (org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>[]) predicateArray8;
        org.apache.commons.collections4.functors.NonePredicate<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> stringKeyAnalyzerQueueKeyValueNonePredicate10 = new org.apache.commons.collections4.functors.NonePredicate<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>(wildcardPredicateArray9);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.Closure<org.apache.commons.collections4.collection.CompositeCollection<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListCollectionClosure11 = org.apache.commons.collections4.ClosureUtils.invokerClosure("", wildcardClassArray4, (java.lang.Object[]) wildcardPredicateArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The parameter types must match the arguments");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray9);
    }
}

