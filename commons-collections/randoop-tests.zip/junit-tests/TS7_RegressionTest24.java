import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest24.test25");
        java.util.Comparator<java.lang.Boolean> booleanComparator1 = org.apache.commons.collections4.ComparatorUtils.booleanComparator(false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(booleanComparator1);
    }
}

