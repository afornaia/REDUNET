import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest38.test39");
        org.apache.commons.collections4.map.ListOrderedMap<org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>> iterableGetSetListValuedMapMap0 = new org.apache.commons.collections4.map.ListOrderedMap<org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>();
    }
}

