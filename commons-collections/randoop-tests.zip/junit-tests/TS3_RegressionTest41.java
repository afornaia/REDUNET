import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest41.test42");
        org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>> charSequenceMapItorItor0 = new org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>();
        org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>> charSequenceMapItorItor1 = new org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>();
        java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>> mapItorItorSet2 = new java.util.LinkedHashSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>();
        boolean boolean3 = mapItorItorSet2.add(charSequenceMapItorItor0);
        boolean boolean4 = mapItorItorSet2.add(charSequenceMapItorItor1);
        org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>> mapItorItorSet5 = new org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>((java.util.Set<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>) mapItorItorSet2);
        java.lang.Iterable<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>> mapItorItorIterable7 = org.apache.commons.collections4.IterableUtils.skippingIterable((java.lang.Iterable<org.apache.commons.collections4.iterators.FilterListIterator<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>>>>) mapItorItorSet2, (long) ' ');
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapItorItorIterable7);
    }
}

