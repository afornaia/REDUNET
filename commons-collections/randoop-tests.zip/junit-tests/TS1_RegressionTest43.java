import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest43.test44");
        java.lang.Class<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> listMapItorClass0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.functors.InstantiateFactory<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>> listMapItorInstantiateFactory1 = new org.apache.commons.collections4.functors.InstantiateFactory<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>>(listMapItorClass0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

