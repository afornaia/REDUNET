import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest6.test07");
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy0 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy1 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy2 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy3 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy4 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>> objConstantTimeToLiveExpirationPolicyMultiKey5 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>>(objConstantTimeToLiveExpirationPolicy0, objConstantTimeToLiveExpirationPolicy1, objConstantTimeToLiveExpirationPolicy2, objConstantTimeToLiveExpirationPolicy3, objConstantTimeToLiveExpirationPolicy4);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy7 = objConstantTimeToLiveExpirationPolicyMultiKey5.getKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
    }
}

