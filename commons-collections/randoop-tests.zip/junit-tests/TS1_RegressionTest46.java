import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest46.test47");
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer> stringKeyAnalyzerQueue1 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>((int) (byte) 1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList3 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList5 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList7 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        java.util.List[] listArray9 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[] referenceStrengthListArray10 = (java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]) listArray9;
        referenceStrengthListArray10[0] = referenceStrengthList3;
        referenceStrengthListArray10[1] = referenceStrengthList5;
        referenceStrengthListArray10[2] = referenceStrengthList7;
        boolean boolean17 = org.apache.commons.collections4.CollectionUtils.containsAny((java.util.Collection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>) stringKeyAnalyzerQueue1, referenceStrengthListArray10);
        org.apache.commons.collections4.Transformer<org.apache.commons.collections4.map.AbstractHashedMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>, java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]> referenceStrengthListMapTransformer18 = org.apache.commons.collections4.TransformerUtils.constantTransformer(referenceStrengthListArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListMapTransformer18);
    }
}

