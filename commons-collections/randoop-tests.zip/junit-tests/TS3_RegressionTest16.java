import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest16.test17");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = null;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.ResettableListIterator, java.util.ListIterator<java.lang.String>> resettableListIteratorMap4 = new org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.ResettableListIterator, java.util.ListIterator<java.lang.String>>(referenceStrength0, referenceStrength1, (int) ' ', (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Load factor must be greater than 0");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

