import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest29.test30");
        org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.Get<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>, org.apache.commons.collections4.list.AbstractLinkedList<java.lang.Comparable<java.lang.String>>> propertyFormatEnumGetMap2 = new org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.Get<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>, org.apache.commons.collections4.list.AbstractLinkedList<java.lang.Comparable<java.lang.String>>>((int) (short) 100, false);
    }
}

