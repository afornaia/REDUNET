import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest31.test32");
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>> objMapConstantTimeToLiveExpirationPolicy0 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.multimap.AbstractMultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>();
    }
}

