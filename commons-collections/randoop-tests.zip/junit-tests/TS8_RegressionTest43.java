import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest43 {

    public static boolean debug = false;

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest43.test44");
        org.apache.commons.collections4.list.GrowthList<java.util.List<java.lang.Comparable<java.lang.String>>> strComparableListList1 = new org.apache.commons.collections4.list.GrowthList<java.util.List<java.lang.Comparable<java.lang.String>>>((int) ' ');
        boolean boolean3 = strComparableListList1.contains((java.lang.Object) 0.0d);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }
}

