import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest33.test34");
        org.apache.commons.collections4.Predicate<org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.multimap.ArrayListValuedHashMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>, java.util.Iterator>> listArrayListValuedHashMapMapPredicate1 = org.apache.commons.collections4.PredicateUtils.invokerPredicate("");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArrayListValuedHashMapMapPredicate1);
    }
}

