import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest46.test47");
        java.util.SortedSet sortedSet0 = org.apache.commons.collections4.SetUtils.EMPTY_SORTED_SET;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(sortedSet0);
    }
}

