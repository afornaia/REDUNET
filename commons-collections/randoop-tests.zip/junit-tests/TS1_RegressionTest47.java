import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest47 {

    public static boolean debug = false;

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest47.test48");
        org.apache.commons.collections4.sequence.EditScript<java.lang.String> strEditScript0 = new org.apache.commons.collections4.sequence.EditScript<java.lang.String>();
    }
}

