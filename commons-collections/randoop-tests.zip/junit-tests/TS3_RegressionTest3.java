import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest3.test04");
        org.apache.commons.collections4.map.PassiveExpiringMap.ExpirationPolicy<org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.Object>, org.apache.commons.collections4.comparators.BooleanComparator> charSequenceIterableGetExpirationPolicy0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.Object>, org.apache.commons.collections4.comparators.BooleanComparator> charSequenceIterableGetMap1 = new org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.Object>, org.apache.commons.collections4.comparators.BooleanComparator>(charSequenceIterableGetExpirationPolicy0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: expiringPolicy");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

