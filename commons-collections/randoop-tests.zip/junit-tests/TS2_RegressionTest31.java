import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest31.test32");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = null;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = null;
        org.apache.commons.collections4.map.ReferenceIdentityMap<org.apache.commons.collections4.OrderedIterator, java.lang.String> orderedIteratorMap2 = new org.apache.commons.collections4.map.ReferenceIdentityMap<org.apache.commons.collections4.OrderedIterator, java.lang.String>(referenceStrength0, referenceStrength1);
        org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.OrderedIterator, java.lang.String> orderedIteratorItor3 = orderedIteratorMap2.mapIterator();
        org.apache.commons.collections4.ResettableListIterator resettableListIterator4 = org.apache.commons.collections4.iterators.EmptyListIterator.RESETTABLE_INSTANCE;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.String str6 = orderedIteratorMap2.put((org.apache.commons.collections4.OrderedIterator) resettableListIterator4, "");
            org.junit.Assert.fail("Expected exception of type java.lang.Error; message: null");
        } catch (java.lang.Error e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(orderedIteratorItor3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(resettableListIterator4);
    }
}

