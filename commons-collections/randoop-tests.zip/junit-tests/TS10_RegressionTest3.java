import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest3.test04");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>> strComparableItor1 = new org.apache.commons.collections4.iterators.ObjectArrayListIterator<java.lang.Comparable<java.lang.String>>((java.lang.Comparable<java.lang.String>[]) strArray0);
        // The following exception was thrown during execution in test generation
        try {
            strComparableItor1.set((java.lang.Comparable<java.lang.String>) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: must call next() or previous() before a call to set()");
        } catch (java.lang.IllegalStateException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strArray0);
    }
}

