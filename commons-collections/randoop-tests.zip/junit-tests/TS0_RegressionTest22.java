import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest22 {

    public static boolean debug = false;

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest22.test23");
        org.apache.commons.collections4.iterators.IteratorChain<org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>> mapIterableAbstractKeyValueItor0 = new org.apache.commons.collections4.iterators.IteratorChain<org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>>();
    }
}

