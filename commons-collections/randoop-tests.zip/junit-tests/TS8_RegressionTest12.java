import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest12.test13");
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy0 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy1 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy2 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy3 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>> objConstantTimeToLiveExpirationPolicy4 = new org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>();
        org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>> objConstantTimeToLiveExpirationPolicyMultiKey5 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>>(objConstantTimeToLiveExpirationPolicy0, objConstantTimeToLiveExpirationPolicy1, objConstantTimeToLiveExpirationPolicy2, objConstantTimeToLiveExpirationPolicy3, objConstantTimeToLiveExpirationPolicy4);
        org.apache.commons.collections4.map.PassiveExpiringMap.ConstantTimeToLiveExpirationPolicy<java.lang.Object, java.util.Collection<java.lang.Comparable<java.lang.String>>>[] objConstantTimeToLiveExpirationPolicyArray6 = objConstantTimeToLiveExpirationPolicyMultiKey5.getKeys();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objConstantTimeToLiveExpirationPolicyArray6);
    }
}

