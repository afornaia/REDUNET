import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest1.test02");
        org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>[] serializableSetArray0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>> serializableSetMultiKey2 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>>(serializableSetArray0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: keys");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

