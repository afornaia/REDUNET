import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest29 {

    public static boolean debug = false;

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest29.test30");
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape0 = null;
        org.apache.commons.collections4.bloomfilter.HasherBloomFilter hasherBloomFilter1 = new org.apache.commons.collections4.bloomfilter.HasherBloomFilter(shape0);
        org.apache.commons.collections4.iterators.SingletonListIterator<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter> abstractBloomFilterItor2 = new org.apache.commons.collections4.iterators.SingletonListIterator<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter>((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) hasherBloomFilter1);
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape3 = null;
        org.apache.commons.collections4.bloomfilter.HasherBloomFilter hasherBloomFilter4 = new org.apache.commons.collections4.bloomfilter.HasherBloomFilter(shape3);
        org.apache.commons.collections4.iterators.SingletonListIterator<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter> abstractBloomFilterItor5 = new org.apache.commons.collections4.iterators.SingletonListIterator<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter>((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) hasherBloomFilter4);
        // The following exception was thrown during execution in test generation
        try {
            abstractBloomFilterItor2.add((org.apache.commons.collections4.bloomfilter.AbstractBloomFilter) hasherBloomFilter4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: add() is not supported by this iterator");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
    }
}

