import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest44.test45");
        org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>> serializableGetReverseComparator0 = new org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>();
        org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.IterableMap<java.io.Serializable, java.lang.Object>> serializableMapReverseComparator1 = new org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.IterableMap<java.io.Serializable, java.lang.Object>>((java.util.Comparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>) serializableGetReverseComparator0);
    }
}

