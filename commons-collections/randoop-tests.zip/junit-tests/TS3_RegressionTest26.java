import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest26.test27");
        org.apache.commons.collections4.iterators.TransformIterator<java.lang.CharSequence, java.util.Dictionary<java.lang.Object, java.lang.Object>> charSequenceItor0 = new org.apache.commons.collections4.iterators.TransformIterator<java.lang.CharSequence, java.util.Dictionary<java.lang.Object, java.lang.Object>>();
    }
}

