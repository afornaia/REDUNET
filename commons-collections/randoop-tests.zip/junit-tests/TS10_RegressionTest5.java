import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest5.test06");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap1 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        org.apache.commons.collections4.MultiSet<java.lang.CharSequence> charSequenceCollection2 = charSequenceArrayListValuedHashMap1.keys();
        org.apache.commons.collections4.multimap.AbstractListValuedMap<java.lang.CharSequence, java.lang.String> charSequenceAbstractListValuedMap3 = null;
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String> charSequenceArrayListValuedHashMap5 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<java.lang.CharSequence, java.lang.String>((int) (byte) -1);
        org.apache.commons.collections4.MultiSet<java.lang.CharSequence> charSequenceCollection6 = charSequenceArrayListValuedHashMap5.keys();
        org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.multimap.AbstractListValuedMap<java.lang.CharSequence, java.lang.String>> charSequenceAbstractListValuedMapMultiKey7 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.multimap.AbstractListValuedMap<java.lang.CharSequence, java.lang.String>>((org.apache.commons.collections4.multimap.AbstractListValuedMap<java.lang.CharSequence, java.lang.String>) charSequenceArrayListValuedHashMap1, charSequenceAbstractListValuedMap3, (org.apache.commons.collections4.multimap.AbstractListValuedMap<java.lang.CharSequence, java.lang.String>) charSequenceArrayListValuedHashMap5);
        charSequenceArrayListValuedHashMap1.trimToSize();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceCollection2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceCollection6);
    }
}

