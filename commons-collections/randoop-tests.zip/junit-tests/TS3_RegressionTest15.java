import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest15 {

    public static boolean debug = false;

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest15.test16");
        java.util.ListIterator<java.lang.String> strItor1 = org.apache.commons.collections4.IteratorUtils.singletonListIterator("hi!");
        java.util.ListIterator[] listIteratorArray3 = new java.util.ListIterator[1];
        @SuppressWarnings("unchecked")
        java.util.ListIterator<java.lang.String>[] strItorArray4 = (java.util.ListIterator<java.lang.String>[]) listIteratorArray3;
        strItorArray4[0] = strItor1;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.ResettableIterator<java.util.ListIterator<java.lang.String>> strItorItor9 = org.apache.commons.collections4.IteratorUtils.arrayIterator(strItorArray4, (int) (byte) 0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: End index must not be greater than the array length");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strItor1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listIteratorArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strItorArray4);
    }
}

