import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest33 {

    public static boolean debug = false;

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest33.test34");
        org.apache.commons.collections4.comparators.BooleanComparator booleanComparator2 = org.apache.commons.collections4.comparators.BooleanComparator.booleanComparator(false);
        org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.comparators.BooleanComparator> strComparableDefaultKeyValue3 = new org.apache.commons.collections4.keyvalue.DefaultKeyValue<java.lang.Comparable<java.lang.String>, org.apache.commons.collections4.comparators.BooleanComparator>((java.lang.Comparable<java.lang.String>) "", booleanComparator2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(booleanComparator2);
    }
}

