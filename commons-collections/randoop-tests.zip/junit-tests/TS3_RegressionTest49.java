import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest49.test50");
        org.apache.commons.collections4.properties.SortedProperties sortedProperties0 = new org.apache.commons.collections4.properties.SortedProperties();
        boolean boolean2 = sortedProperties0.containsKey((java.lang.Object) 100);
        java.util.Map<java.lang.CharSequence, java.lang.Object> charSequenceMap3 = null;
        java.util.Map[] mapArray5 = new java.util.Map[1];
        @SuppressWarnings("unchecked")
        java.util.Map<java.lang.CharSequence, java.lang.Object>[] charSequenceMapArray6 = (java.util.Map<java.lang.CharSequence, java.lang.Object>[]) mapArray5;
        charSequenceMapArray6[0] = charSequenceMap3;
        org.apache.commons.collections4.map.CompositeMap.MapMutator<java.lang.CharSequence, java.lang.Object> charSequenceMapMutator9 = null;
        org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object> charSequenceMap10 = new org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object>(charSequenceMapArray6, charSequenceMapMutator9);
        sortedProperties0.putAll((java.util.Map<java.lang.CharSequence, java.lang.Object>) charSequenceMap10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMapArray6);
    }
}

