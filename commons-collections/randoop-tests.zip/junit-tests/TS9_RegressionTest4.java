import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest4.test05");
        org.apache.commons.collections4.SortedBag<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder> builderCollection0 = org.apache.commons.collections4.BagUtils.emptySortedBag();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builderCollection0);
    }
}

