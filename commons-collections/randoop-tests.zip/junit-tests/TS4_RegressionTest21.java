import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest21.test22");
        org.apache.commons.collections4.Predicate<? super java.lang.String> wildcardPredicate0 = null;
        org.apache.commons.collections4.Predicate[] predicateArray2 = new org.apache.commons.collections4.Predicate[1];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.lang.String>[] wildcardPredicateArray3 = (org.apache.commons.collections4.Predicate<? super java.lang.String>[]) predicateArray2;
        wildcardPredicateArray3[0] = wildcardPredicate0;
        org.apache.commons.collections4.Closure[] closureArray7 = new org.apache.commons.collections4.Closure[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Closure<? super java.lang.String>[] wildcardClosureArray8 = (org.apache.commons.collections4.Closure<? super java.lang.String>[]) closureArray7;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.Closure<java.lang.String> strClosure9 = org.apache.commons.collections4.ClosureUtils.switchClosure(wildcardPredicateArray3, (org.apache.commons.collections4.Closure<? super java.lang.String>[]) closureArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: predicates[0]");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closureArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClosureArray8);
    }
}

