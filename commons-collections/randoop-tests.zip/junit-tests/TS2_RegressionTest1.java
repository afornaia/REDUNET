import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest1.test02");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.CaseInsensitiveMap<java.lang.Comparable<java.lang.String>, java.io.Serializable> strComparableMap2 = new org.apache.commons.collections4.map.CaseInsensitiveMap<java.lang.Comparable<java.lang.String>, java.io.Serializable>((-1), 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Initial capacity must be a non negative number");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

