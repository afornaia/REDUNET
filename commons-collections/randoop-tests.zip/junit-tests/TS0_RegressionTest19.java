import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest19.test20");
        java.util.Iterator[] iteratorArray1 = new java.util.Iterator[0];
        @SuppressWarnings("unchecked")
        java.util.Iterator<? extends org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>>[] wildcardItorArray2 = (java.util.Iterator<? extends org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>>[]) iteratorArray1;
        org.apache.commons.collections4.iterators.IteratorChain<org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>> mapIterableAbstractKeyValueItor3 = new org.apache.commons.collections4.iterators.IteratorChain<org.apache.commons.collections4.keyvalue.AbstractKeyValue<java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>>>(wildcardItorArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iteratorArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardItorArray2);
    }
}

