import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest14.test15");
        org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetCollection0 = org.apache.commons.collections4.MultiSetUtils.emptyMultiSet();
        java.util.List<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>> wildcardMultiKeyIterableGetList1 = org.apache.commons.collections4.IterableUtils.toList((java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection0);
        org.apache.commons.collections4.Factory<org.apache.commons.collections4.MultiSet<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> wildcardMultiKeyIterableGetCollectionFactory2 = org.apache.commons.collections4.FactoryUtils.prototypeFactory(wildcardMultiKeyIterableGetCollection0);
        java.lang.String str3 = org.apache.commons.collections4.IterableUtils.toString((java.lang.Iterable<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>) wildcardMultiKeyIterableGetCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetList1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardMultiKeyIterableGetCollectionFactory2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[]" + "'", str3.equals("[]"));
    }
}

