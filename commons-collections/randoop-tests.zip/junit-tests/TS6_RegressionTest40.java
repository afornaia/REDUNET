import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest40.test41");
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>>> abstractBloomFilterMapItorQueue0 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.OrderedIterator<org.apache.commons.collections4.map.StaticBucketMap<org.apache.commons.collections4.bloomfilter.AbstractBloomFilter, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>>>();
        int int1 = abstractBloomFilterMapItorQueue0.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }
}

