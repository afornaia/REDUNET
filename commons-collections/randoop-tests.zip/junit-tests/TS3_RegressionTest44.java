import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest44 {

    public static boolean debug = false;

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest44.test45");
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript0 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript1 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript2 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>> charSequencePutEditScript3 = new org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>();
        org.apache.commons.collections4.sequence.EditScript[] editScriptArray5 = new org.apache.commons.collections4.sequence.EditScript[4];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[] charSequencePutEditScriptArray6 = (org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>[]) editScriptArray5;
        charSequencePutEditScriptArray6[0] = charSequencePutEditScript0;
        charSequencePutEditScriptArray6[1] = charSequencePutEditScript1;
        charSequencePutEditScriptArray6[2] = charSequencePutEditScript2;
        charSequencePutEditScriptArray6[3] = charSequencePutEditScript3;
        org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>> charSequencePutEditScriptMultiKey16 = new org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.sequence.EditScript<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.Object>>>(charSequencePutEditScriptArray6, true);
        java.lang.String str17 = charSequencePutEditScriptMultiKey16.toString();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(editScriptArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequencePutEditScriptArray6);
    }
}

