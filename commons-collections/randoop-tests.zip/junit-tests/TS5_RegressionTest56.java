import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest56.test57");
        org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object> serializableMap1 = new org.apache.commons.collections4.map.StaticBucketMap<java.io.Serializable, java.lang.Object>(10);
        org.apache.commons.collections4.Predicate predicate2 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate3 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate4 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate5 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate6 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate predicate7 = org.apache.commons.collections4.functors.NullPredicate.INSTANCE;
        org.apache.commons.collections4.Predicate[] predicateArray9 = new org.apache.commons.collections4.Predicate[6];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super java.util.Set<java.io.Serializable>>[] wildcardPredicateArray10 = (org.apache.commons.collections4.Predicate<? super java.util.Set<java.io.Serializable>>[]) predicateArray9;
        wildcardPredicateArray10[0] = predicate2;
        wildcardPredicateArray10[1] = predicate3;
        wildcardPredicateArray10[2] = predicate4;
        wildcardPredicateArray10[3] = predicate5;
        wildcardPredicateArray10[4] = predicate6;
        wildcardPredicateArray10[5] = predicate7;
        org.apache.commons.collections4.functors.NonePredicate<java.util.Set<java.io.Serializable>> serializableSetNonePredicate23 = new org.apache.commons.collections4.functors.NonePredicate<java.util.Set<java.io.Serializable>>(wildcardPredicateArray10);
        java.lang.Boolean boolean24 = org.apache.commons.collections4.MapUtils.getBoolean((java.util.Map<java.io.Serializable, java.lang.Object>) serializableMap1, serializableSetNonePredicate23);
        org.apache.commons.collections4.Predicate<? super java.util.Set<java.io.Serializable>>[] wildcardPredicateArray25 = serializableSetNonePredicate23.getPredicates();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicate7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray9);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray10);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(boolean24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray25);
    }
}

