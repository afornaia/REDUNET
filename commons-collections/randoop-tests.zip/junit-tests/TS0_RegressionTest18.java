import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest18 {

    public static boolean debug = false;

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest18.test19");
        org.apache.commons.collections4.multimap.ArrayListValuedHashMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>> charSequenceMapListArrayListValuedHashMap0 = new org.apache.commons.collections4.multimap.ArrayListValuedHashMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>();
        java.util.Map<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, java.util.Collection<org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>> charSequenceMapListMap1 = charSequenceMapListArrayListValuedHashMap0.asMap();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMapListMap1);
    }
}

