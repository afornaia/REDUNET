import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest34 {

    public static boolean debug = false;

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest34.test35");
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap0 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap2 = referenceStrengthListMap0.remove((java.lang.Object) (short) 10);
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer> stringKeyAnalyzerQueue4 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>((int) (byte) 1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList6 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList8 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList10 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        java.util.List[] listArray12 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[] referenceStrengthListArray13 = (java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]) listArray12;
        referenceStrengthListArray13[0] = referenceStrengthList6;
        referenceStrengthListArray13[1] = referenceStrengthList8;
        referenceStrengthListArray13[2] = referenceStrengthList10;
        boolean boolean20 = org.apache.commons.collections4.CollectionUtils.containsAny((java.util.Collection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>) stringKeyAnalyzerQueue4, referenceStrengthListArray13);
        boolean boolean21 = referenceStrengthListMap0.equals((java.lang.Object) boolean20);
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap22 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap24 = referenceStrengthListMap22.remove((java.lang.Object) (short) 10);
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer> stringKeyAnalyzerQueue26 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>((int) (byte) 1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList28 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList30 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList32 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        java.util.List[] listArray34 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[] referenceStrengthListArray35 = (java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]) listArray34;
        referenceStrengthListArray35[0] = referenceStrengthList28;
        referenceStrengthListArray35[1] = referenceStrengthList30;
        referenceStrengthListArray35[2] = referenceStrengthList32;
        boolean boolean42 = org.apache.commons.collections4.CollectionUtils.containsAny((java.util.Collection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>) stringKeyAnalyzerQueue26, referenceStrengthListArray35);
        boolean boolean43 = referenceStrengthListMap22.equals((java.lang.Object) boolean42);
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap44 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap45 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap46 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> stringKeyAnalyzerQueueMap48 = referenceStrengthListMap46.remove((java.lang.Object) (short) 10);
        org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer> stringKeyAnalyzerQueue50 = new org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>((int) (byte) 1);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList52 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList54 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList56 = new org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>((int) (short) 10);
        java.util.List[] listArray58 = new java.util.List[3];
        @SuppressWarnings("unchecked")
        java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[] referenceStrengthListArray59 = (java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>[]) listArray58;
        referenceStrengthListArray59[0] = referenceStrengthList52;
        referenceStrengthListArray59[1] = referenceStrengthList54;
        referenceStrengthListArray59[2] = referenceStrengthList56;
        boolean boolean66 = org.apache.commons.collections4.CollectionUtils.containsAny((java.util.Collection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>) stringKeyAnalyzerQueue50, referenceStrengthListArray59);
        boolean boolean67 = referenceStrengthListMap46.equals((java.lang.Object) boolean66);
        org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior unknownObjectBehavior68 = org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER;
        boolean boolean69 = referenceStrengthListMap46.containsValue((java.lang.Object) unknownObjectBehavior68);
        java.util.ArrayList<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>> referenceStrengthListMapList70 = new java.util.ArrayList<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>();
        boolean boolean71 = referenceStrengthListMapList70.add(referenceStrengthListMap0);
        boolean boolean72 = referenceStrengthListMapList70.add(referenceStrengthListMap22);
        boolean boolean73 = referenceStrengthListMapList70.add(referenceStrengthListMap44);
        boolean boolean74 = referenceStrengthListMapList70.add(referenceStrengthListMap45);
        boolean boolean75 = referenceStrengthListMapList70.add(referenceStrengthListMap46);
        org.apache.commons.collections4.iterators.ReverseListIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>> referenceStrengthListMapItor76 = new org.apache.commons.collections4.iterators.ReverseListIterator<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>((java.util.List<org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>>) referenceStrengthListMapList70);
        org.apache.commons.collections4.Factory<org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>> referenceStrengthListFactory77 = null;
        org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<java.lang.Cloneable, org.apache.commons.collections4.Factory<org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> cloneableUnmodifiableMapEntry78 = new org.apache.commons.collections4.keyvalue.UnmodifiableMapEntry<java.lang.Cloneable, org.apache.commons.collections4.Factory<org.apache.commons.collections4.list.NodeCachingLinkedList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>((java.lang.Cloneable) referenceStrengthListMapList70, referenceStrengthListFactory77);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(stringKeyAnalyzerQueueMap2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListArray13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(stringKeyAnalyzerQueueMap24);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListArray35);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(stringKeyAnalyzerQueueMap48);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(listArray58);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthListArray59);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + unknownObjectBehavior68 + "' != '" + org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER + "'", unknownObjectBehavior68.equals(org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }
}

