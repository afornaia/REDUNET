import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest10.test11");
        org.apache.commons.collections4.list.GrowthList<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>> charSequenceMapList0 = new org.apache.commons.collections4.list.GrowthList<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>();
        java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>> charSequenceMapIterable1 = org.apache.commons.collections4.IterableUtils.unmodifiableIterable((java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>) charSequenceMapList0);
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Iterable<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>> charSequenceMapIterable3 = org.apache.commons.collections4.IterableUtils.boundedIterable(charSequenceMapIterable1, (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MaxSize parameter must not be negative.");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMapIterable1);
    }
}

