import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest25 {

    public static boolean debug = false;

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest25.test26");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.list.AbstractListDecorator<java.util.List<java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<java.util.List<java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.map.ReferenceIdentityMap<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>>> comparableListListMap4 = new org.apache.commons.collections4.map.LRUMap<org.apache.commons.collections4.list.AbstractListDecorator<java.util.List<java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<java.util.List<java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.map.ReferenceIdentityMap<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>>>((int) ' ', (int) (byte) -1, (float) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Initial capacity must be a non negative number");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

