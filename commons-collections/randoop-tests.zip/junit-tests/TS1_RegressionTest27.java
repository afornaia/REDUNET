import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest27 {

    public static boolean debug = false;

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest27.test28");
        org.apache.commons.collections4.MultiSet<java.util.Iterator<java.lang.Iterable<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>>> stringKeyAnalyzerIterableItorCollection0 = org.apache.commons.collections4.MultiSetUtils.emptyMultiSet();
        org.apache.commons.collections4.MultiSet<java.util.Iterator<java.lang.Iterable<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>>> stringKeyAnalyzerIterableItorCollection1 = org.apache.commons.collections4.MultiSetUtils.synchronizedMultiSet(stringKeyAnalyzerIterableItorCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringKeyAnalyzerIterableItorCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringKeyAnalyzerIterableItorCollection1);
    }
}

