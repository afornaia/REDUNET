import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest39.test40");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.OrderedIterator, java.lang.String>, org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.AbstractHashedMap<org.apache.commons.collections4.OrderedIterator, java.lang.String>>> orderedIteratorIterableGetMap5 = new org.apache.commons.collections4.map.ReferenceMap<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.OrderedIterator, java.lang.String>, org.apache.commons.collections4.keyvalue.MultiKey<org.apache.commons.collections4.map.AbstractHashedMap<org.apache.commons.collections4.OrderedIterator, java.lang.String>>>(referenceStrength0, referenceStrength1, (int) (byte) 10, (float) (short) 0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Load factor must be greater than 0");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + referenceStrength0 + "' != '" + org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT + "'", referenceStrength0.equals(org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT));
        org.junit.Assert.assertTrue("'" + referenceStrength1 + "' != '" + org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT + "'", referenceStrength1.equals(org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.SOFT));
    }
}

