import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest32.test33");
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList0 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj3 = objList0.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList4 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj7 = objList4.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList8 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList0, (java.util.List<java.lang.Object>) objList4);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList10 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj13 = objList10.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList14 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj17 = objList14.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList18 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList10, (java.util.List<java.lang.Object>) objList14);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList19 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object[] objArray20 = objList19.toArray();
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape23 = null;
        org.apache.commons.collections4.bloomfilter.BitSetBloomFilter bitSetBloomFilter24 = new org.apache.commons.collections4.bloomfilter.BitSetBloomFilter(shape23);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList26 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj29 = objList26.set((int) '4', (java.lang.Object) (-1L));
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList30 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object obj33 = objList30.set((int) '4', (java.lang.Object) (-1L));
        java.util.List<java.lang.Object> objList34 = org.apache.commons.collections4.ListUtils.defaultIfNull((java.util.List<java.lang.Object>) objList26, (java.util.List<java.lang.Object>) objList30);
        org.apache.commons.collections4.comparators.ComparableComparator comparableComparator40 = org.apache.commons.collections4.comparators.ComparableComparator.INSTANCE;
        org.apache.commons.collections4.comparators.BooleanComparator booleanComparator42 = org.apache.commons.collections4.comparators.BooleanComparator.booleanComparator(false);
        java.lang.Object[] objArray43 = new java.lang.Object[] { (short) 1, objList10, objList19, true, (-1L), shape23, (byte) 1, objList26, 100L, (byte) 100, (byte) 1, (byte) 1, (short) 0, comparableComparator40, false };
        java.util.ArrayList<java.lang.Object> objList44 = new java.util.ArrayList<java.lang.Object>();
        boolean boolean45 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) objList44, objArray43);
        boolean boolean46 = objList4.removeAll((java.util.Collection<java.lang.Object>) objList44);
        boolean boolean48 = objList44.contains((java.lang.Object) 10.0d);
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList49 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object[] objArray50 = objList49.toArray();
        boolean boolean51 = objList44.addAll((java.util.Collection<java.lang.Object>) objList49);
        java.lang.String str52 = org.apache.commons.collections4.IterableUtils.toString((java.lang.Iterable<java.lang.Object>) objList44);
        boolean boolean54 = objList44.contains((java.lang.Object) 10.0f);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList8);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj13);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj17);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList18);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray20);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj29);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(obj33);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objList34);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(comparableComparator40);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(booleanComparator42);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray43);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray50);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }
}

