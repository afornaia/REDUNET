import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest2.test03");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.WEAK;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength[] referenceStrengthArray1 = new org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength[] { referenceStrength0 };
        java.util.ArrayList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList2 = new java.util.ArrayList<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>();
        boolean boolean3 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>) referenceStrengthList2, referenceStrengthArray1);
        java.util.function.UnaryOperator<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthUnaryOperator4 = null;
        // The following exception was thrown during execution in test generation
        try {
            referenceStrengthList2.replaceAll(referenceStrengthUnaryOperator4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + referenceStrength0 + "' != '" + org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.WEAK + "'", referenceStrength0.equals(org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength.WEAK));
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(referenceStrengthArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }
}

