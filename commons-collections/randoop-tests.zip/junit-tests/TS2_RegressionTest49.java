import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest49 {

    public static boolean debug = false;

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest49.test50");
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape0 = null;
        org.apache.commons.collections4.bloomfilter.HasherBloomFilter hasherBloomFilter1 = new org.apache.commons.collections4.bloomfilter.HasherBloomFilter(shape0);
        org.apache.commons.collections4.bloomfilter.hasher.Shape shape2 = null;
        org.apache.commons.collections4.bloomfilter.HasherBloomFilter hasherBloomFilter3 = new org.apache.commons.collections4.bloomfilter.HasherBloomFilter(shape2);
        // The following exception was thrown during execution in test generation
        try {
            long long4 = org.apache.commons.collections4.bloomfilter.SetOperations.estimateUnionSize((org.apache.commons.collections4.bloomfilter.BloomFilter) hasherBloomFilter1, (org.apache.commons.collections4.bloomfilter.BloomFilter) hasherBloomFilter3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

