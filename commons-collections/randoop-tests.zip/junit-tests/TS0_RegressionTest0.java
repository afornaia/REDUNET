import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest0.test01");
        java.lang.Iterable<? extends java.lang.String> wildcardIterable0 = null;
        java.lang.Iterable[] iterableArray2 = new java.lang.Iterable[1];
        @SuppressWarnings("unchecked")
        java.lang.Iterable<? extends java.lang.String>[] wildcardIterableArray3 = (java.lang.Iterable<? extends java.lang.String>[]) iterableArray2;
        wildcardIterableArray3[0] = wildcardIterable0;
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Iterable<java.lang.String> strIterable6 = org.apache.commons.collections4.IterableUtils.chainedIterable(wildcardIterableArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: iterable");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterableArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardIterableArray3);
    }
}

