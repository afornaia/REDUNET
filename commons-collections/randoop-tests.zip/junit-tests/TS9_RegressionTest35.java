import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest35.test36");
        org.apache.commons.collections4.bloomfilter.hasher.HashFunction hashFunction0 = null;
        org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder builder1 = new org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder(hashFunction0);
        org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder builder3 = builder1.with((byte) 0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builder3);
    }
}

