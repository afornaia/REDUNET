import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest26.test27");
        org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String> charSequenceMap0 = new org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>();
        org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.String> charSequenceMap1 = org.apache.commons.collections4.MapUtils.iterableMap((java.util.Map<java.lang.CharSequence, java.lang.String>) charSequenceMap0);
        java.util.Properties properties2 = org.apache.commons.collections4.MapUtils.toProperties((java.util.Map<java.lang.CharSequence, java.lang.String>) charSequenceMap0);
        org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String> charSequenceMap3 = new org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>();
        org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.String> charSequenceMap4 = org.apache.commons.collections4.MapUtils.iterableMap((java.util.Map<java.lang.CharSequence, java.lang.String>) charSequenceMap3);
        boolean boolean5 = properties2.equals((java.lang.Object) charSequenceMap3);
        org.apache.commons.collections4.Predicate<org.apache.commons.collections4.keyvalue.MultiKey<java.lang.String>> strMultiKeyPredicate6 = org.apache.commons.collections4.PredicateUtils.notNullPredicate();
        boolean boolean7 = properties2.containsValue((java.lang.Object) strMultiKeyPredicate6);
        java.io.Reader reader8 = null;
        // The following exception was thrown during execution in test generation
        try {
            properties2.load(reader8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMap1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(properties2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMap4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strMultiKeyPredicate6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }
}

