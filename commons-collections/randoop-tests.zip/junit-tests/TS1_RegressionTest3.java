import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest3.test04");
        org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>> referenceStrengthListMap0 = new org.apache.commons.collections4.map.LRUMap<java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>, org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.queue.CircularFifoQueue<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>, java.lang.Enum<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength>>>();
        // The following exception was thrown during execution in test generation
        try {
            java.util.List<org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength> referenceStrengthList1 = referenceStrengthListMap0.lastKey();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException; message: Map is empty");
        } catch (java.util.NoSuchElementException e) {
        // Expected exception.
        }
    }
}

