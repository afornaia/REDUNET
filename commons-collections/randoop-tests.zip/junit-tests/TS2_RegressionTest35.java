import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest35.test36");
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength0 = null;
        org.apache.commons.collections4.map.AbstractReferenceMap.ReferenceStrength referenceStrength1 = null;
        org.apache.commons.collections4.map.ReferenceIdentityMap<org.apache.commons.collections4.OrderedIterator, java.lang.String> orderedIteratorMap2 = new org.apache.commons.collections4.map.ReferenceIdentityMap<org.apache.commons.collections4.OrderedIterator, java.lang.String>(referenceStrength0, referenceStrength1);
        java.util.ListIterator<org.apache.commons.collections4.map.ReferenceIdentityMap<org.apache.commons.collections4.OrderedIterator, java.lang.String>> orderedIteratorMapItor3 = org.apache.commons.collections4.IteratorUtils.singletonListIterator(orderedIteratorMap2);
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.OrderedIterator, java.lang.String> orderedIteratorMap4 = org.apache.commons.collections4.MapUtils.fixedSizeMap((java.util.Map<org.apache.commons.collections4.OrderedIterator, java.lang.String>) orderedIteratorMap2);
        int int5 = orderedIteratorMap2.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(orderedIteratorMapItor3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(orderedIteratorMap4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }
}

