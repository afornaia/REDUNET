import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest2.test03");
        org.apache.commons.collections4.OrderedMapIterator<org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> serializableItorItor0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.AbstractOrderedMapIteratorDecorator<org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>> serializableItorItor1 = new org.apache.commons.collections4.iterators.AbstractOrderedMapIteratorDecorator<org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>, org.apache.commons.collections4.iterators.IteratorChain<java.io.Serializable>>(serializableItorItor0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: iterator");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

