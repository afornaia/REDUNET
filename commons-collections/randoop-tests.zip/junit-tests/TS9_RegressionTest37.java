import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest37.test38");
        java.util.Map<org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>> iterableGetSetListValuedMapMap0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.splitmap.AbstractIterableGetMapDecorator<org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>> iterableGetSetListValuedMapAbstractIterableGetMapDecorator1 = new org.apache.commons.collections4.splitmap.AbstractIterableGetMapDecorator<org.apache.commons.collections4.ListValuedMap<org.apache.commons.collections4.SetUtils.SetView<org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>, org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.bloomfilter.hasher.Hasher.Builder>>, org.apache.commons.collections4.IterableGet<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>>(iterableGetSetListValuedMapMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: map");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

