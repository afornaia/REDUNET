import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest3.test04");
        java.lang.Object[] objArray5 = new java.lang.Object[] { true, (-1.0d), 100, (-1), '#' };
        org.apache.commons.collections4.ResettableIterator<java.lang.Object> objItor6 = org.apache.commons.collections4.IteratorUtils.arrayIterator(objArray5);
        org.apache.commons.collections4.ResettableIterator<org.apache.commons.collections4.ResettableIterator<java.lang.Object>> objItorItor7 = org.apache.commons.collections4.IteratorUtils.singletonIterator(objItor6);
        boolean boolean8 = org.apache.commons.collections4.IteratorUtils.isEmpty((java.util.Iterator<java.lang.Object>) objItor6);
        java.lang.String str9 = org.apache.commons.collections4.IteratorUtils.toString((java.util.Iterator<java.lang.Object>) objItor6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objItor6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objItorItor7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[true, -1.0, 100, -1, #]" + "'", str9.equals("[true, -1.0, 100, -1, #]"));
    }
}

