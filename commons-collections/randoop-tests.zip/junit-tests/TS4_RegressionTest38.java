import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest38.test39");
        java.util.Comparator<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparator0 = null;
        org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparatorChain2 = new org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>(comparableMapSpliteratorComparator0, false);
        org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>> comparableMapSpliteratorComparatorChain3 = new org.apache.commons.collections4.comparators.ComparatorChain<java.util.Spliterator<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>>(comparableMapSpliteratorComparator0);
        boolean boolean4 = comparableMapSpliteratorComparatorChain3.isLocked();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }
}

