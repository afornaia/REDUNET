import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest40 {

    public static boolean debug = false;

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest40.test41");
        org.apache.commons.collections4.comparators.BooleanComparator booleanComparator1 = new org.apache.commons.collections4.comparators.BooleanComparator(true);
        boolean boolean2 = booleanComparator1.sortsTrueFirst();
        java.util.Comparator<java.lang.Boolean> booleanComparator3 = org.apache.commons.collections4.ComparatorUtils.nullLowComparator((java.util.Comparator<java.lang.Boolean>) booleanComparator1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(booleanComparator3);
    }
}

