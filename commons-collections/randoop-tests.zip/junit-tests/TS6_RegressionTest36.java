import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest36.test37");
        org.apache.commons.collections4.map.ReferenceIdentityMap<java.lang.Enum<org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>, java.util.RandomAccess> processTypeEnumMap0 = new org.apache.commons.collections4.map.ReferenceIdentityMap<java.lang.Enum<org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>, java.util.RandomAccess>();
    }
}

