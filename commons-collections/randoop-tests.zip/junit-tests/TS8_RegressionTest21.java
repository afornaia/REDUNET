import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest21.test22");
        org.apache.commons.collections4.Predicate[] predicateArray1 = new org.apache.commons.collections4.Predicate[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.MapIterator>[] wildcardPredicateArray2 = (org.apache.commons.collections4.Predicate<? super org.apache.commons.collections4.MapIterator>[]) predicateArray1;
        org.apache.commons.collections4.functors.AllPredicate<org.apache.commons.collections4.MapIterator> mapIteratorAllPredicate3 = new org.apache.commons.collections4.functors.AllPredicate<org.apache.commons.collections4.MapIterator>(wildcardPredicateArray2);
        org.apache.commons.collections4.iterators.SingletonIterator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.MapIterator>> mapIteratorPredicateDecoratorItor5 = new org.apache.commons.collections4.iterators.SingletonIterator<org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.MapIterator>>((org.apache.commons.collections4.functors.PredicateDecorator<org.apache.commons.collections4.MapIterator>) mapIteratorAllPredicate3, false);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(predicateArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardPredicateArray2);
    }
}

