import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest24.test25");
        java.io.PrintStream printStream0 = null;
        org.apache.commons.collections4.map.LinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>> strComparableItorMap4 = new org.apache.commons.collections4.map.LinkedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>((int) '#', (float) (short) 100);
        org.apache.commons.collections4.IterableMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>> strComparableItorMap5 = org.apache.commons.collections4.MapUtils.fixedSizeMap((java.util.Map<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>) strComparableItorMap4);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.MapUtils.debugPrint(printStream0, (java.lang.Object) (-1.0f), (java.util.Map<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>) strComparableItorMap5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableItorMap5);
    }
}

