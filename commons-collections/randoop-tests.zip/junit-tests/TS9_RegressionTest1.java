import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest1.test02");
        org.apache.commons.collections4.map.PassiveExpiringMap.ExpirationPolicy<org.apache.commons.collections4.map.AbstractHashedMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.String>> strMultiValuedMapMapExpirationPolicy0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.map.AbstractHashedMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.String>> strMultiValuedMapMapMap1 = new org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.map.AbstractHashedMap<org.apache.commons.collections4.MultiValuedMap<java.lang.String, java.io.Serializable>, java.lang.Comparable<java.lang.String>>, java.util.Collection<java.lang.String>>(strMultiValuedMapMapExpirationPolicy0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: expiringPolicy");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

