import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest5 {

    public static boolean debug = false;

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest5.test06");
        org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior unknownObjectBehavior0 = org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER;
        org.junit.Assert.assertTrue("'" + unknownObjectBehavior0 + "' != '" + org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER + "'", unknownObjectBehavior0.equals(org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior.AFTER));
    }
}

