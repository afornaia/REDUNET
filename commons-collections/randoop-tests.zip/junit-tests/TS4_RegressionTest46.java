import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest46.test47");
        org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior, java.lang.Enum<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>> unknownObjectBehaviorItor0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.AbstractMapIteratorDecorator<org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior, java.lang.Enum<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>> unknownObjectBehaviorItor1 = new org.apache.commons.collections4.iterators.AbstractMapIteratorDecorator<org.apache.commons.collections4.comparators.FixedOrderComparator.UnknownObjectBehavior, java.lang.Enum<org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>>(unknownObjectBehaviorItor0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: iterator");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

