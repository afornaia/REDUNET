import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest37 {

    public static boolean debug = false;

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest37.test38");
        org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness signedness0 = org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED;
        org.junit.Assert.assertTrue("'" + signedness0 + "' != '" + org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED + "'", signedness0.equals(org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.Signedness.SIGNED));
    }
}

