import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest41 {

    public static boolean debug = false;

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest41.test42");
        java.lang.CharSequence charSequence0 = null;
        org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType processType1 = org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE;
        org.apache.commons.collections4.keyvalue.DefaultMapEntry<java.lang.CharSequence, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType> charSequenceDefaultMapEntry2 = new org.apache.commons.collections4.keyvalue.DefaultMapEntry<java.lang.CharSequence, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>(charSequence0, processType1);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.Factory<org.apache.commons.collections4.keyvalue.DefaultMapEntry<java.lang.CharSequence, org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType>> charSequenceDefaultMapEntryFactory3 = org.apache.commons.collections4.FactoryUtils.prototypeFactory(charSequenceDefaultMapEntry2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The prototype must be cloneable via a public clone method");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        org.junit.Assert.assertTrue("'" + processType1 + "' != '" + org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE + "'", processType1.equals(org.apache.commons.collections4.bloomfilter.hasher.HashFunctionIdentity.ProcessType.ITERATIVE));
    }
}

