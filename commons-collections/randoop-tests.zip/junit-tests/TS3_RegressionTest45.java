import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest45 {

    public static boolean debug = false;

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest45.test46");
        org.apache.commons.collections4.Transformer<java.util.Hashtable<java.lang.Object, java.lang.Object>, org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>> objMapTransformer0 = org.apache.commons.collections4.TransformerUtils.exceptionTransformer();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objMapTransformer0);
    }
}

