import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS2_RegressionTest10 {

    public static boolean debug = false;

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS2_RegressionTest10.test11");
        org.apache.commons.collections4.Bag<java.lang.Comparable<java.lang.String>> strComparableCollection0 = org.apache.commons.collections4.BagUtils.emptyBag();
        org.apache.commons.collections4.Bag<java.lang.Comparable<java.lang.String>> strComparableCollection1 = org.apache.commons.collections4.BagUtils.emptyBag();
        java.lang.Iterable<java.lang.Comparable<java.lang.String>> strComparableIterable3 = org.apache.commons.collections4.IterableUtils.skippingIterable((java.lang.Iterable<java.lang.Comparable<java.lang.String>>) strComparableCollection1, (long) 10);
        // The following exception was thrown during execution in test generation
        try {
            boolean boolean4 = org.apache.commons.collections4.CollectionUtils.addAll((java.util.Collection<java.lang.Comparable<java.lang.String>>) strComparableCollection0, (java.lang.Iterable<java.lang.Comparable<java.lang.String>>) strComparableCollection1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableCollection0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableCollection1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableIterable3);
    }
}

