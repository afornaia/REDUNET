import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest54 {

    public static boolean debug = false;

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest54.test55");
        org.apache.commons.collections4.map.CaseInsensitiveMap<java.lang.reflect.Type, org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>> typeMap1 = new org.apache.commons.collections4.map.CaseInsensitiveMap<java.lang.reflect.Type, org.apache.commons.collections4.set.ListOrderedSet<java.io.Serializable>>(0);
    }
}

