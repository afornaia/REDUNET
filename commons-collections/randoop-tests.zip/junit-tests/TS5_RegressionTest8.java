import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest8 {

    public static boolean debug = false;

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest8.test09");
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.LRUMap<java.lang.String, org.apache.commons.collections4.IterableGet<java.io.Serializable, java.lang.Object>> strMap3 = new org.apache.commons.collections4.map.LRUMap<java.lang.String, org.apache.commons.collections4.IterableGet<java.io.Serializable, java.lang.Object>>(0, 0.0f, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Load factor must be greater than 0");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
    }
}

