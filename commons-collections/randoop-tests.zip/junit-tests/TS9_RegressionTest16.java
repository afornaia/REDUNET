import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest16 {

    public static boolean debug = false;

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest16.test17");
        java.lang.Class<?> wildcardClass0 = null;
        java.lang.Class[] classArray2 = new java.lang.Class[1];
        @SuppressWarnings("unchecked")
        java.lang.Class<?>[] wildcardClassArray3 = (java.lang.Class<?>[]) classArray2;
        wildcardClassArray3[0] = wildcardClass0;
        org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder[] builderArray6 = new org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder[] {};
        org.apache.commons.collections4.comparators.FixedOrderComparator<org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder> builderFixedOrderComparator7 = new org.apache.commons.collections4.comparators.FixedOrderComparator<org.apache.commons.collections4.bloomfilter.hasher.DynamicHasher.Builder>(builderArray6);
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.Transformer<java.lang.Class<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, org.apache.commons.collections4.functors.ComparatorPredicate.Criterion> wildcardClassTransformer8 = org.apache.commons.collections4.TransformerUtils.instantiateTransformer(wildcardClassArray3, (java.lang.Object[]) builderArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Parameter types must match the arguments");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(classArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClassArray3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(builderArray6);
    }
}

