import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest21 {

    public static boolean debug = false;

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest21.test22");
        org.apache.commons.collections4.map.MultiValueMap<org.apache.commons.collections4.SetValuedMap<java.lang.CharSequence, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>, java.lang.String> charSequenceSetValuedMapMap0 = new org.apache.commons.collections4.map.MultiValueMap<org.apache.commons.collections4.SetValuedMap<java.lang.CharSequence, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>, java.lang.String>();
    }
}

