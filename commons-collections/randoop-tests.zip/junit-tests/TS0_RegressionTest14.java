import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest14 {

    public static boolean debug = false;

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest14.test15");
        org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.String>, org.apache.commons.collections4.MultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>> charSequencePutMap0 = new org.apache.commons.collections4.map.PassiveExpiringMap<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.String>, org.apache.commons.collections4.MultiValuedMap<org.apache.commons.collections4.list.AbstractSerializableListDecorator<org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.String>>, org.apache.commons.collections4.IterableGet<java.lang.CharSequence, java.lang.String>>>();
    }
}

