import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS7_RegressionTest17 {

    public static boolean debug = false;

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS7_RegressionTest17.test18");
        org.apache.commons.collections4.iterators.CollatingIterator<org.apache.commons.collections4.multimap.AbstractSetValuedMap<java.lang.CharSequence, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>> charSequenceAbstractSetValuedMapItor0 = new org.apache.commons.collections4.iterators.CollatingIterator<org.apache.commons.collections4.multimap.AbstractSetValuedMap<java.lang.CharSequence, org.apache.commons.collections4.map.AbstractIterableMap<org.apache.commons.collections4.keyvalue.MultiKey<? extends org.apache.commons.collections4.functors.ComparatorPredicate.Criterion>, java.lang.Object>>>();
    }
}

