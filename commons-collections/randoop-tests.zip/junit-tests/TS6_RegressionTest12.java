import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest12.test13");
        org.apache.commons.collections4.list.GrowthList<java.lang.Object> objList0 = new org.apache.commons.collections4.list.GrowthList<java.lang.Object>();
        java.lang.Object[] objArray1 = objList0.toArray();
        // The following exception was thrown during execution in test generation
        try {
            java.lang.Object obj2 = org.apache.commons.collections4.CollectionUtils.extractSingleton((java.util.Collection<java.lang.Object>) objList0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Can extract singleton only when collection size == 1");
        } catch (java.lang.IllegalArgumentException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objArray1);
    }
}

