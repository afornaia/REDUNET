import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS1_RegressionTest30 {

    public static boolean debug = false;

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS1_RegressionTest30.test31");
        java.util.AbstractCollection[] abstractCollectionArray1 = new java.util.AbstractCollection[0];
        @SuppressWarnings("unchecked")
        java.util.AbstractCollection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>[] stringKeyAnalyzerCollectionArray2 = (java.util.AbstractCollection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>[]) abstractCollectionArray1;
        org.apache.commons.collections4.keyvalue.MultiKey<java.util.AbstractCollection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>> stringKeyAnalyzerCollectionMultiKey4 = new org.apache.commons.collections4.keyvalue.MultiKey<java.util.AbstractCollection<org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer>>(stringKeyAnalyzerCollectionArray2, false);
        int int5 = stringKeyAnalyzerCollectionMultiKey4.size();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(abstractCollectionArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(stringKeyAnalyzerCollectionArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }
}

