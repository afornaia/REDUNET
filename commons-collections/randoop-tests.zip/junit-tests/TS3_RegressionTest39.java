import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest39 {

    public static boolean debug = false;

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest39.test40");
        java.util.Comparator<java.lang.Boolean> booleanComparator2 = null;
        java.lang.Boolean boolean3 = org.apache.commons.collections4.ComparatorUtils.min((java.lang.Boolean) false, (java.lang.Boolean) true, booleanComparator2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3.equals(false));
    }
}

