import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest26 {

    public static boolean debug = false;

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest26.test27");
        org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.iterators.ObjectArrayIterator<org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>>, org.apache.commons.collections4.IterableMap<java.io.Serializable, java.lang.Object>> getReverseComparatorItorKeyValue0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.map.SingletonMap<org.apache.commons.collections4.iterators.ObjectArrayIterator<org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>>, org.apache.commons.collections4.IterableMap<java.io.Serializable, java.lang.Object>> getReverseComparatorItorMap1 = new org.apache.commons.collections4.map.SingletonMap<org.apache.commons.collections4.iterators.ObjectArrayIterator<org.apache.commons.collections4.comparators.ReverseComparator<org.apache.commons.collections4.Get<java.io.Serializable, java.lang.Object>>>, org.apache.commons.collections4.IterableMap<java.io.Serializable, java.lang.Object>>(getReverseComparatorItorKeyValue0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

