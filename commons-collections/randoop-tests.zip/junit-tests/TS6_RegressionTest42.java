import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest42 {

    public static boolean debug = false;

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest42.test43");
        java.util.Set<org.apache.commons.collections4.Factory<java.lang.Iterable<java.lang.Object>>> objIterableFactorySet0 = org.apache.commons.collections4.SetUtils.emptySet();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(objIterableFactorySet0);
    }
}

