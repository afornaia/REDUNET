import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS9_RegressionTest6 {

    public static boolean debug = false;

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS9_RegressionTest6.test07");
        org.apache.commons.collections4.ResettableIterator resettableIterator0 = org.apache.commons.collections4.iterators.EmptyIterator.RESETTABLE_INSTANCE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(resettableIterator0);
    }
}

