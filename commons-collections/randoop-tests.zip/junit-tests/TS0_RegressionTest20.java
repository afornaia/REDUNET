import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS0_RegressionTest20 {

    public static boolean debug = false;

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS0_RegressionTest20.test21");
        org.apache.commons.collections4.Closure[] closureArray1 = new org.apache.commons.collections4.Closure[0];
        @SuppressWarnings("unchecked")
        org.apache.commons.collections4.Closure<? super org.apache.commons.collections4.map.PassiveExpiringMap<java.util.RandomAccess, org.apache.commons.collections4.Predicate<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.String>>>>[] wildcardClosureArray2 = (org.apache.commons.collections4.Closure<? super org.apache.commons.collections4.map.PassiveExpiringMap<java.util.RandomAccess, org.apache.commons.collections4.Predicate<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.String>>>>[]) closureArray1;
        org.apache.commons.collections4.Closure<org.apache.commons.collections4.map.PassiveExpiringMap<java.util.RandomAccess, org.apache.commons.collections4.Predicate<org.apache.commons.collections4.Put<java.lang.CharSequence, java.lang.String>>>> randomAccessMapClosure3 = org.apache.commons.collections4.ClosureUtils.chainedClosure(wildcardClosureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closureArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClosureArray2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(randomAccessMapClosure3);
    }
}

