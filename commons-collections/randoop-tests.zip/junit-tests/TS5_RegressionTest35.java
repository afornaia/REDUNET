import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest35 {

    public static boolean debug = false;

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest35.test36");
        org.apache.commons.collections4.Predicate<org.apache.commons.collections4.set.AbstractSerializableSetDecorator<java.io.Serializable>> serializableSetPredicate0 = org.apache.commons.collections4.PredicateUtils.falsePredicate();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableSetPredicate0);
    }
}

