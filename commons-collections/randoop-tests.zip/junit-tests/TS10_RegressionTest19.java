import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS10_RegressionTest19 {

    public static boolean debug = false;

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS10_RegressionTest19.test20");
        org.apache.commons.collections4.Transformer<org.apache.commons.collections4.iterators.ObjectArrayIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.OrderedMap<org.apache.commons.collections4.ResettableIterator<java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.Predicate<java.lang.String>>> strComparableItorTransformer0 = org.apache.commons.collections4.TransformerUtils.nullTransformer();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(strComparableItorTransformer0);
    }
}

