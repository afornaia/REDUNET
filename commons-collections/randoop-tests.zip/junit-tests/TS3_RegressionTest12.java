import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest12 {

    public static boolean debug = false;

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest12.test13");
        java.util.Map<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, java.io.Serializable> charSequenceMapItorMap0 = null;
        // The following exception was thrown during execution in test generation
        try {
            org.apache.commons.collections4.iterators.EntrySetMapIterator<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, java.io.Serializable> charSequenceMapItorItor1 = new org.apache.commons.collections4.iterators.EntrySetMapIterator<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, java.io.Serializable>(charSequenceMapItorMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        // Expected exception.
        }
    }
}

