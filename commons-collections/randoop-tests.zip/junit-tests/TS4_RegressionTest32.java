import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest32 {

    public static boolean debug = false;

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest32.test33");
        org.apache.commons.collections4.sequence.ReplacementsHandler<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableGetReplacementsHandler0 = null;
        org.apache.commons.collections4.sequence.ReplacementsFinder<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableGetReplacementsFinder1 = new org.apache.commons.collections4.sequence.ReplacementsFinder<org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>(strComparableGetReplacementsHandler0);
        org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence> strComparableMap4 = new org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>((java.lang.Comparable<java.lang.String>) "hi!", (java.lang.CharSequence) "hi!");
        strComparableGetReplacementsFinder1.visitKeepCommand((org.apache.commons.collections4.Get<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap4);
        java.util.Map<java.lang.CharSequence, java.lang.Comparable<java.lang.String>> charSequenceMap6 = org.apache.commons.collections4.MapUtils.invertMap((java.util.Map<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(charSequenceMap6);
    }
}

