import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS4_RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS4_RegressionTest0.test01");
        org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence> strComparableMap2 = new org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>((java.lang.Comparable<java.lang.String>) "hi!", (java.lang.CharSequence) "hi!");
        java.util.ArrayList<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableMapList3 = new java.util.ArrayList<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>();
        boolean boolean4 = strComparableMapList3.add((org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap2);
        org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence> strComparableMap7 = new org.apache.commons.collections4.map.SingletonMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>((java.lang.Comparable<java.lang.String>) "hi!", (java.lang.CharSequence) "hi!");
        java.util.LinkedHashSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableMapSet8 = new java.util.LinkedHashSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>();
        boolean boolean9 = strComparableMapSet8.add((org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>) strComparableMap7);
        org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>> strComparableMapSet10 = new org.apache.commons.collections4.set.CompositeSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>((java.util.Set<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>) strComparableMapSet8);
        java.util.HashSet[] hashSetArray12 = new java.util.HashSet[1];
        @SuppressWarnings("unchecked")
        java.util.HashSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>[] comparableMapSetArray13 = (java.util.HashSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>[]) hashSetArray12;
        comparableMapSetArray13[0] = strComparableMapSet8;
        // The following exception was thrown during execution in test generation
        try {
            java.util.HashSet<org.apache.commons.collections4.BoundedMap<java.lang.Comparable<java.lang.String>, java.lang.CharSequence>>[] comparableMapSetArray16 = strComparableMapList3.toArray(comparableMapSetArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException; message: null");
        } catch (java.lang.ArrayStoreException e) {
        // Expected exception.
        }
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(hashSetArray12);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(comparableMapSetArray13);
    }
}

