import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS8_RegressionTest13 {

    public static boolean debug = false;

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS8_RegressionTest13.test14");
        org.apache.commons.collections4.iterators.FilterIterator<org.apache.commons.collections4.map.AbstractReferenceMap<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>> propertyFormatEnumMapItor0 = new org.apache.commons.collections4.iterators.FilterIterator<org.apache.commons.collections4.map.AbstractReferenceMap<java.lang.Enum<org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>, java.util.RandomAccess>>();
    }
}

