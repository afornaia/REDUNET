import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS5_RegressionTest24 {

    public static boolean debug = false;

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS5_RegressionTest24.test25");
        java.util.Iterator iterator0 = org.apache.commons.collections4.iterators.EmptyIterator.INSTANCE;
        java.util.Iterator iterator1 = org.apache.commons.collections4.iterators.EmptyIterator.INSTANCE;
        java.util.Iterator iterator2 = org.apache.commons.collections4.iterators.EmptyIterator.INSTANCE;
        java.util.Iterator iterator3 = org.apache.commons.collections4.iterators.EmptyIterator.INSTANCE;
        java.util.Iterator iterator4 = org.apache.commons.collections4.iterators.EmptyIterator.INSTANCE;
        java.util.Iterator[] iteratorArray6 = new java.util.Iterator[5];
        @SuppressWarnings("unchecked")
        java.util.Iterator<? extends org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>[] wildcardItorArray7 = (java.util.Iterator<? extends org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>>[]) iteratorArray6;
        wildcardItorArray7[0] = iterator0;
        wildcardItorArray7[1] = iterator1;
        wildcardItorArray7[2] = iterator2;
        wildcardItorArray7[3] = iterator3;
        wildcardItorArray7[4] = iterator4;
        java.util.Iterator<org.apache.commons.collections4.KeyValue<org.apache.commons.collections4.collection.AbstractCollectionDecorator<java.io.Serializable>, java.lang.reflect.AnnotatedElement>> serializableCollectionKeyValueItor18 = org.apache.commons.collections4.IteratorUtils.chainedIterator(wildcardItorArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterator0);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterator1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterator2);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterator3);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iterator4);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(iteratorArray6);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardItorArray7);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(serializableCollectionKeyValueItor18);
    }
}

