import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS6_RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS6_RegressionTest3.test04");
        org.apache.commons.collections4.Closure closure0 = org.apache.commons.collections4.functors.ExceptionClosure.INSTANCE;
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(closure0);
    }
}

