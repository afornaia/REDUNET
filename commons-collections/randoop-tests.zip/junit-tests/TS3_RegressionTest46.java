import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TS3_RegressionTest46 {

    public static boolean debug = false;

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "TS3_RegressionTest46.test47");
        java.util.Map[] mapArray1 = new java.util.Map[0];
        @SuppressWarnings("unchecked")
        java.util.Map<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>[] mapItorMapArray2 = (java.util.Map<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>[]) mapArray1;
        org.apache.commons.collections4.map.CompositeMap.MapMutator<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat> charSequenceMapItorMapMutator3 = null;
        org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat> charSequenceMapItorMap4 = new org.apache.commons.collections4.map.CompositeMap<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>((java.util.Map<org.apache.commons.collections4.MapIterator<org.apache.commons.collections4.IterableMap<java.lang.CharSequence, java.lang.Object>, java.lang.Comparable<java.lang.String>>, org.apache.commons.collections4.properties.AbstractPropertiesFactory.PropertyFormat>[]) mapArray1, charSequenceMapItorMapMutator3);
        org.apache.commons.collections4.map.CompositeMap.MapMutator<java.lang.CharSequence, java.lang.Object> charSequenceMapMutator5 = null;
        org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object> charSequenceMap6 = new org.apache.commons.collections4.map.CompositeMap<java.lang.CharSequence, java.lang.Object>((java.util.Map<java.lang.CharSequence, java.lang.Object>[]) mapArray1, charSequenceMapMutator5);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapArray1);
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(mapItorMapArray2);
    }
}

