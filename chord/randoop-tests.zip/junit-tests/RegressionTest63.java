import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest63 {

    public static boolean debug = false;

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest63.test64");
        java.net.InetSocketAddress inetSocketAddress0 = null;
        java.lang.String str2 = chord_package.Helper.sendRequest(inetSocketAddress0, "ffffffa6");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(str2);
    }
}

