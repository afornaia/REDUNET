import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest52 {

    public static boolean debug = false;

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest52.test53");
        // The following exception was thrown during execution in test generation
        try {
            chord_package.RealQuery.computeQuery("00000005", "0000000a", false);
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"0000000a\"");
        } catch (java.lang.NumberFormatException e) {
        // Expected exception.
        }
    }
}

