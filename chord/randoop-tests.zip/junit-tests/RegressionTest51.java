import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest51 {

    public static boolean debug = false;

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest51.test52");
        chord_package.Logger logger1 = new chord_package.Logger("hi!");
        logger1.closeFile();
        logger1.closeFile();
        logger1.writeLog("");
    }
}

