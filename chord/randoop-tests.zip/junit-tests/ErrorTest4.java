import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest4 {

    public static boolean debug = false;

    @Test
    public void test5() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest4.test5");
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        long long2 = chord_package.Helper.getIthStart((long) '#', (int) (short) 100);
    }
}

