import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest74 {

    public static boolean debug = false;

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest74.test75");
        chord_package.Peer peer0 = null;
        chord_package.Stabilize stabilize1 = new chord_package.Stabilize(peer0);
        stabilize1.toDie();
        stabilize1.run();
    }
}

