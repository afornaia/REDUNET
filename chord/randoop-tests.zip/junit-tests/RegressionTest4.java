import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test05");
        // The following exception was thrown during execution in test generation
        try {
            chord_package.ProxyQuery.computeQuery("hi!", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: System.exit(1)");
        } catch (java.lang.RuntimeException e) {
        // Expected exception.
        }
    }
}

