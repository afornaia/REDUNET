import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest7 {

    public static boolean debug = false;

    @Test
    public void test8() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest7.test8");
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        long long1 = chord_package.Helper.getPowerOfTwo((int) (byte) 100);
    }
}

