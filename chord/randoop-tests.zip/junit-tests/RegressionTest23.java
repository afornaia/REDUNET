import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest23 {

    public static boolean debug = false;

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest23.test24");
        // The following exception was thrown during execution in test generation
        try {
            chord_package.RealQuery.computeQuery("hi!", "hi!", false);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: System.exit(1)");
        } catch (java.lang.RuntimeException e) {
        // Expected exception.
        }
    }
}

