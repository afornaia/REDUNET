import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest58 {

    public static boolean debug = false;

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest58.test59");
        long long2 = 0L; // flaky: chord_package.Helper.getIthStart(10L, (int) (byte) 10);
        // Regression assertion (captures the current behavior of the code)
// flaky:         org.junit.Assert.assertTrue("'" + long2 + "' != '" + 522L + "'", long2 == 522L);
    }
}
