import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest5 {

    public static boolean debug = false;

    @Test
    public void test6() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest5.test6");
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        long long1 = chord_package.Helper.getPowerOfTwo((int) (short) 100);
    }
}

