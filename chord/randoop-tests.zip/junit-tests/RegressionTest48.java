import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest48 {

    public static boolean debug = false;

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest48.test49");
        chord_package.Logger logger1 = new chord_package.Logger("hi!");
        logger1.closeFile();
        logger1.closeFile();
        logger1.writeLog("ffffffa6");
    }
}

