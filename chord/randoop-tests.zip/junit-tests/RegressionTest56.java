import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest56 {

    public static boolean debug = false;

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest56.test57");
        // The following exception was thrown during execution in test generation
        try {
            chord_package.ProxyQuery.computeQuery("00000023", "");
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: System.exit(1)");
        } catch (java.lang.RuntimeException e) {
        // Expected exception.
        }
    }
}

