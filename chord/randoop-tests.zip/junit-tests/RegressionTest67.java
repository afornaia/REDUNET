import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest67 {

    public static boolean debug = false;

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest67.test68");
        chord_package.Peer peer0 = null;
        chord_package.FixFingers fixFingers1 = new chord_package.FixFingers(peer0);
        fixFingers1.toDie();
        fixFingers1.run();
        fixFingers1.run();
        java.lang.Class<?> wildcardClass5 = fixFingers1.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass5);
    }
}

