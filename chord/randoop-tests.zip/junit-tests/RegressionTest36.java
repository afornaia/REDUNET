import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest36 {

    public static boolean debug = false;

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest36.test37");
        java.net.InetSocketAddress inetSocketAddress1 = chord_package.Helper.createSocketAddress("hi!");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(inetSocketAddress1);
    }
}

