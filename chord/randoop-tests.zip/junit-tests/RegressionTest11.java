import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest11 {

    public static boolean debug = false;

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest11.test12");
        chord_package.Peer peer0 = null;
        chord_package.FixFingers fixFingers1 = new chord_package.FixFingers(peer0);
        fixFingers1.toDie();
        java.lang.Class<?> wildcardClass3 = fixFingers1.getClass();
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNotNull(wildcardClass3);
    }
}

