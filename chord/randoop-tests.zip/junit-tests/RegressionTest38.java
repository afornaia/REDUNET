import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest38 {

    public static boolean debug = false;

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest38.test39");
        java.net.InetSocketAddress inetSocketAddress1 = chord_package.Helper.createSocketAddress("00000020");
        // Regression assertion (captures the current behavior of the code)
        org.junit.Assert.assertNull(inetSocketAddress1);
    }
}

