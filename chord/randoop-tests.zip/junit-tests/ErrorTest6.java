import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest6 {

    public static boolean debug = false;

    @Test
    public void test7() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest6.test7");
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        long long2 = chord_package.Helper.getIthStart(2893617912L, (int) (short) 0);
    }
}

