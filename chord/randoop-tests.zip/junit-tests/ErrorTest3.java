import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ErrorTest3 {

    public static boolean debug = false;

    @Test
    public void test4() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "ErrorTest3.test4");
        // during test generation this statement threw an exception of type java.lang.NullPointerException in error
        long long2 = chord_package.Helper.getIthStart((long) (short) 100, (int) '4');
    }
}

