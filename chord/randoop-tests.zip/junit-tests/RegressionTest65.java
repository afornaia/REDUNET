import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest65 {

    public static boolean debug = false;

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest65.test66");
        chord_package.Peer peer0 = null;
        chord_package.AskPredecessor askPredecessor1 = new chord_package.AskPredecessor(peer0);
        askPredecessor1.toDie();
        askPredecessor1.toDie();
    }
}

