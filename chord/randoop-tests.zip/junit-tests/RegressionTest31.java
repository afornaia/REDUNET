import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest31 {

    public static boolean debug = false;

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest31.test32");
        chord_package.Peer peer0 = null;
        chord_package.FixFingers fixFingers1 = new chord_package.FixFingers(peer0);
        fixFingers1.toDie();
        fixFingers1.run();
        fixFingers1.toDie();
        fixFingers1.toDie();
        fixFingers1.toDie();
        fixFingers1.toDie();
    }
}

